import os,re,json,requests,time,sys
from pathlib import Path
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright

BASE='http://127.0.0.1:8000'
OUT=Path('/mnt/data/ERP_V10_PAGE_SCREENSHOTS')
OUT.mkdir(exist_ok=True)
s=requests.Session()
r=s.post(BASE+'/login',data={'username':'admin','password':'Admin12345678!'},allow_redirects=False,timeout=10)
print('login',r.status_code)
headers={'X-Company-ID':'1','X-Branch-ID':'1'}
paths=[]
openapi=requests.get(BASE+'/openapi.json',timeout=10).json()
for path,ops in openapi['paths'].items():
    if '{' not in path and 'get' in ops:
        paths.append(path)
# add health and common root already present

def safe_name(path):
    x=path.strip('/').replace('/','__') or 'home'
    x=re.sub(r'[^A-Za-z0-9_.-]+','_',x)
    return x[:150]

def inline_html(html):
    soup=BeautifulSoup(html,'html.parser')
    # Inline CSS so Chromium can render without network navigation.
    for link in list(soup.find_all('link',href=True)):
        href=link.get('href','')
        if href.startswith('/static/'):
            try:
                rr=requests.get(BASE+href,timeout=8)
                if rr.ok:
                    st=soup.new_tag('style'); st.string=rr.text; link.replace_with(st)
            except Exception: pass
    for script in list(soup.find_all('script',src=True)):
        src=script.get('src','')
        if src.startswith('/static/'):
            try:
                rr=requests.get(BASE+src,timeout=8)
                if rr.ok:
                    ns=soup.new_tag('script'); ns.string=rr.text; script.replace_with(ns)
            except Exception: pass
    # Prevent external navigation during screenshot.
    for tag in soup.find_all(['img','script','link']):
        if tag.name=='img' and tag.get('src','').startswith('/static/'):
            tag['src']=BASE+tag['src']
    return str(soup)

results=[]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':1000}, device_scale_factor=1)
    for i,path in enumerate(paths,1):
        try:
            resp=s.get(BASE+path,headers=headers,timeout=15,allow_redirects=True)
            ctype=resp.headers.get('content-type','')
            if resp.status_code==200 and 'text/html' in ctype:
                html=inline_html(resp.text)
                page.set_content(html,wait_until='load',timeout=20000)
                # Let layout/fonts settle.
                page.wait_for_timeout(250)
                fn=f'{i:03d}_{safe_name(path)}.png'
                page.screenshot(path=str(OUT/fn),full_page=True)
                results.append((path,'captured',fn,resp.url))
                print('CAPTURED',path,fn)
            else:
                results.append((path,f'skip {resp.status_code} {ctype.split(";")[0]}','',resp.url))
                print('SKIP',path,resp.status_code,ctype)
        except Exception as e:
            results.append((path,'error '+str(e)[:160],'',''))
            print('ERROR',path,e)
    browser.close()

# report
lines=['# ERP V10 Page Screenshot Capture','',f'Captured: {sum(1 for x in results if x[1]=="captured")}',f'Total literal GET routes inspected: {len(results)}','', '| Path | Result | File |','|---|---|---|']
for path,status,fn,url in results:
    lines.append(f'| `{path}` | {status} | `{fn}` |')
(OUT/'SCREENSHOT_CAPTURE_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
print('DONE',sum(1 for x in results if x[1]=='captured'))
