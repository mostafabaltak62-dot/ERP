import re,json,requests
from pathlib import Path
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:8000'; OUT=Path('/mnt/data/ERP_V10_PAGE_SCREENSHOTS'); OUT.mkdir(exist_ok=True)
openapi=requests.get(BASE+'/openapi.json',timeout=10).json()
paths=[p for p,o in openapi['paths'].items() if '{' not in p and 'get' in o and p not in ['/logout']]
# prioritize UI pages before APIs
paths.sort(key=lambda p: (0 if not p.startswith('/api/') else 1,p))
s=requests.Session(); headers={'X-Company-ID':'1','X-Branch-ID':'1'}
def login():
 s.cookies.clear(); s.post(BASE+'/login',data={'username':'admin','password':'Admin12345678!'},allow_redirects=False,timeout=10)
login()
def safe(p): return re.sub(r'[^A-Za-z0-9_.-]+','_',p.strip('/').replace('/','__') or 'home')[:120]
def inline_css(html):
 soup=BeautifulSoup(html,'html.parser')
 for link in list(soup.find_all('link',href=True)):
  href=link.get('href','')
  if href.startswith('/static/'):
   try:
    rr=requests.get(BASE+href,timeout=5)
    if rr.ok:
     st=soup.new_tag('style'); st.string=rr.text; link.replace_with(st)
   except: pass
 return str(soup)
results=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
 context=browser.new_context(viewport={'width':1440,'height':1000},java_script_enabled=False)
 page=context.new_page()
 for i,path in enumerate(paths,1):
  try:
   if path=='/logout': login()
   r=s.get(BASE+path,headers=headers,timeout=8,allow_redirects=False)
   if r.status_code in (301,302,303,307,308) and r.headers.get('location','').startswith('/login'):
    login(); r=s.get(BASE+path,headers=headers,timeout=8,allow_redirects=True)
   ct=r.headers.get('content-type','')
   if r.status_code==200 and 'text/html' in ct:
    page.set_content(inline_css(r.text),wait_until='domcontentloaded',timeout=5000)
    page.screenshot(path=str(OUT/f'{i:03d}_{safe(path)}.png'),full_page=True,timeout=10000)
    results.append((path,'captured',f'{i:03d}_{safe(path)}.png'))
    print('OK',path,flush=True)
   else:
    results.append((path,f'skip {r.status_code} {ct.split(";")[0]}',''))
    print('SKIP',path,r.status_code,flush=True)
  except Exception as e:
   results.append((path,'error '+str(e)[:100],'')); print('ERR',path,e,flush=True)
 browser.close()
lines=['# Screenshot Capture Report','',f'Captured {sum(x[1]=="captured" for x in results)} HTML pages from {len(results)} literal GET routes.','', '|Path|Result|File|','|---|---|---|']
for a,b,c in results: lines.append(f'|`{a}`|{b}|`{c}`|')
(OUT/'SCREENSHOT_CAPTURE_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
