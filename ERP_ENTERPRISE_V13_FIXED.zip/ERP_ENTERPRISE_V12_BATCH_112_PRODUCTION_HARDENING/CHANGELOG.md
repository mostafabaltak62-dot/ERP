# Changelog

## V13.1
- Fix: `logger` was defined inside a docstring in `security_hardening.py` (NameError when Redis failed).
- Security: placeholder detection now rejects `GENERATE...`, `USER:PASSWORD@HOST`; `.env.example` uses `CHANGE_ME` values.
- Fix: `.env` is now loaded into the process environment (bootstrap admin, CSRF flags) and by Alembic.
- Local launchers (`RUN_LOCAL_WINDOWS.bat`, `run_local.sh`) generate a safe development `.env`.
- `pytest` moved to `requirements-dev.txt`; Docker runs multiple workers (`WEB_CONCURRENCY`).
- README rewritten; historical BATCH/PHASE reports moved to `docs/archive/`.
