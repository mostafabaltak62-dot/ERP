from decimal import Decimal
from datetime import datetime, date
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, Account, AccountTypeEnum, JournalEntry, JournalLine
from app.enterprise_models import Company
from app.reporting import trial_balance, pnl, balance_sheet, general_ledger
from app.accounting import create_entry
from app.governance import set_request_context, clear_request_context

def setup():
    e=create_engine("sqlite:///:memory:")
    Base.metadata.create_all(e)
    S=sessionmaker(bind=e); db=S(); c=Company(code="R59",name="Report Co"); db.add(c); db.flush()
    cash=Account(company_id=c.id,code="1000",name="Cash",account_type=AccountTypeEnum.asset,is_active=True)
    sales=Account(company_id=c.id,code="4000",name="Sales",account_type=AccountTypeEnum.revenue,is_active=True)
    expense=Account(company_id=c.id,code="6000",name="Expense",account_type=AccountTypeEnum.expense,is_active=True)
    payable=Account(company_id=c.id,code="2000",name="Payable",account_type=AccountTypeEnum.liability,is_active=True)
    db.add_all([cash,sales,expense,payable]); db.flush()
    return db,c,cash,sales,expense,payable

def post(db,c,e_num,dt,lines):
    pairs=[]
    for a,d,cr in lines: pairs.append((a.code,d,cr))
    set_request_context(request_id="test",user_id=1,company_id=c.id,branch_id=None,ip_address=None)
    create_entry(db,e_num,1,pairs,source_type="test_report",source_id=abs(hash((e_num,c.id))) % 100000000,entry_date=dt)
    db.commit()
    clear_request_context()

def test_authoritative_reports_reconcile():
    db,c,cash,sales,expense,payable=setup()
    post(db,c,"J1",datetime(2026,1,10),[(cash,"1500","0"),(sales,"0","1500")])
    post(db,c,"J2",datetime(2026,1,20),[(expense,"400","0"),(cash,"0","400")])
    tb=trial_balance(db,c.id,date(2026,1,1),date(2026,1,31))
    assert sum(Decimal(x["debit"]) for x in tb)==sum(Decimal(x["credit"]) for x in tb)==Decimal("1900")
    p=pnl(db,c.id,date(2026,1,1),date(2026,1,31))
    assert Decimal(p["revenue"])==Decimal("1500.000000")
    assert Decimal(p["expenses"])==Decimal("400.000000")
    assert Decimal(p["net_profit"])==Decimal("1100.000000")

def test_gl_is_tenant_scoped_and_ordered():
    db,c,cash,sales,expense,payable=setup()
    post(db,c,"J1",datetime(2026,2,1),[(cash,"100","0"),(sales,"0","100")])
    post(db,c,"J2",datetime(2026,2,2),[(expense,"20","0"),(cash,"0","20")])
    rows=general_ledger(db,c.id,date(2026,2,1),date(2026,2,28),cash.id)
    assert len(rows)==2 and rows[0]["entry_number"] != rows[1]["entry_number"]
    assert rows[-1]["running_balance"]=="80.000000"

def test_balance_sheet_includes_current_period_profit():
    db,c,cash,sales,expense,payable=setup()
    post(db,c,"J1",datetime(2026,3,1),[(cash,"1000","0"),(sales,"0","1000")])
    post(db,c,"J2",datetime(2026,3,2),[(expense,"250","0"),(cash,"0","250")])
    bs=balance_sheet(db,c.id,date(2026,3,31))
    assert bs["balanced"] is True
    assert Decimal(bs["assets"])==Decimal("750.000000")
    assert Decimal(bs["equity"])==Decimal("750.000000")

