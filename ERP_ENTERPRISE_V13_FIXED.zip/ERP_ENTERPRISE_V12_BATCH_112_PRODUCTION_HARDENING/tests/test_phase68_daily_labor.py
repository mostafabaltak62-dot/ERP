from datetime import date, datetime
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
import app.enterprise_models, app.construction_models, app.governance_models, app.hr_models, app.document_models
from app.enterprise_models import Company, Project, ProjectCost
from app.hr_models import DailyWorker, DailyLaborEntry
from app.routers.hr_router import create_daily_worker, create_daily_labor, approve_daily_labor, create_daily_labor_settlement

def db():
    e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); return sessionmaker(bind=e)()
class U: id=1

def test_daily_worker_and_overtime_calculation():
    s=db(); c=Company(code='D68',name='Daily Co'); s.add(c); s.flush(); p=Project(company_id=c.id,code='P68',name='Site Project',budget=100000); s.add(p); s.commit()
    class X:
        def model_dump(self): return {'company_id':c.id,'worker_code':'DW1','name':'Ali','trade':'Mason','worker_type':'daily','daily_rate':Decimal('300'),'overtime_rate':Decimal('60'),'normal_hours':Decimal('8'),'national_id':None,'phone':None}
    w=create_daily_worker(X(),s,U())
    class Y:
        company_id=c.id; worker_id=w['id']; project_id=p.id; site_id=wbs_id=cost_code_id=boq_line_id=None; work_date=date(2026,8,25); check_in=datetime(2026,8,25,8); check_out=datetime(2026,8,25,19); regular_hours=None; overtime_hours=Decimal('0'); other_amount=deduction_amount=Decimal('0'); notes=None
    out=create_daily_labor(Y(),s,U())
    assert Decimal(out['regular_amount'])==Decimal('300.000000'); assert Decimal(out['overtime_amount'])==Decimal('180.000000'); assert Decimal(out['net_amount'])==Decimal('480.000000')

def test_approval_creates_project_cost_once():
    s=db(); c=Company(code='D69',name='Cost Co'); s.add(c); s.flush(); p=Project(company_id=c.id,code='P69',name='Project',budget=100000); s.add(p); s.flush(); w=DailyWorker(company_id=c.id,worker_code='DW2',name='Omar',daily_rate=250,overtime_rate=50); s.add(w); s.flush(); e=DailyLaborEntry(company_id=c.id,worker_id=w.id,project_id=p.id,work_date=date(2026,8,25),regular_hours=8,overtime_hours=2,daily_rate=250,overtime_rate=50,regular_amount=250,overtime_amount=100,net_amount=350); s.add(e); s.commit()
    out=approve_daily_labor(e.id,c.id,s,U()); assert out['status']=='approved'; assert s.query(ProjectCost).filter_by(source_type='daily_labor',source_id=e.id).count()==1
    out2=approve_daily_labor(e.id,c.id,s,U()); assert out2['project_cost_id']==out['project_cost_id']; assert s.query(ProjectCost).filter_by(source_type='daily_labor',source_id=e.id).count()==1

def test_settlement_totals():
    s=db(); c=Company(code='D70',name='Settlement Co'); s.add(c); s.flush(); p=Project(company_id=c.id,code='P70',name='Project',budget=100000); s.add(p); s.flush(); w=DailyWorker(company_id=c.id,worker_code='DW3',name='Hassan',daily_rate=200,overtime_rate=40); s.add(w); s.flush()
    s.add_all([DailyLaborEntry(company_id=c.id,worker_id=w.id,project_id=p.id,work_date=date(2026,8,20),regular_amount=200,overtime_amount=80,other_amount=10,deduction_amount=20,net_amount=270,status='approved'),DailyLaborEntry(company_id=c.id,worker_id=w.id,project_id=p.id,work_date=date(2026,8,21),regular_amount=200,overtime_amount=0,other_amount=0,deduction_amount=0,net_amount=200,status='approved')]); s.commit()
    class X: company_id=c.id; project_id=p.id; period_start=date(2026,8,1); period_end=date(2026,8,31)
    out=create_daily_labor_settlement(X(),s,U()); assert Decimal(out['gross_amount'])==Decimal('490.000000'); assert Decimal(out['deductions'])==Decimal('20.000000'); assert Decimal(out['net_amount'])==Decimal('470.000000')
