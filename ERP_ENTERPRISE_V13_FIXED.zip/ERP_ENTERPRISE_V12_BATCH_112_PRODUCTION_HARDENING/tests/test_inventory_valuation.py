from decimal import Decimal
from app.enterprise_models import InventoryValuationPolicy, InventoryCostLayer, InventoryCostConsumption
from app.inventory_valuation import receive, issue
from app.governance import clear_request_context
from test_phase51_transactions import setup_db


def test_fifo_consumes_oldest_cost_layer_first():
    db, company, user, customer, supplier, item, tax = setup_db()
    try:
        policy = InventoryValuationPolicy(company_id=company.id, item_id=item.id, method="fifo", allow_negative=False)
        db.add(policy); db.flush()
        # Existing setup stock is 10 @ 60. Add newer stock at 100.
        receive(db, company.id, item.id, Decimal("10"), Decimal("100"), "test_receipt", 1001)
        cost, _ = issue(db, company.id, item.id, Decimal("10"), "test_issue", 2001)
        db.commit()
        assert cost == Decimal("600.000000")
        remaining = db.query(InventoryCostLayer).filter(InventoryCostLayer.company_id==company.id,
                                                         InventoryCostLayer.item_id==item.id,
                                                         InventoryCostLayer.remaining_qty>0).all()
        assert len(remaining) == 1
        assert remaining[0].remaining_qty == Decimal("10.000000")
        assert remaining[0].unit_cost == Decimal("100.000000")
    finally:
        clear_request_context(); db.close()


def test_weighted_average_uses_authoritative_layer_costs():
    db, company, user, customer, supplier, item, tax = setup_db()
    try:
        policy = InventoryValuationPolicy(company_id=company.id, item_id=item.id, method="weighted_average", allow_negative=False)
        db.add(policy); db.flush()
        receive(db, company.id, item.id, Decimal("10"), Decimal("100"), "test_receipt", 3001)
        cost, _ = issue(db, company.id, item.id, Decimal("10"), "test_issue", 4001)
        db.commit()
        assert cost == Decimal("800.000000")
        consumed = db.query(InventoryCostConsumption).filter(InventoryCostConsumption.source_id==4001).all()
        assert sum((x.total_cost for x in consumed), Decimal("0")) == Decimal("800.000000")
    finally:
        clear_request_context(); db.close()
