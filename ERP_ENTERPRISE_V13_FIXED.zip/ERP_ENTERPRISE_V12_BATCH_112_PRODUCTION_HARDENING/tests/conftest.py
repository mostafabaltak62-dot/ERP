import os
import sys
import uuid
import secrets
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("ERP_ENV", "development")
os.environ.setdefault("JWT_SECRET_KEY", secrets.token_urlsafe(48))
os.environ.setdefault("ENCRYPTION_KEY", secrets.token_urlsafe(48))
os.environ.setdefault("ERP_BOOTSTRAP_ADMIN_PASSWORD", secrets.token_urlsafe(24) + "A1!")
os.environ.setdefault("DATABASE_URL", f"sqlite:///./test_suite_{uuid.uuid4().hex[:8]}.db")

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.db_base import Base
from app.database import engine
from app.governance import clear_request_context


Base.metadata.create_all(bind=engine)


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c

@pytest.fixture(autouse=True)
def isolate_global_runtime_state():
    # Tests create many independent in-memory SQLite databases while the ERP
    # tenant context/rate limiter are process-global. Reset both between tests
    # so one test cannot leak a tenant or consumed rate-limit window into the
    # next test. This changes test isolation only, not production security.
    clear_request_context()
    try:
        from app import security_hardening
        with security_hardening._lock:
            security_hardening._buckets.clear()
    except Exception:
        pass
    yield
    clear_request_context()
    try:
        from app import security_hardening
        with security_hardening._lock:
            security_hardening._buckets.clear()
    except Exception:
        pass
