import datetime
from decimal import Decimal
from app.deep_transactions import ap_aging
from app.transaction_services import create_purchase_invoice, create_supplier_payment
from app.governance import clear_request_context
from test_phase51_transactions import setup_db


def test_ap_aging_as_of_payment_return_and_supplier_terms():
    db, company, user, customer, supplier, item, tax = setup_db()
    try:
        supplier.payment_terms_days = 30
        inv = create_purchase_invoice(db, company.id, user.id, supplier.id,
            [{'item_id': item.id, 'quantity': 1, 'unit_price': 100}], tax_rate_id=tax.id)
        inv.invoice_date = datetime.datetime(2026, 7, 1)
        db.flush()
        v = create_supplier_payment(db, company.id, user.id, inv.id, Decimal('50'), payment_date=datetime.datetime(2026, 8, 10))
        db.flush()
        rows = ap_aging(db, company.id, datetime.date(2026, 8, 1))
        assert rows[0]['paid'] == Decimal('0.00')
        assert rows[0]['returned'] == Decimal('0.00')
        assert rows[0]['outstanding'] == Decimal(str(inv.total_amount)).quantize(Decimal('0.01'))
        assert rows[0]['bucket'] == '1-30'
        rows = ap_aging(db, company.id, datetime.date(2026, 8, 15))
        assert rows[0]['paid'] == Decimal('50.00')
        assert rows[0]['outstanding'] == Decimal('60.00')
        assert rows[0]['overdue_days'] == 15
        assert rows[0]['bucket'] == '1-30'
    finally:
        clear_request_context(); db.close()


def test_ap_aging_supplier_filter_and_branch_scope():
    db, company, user, customer, supplier, item, tax = setup_db()
    try:
        from app.models import Supplier
        from app.enterprise_models import Branch
        from app.transaction_services import create_purchase_invoice
        other = Supplier(company_id=company.id, code='SUP-OTHER-100', name='Other Supplier', payment_terms_days=0)
        db.add(other); db.flush()
        inv1 = create_purchase_invoice(db, company.id, user.id, supplier.id,
            [{'item_id': item.id, 'quantity': 1, 'unit_price': 100}], tax_rate_id=tax.id)
        inv2 = create_purchase_invoice(db, company.id, user.id, other.id,
            [{'item_id': item.id, 'quantity': 1, 'unit_price': 200}], tax_rate_id=tax.id)
        inv1.invoice_date = inv2.invoice_date = datetime.datetime(2026, 7, 1)
        db.flush()
        assert len(ap_aging(db, company.id, datetime.date(2026, 7, 2), supplier_id=supplier.id)) == 1
        assert ap_aging(db, company.id, datetime.date(2026, 7, 2), supplier_id=999999) == []
        b = db.query(Branch).filter(Branch.company_id==company.id).first()
        if b:
            inv1.branch_id = b.id; inv2.branch_id = None; db.flush()
            assert len(ap_aging(db, company.id, datetime.date(2026, 7, 2), branch_id=b.id)) == 1
    finally:
        clear_request_context(); db.close()


def test_ap_aging_applies_posted_purchase_returns_and_supplier_policy():
    db, company, user, customer, supplier, item, tax = setup_db()
    try:
        from app.enterprise_models import PurchaseReturn
        from app.commercial_completion_models import SupplierCreditPolicy
        inv = create_purchase_invoice(db, company.id, user.id, supplier.id,
            [{'item_id': item.id, 'quantity': 1, 'unit_price': 100}], tax_rate_id=tax.id)
        inv.invoice_date = datetime.datetime(2026, 7, 1)
        supplier.payment_terms_days = 60
        db.add(SupplierCreditPolicy(company_id=company.id, supplier_id=supplier.id, payment_terms_days=10, credit_limit=1000))
        db.flush()
        db.add(PurchaseReturn(company_id=company.id, return_number='RET-100', purchase_invoice_id=inv.id,
                              supplier_id=supplier.id, return_date=datetime.datetime(2026, 7, 5),
                              status='posted', total_amount=Decimal('20.00')))
        db.flush()
        rows = ap_aging(db, company.id, datetime.date(2026, 7, 6))
        assert rows[0]['original'] == Decimal(str(inv.total_amount)).quantize(Decimal('0.01'))
        assert rows[0]['returned'] == Decimal('20.00')
        assert rows[0]['outstanding'] == Decimal(str(inv.total_amount - Decimal('20'))).quantize(Decimal('0.01'))
        assert rows[0]['due_date'] == datetime.date(2026, 7, 11)
        assert rows[0]['bucket'] == 'current'
    finally:
        clear_request_context(); db.close()


def test_ap_aging_routes_and_template_are_hardened():
    from pathlib import Path
    route = Path('app/routers/financial_reporting_ui.py').read_text(encoding='utf-8')
    api = Path('app/routers/deep_transactions_router.py').read_text(encoding='utf-8')
    template = Path('templates/aging_report.html').read_text(encoding='utf-8')
    assert 'def ap_aging_page' in route and 'supplier_id:int|None=None' in route
    assert 'def ap_aging_export' in route and 'Accounts Payable Aging' in route
    assert 'def get_ap_aging' in api and 'branch_id: int | None = None' in api and 'supplier_id: int | None = None' in api
    assert 'name="supplier_id"' in template and 'r.original' in template and 'r.returned' in template
