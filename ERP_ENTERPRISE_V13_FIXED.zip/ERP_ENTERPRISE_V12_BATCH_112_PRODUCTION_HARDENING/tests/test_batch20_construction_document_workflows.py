from app.routers.construction_document_forms_router import FORM_TYPES, STATUS_FROM_DECISION

def test_all_requested_construction_forms_are_registered():
    expected={'SIR','MIR','MT','DWG','LITER','BOQ','RFI','V.O','QS','SNA','DOC','POUR','INITIAL_HANDOVER','FINAL_HANDOVER','LOG'}
    assert expected.issubset(FORM_TYPES)

def test_decision_mapping_has_core_workflow():
    assert STATUS_FROM_DECISION['approved']=='approved'
    assert STATUS_FROM_DECISION['revise_and_resubmit']=='revision_required'
    assert STATUS_FROM_DECISION['rejected']=='rejected'
