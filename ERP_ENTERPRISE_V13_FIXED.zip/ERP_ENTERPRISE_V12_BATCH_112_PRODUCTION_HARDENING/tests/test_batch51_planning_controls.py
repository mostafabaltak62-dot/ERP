from datetime import date
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
import app.construction_models
from app.enterprise_models import Company, Project
from app.construction_services import create_activity, create_delay_event, approve_delay_event, create_time_impact_analysis, approve_time_impact_analysis, calculate_schedule_health
from app.construction_models import ConstructionTimeImpactAnalysis


def test_time_impact_analysis_and_health_governance():
    e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); S=sessionmaker(bind=e); db=S()
    c=Company(code='C051',name='Planning Controls Co'); db.add(c); db.flush()
    p=Project(company_id=c.id,code='P051',name='Tower',budget=100000); db.add(p); db.flush()
    a=create_activity(db,c.id,p.id,'A-01','Structure',date(2026,8,1),date(2026,8,10),100000)
    event=create_delay_event(db,c.id,p.id,'DE-001',date(2026,8,5),'Late instruction','Approved instruction delay',5,True,False,a.id)
    approve_delay_event(db,c.id,event.id,3)
    tia=create_time_impact_analysis(db,c.id,p.id,event.id,status_date=date(2026,8,31),user_id=1)
    assert tia.calculated_impact_days == 3
    assert tia.impacted_project_finish is not None
    approve_time_impact_analysis(db,c.id,tia.id,1)
    assert tia.status == 'approved'
    health=calculate_schedule_health(db,c.id,p.id,date(2026,8,31))
    assert 0 <= health['score'] <= 100
    assert db.query(ConstructionTimeImpactAnalysis).count() == 1
