from fastapi import HTTPException
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models import Base, User, RoleEnum
from app.enterprise_models import Currency, Company, Branch, UserCompanyAccess
from app.governance_models import Permission, Role, RolePermission, UserRole
from app.governance import _has_permission, set_request_context, clear_request_context
from app.routers.admin_security_router import _assert_role_assignment_allowed, _can_manage_role_scope


def make_db():
    e = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(e)
    return sessionmaker(bind=e)()


def tenant(db):
    ccy = Currency(code="EGP", name="Egyptian Pound")
    db.add(ccy); db.flush()
    c1 = Company(code="C1", name="Company 1", base_currency_id=ccy.id)
    c2 = Company(code="C2", name="Company 2", base_currency_id=ccy.id)
    db.add_all([c1, c2]); db.flush()
    b1 = Branch(company_id=c1.id, code="B1", name="Branch 1")
    b2 = Branch(company_id=c2.id, code="B2", name="Branch 2")
    db.add_all([b1, b2]); db.flush()
    return c1, c2, b1, b2


def test_inactive_role_cannot_grant_permission():
    db = make_db()
    u = User(username="u", full_name="U", password_hash="x", role=RoleEnum.employee)
    role = Role(code="r82", name="Role 82", is_active=False)
    perm = Permission(code="p82", description="P82", is_active=True)
    db.add_all([u, role, perm]); db.flush()
    db.add(RolePermission(role_id=role.id, permission_id=perm.id))
    db.add(UserRole(user_id=u.id, role_id=role.id, is_active=True))
    db.commit()
    assert _has_permission(db, u.id, "p82") is False
    db.close()


def test_non_admin_cannot_manage_unassigned_company_role_scope():
    db = make_db(); c1, c2, b1, b2 = tenant(db)
    actor = User(username="manager", full_name="Manager", password_hash="x", role=RoleEnum.employee)
    db.add(actor); db.flush()
    db.add(UserCompanyAccess(user_id=actor.id, company_id=c1.id, branch_id=b1.id, can_manage=True))
    db.commit()
    assert _can_manage_role_scope(db, actor, c1.id, b1.id) is True
    assert _can_manage_role_scope(db, actor, c2.id, b2.id) is False
    db.close()


def test_non_admin_cannot_grant_equal_or_higher_role():
    db = make_db(); c1, _, b1, _ = tenant(db)
    actor = User(username="mgr", full_name="Manager", password_hash="x", role=RoleEnum.employee)
    db.add(actor); db.flush()
    db.add(UserCompanyAccess(user_id=actor.id, company_id=c1.id, branch_id=b1.id, can_manage=True))
    held = Role(code="project_manager", name="Project Manager", is_active=True)
    target = Role(code="finance_manager", name="Finance Manager", is_active=True)
    db.add_all([held, target]); db.flush()
    db.add(UserRole(user_id=actor.id, role_id=held.id, company_id=c1.id, branch_id=b1.id, is_active=True))
    db.commit()
    try:
        _assert_role_assignment_allowed(db, actor, {"code": "finance_manager"}, c1.id, b1.id)
        assert False, "Higher role must be rejected"
    except HTTPException as exc:
        assert exc.status_code == 403
    db.close()


def test_branch_only_manager_cannot_grant_company_wide_role():
    db = make_db(); c1, _, b1, _ = tenant(db)
    actor = User(username="branch_mgr", full_name="Branch Manager", password_hash="x", role=RoleEnum.employee)
    db.add(actor); db.flush()
    db.add(UserCompanyAccess(user_id=actor.id, company_id=c1.id, branch_id=b1.id, can_manage=True))
    db.commit()
    assert _can_manage_role_scope(db, actor, c1.id, None) is False
    db.close()
