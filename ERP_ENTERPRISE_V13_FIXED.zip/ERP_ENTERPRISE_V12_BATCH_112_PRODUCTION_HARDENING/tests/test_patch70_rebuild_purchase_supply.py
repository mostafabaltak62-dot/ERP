from decimal import Decimal
from pathlib import Path
import pytest
from fastapi import HTTPException
from app.models import PurchaseOrder, PurchaseOrderLine, PurchaseReceipt
from app.warehouse_models import Warehouse
from app.deep_transactions import receive_purchase_order
from app.commercial_completion_models import ProcurementRequest, ProcurementRequestLine, RFQ
from test_phase51_transactions import setup_db
from app.governance import clear_request_context


def test_partial_receipts_are_cumulative_and_second_receipt_is_allowed():
    db, company, user, customer, supplier, item, tax = setup_db()
    try:
        wh = Warehouse(company_id=company.id, branch_id=1, code="WH-P70", name="P70", is_active=True)
        db.add(wh); db.flush()
        po = PurchaseOrder(company_id=company.id, branch_id=1, po_number="PO-P70-1", supplier_id=supplier.id,
                           warehouse_id=wh.id, created_by_id=user.id, approval_status="approved")
        db.add(po); db.flush()
        line = PurchaseOrderLine(company_id=company.id, po_id=po.id, item_id=item.id,
                                 quantity=Decimal("10"), unit_price=Decimal("20"), line_total=Decimal("200"))
        db.add(line); db.flush()
        r1 = receive_purchase_order(db, company.id, po.id, user.id, {str(line.id): Decimal("4")})
        r2 = receive_purchase_order(db, company.id, po.id, user.id, {str(line.id): Decimal("6")})
        assert r1.id != r2.id
        assert db.query(PurchaseReceipt).filter_by(po_id=po.id).count() == 2
        db.rollback()
    finally:
        clear_request_context(); db.close()


def test_procurement_request_constraints_reject_duplicate_item_and_nonpositive_qty():
    db, company, user, customer, supplier, item, tax = setup_db()
    try:
        pr = ProcurementRequest(company_id=company.id, request_number="PR-P70-1", requested_by_id=user.id,
                                status="submitted", priority="normal")
        db.add(pr); db.flush()
        db.add(ProcurementRequestLine(company_id=company.id, request_id=pr.id, item_id=item.id, quantity=Decimal("1")))
        db.flush()
        with pytest.raises(Exception):
            db.add(ProcurementRequestLine(company_id=company.id, request_id=pr.id, item_id=item.id, quantity=Decimal("2")))
            db.flush()
        db.rollback()
        db.add(ProcurementRequestLine(company_id=company.id, request_id=pr.id, item_id=item.id, quantity=Decimal("0")))
        with pytest.raises(Exception): db.flush()
        db.rollback()
    finally:
        clear_request_context(); db.close()


def test_patch70_rebuild_removes_nonexistent_purchase_order_status_assignment():
    text = Path("app/routers/commercial_completion_router.py").read_text(encoding="utf-8")
    assert "doc.status=" not in text
    assert "doc.approval_status=result.status" in text


def test_valuation_rebuild_uses_operational_date():
    text = Path("app/inventory_valuation.py").read_text(encoding="utf-8")
    assert "order_by(StockMovement.operational_date.asc()" in text
    assert "m.operational_date or m.created_at" in text


def test_direct_stock_movement_valuation_uses_operational_date():
    text = Path("app/inventory_valuation.py").read_text(encoding="utf-8")
    assert 'movement.operational_date or movement.created_at' in text

def test_standard_cost_is_supported_by_rebuild_method_validation():
    text = Path("app/inventory_valuation.py").read_text(encoding="utf-8")
    assert 'method not in {"fifo", "weighted_average", "standard"}' in text

def test_batch26_unique_constraints_use_sqlite_batch_mode():
    text = Path("alembic/versions/y5z6a7b8c9d0_batch26_site_operations_center.py").read_text(encoding="utf-8")
    assert "op.create_unique_constraint" not in text
    assert "batch.create_unique_constraint" in text
