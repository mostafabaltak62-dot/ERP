from datetime import date, datetime
from decimal import Decimal
from app.enterprise_models import Company
from app.models import Account, AccountTypeEnum, JournalEntry, JournalLine, PeriodClosingEntry
from app.financial_reporting import trial_balance, profit_and_loss, balance_sheet, cash_flow, validate_financials
from app.database import SessionLocal


def setup_db(db):
    c=Company(code="RPT", name="Reporting Co")
    db.add(c); db.flush()
    cash=Account(company_id=c.id,code="1100",name="Cash",account_type=AccountTypeEnum.asset,normal_balance="debit",statement_section="cash_and_equivalents",cash_flow_category="operating")
    ar=Account(company_id=c.id,code="1200",name="AR",account_type=AccountTypeEnum.asset,normal_balance="debit",statement_section="trade_receivables",cash_flow_category="operating")
    rev=Account(company_id=c.id,code="4100",name="Revenue",account_type=AccountTypeEnum.revenue,normal_balance="credit",statement_section="revenue",cash_flow_category="operating")
    exp=Account(company_id=c.id,code="5200",name="Expense",account_type=AccountTypeEnum.expense,normal_balance="debit",statement_section="operating_expenses",cash_flow_category="operating")
    db.add_all([cash,ar,rev,exp]); db.flush(); return c,cash,ar,rev,exp


def post(db,c,n,dt,lines,status="posted"):
    e=JournalEntry(company_id=c.id,entry_number=n,entry_date=dt,description=n,status="draft")
    db.add(e); db.flush()
    for a,d,cr in lines: db.add(JournalLine(company_id=c.id,entry_id=e.id,account_id=a.id,debit=d,credit=cr))
    db.flush(); e.status=status; db.commit(); return e


def test_drafts_are_excluded_and_statements_reconcile():
    db=SessionLocal(); c,cash,ar,rev,exp=setup_db(db)
    post(db,c,"DRAFT",datetime(2026,1,1),[(cash,100,0),(rev,0,100)],status="draft")
    post(db,c,"SALE",datetime(2026,1,2),[(ar,100,0),(rev,0,100)])
    post(db,c,"COLLECT",datetime(2026,1,3),[(cash,100,0),(ar,0,100)])
    post(db,c,"EXP",datetime(2026,1,4),[(exp,25,0),(cash,0,25)])
    tb=trial_balance(db,c.id,date(2026,1,1),date(2026,1,31))
    assert sum(Decimal(x["debit"]) for x in tb)==sum(Decimal(x["credit"]) for x in tb)==Decimal("225.00")
    p=profit_and_loss(db,c.id,date(2026,1,1),date(2026,1,31)); assert p["net_profit"]==Decimal("75.00")
    bs=balance_sheet(db,c.id,date(2026,1,31)); assert bs["balanced"] is True and bs["asset_total"]==Decimal("75.00")
    cf=cash_flow(db,c.id,date(2026,1,1),date(2026,1,31)); assert cf["closing_cash"]==Decimal("75.00") and cf["reconciles"]
    assert validate_financials(db,c.id,date(2026,1,1),date(2026,1,31))["overall"]
    db.close()
