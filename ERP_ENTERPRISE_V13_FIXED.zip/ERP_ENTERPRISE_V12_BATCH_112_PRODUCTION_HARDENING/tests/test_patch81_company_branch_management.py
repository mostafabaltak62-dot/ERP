from pathlib import Path
from types import SimpleNamespace
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, User, RoleEnum
from app.enterprise_models import Company, Branch, Currency, UserCompanyAccess
from app.routers.organization_admin_router import _company_for_admin


def db_setup():
    e=create_engine('sqlite:///:memory:')
    Base.metadata.create_all(e)
    S=sessionmaker(bind=e); db=S()
    usd=Currency(code='EGP',name='Egyptian Pound',decimal_places=2,is_active=True)
    inactive=Currency(code='XXX',name='Inactive',decimal_places=2,is_active=False)
    c1=Company(code='C1',name='Company One',is_active=True)
    c2=Company(code='C2',name='Company Two',is_active=True)
    db.add_all([usd,inactive,c1,c2]); db.flush()
    b1=Branch(company_id=c1.id,code='MAIN',name='Main',is_active=True)
    b2=Branch(company_id=c2.id,code='MAIN',name='Main',is_active=True)
    u=User(username='mgr',full_name='Manager',password_hash='x',role=RoleEnum.employee,is_active=True)
    db.add_all([b1,b2,u]); db.flush()
    db.add(UserCompanyAccess(user_id=u.id,company_id=c1.id,branch_id=None,can_manage=True)); db.commit()
    return db,c1,c2,b1,b2,u


def test_company_manager_cannot_resolve_other_company():
    db,c1,c2,b1,b2,u=db_setup()
    assert _company_for_admin(db,u,c1.id).id==c1.id
    try:
        _company_for_admin(db,u,c2.id)
        assert False
    except Exception as exc:
        assert getattr(exc,'status_code',None)==403


def test_branch_access_cannot_cross_company_or_inactive_entities():
    text=Path('app/routers/organization_admin_router.py').read_text()
    assert 'Branch.id == branch_id, Branch.company_id == company.id' in text
    assert 'if not target.is_active' in text
    assert 'if not branch.is_active' in text
    assert 'base currency must be active' in text.lower()


def test_organization_audits_and_does_not_offer_delete():
    text=Path('app/routers/organization_admin_router.py').read_text()
    assert 'GovernanceAuditLog' in text
    assert 'def _audit' in text
    assert 'company/{company_id}/delete' not in text
    assert 'branch/{branch_id}/delete' not in text
