from fastapi import HTTPException
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, User, RoleEnum
from app.routers.admin_security_router import _require_platform_admin, _validate_manager, _ensure_admin_survival
from pathlib import Path


def make_db():
    e = create_engine('sqlite:///:memory:', connect_args={'check_same_thread': False})
    Base.metadata.create_all(e)
    return sessionmaker(bind=e)()


def test_account_lifecycle_is_platform_admin_only():
    user = User(username='u', full_name='U', password_hash='x', role=RoleEnum.manager)
    try:
        _require_platform_admin(user)
        assert False
    except HTTPException as exc:
        assert exc.status_code == 403


def test_inactive_manager_cannot_be_assigned():
    db = make_db()
    manager = User(username='m', full_name='M', password_hash='x', role=RoleEnum.manager, is_active=False)
    db.add(manager); db.commit()
    try:
        _validate_manager(db, manager.id)
        assert False
    except HTTPException as exc:
        assert exc.status_code == 422
    db.close()


def test_last_active_admin_cannot_be_demoted_or_disabled():
    db = make_db()
    admin = User(username='a', full_name='A', password_hash='x', role=RoleEnum.admin, is_active=True)
    db.add(admin); db.commit()
    for role in (RoleEnum.employee,):
        try:
            _ensure_admin_survival(db, admin, new_role=role)
            assert False
        except HTTPException as exc:
            assert exc.status_code == 422
    db.close()


def test_account_delete_is_presented_as_deactivation_and_security_center_mentions_retention():
    html = Path('templates/admin_accounts.html').read_text(encoding='utf-8')
    assert 'تعطيل' in html or 'إيقاف' in html
    assert 'استرداد' in html
