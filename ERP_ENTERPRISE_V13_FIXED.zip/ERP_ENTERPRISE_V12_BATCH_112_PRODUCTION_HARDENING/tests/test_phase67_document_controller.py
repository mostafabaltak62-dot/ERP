from app.time_utils import utcnow
from datetime import date, datetime
from pathlib import Path
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
import app.enterprise_models, app.construction_models, app.governance_models, app.hr_models, app.document_models
from app.enterprise_models import Company, Project
from app.document_models import ProjectDocument, ProjectDocumentRevision, DocumentTransmittal, DocumentTransmittalLine, DocumentApproval, DocumentDistribution

def db():
    e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); return sessionmaker(bind=e)()

def test_document_controller_register_revision_transmittal_approval_and_distribution(tmp_path):
    s=db(); c=Company(code='D67',name='Docs Co'); s.add(c); s.flush(); p=Project(company_id=c.id,code='P67',name='Docs Project',budget=100000); s.add(p); s.flush()
    d=ProjectDocument(company_id=c.id,project_id=p.id,document_no='P67-SIR-0001',title='Inspection Request - Concrete',document_type='SIR',status='draft',created_by_id=1,created_at=utcnow(),updated_at=utcnow()); s.add(d); s.flush()
    file=tmp_path/'sir.pdf'; file.write_bytes(b'fake-pdf-content'); import hashlib; sha=hashlib.sha256(file.read_bytes()).hexdigest()
    r=ProjectDocumentRevision(company_id=c.id,document_id=d.id,revision_no=1,revision_code='R0',file_name='sir.pdf',stored_path=str(file),mime_type='application/pdf',file_size=file.stat().st_size,sha256=sha,status='submitted',uploaded_by_id=1,uploaded_at=utcnow(),is_current=True); s.add(r); d.current_revision_no=1; d.status='submitted'; s.flush()
    t=DocumentTransmittal(company_id=c.id,project_id=p.id,transmittal_no='TR-0001',recipient='Consultant',subject='SIR submission',purpose='for_review',issue_date=date.today(),created_by_id=1,created_at=utcnow()); s.add(t); s.flush(); s.add(DocumentTransmittalLine(company_id=c.id,transmittal_id=t.id,document_id=d.id,revision_id=r.id,action='review')); s.add(DocumentApproval(company_id=c.id,document_id=d.id,revision_id=r.id,approver_id=2,decision='approved',approved_at=utcnow())); s.add(DocumentDistribution(company_id=c.id,document_id=d.id,revision_id=r.id,recipient='Site Team',recipient_role='Site Engineer',distribution_method='system',distributed_at=utcnow())); s.commit()
    assert s.query(ProjectDocument).count()==1; assert s.query(ProjectDocumentRevision).one().sha256==sha; assert s.query(DocumentTransmittalLine).one().revision_id==r.id; assert s.query(DocumentApproval).one().decision=='approved'; assert s.query(DocumentDistribution).one().recipient=='Site Team'

def test_document_controller_supports_required_document_types():
    required={'DRAWING','MATERIAL','SIR','MIR','MT','DOC','LETTER_IN','LETTER_OUT','MINUTES','HANDOVER'}
    from app.routers.document_controller_router import DOC_TYPES
    assert required.issubset(DOC_TYPES)
