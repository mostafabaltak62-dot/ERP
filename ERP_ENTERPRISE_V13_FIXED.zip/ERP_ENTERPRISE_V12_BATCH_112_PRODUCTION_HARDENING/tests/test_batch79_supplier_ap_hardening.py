import datetime
from decimal import Decimal
from app.deep_transactions import ap_aging
from app.transaction_services import create_purchase_invoice, create_supplier_payment
from app.governance import clear_request_context
from test_phase51_transactions import setup_db


def test_ap_aging_is_invoice_based_and_uses_supplier_terms():
    db, company, user, customer, supplier, item, tax = setup_db()
    try:
        supplier.payment_terms_days = 30
        inv = create_purchase_invoice(db, company.id, user.id, supplier.id,
            [{'item_id': item.id, 'quantity': 1, 'unit_price': 100}], tax_rate_id=tax.id)
        inv.invoice_date = datetime.datetime(2026, 7, 1)
        db.flush()
        rows = ap_aging(db, company.id, datetime.date(2026, 7, 20))
        assert rows[0]['bucket'] == 'current'
        assert rows[0]['due_date'] == datetime.date(2026, 7, 31)
        rows = ap_aging(db, company.id, datetime.date(2026, 8, 15))
        assert rows[0]['overdue_days'] == 15
        assert rows[0]['bucket'] == '1-30'
    finally:
        clear_request_context(); db.close()


def test_ap_aging_excludes_po_only_commitments_and_respects_invoice_payment():
    db, company, user, customer, supplier, item, tax = setup_db()
    try:
        from app.models import PurchaseOrder
        po = PurchaseOrder(company_id=company.id, supplier_id=supplier.id, po_number='PO-79', approval_status='approved')
        db.add(po); db.flush()
        assert ap_aging(db, company.id) == []
        inv = create_purchase_invoice(db, company.id, user.id, supplier.id,
            [{'item_id': item.id, 'quantity': 1, 'unit_price': 100}], tax_rate_id=tax.id)
        create_supplier_payment(db, company.id, user.id, inv.id, Decimal('50'))
        rows = ap_aging(db, company.id)
        assert len(rows) == 1
        assert rows[0]['outstanding'] == Decimal('60.00')
    finally:
        clear_request_context(); db.close()
