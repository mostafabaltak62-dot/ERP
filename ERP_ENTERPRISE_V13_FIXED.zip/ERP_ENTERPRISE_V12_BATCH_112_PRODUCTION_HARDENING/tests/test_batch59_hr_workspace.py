from pathlib import Path

def test_hr_workspace_is_tenant_scoped_and_operationally_visible():
    router=Path('app/routers/hr_ui_router.py').read_text(encoding='utf-8')
    template=Path('templates/hr_workspace.html').read_text(encoding='utf-8')
    assert 'Employee.company_id==cid' in router
    assert 'LeaveRequest.company_id==cid' in router
    assert 'AttendanceRecord.company_id==cid' in router
    assert 'HRDocument.company_id==cid' in router
    for label in ['إجازات قيد المراجعة','حضور اليوم','غياب اليوم','مستندات تنتهي خلال 30 يوم','مستندات منتهية']:
        assert label in template

def test_hr_dashboard_queries_have_expiry_window_and_latest_payroll():
    text=Path('app/routers/hr_ui_router.py').read_text(encoding='utf-8')
    assert 'timedelta(days=30)' in text
    assert 'PayrollRun.company_id==cid' in text
    assert 'order_by(PayrollRun.end_date.desc())' in text
