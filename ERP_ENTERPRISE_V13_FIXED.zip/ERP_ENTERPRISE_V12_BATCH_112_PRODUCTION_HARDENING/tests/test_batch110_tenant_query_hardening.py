from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models import Base, User, RoleEnum
from app.enterprise_models import Currency, Company, Branch
from app.governance_models import ApprovalRule, ApprovalRequest
from app.workflows import request_approval
from app.governance import clear_request_context
from app.accounting import next_number


def make_db():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)()


def make_company(db, code):
    ccy = db.query(Currency).filter_by(code="EGP").first()
    if not ccy:
        ccy = Currency(code="EGP", name="Egyptian Pound")
        db.add(ccy); db.flush()
    company = Company(code=code, name=code, base_currency_id=ccy.id)
    db.add(company); db.flush()
    branch = Branch(company_id=company.id, code=f"{code}B", name=f"{code} Branch")
    user = User(username=f"user_{code}", full_name=code, password_hash="x", role=RoleEnum.employee)
    db.add_all([branch, user]); db.flush()
    return company, branch, user


def test_approval_idempotency_is_scoped_by_company():
    clear_request_context()
    db = make_db()
    c1, b1, u1 = make_company(db, "C1")
    c2, b2, u2 = make_company(db, "C2")
    db.add_all([
        ApprovalRule(company_id=c1.id, document_type="po", name="C1 rule", priority=1),
        ApprovalRule(company_id=c2.id, document_type="po", name="C2 rule", priority=1),
    ])
    db.commit()

    r1 = request_approval(db, company_id=c1.id, branch_id=b1.id, document_type="po", document_id=77, requested_by_id=u1.id, amount=Decimal("1"))
    r2 = request_approval(db, company_id=c2.id, branch_id=b2.id, document_type="po", document_id=77, requested_by_id=u2.id, amount=Decimal("1"))
    db.commit()

    assert r1.id != r2.id
    assert db.query(ApprovalRequest).filter_by(document_type="po", document_id=77).count() == 2
    db.close()


def test_global_sequence_rejects_invalid_keys_and_allocates_monotonically():
    clear_request_context()
    db = make_db()
    assert next_number(db, "test_seq", "T") == "T-000001"
    assert next_number(db, "test_seq", "T") == "T-000002"
    try:
        next_number(db, "", "T")
    except Exception as exc:
        assert getattr(exc, "status_code", None) == 422
    else:
        raise AssertionError("empty sequence key must be rejected")
    db.close()
