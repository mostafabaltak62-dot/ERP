from pathlib import Path

def test_user_directory_v2_ui_has_profile_and_password_controls():
    html = Path("templates/users.html").read_text(encoding="utf-8")
    for marker in ["employee_code", "job_title", "department", "manager_user_id", "password-toggle", "GOVERNANCE", "قالب جاهز", "كلمة مرور جديدة"]:
        assert marker in html

def test_user_model_has_directory_fields():
    src = Path("app/models.py").read_text(encoding="utf-8")
    for marker in ["employee_code", "job_title", "department", "manager_user_id"]:
        assert marker in src

def test_user_directory_has_permission_presets():
    src = Path("app/routers/auth_router.py").read_text(encoding="utf-8")
    for marker in ["PERMISSION_PRESETS", "engineer", "supervisor", "finance", "project_manager", "/permissions/preset"]:
        assert marker in src
