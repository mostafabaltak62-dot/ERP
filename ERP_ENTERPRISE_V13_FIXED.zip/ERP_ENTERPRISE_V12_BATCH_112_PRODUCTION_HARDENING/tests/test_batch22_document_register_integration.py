from pathlib import Path

def test_batch22_migration_declares_form_attachments():
    text=Path('alembic/versions/w3x4y5z6a7b8_batch22_document_register_attachments.py').read_text()
    assert 'construction_document_form_attachments' in text
    assert "down_revision='v2w3x4y5z6b8'" in text

def test_official_form_router_has_secure_attachment_and_history_endpoints():
    text=Path('app/routers/construction_document_forms_router.py').read_text()
    assert "/{form_id}/attachments" in text
    assert "/{form_id}/history" in text
    assert 'hashlib.sha256' in text
    assert 'FORM_ALLOWED_EXT' in text

def test_project_register_links_official_forms():
    text=Path('templates/project_documents.html').read_text()
    assert 'construction-document-forms/ui/workspace' in text
    assert 'form_by_document' in text
