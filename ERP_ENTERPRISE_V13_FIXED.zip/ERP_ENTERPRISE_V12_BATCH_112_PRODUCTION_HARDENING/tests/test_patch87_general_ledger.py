from datetime import datetime, date
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, Account, AccountTypeEnum, JournalEntry, JournalLine
from app.enterprise_models import Company, Branch
from app.accounting import create_entry
from app.reporting import general_ledger
from app.governance import set_request_context, clear_request_context

def setup():
    e=create_engine("sqlite:///:memory:")
    Base.metadata.create_all(e); S=sessionmaker(bind=e); db=S()
    c=Company(code="GL87",name="GL Co"); db.add(c); db.flush()
    b=Branch(company_id=c.id,code="B1",name="Branch 1",is_active=True); db.add(b); db.flush()
    cash=Account(company_id=c.id,code="1000",name="Cash",account_type=AccountTypeEnum.asset,is_active=True)
    sales=Account(company_id=c.id,code="4000",name="Sales",account_type=AccountTypeEnum.revenue,is_active=True)
    old=Account(company_id=c.id,code="9999",name="Retired",account_type=AccountTypeEnum.expense,is_active=False)
    other=Company(code="GL88",name="Other"); db.add(other); db.flush()
    foreign=Account(company_id=other.id,code="1000",name="Foreign Cash",account_type=AccountTypeEnum.asset,is_active=True)
    db.add_all([cash,sales,old,foreign]); db.flush()
    return db,c,b,cash,sales,old,foreign

def post(db,c,b,num,dt,lines):
    set_request_context(request_id="gl87",user_id=1,company_id=c.id,branch_id=b.id)
    create_entry(db,num,1,[(a.code,d,cr) for a,d,cr in lines],"test",abs(hash(num))%100000,dt,company_id=c.id,branch_id=b.id)
    db.commit(); clear_request_context()

def test_general_ledger_keeps_historical_inactive_accounts_and_opening_balance():
    db,c,b,cash,sales,old,foreign=setup()
    # Post while the account is active, then retire it; historical activity must remain reportable.
    old.is_active=True
    db.flush()
    post(db,c,b,"J2",datetime(2026,1,5),[(old,40,"0"),(cash,0,40)])
    old.is_active=False
    db.commit()
    rows=general_ledger(db,c.id,date(2026,1,1),date(2026,1,31),old.id,b.id)
    assert len(rows)==1
    assert rows[0]["account_active"] is False
    assert rows[0]["opening_balance"] == "0.000000"

def test_general_ledger_isolated_by_company_and_branch():
    db,c,b,cash,sales,old,foreign=setup()
    post(db,c,b,"J1",datetime(2026,1,2),[(cash,100,"0"),(sales,0,100)])
    rows=general_ledger(db,c.id,date(2026,1,1),date(2026,1,31),foreign.id,b.id)
    assert rows == []
