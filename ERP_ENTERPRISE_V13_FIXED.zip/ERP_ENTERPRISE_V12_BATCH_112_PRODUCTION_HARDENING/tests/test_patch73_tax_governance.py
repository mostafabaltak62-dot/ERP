from decimal import Decimal
from app.models import TaxRate, TaxTransaction
from app.routers.pro_ledger_router import _validate_tax_master


def test_tax_master_validation_and_account_scope():
    class DummyDB:
        def query(self, *a, **k):
            class Q:
                def filter(self, *a, **k): return self
                def first(self): return object()
            return Q()
    out=_validate_tax_master(DummyDB(),1,None,"VAT14","VAT",Decimal("14"),"2200","output")
    assert out[0]=="VAT14" and out[2]==Decimal("14.00")


def test_tax_transaction_model_has_historical_snapshot_fields():
    for name in ("branch_id","rate_applied","tax_code_snapshot","tax_name_snapshot","tax_account_code_snapshot"):
        assert hasattr(TaxTransaction,name)


def test_tax_rate_has_integrity_constraints():
    names={c.name for c in TaxRate.__table__.constraints}
    assert "ck_tax_rate_range" in names
    assert "ck_tax_direction" in names
