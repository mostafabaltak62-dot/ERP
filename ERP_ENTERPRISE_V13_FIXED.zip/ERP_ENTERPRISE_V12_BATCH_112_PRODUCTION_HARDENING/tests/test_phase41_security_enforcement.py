from fastapi import HTTPException
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from app.models import Base, User, RoleEnum, Customer
from app.enterprise_models import Currency, Company, Branch, UserCompanyAccess
from app.governance_models import Permission, Role, RolePermission, UserRole, GovernanceAuditLog
from app.governance import set_request_context, clear_request_context, _has_permission
from app.governance import route_permission


def make_db():
    e = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(e)
    return sessionmaker(bind=e)()


def test_dynamic_company_isolation():
    db = make_db()
    ccy = Currency(code="EGP", name="Egyptian Pound"); db.add(ccy); db.flush()
    c1 = Company(code="C1", name="Company 1", base_currency_id=ccy.id); c2 = Company(code="C2", name="Company 2", base_currency_id=ccy.id)
    db.add_all([c1, c2]); db.flush()
    b1 = Branch(company_id=c1.id, code="B1", name="B1"); b2 = Branch(company_id=c2.id, code="B2", name="B2"); db.add_all([b1,b2]); db.flush()
    u = User(username="u1", full_name="User", password_hash="x", role=RoleEnum.employee); db.add(u); db.flush()
    db.add(UserCompanyAccess(user_id=u.id, company_id=c1.id, branch_id=b1.id))
    db.add_all([Customer(code="C1-CUST", name="One", company_id=c1.id), Customer(code="C2-CUST", name="Two", company_id=c2.id)])
    db.commit()
    set_request_context(request_id="r", user_id=u.id, company_id=c1.id, branch_id=b1.id)
    rows = db.execute(select(Customer)).scalars().all()
    assert [r.name for r in rows] == ["One"]
    clear_request_context(); db.close()


def test_tenant_header_cannot_become_authorization():
    from app.governance import resolve_tenant
    db = make_db()
    ccy = Currency(code="EGP", name="Egyptian Pound"); db.add(ccy); db.flush()
    c1 = Company(code="C1", name="Company 1", base_currency_id=ccy.id); c2 = Company(code="C2", name="Company 2", base_currency_id=ccy.id); db.add_all([c1,c2]); db.flush()
    b1 = Branch(company_id=c1.id, code="B1", name="B1"); b2 = Branch(company_id=c2.id, code="B2", name="B2"); db.add_all([b1,b2]); db.flush()
    u = User(username="u2", full_name="User", password_hash="x", role=RoleEnum.employee); db.add(u); db.flush()
    db.add(UserCompanyAccess(user_id=u.id, company_id=c1.id, branch_id=b1.id)); db.commit()
    try:
        resolve_tenant(db, u, c2.id, b2.id)
        assert False, "Unauthorized tenant context must be rejected"
    except HTTPException as exc:
        assert exc.status_code == 403
    db.close()


def test_audit_log_is_immutable():
    db = make_db()
    row = GovernanceAuditLog(request_id="r", action="create", entity_type="Customer", entity_id="1")
    db.add(row); db.commit()
    row.action = "delete"
    try:
        db.commit()
        assert False, "Audit log mutation must be rejected"
    except HTTPException as exc:
        assert exc.status_code == 409
        db.rollback()
    db.close()


def test_granular_route_policy():
    assert route_permission("GET", "/sales") == "sales:view"
    assert route_permission("POST", "/sales/new") == "sales:create"
    assert route_permission("POST", "/enterprise/journal/10/reverse") == "journal:reverse"
    assert route_permission("GET", "/accounting/reports/trial-balance") == "reports:view"
    assert route_permission("GET", "/api/v1/health") is None


def test_permission_engine_is_role_based():
    db = make_db()
    u = User(username="perm", full_name="Permission User", password_hash="x", role=RoleEnum.employee); db.add(u); db.flush()
    p = Permission(code="sales:create", description="Create sales"); r = Role(code="sales_role", name="Sales"); db.add_all([p,r]); db.flush()
    db.add(RolePermission(role_id=r.id, permission_id=p.id)); db.add(UserRole(user_id=u.id, role_id=r.id, is_active=True)); db.commit()
    assert _has_permission(db, u.id, "sales:create") is True
    assert _has_permission(db, u.id, "sales:post") is False
    db.close()


def test_orm_write_cannot_cross_active_tenant_boundary():
    db = make_db()
    ccy = Currency(code="EGP", name="Egyptian Pound"); db.add(ccy); db.flush()
    c1 = Company(code="C1", name="Company 1", base_currency_id=ccy.id)
    c2 = Company(code="C2", name="Company 2", base_currency_id=ccy.id)
    db.add_all([c1, c2]); db.flush()
    set_request_context(request_id="r-write", user_id=1, company_id=c1.id, branch_id=None)
    db.add(Customer(code="CROSS", name="Cross tenant", company_id=c2.id))
    try:
        db.commit()
        assert False, "Cross-tenant ORM writes must be rejected"
    except HTTPException as exc:
        assert exc.status_code == 403
        db.rollback()
    finally:
        clear_request_context(); db.close()
