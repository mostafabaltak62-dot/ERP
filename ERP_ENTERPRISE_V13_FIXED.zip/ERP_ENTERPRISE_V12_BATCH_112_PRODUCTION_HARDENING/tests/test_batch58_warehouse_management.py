from pathlib import Path

def test_warehouse_management_has_scope_and_governance_controls():
    router=Path('app/routers/commercial_workspace_router.py').read_text(encoding='utf-8')
    template=Path('templates/warehouses.html').read_text(encoding='utf-8')
    assert 'WAREHOUSE_TYPES' in router
    assert 'Warehouse.company_id == cid' in router
    assert 'branch_id' in router and 'project_id' in router
    assert 'لا يمكن ربط المخزن بفرع خارج نطاق الفرع الحالي' in router
    assert 'def edit_warehouse_form' in router
    assert 'def deactivate_warehouse' in router
    assert 'تعديل' in template and 'إيقاف' in template

def test_warehouse_migration_follows_patch56():
    text=Path('alembic/versions/p58_warehouse_management_hardening.py').read_text()
    assert "down_revision='p56_cost_control_authoritative_linkage'" in text
    assert 'ix_warehouses_company_branch_active' in text
