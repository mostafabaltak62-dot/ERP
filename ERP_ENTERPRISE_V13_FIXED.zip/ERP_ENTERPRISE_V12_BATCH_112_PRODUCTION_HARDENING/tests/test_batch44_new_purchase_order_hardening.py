from decimal import Decimal
import pytest
from fastapi import HTTPException
from app.routers.purchases_router import _parse_po_decimal, _validate_po_payment_method


def test_new_po_numeric_boundaries_are_finite_and_non_negative():
    assert _parse_po_decimal("0.01", "الكمية") == Decimal("0.01")
    assert _parse_po_decimal("1000000000000", "السعر") == Decimal("1000000000000")
    with pytest.raises(HTTPException):
        _parse_po_decimal("NaN", "الكمية")


def test_new_po_payment_method_allowlist_rejects_injected_values():
    for value in ("<script>alert(1)</script>", "javascript", "cash;DROP TABLE"):
        with pytest.raises(HTTPException):
            _validate_po_payment_method(value)
