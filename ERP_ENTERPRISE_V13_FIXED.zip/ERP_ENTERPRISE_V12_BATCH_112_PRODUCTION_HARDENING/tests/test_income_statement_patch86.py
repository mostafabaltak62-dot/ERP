from datetime import date, datetime
from decimal import Decimal
from app.enterprise_models import Company
from app.models import Account, AccountTypeEnum, JournalEntry, JournalLine
from app.financial_reporting import profit_and_loss, trial_balance
from app.database import SessionLocal


def _post(db,c,n,dt,lines,status='posted'):
    e=JournalEntry(company_id=c.id,entry_number=n,entry_date=dt,description=n,status='draft')
    db.add(e); db.flush()
    for a,d,cr in lines:
        db.add(JournalLine(company_id=c.id,entry_id=e.id,account_id=a.id,debit=d,credit=cr))
    db.flush(); e.status=status; db.commit(); return e


def test_income_statement_has_authoritative_profit_metrics_and_branch_scope():
    db=SessionLocal(); c=Company(code='P86',name='P86'); db.add(c); db.flush()
    cash=Account(company_id=c.id,code='1100',name='Cash',account_type=AccountTypeEnum.asset,normal_balance='debit')
    rev=Account(company_id=c.id,code='4100',name='Revenue',account_type=AccountTypeEnum.revenue,normal_balance='credit',statement_section='revenue')
    cogs=Account(company_id=c.id,code='5100',name='COGS',account_type=AccountTypeEnum.expense,normal_balance='debit',statement_section='cost_of_sales')
    opex=Account(company_id=c.id,code='5200',name='Opex',account_type=AccountTypeEnum.expense,normal_balance='debit',statement_section='operating_expenses')
    old=Account(company_id=c.id,code='4199',name='Retired Revenue',account_type=AccountTypeEnum.revenue,normal_balance='credit',statement_section='revenue',is_active=False)
    db.add_all([cash,rev,cogs,opex,old]); db.commit()
    _post(db,c,'S1',datetime(2026,1,2),[(cash,200,0),(rev,0,200)])
    _post(db,c,'S2',datetime(2026,1,3),[(cogs,80,0),(cash,0,80)])
    _post(db,c,'S3',datetime(2026,1,4),[(opex,30,0),(cash,0,30)])
    _post(db,c,'S4',datetime(2026,1,5),[(cash,20,0),(old,0,20)])
    r=profit_and_loss(db,c.id,date(2026,1,1),date(2026,1,31))
    assert r['revenue_total']==Decimal('220.00')
    assert r['gross_profit']==Decimal('140.00')
    assert r['operating_expenses']==Decimal('30.00')
    assert r['net_profit']==Decimal('110.00')
    assert r['gross_margin_pct']==Decimal('63.64')
    assert r['net_margin_pct']==Decimal('50.00')
    assert any(x['code']=='4199' for x in r['revenue_lines'])
    db.close()
