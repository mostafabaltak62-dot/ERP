from datetime import date, datetime
from types import SimpleNamespace
from decimal import Decimal

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models import Base, Account, AccountTypeEnum
from app.enterprise_models import Company
from app.accounting import create_entry
from app.governance import set_request_context, clear_request_context
from app.routers.advanced_finance_router import profitability


def setup():
    e = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(e)
    S = sessionmaker(bind=e)
    db = S()
    c = Company(code="P75", name="Profitability Co")
    db.add(c); db.flush()
    sales = Account(company_id=c.id, code="4100", name="Sales", account_type=AccountTypeEnum.revenue, is_active=True)
    cogs = Account(company_id=c.id, code="5100", name="COGS", account_type=AccountTypeEnum.expense, statement_section="cost_of_sales", is_active=True)
    opex = Account(company_id=c.id, code="6100", name="Opex", account_type=AccountTypeEnum.expense, statement_section="operating_expenses", is_active=True)
    cash = Account(company_id=c.id, code="1000", name="Cash", account_type=AccountTypeEnum.asset, is_active=True)
    db.add_all([sales, cogs, opex, cash]); db.flush(); db.commit()
    return db, c, sales, cogs, opex, cash


def post(db, c, num, dt, pairs):
    set_request_context(request_id=num, user_id=1, company_id=c.id, branch_id=None)
    create_entry(db, num, 1, [(a.code, d, cr) for a, d, cr in pairs], source_type="profitability_test", source_id=abs(hash((num, c.id))) % 100000000, entry_date=dt)
    db.commit(); clear_request_context()


def test_profitability_uses_authoritative_pnl_not_hardcoded_codes():
    db, c, sales, cogs, opex, cash = setup()
    post(db, c, "P75-1", datetime(2026, 1, 10), [(cash, "2000", "0"), (sales, "0", "2000")])
    post(db, c, "P75-2", datetime(2026, 1, 15), [(cogs, "800", "0"), (cash, "0", "800")])
    post(db, c, "P75-3", datetime(2026, 1, 20), [(opex, "300", "0"), (cash, "0", "300")])
    user = SimpleNamespace(id=1, full_name="Admin", role=SimpleNamespace(value="admin"))
    set_request_context(company_id=c.id, branch_id=None)
    response = profitability(SimpleNamespace(), "2026-01-01", "2026-01-31", None, db, user)
    ctx = response.context
    assert ctx["revenue"] == Decimal("2000.00")
    assert ctx["cogs"] == Decimal("800.00")
    assert ctx["gross"] == Decimal("1200.00")
    assert ctx["operating_expenses"] == Decimal("300.00")
    assert ctx["net_profit"] == Decimal("900.00")
    assert ctx["gross_margin_pct"] == Decimal("60.00")
    assert ctx["net_margin_pct"] == Decimal("45.00")
    clear_request_context()


def test_profitability_rejects_invalid_date_range():
    db, c, *_ = setup()
    user = SimpleNamespace(id=1, full_name="Admin", role=SimpleNamespace(value="admin"))
    set_request_context(company_id=c.id, branch_id=None)
    try:
        try:
            profitability(SimpleNamespace(), "2026-02-01", "2026-01-01", None, db, user)
            assert False, "expected HTTPException"
        except Exception as exc:
            assert getattr(exc, "status_code", None) == 422
    finally:
        clear_request_context()
