from decimal import Decimal
import pytest
from fastapi import HTTPException
from app.routers.purchases_router import _clean_supplier_payload, _masked


def payload(**kw):
    base=dict(code='SUP-046',name='Supplier 46',phone='',email='TEST@EXAMPLE.COM',address='',legal_name='',supplier_type='company',contact_person='',tax_number='',registration_number='',country='',city='',postal_code='',payment_terms_days='30',preferred_payment_method='',currency_code='egp',credit_limit='1000.50',bank_name='',bank_account_name='',bank_account_number='',iban='',swift_code='')
    base.update(kw)
    return _clean_supplier_payload(**base)


def test_supplier_payload_rejects_non_finite_credit_limit():
    with pytest.raises(HTTPException): payload(credit_limit='NaN')
    with pytest.raises(HTTPException): payload(credit_limit='Infinity')


def test_supplier_payload_rejects_invalid_payment_terms():
    with pytest.raises(HTTPException): payload(payment_terms_days='-1')
    with pytest.raises(HTTPException): payload(payment_terms_days='3651')


def test_supplier_bank_values_are_masked_for_detail_display():
    assert _masked('1234567890') == '******7890'
    assert _masked('EG1234567890', 4) == '********7890'
    assert _masked(None) is None


def test_supplier_page_contract_has_pagination_and_status_controls():
    from pathlib import Path
    html=Path('templates/supplier_list.html').read_text(encoding='utf-8')
    assert 'name="status"' in html
    assert 'page={{ page+1 }}' in html
    assert 'bank' not in html.lower()

def test_supplier_currency_is_treated_as_historical_financial_master_data():
    from pathlib import Path
    src=Path('app/routers/purchases_router.py').read_text(encoding='utf-8')
    assert 'has_financial_history' in src
    assert 'لا يمكن تغيير عملة المورد بعد وجود فواتير شراء' in src

def test_supplier_context_fails_closed():
    from pathlib import Path
    src=Path('app/routers/purchases_router.py').read_text(encoding='utf-8')
    assert 'if not company_id:' in src
    assert 'if not cid: raise HTTPException(403' in src
