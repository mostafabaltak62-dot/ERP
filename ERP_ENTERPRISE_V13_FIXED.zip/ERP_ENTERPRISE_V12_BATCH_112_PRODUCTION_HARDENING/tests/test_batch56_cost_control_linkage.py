from datetime import date, datetime
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
from app.enterprise_models import Company, Project, ProjectCost
from app.construction_models import ConstructionCostCode, WBSNode, ConstructionCostBudgetLine, ConstructionCommitment, ConstructionCostForecastVersion
from app.construction_services import (create_cost_budget_revision, approve_cost_budget_revision, authoritative_budget_total,
    reconcile_project_costs, generate_cost_forecast, refresh_cost_alerts)

def setup():
    import app.construction_models
    e=create_engine('sqlite:///:memory:')
    Base.metadata.create_all(e); S=sessionmaker(bind=e); db=S()
    c=Company(code='C56',name='Linkage Co'); db.add(c); db.flush()
    p=Project(company_id=c.id,code='P56',name='Project 56',budget=10000); db.add(p); db.flush()
    cc=ConstructionCostCode(company_id=c.id,code='01',name='Civil',category='material',is_active=True); db.add(cc); db.flush()
    w=WBSNode(company_id=c.id,project_id=p.id,code='1',name='Civil',level=1,budget_amount=1000,is_active=True); db.add(w); db.flush()
    db.add(ConstructionCostBudgetLine(company_id=c.id,project_id=p.id,cost_code_id=cc.id,wbs_id=w.id,description='Base',budget_amount=1000,budget_date=date(2026,9,1),status='active'))
    db.commit(); return db,c,p,cc,w

def test_approved_revision_changes_authoritative_budget():
    db,c,p,cc,w=setup()
    assert authoritative_budget_total(db,c.id,p.id)==Decimal('1000.00')
    r=create_cost_budget_revision(db,c.id,p.id,date(2026,9,2),'Scope increase',7,[{'cost_code_id':cc.id,'wbs_id':w.id,'period_date':date(2026,9,1),'delta_amount':250}])
    approve_cost_budget_revision(db,c.id,r.id,8)
    assert authoritative_budget_total(db,c.id,p.id)==Decimal('1250.00')

def test_reconciliation_and_alerts():
    db,c,p,cc,w=setup()
    db.add(ProjectCost(company_id=c.id,project_id=p.id,cost_type='material',source_type='test',source_id=1,amount=1100,cost_date=datetime(2026,9,5),description='Actual'))
    db.add(ConstructionCommitment(company_id=c.id,project_id=p.id,cost_code_id=cc.id,wbs_id=w.id,source_type='test',commitment_date=date(2026,9,5),description='Commitment',committed_amount=200,released_amount=0,status='open'))
    db.commit()
    r=reconcile_project_costs(db,c.id,p.id,date(2026,9,30)); assert r.unreconciled_amount==Decimal('100.00') and r.status=='exception'
    alerts=refresh_cost_alerts(db,c.id,p.id,date(2026,9,30)); assert any(a.alert_type=='RECONCILIATION_EXCEPTION' for a in alerts)

def test_automatic_forecast_creates_version():
    db,c,p,cc,w=setup()
    db.add(ProjectCost(company_id=c.id,project_id=p.id,cost_type='material',source_type='test',source_id=1,amount=400,cost_date=datetime(2026,9,5),description='Actual')); db.commit()
    v=generate_cost_forecast(db,c.id,p.id,date(2026,9,30),7,'remaining_budget')
    assert v.version_no==1 and Decimal(str(v.total_etc))==Decimal('600.00') and Decimal(str(v.total_eac))==Decimal('1000.00')
