import json
from datetime import date
from types import SimpleNamespace
from pathlib import Path
from openpyxl import load_workbook

from app.routers.construction_document_forms_router import (
    FORM_TYPES, FORM_SCHEMAS, _validate, FormIn, _excel_response, _pdf_response,
)

EXPECTED = {'SIR','MIR','MT','DWG','LITER','BOQ','RFI','V.O','QS','SNA','DOC','POUR','INITIAL_HANDOVER','FINAL_HANDOVER','LOG'}

def test_all_15_workspace_cards_have_schema_and_metadata():
    assert set(FORM_TYPES) == EXPECTED
    assert set(FORM_SCHEMAS) == EXPECTED
    for code in EXPECTED:
        assert FORM_TYPES[code]['label_ar'] and FORM_TYPES[code]['label_en']
        assert FORM_SCHEMAS[code]
        assert all(len(f) >= 4 for s in FORM_SCHEMAS[code] for f in s['fields'])

def test_server_validation_covers_required_schema_fields():
    for code in EXPECTED:
        data={}
        for sec in FORM_SCHEMAS[code]:
            for f in sec['fields']:
                if f[3]:
                    data[f[0]] = (f[4][0] if f[2]=='select' and f[4] else ('1' if f[2]=='number' else ('2026-09-02' if f[2]=='date' else 'X')))
        _validate(FormIn(project_id=1, form_type=code, title='Test Form', data=data))

def test_workspace_contains_all_expected_cards():
    text=Path('app/routers/construction_document_forms_router.py').read_text()
    for code in EXPECTED:
        assert f"'{code}':" in text
    assert '/ui/export/xlsx/' in text
    assert '/ui/export/pdf/' in text
    assert '/ui/edit/' in text

def test_export_generators_produce_real_xlsx_and_pdf_for_all_15_forms():
    for code in sorted(EXPECTED):
        row=SimpleNamespace(form_no=f'{code.replace(".","-")}-1-2026-0001',status='draft',submission_type='new',discipline='مدني',zone='A',level='01',issue_date=date(2026,9,2),due_date=date(2026,9,5),current_revision=0,contractor_representative='Contractor',consultant_representative='Consultant')
        project=SimpleNamespace(name='Test Project')
        meta=FORM_TYPES[code]; schema=FORM_SCHEMAS[code]; data={}
        for sec in schema:
            for f in sec['fields']:
                if f[3]: data[f[0]]=(f[4][0] if f[2]=='select' and f[4] else 'X')
        x=_excel_response(row,project,meta,schema,data)
        body=x.body
        wb=load_workbook(__import__('io').BytesIO(body), read_only=True)
        ws=wb.active
        values=[c.value for rowv in ws.iter_rows(min_row=1,max_row=80) for c in rowv]
        assert row.form_no in values
        assert any(v == 'X' for v in values)
        p=_pdf_response(row,project,meta,schema,data)
        pdf=p.body
        assert pdf.startswith(b'%PDF-') and len(pdf)>1000

def test_no_fake_full_suite_assertion_in_legacy_accounting_test():
    text=Path('tests/test_patch101_general_accounting.py').read_text()
    assert ' or True' not in text

def test_schema_validation_rejects_tampered_selects_dates_and_negative_quantities():
    base={}
    for sec in FORM_SCHEMAS['MIR']:
        for f in sec['fields']:
            if f[3]: base[f[0]]=f[4][0] if f[2]=='select' and f[4] else ('1' if f[2]=='number' else ('2026-09-02' if f[2]=='date' else 'X'))
    bad=dict(base); bad['material']='Steel'; bad['supplier']='Supplier'; bad['quantity']='-1'
    import pytest
    with pytest.raises(Exception): _validate(FormIn(project_id=1,form_type='MIR',title='MIR',data=bad))
    bad=dict(base); bad['quantity']='1'; bad['inspection_date']='not-a-date'
    with pytest.raises(Exception): _validate(FormIn(project_id=1,form_type='MIR',title='MIR',data=bad))
