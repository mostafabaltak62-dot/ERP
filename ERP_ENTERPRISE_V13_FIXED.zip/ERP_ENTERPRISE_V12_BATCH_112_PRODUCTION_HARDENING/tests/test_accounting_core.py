import datetime
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models import Base, Account, AccountTypeEnum, AccountingPeriod, JournalEntry, JournalLine
from app.accounting import ensure_default_accounts, create_entry


@pytest.fixture()
def db():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    ensure_default_accounts(session)
    yield session
    session.close()


def test_balanced_entry_posts(db):
    entry = create_entry(
        db, "test", 1,
        [("1100", "100.00", "0"), ("4100", "0", "100.00")],
        "test_source", 1,
        datetime.datetime(2026, 8, 24),
    )
    db.commit()
    assert entry.status == "posted"
    assert sum(x.debit for x in entry.lines) == sum(x.credit for x in entry.lines)


def test_unbalanced_entry_rejected(db):
    with pytest.raises(Exception):
        create_entry(db, "bad", 1, [("1100", 100, 0), ("4100", 0, 90)])


def test_closed_period_rejected(db):
    db.add(AccountingPeriod(
        name="2026-08",
        start_date=datetime.datetime(2026, 8, 1),
        end_date=datetime.datetime(2026, 8, 31),
        is_closed=True,
    ))
    db.commit()
    with pytest.raises(Exception):
        create_entry(
            db, "closed", 1,
            [("1100", 100, 0), ("4100", 0, 100)],
            "closed_test", 1,
            datetime.datetime(2026, 8, 24),
        )


def test_duplicate_source_rejected(db):
    create_entry(db, "one", 1, [("1100", 10, 0), ("4100", 0, 10)], "same", 77)
    db.commit()
    with pytest.raises(Exception):
        create_entry(db, "two", 1, [("1100", 10, 0), ("4100", 0, 10)], "same", 77)


def test_posted_entry_is_immutable(db):
    entry = create_entry(db, "immutable", 1, [("1100", 10, 0), ("4100", 0, 10)], "immutable", 88)
    db.commit()
    entry.description = "tampered"
    with pytest.raises(ValueError):
        db.commit()


def test_posted_entry_cannot_receive_new_lines(db):
    entry = create_entry(db, "immutable-lines", 1, [("1100", 10, 0), ("4100", 0, 10)], "immutable-lines", 99)
    db.commit()
    db.add(JournalLine(entry_id=entry.id, account_id=db.query(Account).filter_by(code="1100").one().id, debit=1, credit=0))
    with pytest.raises(ValueError):
        db.commit()
    db.rollback()


def test_accounting_period_dates_are_database_constrained(db):
    db.add(AccountingPeriod(name="bad", start_date=datetime.datetime(2026, 9, 1), end_date=datetime.datetime(2026, 8, 1)))
    with pytest.raises(Exception):
        db.commit()
    db.rollback()
