from decimal import Decimal
from datetime import date
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
import app.construction_models
from app.enterprise_models import Company, Project, ProjectCost
from app.construction_services import create_wbs, create_activity, create_schedule_baseline, create_progress_period, set_activity_progress, create_time_phased_budget, create_evm_cost_allocation, construction_performance_dashboard

def test_phase641_wbs_boq_style_rollup_and_trend():
    e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); S=sessionmaker(bind=e); db=S()
    c=Company(code='C641',name='Rollup Co'); db.add(c); db.flush(); p=Project(company_id=c.id,code='P641',name='Tower',budget=100000); db.add(p); db.flush()
    w=create_wbs(db,c.id,p.id,'03','Concrete',100000)
    a=create_activity(db,c.id,p.id,'A-01','Concrete',date(2026,8,1),date(2026,9,30),100000,wbs_id=w.id)
    b=create_schedule_baseline(db,c.id,p.id,1,date(2026,8,1),[{'activity_id':a.id,'planned_start':date(2026,8,1),'planned_finish':date(2026,9,30),'budget_amount':100000}])
    create_time_phased_budget(db,c.id,p.id,date(2026,8,25),40000,b.id,a.id)
    period=create_progress_period(db,c.id,p.id,date(2026,8,25),b.id); set_activity_progress(db,c.id,p.id,period.id,a.id,30)
    pc=ProjectCost(company_id=c.id,project_id=p.id,cost_type='labor',source_type='test',source_id=641,amount=35000); db.add(pc); db.flush()
    create_evm_cost_allocation(db,c.id,p.id,pc.id,35000,wbs_id=w.id); db.flush()
    dash=construction_performance_dashboard(db,c.id,p.id,date(2026,8,25),b.id)
    assert dash['project']['pv']==Decimal('40000.00'); assert dash['project']['ev']==Decimal('30000.00')
    assert dash['wbs'][0]['ac']==Decimal('35000.00'); assert dash['wbs'][0]['cpi']==Decimal('0.85714286'); assert dash['wbs'][0]['spi']==Decimal('0.75000000')
