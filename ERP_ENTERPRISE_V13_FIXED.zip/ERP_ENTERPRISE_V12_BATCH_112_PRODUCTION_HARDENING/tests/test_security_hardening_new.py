import os
from fastapi.testclient import TestClient
from app.main import app
from app.security_hardening import rate_limit_check
from app.auth import hash_password, verify_password


def test_auth_rate_limit_is_five_per_minute():
    key = "auth:test-security-hardening"
    assert all(rate_limit_check(key, 5, now=1000 + i)[0] for i in range(5))
    allowed, retry = rate_limit_check(key, 5, now=1005)
    assert allowed is False
    assert retry > 0


def test_api_rate_limit_returns_429():
    key = "api:test-security-hardening"
    for i in range(100):
        assert rate_limit_check(key, 100, now=2000 + (i * 0.1))[0]
    allowed, retry = rate_limit_check(key, 100, now=2010)
    assert allowed is False
    assert retry > 0


def test_password_policy_and_bcrypt():
    password = "StrongPassword" + os.urandom(8).hex() + "1!"
    hashed = hash_password(password)
    assert verify_password(password, hashed)
    assert not verify_password("WrongPassword123!", hashed)


def test_mobile_refresh_token_rotation_and_replay_protection():
    with TestClient(app) as client:
        login = client.post("/api/v1/mobile/auth/login", json={
            "username": "admin",
            "password": os.environ["ERP_BOOTSTRAP_ADMIN_PASSWORD"],
            "company_id": 1,
        })
        if login.status_code == 403:
            # Existing test databases can have a non-1 DEFAULT company id.
            from app.database import SessionLocal
            from app.enterprise_models import Company
            db = SessionLocal()
            try:
                cid = db.query(Company.id).filter(Company.code == "DEFAULT").order_by(Company.id).first()[0]
            finally:
                db.close()
            login = client.post("/api/v1/mobile/auth/login", json={
                "username": "admin",
                "password": os.environ["ERP_BOOTSTRAP_ADMIN_PASSWORD"],
                "company_id": cid,
            })
        assert login.status_code == 200, login.text
        refresh = login.json()["refresh_token"]
        rotated = client.post("/api/v1/mobile/auth/refresh", json={"refresh_token": refresh})
        assert rotated.status_code == 200, rotated.text
        new_refresh = rotated.json()["refresh_token"]
        replay = client.post("/api/v1/mobile/auth/refresh", json={"refresh_token": refresh})
        assert replay.status_code == 401
        assert new_refresh != refresh


def test_auth_endpoints_are_classified_as_strictly_rate_limited():
    from app.main import app
    from app.governance import route_permission
    from app.security_hardening import AUTH_LIMIT
    # Source-level guard for the middleware policy: recovery and mobile refresh
    # must use the same 5/min bucket as login, rather than the generic API limit.
    source = __import__('pathlib').Path(__file__).parents[1].joinpath('app/main.py').read_text(encoding='utf-8')
    assert '"/forgot-password/request"' in source
    assert '"/forgot-password/verify"' in source
    assert '"/forgot-password/complete"' in source
    assert '"/api/v1/mobile/auth/refresh"' in source
    assert AUTH_LIMIT == 5
    assert route_permission("POST", "/api/v1/deep-transactions/reconcile") == "journal:post"


def test_redis_rate_limiter_path_is_used_even_with_fractional_time(monkeypatch):
    from app import security_hardening as sh

    class FakeRedis:
        def __init__(self): self.count = 0; self.expirations = []
        def incr(self, key): self.count += 1; return self.count
        def expire(self, key, seconds): self.expirations.append((key, seconds))

    fake = FakeRedis()
    monkeypatch.setattr(sh, '_redis', fake)
    monkeypatch.setattr(sh, '_buckets', {})
    assert sh.rate_limit_check('api:redis-test', 2, now=1234.25)[0]
    assert sh.rate_limit_check('api:redis-test', 2, now=1234.75)[0]
    allowed, retry = sh.rate_limit_check('api:redis-test', 2, now=1235.25)
    assert allowed is False
    assert retry > 0
    assert fake.count == 3
