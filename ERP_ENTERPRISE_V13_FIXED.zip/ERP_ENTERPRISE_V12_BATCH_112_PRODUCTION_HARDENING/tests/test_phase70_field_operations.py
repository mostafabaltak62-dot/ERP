from datetime import date, datetime
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
import app.enterprise_models, app.construction_models, app.enterprise_plus_models, app.field_ops_models, app.governance_models, app.hr_models, app.document_models
from app.enterprise_models import Company, Project, Equipment, Contract, ProjectCost
from app.models import Item
from app.construction_models import ConstructionVariation, ConstructionSite, BOQRevision, BOQLine
from app.field_ops_services import create_equipment_log, add_equipment_cost, post_equipment_log, approve_variation_amendment, create_material_requisition, approve_material_requisition, fulfill_material_requisition, BudgetExceeded, submit_offline_batch, process_offline_batch, create_webhook_subscription, enqueue_webhook_event, webhook_signature

class U: id=1

def db():
    e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); return sessionmaker(bind=e)()

def test_equipment_log_estimated_vs_actual_and_project_cost():
    s=db(); c=Company(code='F70',name='Field'); s.add(c); s.flush(); p=Project(company_id=c.id,code='P1',name='Site',budget=100000); eq=Equipment(company_id=c.id,code='EX1',name='Excavator',hourly_rate=100); s.add_all([p,eq]); s.flush()
    log=create_equipment_log(s,c.id,p.id,eq.id,date(2026,8,25),0,8); assert Decimal(str(log.estimated_cost))==Decimal('800.000000')
    add_equipment_cost(s,c.id,eq.id,p.id,'fuel',160,date(2026,8,25),equipment_log_id=log.id); add_equipment_cost(s,c.id,eq.id,p.id,'maintenance',40,date(2026,8,25),equipment_log_id=log.id); s.flush()
    assert Decimal(str(log.actual_cost))==Decimal('1000.000000'); assert Decimal(str(log.actual_hourly_cost))==Decimal('125.000000'); assert Decimal(str(log.variance_amount))==Decimal('200.000000')
    post_equipment_log(s,c.id,log.id); s.commit(); assert s.query(ProjectCost).filter_by(source_type='equipment_log',source_id=log.id).count()==1

def test_variation_amendment_updates_budget_and_contract_once():
    s=db(); c=Company(code='F71',name='Commercial'); s.add(c); s.flush(); p=Project(company_id=c.id,code='P1',name='Project',budget=1000); s.add(p); s.flush(); ct=Contract(company_id=c.id,contract_number='C1',contract_type='customer',project_id=p.id,value=1000); s.add(ct); s.flush(); v=ConstructionVariation(company_id=c.id,project_id=p.id,contract_id=ct.id,variation_no='VO-1',description='Extra work',amount=250); s.add(v); s.flush()
    approve_variation_amendment(s,c.id,v.id,'VOA-1',1); s.commit(); assert p.budget==Decimal('1250.000000'); assert ct.value==Decimal('1250.000000'); approve_variation_amendment(s,c.id,v.id,'VOA-2',1); assert p.budget==Decimal('1250.000000')

def test_material_requisition_budget_guard_and_workflow():
    s=db(); c=Company(code='F72',name='Materials'); s.add(c); s.flush(); p=Project(company_id=c.id,code='P1',name='Project',budget=100000); i=Item(company_id=c.id,code='MAT1',name='Concrete'); s.add_all([p,i]); s.flush()
    req=create_material_requisition(s,c.id,p.id,'MR-1',[{'item_id':i.id,'requested_qty':8,'estimated_unit_cost':10,'budget_qty':10}],1); s.commit(); approve_material_requisition(s,c.id,req.id,1); fulfill_material_requisition(s,c.id,req.id,'stock_issue','ISS-1'); s.commit(); assert req.status=='fulfilled'
    try: create_material_requisition(s,c.id,p.id,'MR-2',[{'item_id':i.id,'requested_qty':3,'estimated_unit_cost':10,'budget_qty':10}],1); assert False
    except BudgetExceeded: pass

def test_offline_sync_and_webhook_queue_are_idempotent():
    s=db(); c=Company(code='F73',name='Integration'); s.add(c); s.flush(); b=submit_offline_batch(s,c.id,'device-1','batch-1',1,[{'operation_id':'op-1','entity_type':'site_requisition','entity_id':10,'operation':'update','payload':{'status':'approved'},'client_version':1}]); process_offline_batch(s,c.id,b.id); s.commit(); assert b.status=='processed'; b2=submit_offline_batch(s,c.id,'device-1','batch-1',1,[]); assert b2.id==b.id
    sub=create_webhook_subscription(s,c.id,'Budget Alerts','https://example.test/hook',__import__('secrets').token_urlsafe(24),'budget.exceeded'); event,count=enqueue_webhook_event(s,c.id,'budget.exceeded',{'project_id':1}); s.commit(); assert count==1; assert webhook_signature('runtime-test-secret',{'project_id':1}); assert event

def test_field_workflow_material_to_certificate_end_to_end():
    s=db(); c=Company(code='F74',name='End to End'); s.add(c); s.flush(); p=Project(company_id=c.id,code='P1',name='Project',budget=100000); s.add(p); s.flush()
    item=Item(company_id=c.id,code='MAT-E2E',name='Concrete'); s.add(item); s.flush()
    req=create_material_requisition(s,c.id,p.id,'MR-E2E',[{'item_id':item.id,'requested_qty':5,'estimated_unit_cost':100,'budget_qty':10}],1)
    approve_material_requisition(s,c.id,req.id,1); fulfill_material_requisition(s,c.id,req.id,'stock_issue','ISS-E2E')
    s.add(ProjectCost(company_id=c.id,project_id=p.id,cost_type='material',source_type='site_material_requisition',source_id=req.id,amount=500)); s.flush()
    boq=BOQRevision(company_id=c.id,project_id=p.id,revision_no=1,status='approved',effective_date=date(2026,8,25)); s.add(boq); s.flush()
    line=BOQLine(company_id=c.id,revision_id=boq.id,project_id=p.id,item_code='01',description='Concrete',unit='m3',contract_qty=10,contract_rate=100); s.add(line); s.flush()
    from app.construction_services import record_measurement, approve_measurement, create_progress_certificate, approve_certificate
    m,_=record_measurement(s,c.id,p.id,'M-E2E',date(2026,8,25),1,[{'boq_line_id':line.id,'current_qty':5,'cumulative_qty':5}])
    approve_measurement(s,c.id,m.id)
    cert=create_progress_certificate(s,c.id,p.id,'PC-E2E',date(2026,8,25),1,[{'boq_line_id':line.id,'current_qty':5,'cumulative_qty':5}],0,0)
    assert cert.gross_amount==Decimal('500.000000')
    # Accounting posting requires a customer contract; the cost/request leg remains traceable before revenue posting.
    s.commit(); assert s.query(ProjectCost).filter_by(source_type='site_material_requisition',source_id=req.id).count()==1


def test_license_alerts_and_budget_webhook_queue():
    s=db(); c=Company(code='F75',name='Alerts'); s.add(c); s.flush(); p=Project(company_id=c.id,code='P1',name='Project',budget=100); s.add(p); s.flush()
    create_webhook_subscription(s,c.id,'Alerts','https://example.test/hook',__import__('secrets').token_urlsafe(24),'license.expiring')
    from app.field_ops_services import create_license, evaluate_license_alerts
    create_license(s,c.id,'Equipment Permit','LIC-1',date(2026,9,1),30,project_id=p.id); alerts=evaluate_license_alerts(s,c.id,date(2026,8,25)); s.commit(); assert alerts and alerts[0][1]=='expiring'

def test_existing_fuel_and_maintenance_are_project_costed():
    from app.enterprise_models import FuelTransaction, MaintenanceRecord
    s=db(); c=Company(code='F76',name='Fleet Cost'); s.add(c); s.flush(); p=Project(company_id=c.id,code='P1',name='Project',budget=10000); eq=Equipment(company_id=c.id,code='EQ1',name='Crane',hourly_rate=80); s.add_all([p,eq]); s.flush()
    fuel=FuelTransaction(company_id=c.id,equipment_id=eq.id,transaction_date=datetime(2026,8,25,9),quantity=20,unit_cost=10,total_cost=200); maint=MaintenanceRecord(company_id=c.id,equipment_id=eq.id,maintenance_date=date(2026,8,25),cost=150,description='Service'); s.add_all([fuel,maint]); s.flush()
    from app.field_ops_services import allocate_existing_fuel_transaction, allocate_existing_maintenance_record
    f=allocate_existing_fuel_transaction(s,c.id,fuel.id,p.id); m=allocate_existing_maintenance_record(s,c.id,maint.id,p.id); s.commit()
    assert f.project_cost_id and m.project_cost_id
    assert sum(Decimal(str(x.amount)) for x in s.query(ProjectCost).filter(ProjectCost.project_id==p.id).all())==Decimal('350.000000')
