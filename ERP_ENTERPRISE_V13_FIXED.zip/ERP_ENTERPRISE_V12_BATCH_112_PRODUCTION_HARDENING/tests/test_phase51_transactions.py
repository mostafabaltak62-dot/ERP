import datetime
from decimal import Decimal
from sqlalchemy import create_engine, func, case
from sqlalchemy.orm import sessionmaker

from app.models import Base, User, RoleEnum, Item, ItemTypeEnum, Customer, Supplier, StockMovement, MovementTypeEnum, TaxRate, JournalEntry, FinanceVoucher, PaymentAllocation
from app.enterprise_models import Company, Branch, Currency
from app.accounting import ensure_default_accounts
from app.governance import set_request_context, clear_request_context
from app.transaction_services import create_sales_order, confirm_sales_order, deliver_sales_order, invoice_sales_delivery, create_purchase_invoice, create_customer_receipt, create_supplier_payment


def setup_db():
    clear_request_context()
    engine=create_engine('sqlite:///:memory:', connect_args={'check_same_thread':False})
    Base.metadata.create_all(engine)
    S=sessionmaker(bind=engine); db=S()
    cur=Currency(code='EGP', name='Egyptian Pound', decimal_places=2, is_active=True); db.add(cur); db.flush()
    company=Company(code='C1', name='Company 1', base_currency_id=cur.id, is_active=True); db.add(company); db.flush()
    branch=Branch(company_id=company.id, code='B1', name='Branch 1', is_active=True); db.add(branch)
    user=User(username='u1', full_name='User 1', password_hash='x', role=RoleEnum.admin, is_active=True); db.add(user); db.flush()
    customer=Customer(company_id=company.id, code='CUS1', name='Customer'); supplier=Supplier(company_id=company.id, code='SUP1', name='Supplier')
    item=Item(company_id=company.id, code='IT1', name='Product', item_type=ItemTypeEnum.product, purchase_price=Decimal('60'), sale_price=Decimal('100'))
    tax=TaxRate(company_id=company.id, code='VAT10', name='VAT 10%', rate=Decimal('10'), tax_account_code='2200')
    db.add_all([customer,supplier,item,tax]); db.flush()
    db.add(StockMovement(company_id=company.id, item_id=item.id, movement_type=MovementTypeEnum.in_, quantity=Decimal('10'), unit_cost=Decimal('60'), total_cost=Decimal('600'), created_by_id=user.id))
    db.commit()
    set_request_context(request_id='test', user_id=user.id, company_id=company.id, branch_id=branch.id, ip_address='127.0.0.1')
    ensure_default_accounts(db, company.id)
    db.commit()
    return db, company, user, customer, supplier, item, tax


def test_sales_order_delivery_invoice_payment_is_atomic_and_balanced():
    db, company, user, customer, supplier, item, tax=setup_db()
    try:
        order=create_sales_order(db, company.id, user.id, customer.id, [{'item_id':item.id,'quantity':2,'unit_price':100}], 'credit')
        confirm_sales_order(db, order.id, company.id)
        delivery=deliver_sales_order(db, order.id, company.id, user.id)
        invoice=invoice_sales_delivery(db, delivery.id, company.id, user.id, tax.id)
        assert invoice.subtotal == Decimal('200.000000')
        assert invoice.tax_amount == Decimal('20.000000')
        assert invoice.total_amount == Decimal('220.000000')
        payment=create_customer_receipt(db, company.id, user.id, invoice.id, Decimal('100'))
        db.commit()
        assert payment.amount == Decimal('100.000000')
        assert db.query(PaymentAllocation).filter(PaymentAllocation.sale_invoice_id==invoice.id).one().amount == Decimal('100.000000')
        assert db.query(StockMovement).filter(StockMovement.item_id==item.id, StockMovement.movement_type==MovementTypeEnum.out).one().quantity == Decimal('2.000000')
        for entry in db.query(JournalEntry).all():
            debit=sum((x.debit for x in entry.lines), Decimal('0')); credit=sum((x.credit for x in entry.lines), Decimal('0'))
            assert debit == credit
    finally:
        clear_request_context(); db.close()


def test_purchase_invoice_and_partial_supplier_payment():
    db, company, user, customer, supplier, item, tax=setup_db()
    try:
        inv=create_purchase_invoice(db, company.id, user.id, supplier.id, [{'item_id':item.id,'quantity':3,'unit_price':70}], tax_rate_id=tax.id)
        pay=create_supplier_payment(db, company.id, user.id, inv.id, Decimal('50'))
        db.commit()
        assert inv.total_amount == Decimal('231.000000')
        assert pay.amount == Decimal('50.000000')
        alloc=db.query(PaymentAllocation).filter(PaymentAllocation.purchase_invoice_id==inv.id).one()
        assert alloc.amount == Decimal('50.000000')
    finally:
        clear_request_context(); db.close()


def test_transaction_rolls_back_if_delivery_fails():
    db, company, user, customer, supplier, item, tax=setup_db()
    try:
        order=create_sales_order(db, company.id, user.id, customer.id, [{'item_id':item.id,'quantity':20,'unit_price':100}], 'credit')
        db.flush(); confirm_sales_order(db, order.id, company.id)
        try:
            deliver_sales_order(db, order.id, company.id, user.id)
        except Exception:
            db.rollback()
        assert db.query(StockMovement).filter(StockMovement.item_id==item.id, StockMovement.movement_type==MovementTypeEnum.out).count() == 0
        assert db.query(JournalEntry).count() == 0
    finally:
        clear_request_context(); db.close()
