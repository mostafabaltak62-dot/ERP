from decimal import Decimal
import pytest
from fastapi import HTTPException
from app.routers.purchases_router import _parse_po_decimal, _validate_po_payment_method


def test_po_decimal_rejects_nan_and_infinity():
    with pytest.raises(HTTPException): _parse_po_decimal("NaN", "الكمية")
    with pytest.raises(HTTPException): _parse_po_decimal("Infinity", "السعر")
    assert _parse_po_decimal("12.50", "الكمية") == Decimal("12.50")


def test_po_payment_method_is_allowlisted():
    assert _validate_po_payment_method("نقدي") == "نقدي"
    assert _validate_po_payment_method("credit") == "credit"
    with pytest.raises(HTTPException): _validate_po_payment_method("javascript")
