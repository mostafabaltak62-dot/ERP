from decimal import Decimal
from datetime import date
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
from app.enterprise_models import Company, Project, Contract
from app.construction_models import (
    ConstructionCostCode, SubcontractorBOQLine, SubcontractorMeasurement,
    SubcontractorProgress, ConstructionCostBudgetLine, ConstructionCommitment,
    ConstructionCostForecast
)
from app.construction_services import (
    create_subcontractor_boq_line, create_subcontractor_measurement,
    approve_subcontractor_measurement, create_subcontractor_progress_from_measurement,
    approve_subcontractor_progress, create_advance, create_cost_budget_line, create_commitment,
    create_cost_forecast, construction_cost_control, project_profitability,
    subcontractor_control
)
from app.accounting import ensure_default_accounts

def setup():
    import app.construction_models
    e=create_engine('sqlite:///:memory:')
    Base.metadata.create_all(e)
    S=sessionmaker(bind=e); db=S()
    c=Company(code='C63',name='Cost Control Co'); db.add(c); db.flush()
    p=Project(company_id=c.id,code='P63',name='Tower 63',budget=100000); db.add(p); db.flush()
    sub=Contract(company_id=c.id,contract_number='SUB63',contract_type='subcontractor',project_id=p.id,value=50000); db.add(sub); db.flush()
    ensure_default_accounts(db,c.id); db.commit()
    return db,c,p,sub

def test_subcontractor_boq_measurement_certificate_and_actual_are_linked():
    db,c,p,sub=setup()
    boq=create_subcontractor_boq_line(db,c.id,p.id,sub.id,'S-01','Concrete','m3',100,500)
    m,total=create_subcontractor_measurement(db,c.id,p.id,sub.id,'SM-63',date(2026,8,1),1,[
        {'subcontractor_boq_line_id':boq.id,'current_qty':20,'cumulative_qty':20}
    ])
    assert total==Decimal('10000.00')
    approve_subcontractor_measurement(db,c.id,m.id)
    create_advance(db,c.id,p.id,sub.id,'payable',1000,date(2026,7,1),'ADV-63',user_id=1)
    cert=create_subcontractor_progress_from_measurement(db,c.id,p.id,sub.id,'SC-63',date(2026,8,10),m.id,500,1000,200,1)
    assert cert.gross_amount==Decimal('10000.00')
    posted=approve_subcontractor_progress(db,c.id,cert.id,1)
    assert posted.measurement_id==m.id and posted.journal_entry_id
    assert db.query(SubcontractorProgress).count()==1
    # Gross less commercial deductions is recognized construction actual.
    from app.enterprise_models import ProjectCost
    pc=db.query(ProjectCost).filter_by(source_type='subcontractor_progress',source_id=cert.id).one()
    assert pc.amount==Decimal('9800.00')

def test_budget_commitment_actual_forecast_eac_and_profitability():
    db,c,p,sub=setup()
    create_cost_budget_line(db,c.id,p.id,'Concrete package',20000)
    create_commitment(db,c.id,p.id,'Subcontract package',15000,date(2026,8,1),contract_id=sub.id)
    from app.enterprise_models import ProjectCost
    db.add(ProjectCost(company_id=c.id,project_id=p.id,cost_type='labor',source_type='test',source_id=1,amount=4000))
    db.flush()
    create_cost_forecast(db,c.id,p.id,'Remaining concrete',7000,date(2026,9,1))
    ctl=construction_cost_control(db,c.id,p.id)
    assert ctl['budget']==Decimal('20000.00')
    assert ctl['commitment']==Decimal('15000.00')
    assert ctl['actual']==Decimal('4000.00')
    assert ctl['forecast_etc']==Decimal('7000.00')
    assert ctl['eac']==Decimal('11000.00')
    assert ctl['variance_at_completion']==Decimal('9000.00')

def test_subcontractor_control_reports_retention_and_advance_balance():
    db,c,p,sub=setup()
    boq=create_subcontractor_boq_line(db,c.id,p.id,sub.id,'S-02','Block','m2',50,200)
    m,_=create_subcontractor_measurement(db,c.id,p.id,sub.id,'SM-64',date(2026,8,1),1,[
        {'subcontractor_boq_line_id':boq.id,'current_qty':10,'cumulative_qty':10}
    ])
    approve_subcontractor_measurement(db,c.id,m.id)
    cert=create_subcontractor_progress_from_measurement(db,c.id,p.id,sub.id,'SC-64',date(2026,8,10),m.id,100,0,50,1)
    approve_subcontractor_progress(db,c.id,cert.id,1)
    out=subcontractor_control(db,c.id,p.id,sub.id)
    assert out['boq_commitment']==Decimal('10000.00')
    assert out['measured']==Decimal('2000.00')
    assert out['certified_gross']==Decimal('2000.00')
    assert out['retention_payable']==Decimal('100.00')
    assert out['deductions']==Decimal('50.00')
