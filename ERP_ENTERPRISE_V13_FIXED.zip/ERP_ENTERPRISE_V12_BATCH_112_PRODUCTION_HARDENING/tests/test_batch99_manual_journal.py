import asyncio
import datetime
import uuid
from urllib.parse import urlencode

from fastapi import HTTPException
from starlette.requests import Request

from app.database import SessionLocal
from app.models import User, Account, AccountTypeEnum, AccountingPeriod, JournalEntry, CostCenter
from app.enterprise_models import Company, Branch, UserCompanyAccess
from app.governance import set_request_context, clear_request_context
from app.routers.accounting_router import create_manual_journal


def _request(data):
    body = urlencode(data, doseq=True).encode()
    async def receive():
        return {"type": "http.request", "body": body, "more_body": False}
    return Request({"type":"http","method":"POST","path":"/accounting/journal/new",
                    "headers":[(b"content-type",b"application/x-www-form-urlencoded"),
                               (b"content-length",str(len(body)).encode())],
                    "scheme":"http","server":("test",80),"client":("127.0.0.1",1),"query_string":b""}, receive=receive)


def _run(coro):
    return asyncio.run(coro)


def setup_case():
    db = SessionLocal()
    token = uuid.uuid4().hex[:8]
    c = Company(code="P99"+token, name="Patch99 Journal", is_active=True); db.add(c); db.flush()
    b1 = Branch(company_id=c.id, code="J1"+token[:5], name="Journal Branch 1", is_active=True); db.add(b1); db.flush()
    b2 = Branch(company_id=c.id, code="J2"+token[:5], name="Journal Branch 2", is_active=True); db.add(b2); db.flush()
    u = User(username="j99-"+token, full_name="Journal Tester", password_hash="x", role="admin"); db.add(u); db.flush()
    db.add(UserCompanyAccess(user_id=u.id, company_id=c.id, branch_id=None))
    a1 = Account(company_id=c.id, branch_id=b1.id, code="9911"+token[:3], name="Cash", account_type=AccountTypeEnum.asset, normal_balance="debit", is_active=True)
    a2 = Account(company_id=c.id, branch_id=b1.id, code="9912"+token[:3], name="Revenue", account_type=AccountTypeEnum.revenue, normal_balance="credit", is_active=True)
    a3 = Account(company_id=c.id, branch_id=b2.id, code="9913"+token[:3], name="Other", account_type=AccountTypeEnum.expense, normal_balance="debit", is_active=True)
    db.add_all([a1,a2,a3]); db.flush()
    cc = CostCenter(company_id=c.id, branch_id=b1.id, code="CC99"+token[:3], name="CC", is_active=True); db.add(cc)
    db.add(AccountingPeriod(company_id=c.id, branch_id=b1.id, name="Sep-99-"+token,
                            start_date=datetime.datetime(2026,9,1), end_date=datetime.datetime(2026,9,30,23,59), is_closed=False))
    db.commit()
    set_request_context(company_id=c.id, branch_id=b1.id, user_id=u.id, request_id="r99-"+token)
    return db,c,b1,b2,u,a1,a2,a3,cc


def test_manual_journal_branch_period_and_cost_center_governance():
    db,c,b1,b2,u,a1,a2,a3,cc = setup_case()
    try:
        response = _run(create_manual_journal(_request({
            "branch_id": str(b1.id), "entry_date": "2026-09-02T10:00", "reference": "R99",
            "description": "Manual test", "account_id[]": [str(a1.id),str(a2.id)],
            "debit[]": ["100","0"], "credit[]": ["0","100"],
            "line_description[]": ["cash","revenue"], "cost_center_id[]": [str(cc.id),""],
            "allocation_amount[]": ["100","0"]
        }), db, u, None))
        assert response.status_code == 303
        entry = db.query(JournalEntry).order_by(JournalEntry.id.desc()).first()
        assert entry.company_id == c.id and entry.branch_id == b1.id and entry.status == "posted"
        assert sum(x.debit for x in entry.lines) == sum(x.credit for x in entry.lines)

        with __import__('pytest').raises(HTTPException) as ex:
            _run(create_manual_journal(_request({
                "branch_id": str(b1.id), "entry_date": "2026-09-02T10:00", "description": "bad",
                "account_id[]": [str(a3.id),str(a2.id)], "debit[]": ["10","0"], "credit[]": ["0","10"],
                "line_description[]": ["", ""], "cost_center_id[]": ["", ""], "allocation_amount[]": ["0","0"]
            }), db, u, None))
        assert ex.value.status_code == 422

        with __import__('pytest').raises(HTTPException) as ex2:
            _run(create_manual_journal(_request({
                "branch_id": str(b1.id), "entry_date": "2026-10-02T10:00", "description": "bad",
                "account_id[]": [str(a1.id),str(a2.id)], "debit[]": ["10","0"], "credit[]": ["0","10"],
                "line_description[]": ["", ""], "cost_center_id[]": ["", ""], "allocation_amount[]": ["0","0"]
            }), db, u, None))
        assert ex2.value.status_code == 409
    finally:
        clear_request_context()
        db.close()
