import os
import importlib


def test_database_url_is_safely_built_from_discrete_credentials(monkeypatch):
    import app.core_settings as settings
    settings.security_settings.cache_clear()
    monkeypatch.delenv('DATABASE_URL', raising=False)
    monkeypatch.setenv('ERP_DB_HOST', 'postgres')
    monkeypatch.setenv('ERP_DB_PORT', '5432')
    monkeypatch.setenv('ERP_DB_NAME', 'erp main')
    monkeypatch.setenv('ERP_DB_USER', 'erp@user')
    monkeypatch.setenv('ERP_DB_PASSWORD', 'p@ss:/# word')
    monkeypatch.setenv('JWT_SECRET_KEY', 'x' * 32)
    monkeypatch.setenv('ENCRYPTION_KEY', 'y' * 32)
    url = settings.security_settings()['DATABASE_URL']
    assert url.startswith('postgresql+psycopg://erp%40user:p%40ss%3A%2F%23%20word@postgres:5432/')
    assert url.endswith('/erp%20main')
    settings.security_settings.cache_clear()


def test_redis_url_encodes_reserved_password_characters(monkeypatch):
    from app.core_settings import redis_connection_url
    monkeypatch.setenv('ERP_REDIS_HOST', 'redis')
    monkeypatch.setenv('ERP_REDIS_PORT', '6379')
    monkeypatch.setenv('REDIS_PASSWORD', 'p@ss:/# word')
    assert redis_connection_url(0) == 'redis://:p%40ss%3A%2F%23%20word@redis:6379/0'


def test_production_auth_backend_outage_rejects_token(monkeypatch):
    # Exercise fail-closed semantics without needing a real Redis server.
    import app.auth as auth

    class BrokenRedis:
        def get(self, *_a, **_kw):
            raise OSError('down')
        def exists(self, *_a, **_kw):
            raise OSError('down')

    monkeypatch.setattr(auth, '_auth_redis', BrokenRedis())
    monkeypatch.setattr(auth, '_PRODUCTION', True)
    payload = {'jti': 'abc', 'sub': '1', 'type': 'access', 'authz_version': 0}
    assert auth._token_revoked(payload) is True
