from datetime import date
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, User, RoleEnum
import app.enterprise_models, app.construction_models, app.governance_models, app.hr_models
from app.enterprise_models import Company, Branch, Department, Project, Employee, PayrollRun, PayrollLine, ProjectCost
from app.hr_models import EmployeeProfile, EmployeeProjectAssignment, UserScope, RoleApprovalLimit
from app.governance_models import Role
from app.governance import scope_allows

def db():
    e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); return sessionmaker(bind=e)()

def test_hr_employee_project_and_payroll_cost_chain():
    s=db(); c=Company(code='HR65',name='HR Co'); s.add(c); s.flush(); b=Branch(company_id=c.id,code='SITE',name='Site'); d=Department(company_id=c.id,code='ENG',name='Engineering'); s.add_all([b,d]); s.flush()
    e=Employee(company_id=c.id,employee_code='E01',name='Ali',department_id=d.id,base_salary=Decimal('12000')); s.add(e); s.flush()
    p=EmployeeProfile(company_id=c.id,employee_id=e.id,branch_id=b.id,job_title='Engineer',basic_salary=Decimal('12000')); s.add(p)
    pr=Project(company_id=c.id,code='P01',name='Project',budget=100000); s.add(pr); s.flush()
    a=EmployeeProjectAssignment(company_id=c.id,employee_id=e.id,project_id=pr.id,allocation_percent=100,start_date=date(2026,1,1),is_primary=True); s.add(a)
    run=PayrollRun(company_id=c.id,period_label='2026-08',start_date=date(2026,8,1),end_date=date(2026,8,31)); s.add(run); s.flush()
    line=PayrollLine(company_id=c.id,payroll_run_id=run.id,employee_id=e.id,gross=Decimal('12000'),deductions=0,net=Decimal('12000'),project_id=pr.id); s.add(line); s.flush()
    s.add(ProjectCost(company_id=c.id,project_id=pr.id,cost_type='labor_payroll',source_type='payroll_line',source_id=line.id,amount=line.gross,cost_date=run.end_date)); s.commit()
    assert s.query(EmployeeProfile).count()==1 and s.query(ProjectCost).filter_by(project_id=pr.id).one().amount==Decimal('12000.000000')

def test_scoped_access_and_approval_limit():
    s=db(); c=Company(code='SEC65',name='Sec Co'); s.add(c); s.flush(); p1=Project(company_id=c.id,code='A',name='A'); p2=Project(company_id=c.id,code='B',name='B'); s.add_all([p1,p2]); u=User(username='officer',full_name='Officer',password_hash='x',role=RoleEnum.employee); s.add(u); s.flush()
    s.add(UserScope(user_id=u.id,company_id=c.id,project_id=p1.id,can_view=True,can_edit=False,can_approve=False)); r=Role(code='procurement_officer',name='Procurement Officer'); s.add(r); s.flush(); s.add(RoleApprovalLimit(role_id=r.id,company_id=c.id,document_type='purchase_order',max_amount=Decimal('10000'))); s.commit()
    assert scope_allows(s,u.id,c.id,project_id=p1.id,write=False) is True
    assert scope_allows(s,u.id,c.id,project_id=p1.id,write=True) is False
    assert scope_allows(s,u.id,c.id,project_id=p2.id,write=False) is False
    assert s.query(RoleApprovalLimit).one().max_amount == Decimal('10000.000000')
