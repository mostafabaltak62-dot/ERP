import datetime
from decimal import Decimal
from urllib.parse import parse_qs, urlparse

import pytest
from fastapi import HTTPException
from starlette.requests import Request

from app.database import SessionLocal
from app.accounting import create_entry
from app.database import SessionLocal
from app.enterprise_models import Company, Branch, UserCompanyAccess
from app.models import Account, AccountTypeEnum, JournalEntry, JournalLine, User
from app.governance import set_request_context, clear_request_context


@pytest.fixture
def db():
    session = SessionLocal()
    try:
        yield session
    finally:
        session.rollback()
        session.close()
from app.routers.accounting_router import accounting_home, account_ledger, export_report, deactivate_account


def _request(path="/accounting", query=""):
    return Request({"type": "http", "method": "GET", "path": path,
                    "headers": [], "scheme": "http", "server": ("test", 80),
                    "client": ("127.0.0.1", 1), "query_string": query.encode()})


def setup_case():
    db = SessionLocal()
    token = datetime.datetime.now().strftime("%H%M%S%f")
    c = Company(code="P101" + token[:8], name="General Accounting 101", is_active=True)
    db.add(c); db.flush()
    b1 = Branch(company_id=c.id, code="GA1" + token[:5], name="GA Branch 1", is_active=True)
    b2 = Branch(company_id=c.id, code="GA2" + token[:5], name="GA Branch 2", is_active=True)
    db.add_all([b1, b2]); db.flush()
    u = User(username="ga101-" + token[:8], full_name="GA Tester", password_hash="x", role="admin")
    db.add(u); db.flush()
    db.add(UserCompanyAccess(user_id=u.id, company_id=c.id, branch_id=None))
    a1 = Account(company_id=c.id, branch_id=b1.id, code="10101" + token[:3], name="Cash B1", account_type=AccountTypeEnum.asset, normal_balance="debit", is_active=True)
    a2 = Account(company_id=c.id, branch_id=b1.id, code="40101" + token[:3], name="Sales B1", account_type=AccountTypeEnum.revenue, normal_balance="credit", is_active=True)
    a3 = Account(company_id=c.id, branch_id=b2.id, code="10201" + token[:3], name="Cash B2", account_type=AccountTypeEnum.asset, normal_balance="debit", is_active=True)
    a4 = Account(company_id=c.id, branch_id=b2.id, code="40201" + token[:3], name="Sales B2", account_type=AccountTypeEnum.revenue, normal_balance="credit", is_active=True)
    db.add_all([a1, a2, a3, a4]); db.flush()
    def post_direct(branch, n, left, right, amount, when):
        e = JournalEntry(company_id=c.id, branch_id=branch.id, entry_number=n, entry_date=when,
                         description=n, source_type="p101-test", source_id=abs(hash(token + n)) % 100000000,
                         status="draft", created_by_id=u.id)
        db.add(e); db.flush()
        db.add_all([
            JournalLine(entry_id=e.id, company_id=c.id, branch_id=branch.id, account_id=left.id, debit=amount, credit=0, description="debit"),
            JournalLine(entry_id=e.id, company_id=c.id, branch_id=branch.id, account_id=right.id, debit=0, credit=amount, description="credit"),
        ])
        db.flush(); e.status = "posted"; e.posted_at = datetime.datetime.now(); e.posted_by_id = u.id
    set_request_context(request_id="p101-" + token, user_id=u.id, company_id=c.id)
    post_direct(b1, "P101-B1-" + token[:8], a1, a2, 100, datetime.datetime(2026, 9, 1))
    post_direct(b2, "P101-B2-" + token[:8], a3, a4, 200, datetime.datetime(2026, 9, 2))
    db.commit()
    return db, c, b1, b2, u, a1, a2, a3, a4


def test_general_accounting_home_is_branch_governed_and_bulk():
    db, c, b1, b2, u, a1, a2, a3, a4 = setup_case()
    try:
        set_request_context(request_id="p101-home", user_id=u.id, company_id=c.id)
        response = accounting_home(_request(), db=db, user=u)
        assert response.context["branch_id"] is None
        ids = {r["account"].id for r in response.context["accounts"]}
        assert {a1.id, a2.id, a3.id, a4.id} <= ids
        assert response.context["total_debit"] == Decimal("300.00")
        assert response.context["total_credit"] == Decimal("300.00")

        response_b1 = accounting_home(_request("/accounting", f"branch_id={b1.id}"), branch_id=b1.id, db=db, user=u)
        ids_b1 = {r["account"].id for r in response_b1.context["accounts"]}
        assert a1.id in ids_b1 and a2.id in ids_b1
        assert a3.id not in ids_b1 and a4.id not in ids_b1
        assert response_b1.context["total_debit"] == Decimal("100.00")
    finally:
        clear_request_context(); db.close()


def test_legacy_account_ledger_redirects_to_authoritative_report():
    db, c, b1, b2, u, a1, a2, a3, a4 = setup_case()
    try:
        set_request_context(request_id="p101-ledger", user_id=u.id, company_id=c.id)
        r = account_ledger(a1.id, _request("/accounting/ledger/" + str(a1.id), f"start_date=2026-09-01&end_date=2026-09-30&branch_id={b1.id}"), db, u)
        assert r.status_code == 307
        parsed = urlparse(r.headers["location"])
        assert parsed.path == "/accounting/reports/general-ledger"
        q = parse_qs(parsed.query)
        assert q["account_id"] == [str(a1.id)]
        assert q["branch_id"] == [str(b1.id)]

        with pytest.raises(HTTPException) as ex:
            account_ledger(a3.id, _request("/accounting/ledger/" + str(a3.id), f"branch_id={b1.id}"), db, u)
        assert ex.value.status_code == 404
    finally:
        clear_request_context(); db.close()


def test_legacy_exports_honor_branch_scope():
    db, c, b1, b2, u, a1, a2, a3, a4 = setup_case()
    try:
        set_request_context(request_id="p101-export", user_id=u.id, company_id=c.id)
        x = export_report("trial-balance", "xlsx", "2026-09-01", "2026-09-30", branch_id=b1.id, db=db, user=u)
        assert x.media_type == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        assert 'trial-balance.xlsx' in x.headers.get("content-disposition", "")
    finally:
        clear_request_context(); db.close()


def test_deactivate_account_enforces_branch_scope():
    db, c, b1, b2, u, a1, a2, a3, a4 = setup_case()
    try:
        branch_user = User(username="ga101-branch-" + datetime.datetime.now().strftime("%H%M%S%f"), full_name="Branch Tester", password_hash="x", role="admin")
        db.add(branch_user); db.flush()
        db.add(UserCompanyAccess(user_id=branch_user.id, company_id=c.id, branch_id=b1.id))
        db.commit()
        set_request_context(request_id="p101-deactivate", user_id=branch_user.id, company_id=c.id, branch_id=b1.id)
        with pytest.raises(HTTPException) as ex:
            deactivate_account(a3.id, db=db, user=branch_user)
        assert ex.value.status_code in (403, 404)
        db.refresh(a3)
        assert a3.is_active is True
    finally:
        clear_request_context(); db.close()

def test_branch_only_user_cannot_mutate_global_account():
    db, c, b1, b2, u, a1, a2, a3, a4 = setup_case()
    try:
        global_acc = Account(company_id=c.id, branch_id=None, code="10999" + datetime.datetime.now().strftime("%f")[:3], name="Global Cash", account_type=AccountTypeEnum.asset, normal_balance="debit", is_active=True)
        db.add(global_acc); db.flush()
        branch_user = User(username="ga101-global-" + datetime.datetime.now().strftime("%H%M%S%f"), full_name="Branch Global Tester", password_hash="x", role="admin")
        db.add(branch_user); db.flush()
        db.add(UserCompanyAccess(user_id=branch_user.id, company_id=c.id, branch_id=b1.id)); db.commit()
        set_request_context(request_id="p102-global", user_id=branch_user.id, company_id=c.id, branch_id=b1.id)
        with pytest.raises(HTTPException) as ex1:
            from app.routers.accounting_router import edit_account
            edit_account(global_acc.id, db=db, user=branch_user, name="Changed", account_type="asset", parent_id="", normal_balance="debit", statement_section="assets", cash_flow_category="")
        assert ex1.value.status_code == 403
        with pytest.raises(HTTPException) as ex2:
            deactivate_account(global_acc.id, db=db, user=branch_user)
        assert ex2.value.status_code == 403
        db.refresh(global_acc)
        assert global_acc.is_active is True
    finally:
        clear_request_context(); db.close()
