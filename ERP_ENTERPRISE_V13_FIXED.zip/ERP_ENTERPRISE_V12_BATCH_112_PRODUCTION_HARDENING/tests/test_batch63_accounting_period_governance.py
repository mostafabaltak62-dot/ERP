from datetime import datetime
import uuid
import pytest
from fastapi import HTTPException
from app.database import SessionLocal
from app.models import AccountingPeriod, User, AuditLog
from app.enterprise_models import Company, Branch
from app.governance import set_request_context, clear_request_context
from app.routers.finance_router import create_period


def setup_case():
    db=SessionLocal()
    c=Company(code='P63'+uuid.uuid4().hex[:6],name='Period 63',is_active=True); db.add(c); db.flush()
    b=Branch(company_id=c.id,code='PB'+uuid.uuid4().hex[:5],name='Period Branch',is_active=True); db.add(b); db.flush()
    u=User(username='p63-'+uuid.uuid4().hex[:8],full_name='Period Tester',password_hash='x',role='admin'); db.add(u); db.commit()
    set_request_context(company_id=c.id,branch_id=b.id,user_id=u.id)
    return db,c,b,u


def test_period_creation_rejects_bad_dates_and_overlap():
    db,c,b,u=setup_case()
    try:
        with pytest.raises(HTTPException) as ex:
            create_period(db=db,user=u,name='bad',start_date='bad',end_date='2026-01-01T00:00')
        assert ex.value.status_code==422
        create_period(db=db,user=u,name='Jan',start_date='2026-01-01T00:00',end_date='2026-01-31T23:59')
        with pytest.raises(HTTPException) as ex2:
            create_period(db=db,user=u,name='Overlap',start_date='2026-01-15T00:00',end_date='2026-02-01T00:00')
        assert ex2.value.status_code==409
    finally:
        clear_request_context(); db.close()


def test_period_name_is_scoped_and_audit_logged():
    db,c,b,u=setup_case()
    try:
        create_period(db=db,user=u,name='Jan 2026',start_date='2026-03-01T00:00',end_date='2026-03-31T23:59')
        with pytest.raises(HTTPException) as ex:
            create_period(db=db,user=u,name='Jan 2026',start_date='2026-04-01T00:00',end_date='2026-04-30T23:59')
        assert ex.value.status_code==409
        assert db.query(AuditLog).filter(AuditLog.user_id==u.id,AuditLog.entity_type=='accounting_period',AuditLog.action=='create').count()==1
    finally:
        clear_request_context(); db.close()
