from datetime import date, datetime
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, Account, AccountTypeEnum, JournalEntry, JournalLine, TaxTransaction, FixedAsset
from app.enterprise_models import Company, Branch
from app.accounting_controls import build_accounting_control_report


def setup_db():
    e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); db=sessionmaker(bind=e)()
    c=Company(code='P91',name='Controls Co'); db.add(c); db.flush()
    b=Branch(company_id=c.id,code='B1',name='Branch 1',is_active=True); db.add(b); db.flush()
    cash=Account(company_id=c.id,code='1100',name='Cash',account_type=AccountTypeEnum.asset,normal_balance='debit',statement_section='cash_and_equivalents')
    rev=Account(company_id=c.id,code='4100',name='Revenue',account_type=AccountTypeEnum.revenue,normal_balance='credit',statement_section='revenue')
    inv=Account(company_id=c.id,code='1300',name='Inventory',account_type=AccountTypeEnum.asset,normal_balance='debit',statement_section='inventory')
    cogs=Account(company_id=c.id,code='5100',name='COGS',account_type=AccountTypeEnum.expense,normal_balance='debit',statement_section='cost_of_sales')
    db.add_all([cash,rev,inv,cogs]); db.flush(); return db,c,b,cash,rev


def post(db,c,b,num,when,pairs):
    e=JournalEntry(company_id=c.id,branch_id=b.id,entry_number=num,entry_date=when,description=num,status='draft'); db.add(e); db.flush()
    for a,d,cr in pairs: db.add(JournalLine(company_id=c.id,entry_id=e.id,account_id=a.id,debit=d,credit=cr))
    db.flush(); e.status='posted'; db.commit(); return e


def test_control_check_uses_branch_and_real_tax_linkage():
    db,c,b,cash,rev=setup_db()
    post(db,c,b,'OK',datetime(2026,1,2),[(cash,100,0),(rev,0,100)])
    tx=TaxTransaction(company_id=c.id,branch_id=b.id,tax_rate_id=1,source_type='sale_invoice',source_id=1,taxable_amount=100,tax_amount=15,tax_direction='output',rate_applied=15,created_at=datetime(2026,1,3))
    db.add(tx); db.commit()
    r=build_accounting_control_report(db,c.id,date(2026,1,1),date(2026,1,31),b.id)
    tax=[x for x in r['checks'] if x[0]=='ضريبة القيمة المضافة'][0]
    assert tax[1] is False
    assert len(r['tax']['orphaned'])==1


def test_control_check_rejects_invalid_fixed_asset():
    db,c,b,cash,rev=setup_db()
    db.add(FixedAsset(company_id=c.id,branch_id=b.id,asset_code='FA1',name='Bad',acquisition_date=datetime(2026,1,1),acquisition_cost=100,useful_life_months=0,accumulated_depreciation=0,residual_value=0))
    db.commit()
    r=build_accounting_control_report(db,c.id,date(2026,1,1),date(2026,1,31),b.id)
    fa=[x for x in r['checks'] if x[0]=='الأصول والإهلاك'][0]
    assert fa[1] is False
