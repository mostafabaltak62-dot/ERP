from datetime import date
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
from app.enterprise_models import Company, Project, Contract
from app.construction_models import ConstructionCostCode, WBSNode
from app.construction_services import create_commitment, create_cost_forecast


def setup():
    import app.construction_models
    e=create_engine('sqlite:///:memory:')
    Base.metadata.create_all(e)
    S=sessionmaker(bind=e); db=S()
    c=Company(code='C54', name='Cost Governance Co'); db.add(c); db.flush()
    p=Project(company_id=c.id, code='P54', name='Project 54', budget=100000); db.add(p); db.flush()
    cc=ConstructionCostCode(company_id=c.id, code='01', name='Civil', category='direct', is_active=True); db.add(cc); db.flush()
    w=WBSNode(company_id=c.id, project_id=p.id, code='1', name='Civil', level=1, budget_amount=1000, is_active=True); db.add(w); db.commit()
    return db,c,p,cc,w


def test_commitment_rejects_cross_project_wbs_and_inactive_code():
    db,c,p,cc,w=setup()
    other=Project(company_id=c.id, code='P55', name='Other', budget=1000); db.add(other); db.flush()
    bad_w=WBSNode(company_id=c.id, project_id=other.id, code='1', name='Other', level=1, budget_amount=0, is_active=True); db.add(bad_w); db.commit()
    try:
        create_commitment(db,c.id,p.id,'Bad WBS',100,date(2026,9,1),wbs_id=bad_w.id)
        assert False
    except ValueError as e:
        assert 'Invalid WBS' in str(e)
    cc.is_active=False; db.commit()
    try:
        create_commitment(db,c.id,p.id,'Bad code',100,date(2026,9,1),cost_code_id=cc.id)
        assert False
    except ValueError as e:
        assert 'cost code' in str(e).lower()


def test_forecast_requires_date_description_and_scoped_wbs():
    db,c,p,cc,w=setup()
    try:
        create_cost_forecast(db,c.id,p.id,'',100,date(2026,9,1),wbs_id=w.id)
        assert False
    except ValueError as e:
        assert 'description' in str(e).lower()
    try:
        create_cost_forecast(db,c.id,p.id,'Forecast',100,date(2026,9,1),wbs_id=99999)
        assert False
    except ValueError as e:
        assert 'invalid wbs' in str(e).lower()
