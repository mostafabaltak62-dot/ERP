from decimal import Decimal
from datetime import date
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, Item, StockMovement, MovementTypeEnum
from app.enterprise_models import Company, Project, Employee, Equipment, Contract
from app.construction_models import ConstructionSite
from app.construction_services import create_site, issue_site_material, record_equipment_usage, record_labor, create_subcontractor_boq_line, construction_cash_flow

def setup():
    import app.construction_models
    e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); S=sessionmaker(bind=e); db=S()
    c=Company(code='C61',name='Site Co'); db.add(c); db.flush()
    p=Project(company_id=c.id,code='P61',name='Tower'); db.add(p); db.flush()
    item=Item(company_id=c.id,code='CEM61',name='Cement',purchase_price=10,sale_price=12); db.add(item)
    emp=Employee(company_id=c.id,employee_code='E61',name='Worker'); db.add(emp)
    eq=Equipment(company_id=c.id,code='EQ61',name='Excavator',hourly_rate=100); db.add(eq)
    contract=Contract(company_id=c.id,contract_number='SC61',contract_type='subcontractor',project_id=p.id,value=10000); db.add(contract); db.flush()
    db.add(StockMovement(company_id=c.id,item_id=item.id,movement_type=MovementTypeEnum.in_,quantity=100,unit_cost=10,total_cost=1000)); db.commit()
    return db,c,p,item,emp,eq,contract

def test_site_material_equipment_labor_and_cashflow():
    db,c,p,item,emp,eq,contract=setup(); site=create_site(db,c.id,p.id,'S1','Main Site')
    issue=issue_site_material(db,c.id,p.id,site.id,item.id,10,Decimal('10'),date(2026,2,1),'MI-1')
    assert issue.total_cost==Decimal('100.00')
    assert db.query(StockMovement).filter_by(item_id=item.id,movement_type=MovementTypeEnum.out).one().quantity==10
    usage=record_equipment_usage(db,c.id,p.id,eq.id,date(2026,2,1),0,5,100,site.id); assert usage.total_cost==Decimal('500.00')
    labor=record_labor(db,c.id,p.id,emp.id,date(2026,2,1),8,2,20,30,site.id); assert labor.total_cost==Decimal('220.00')
    sub=create_subcontractor_boq_line(db,c.id,p.id,contract.id,'SUB-1','Masonry','m2',100,50); assert sub.contract_qty==100
    db.commit()
    cf=construction_cash_flow(db,c.id,p.id); assert cf['material_outflow']==Decimal('100.00'); assert cf['equipment_outflow']==Decimal('500.00'); assert cf['labor_outflow']==Decimal('220.00')

def test_material_issue_cannot_overdraw_stock():
    db,c,p,item,emp,eq,contract=setup(); site=create_site(db,c.id,p.id,'S1','Main Site')
    try: issue_site_material(db,c.id,p.id,site.id,item.id,101,10,date(2026,2,1))
    except ValueError as e: assert 'Insufficient stock' in str(e)
    else: raise AssertionError('Expected stock guard')
