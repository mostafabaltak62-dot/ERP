from datetime import date
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, User, RoleEnum, JournalEntry
import app.enterprise_models, app.construction_models, app.governance_models, app.hr_models
from app.enterprise_models import Company, Project, Employee, PayrollRun, PayrollLine, ProjectCost
from app.hr_models import EmployeeProfile, EmployeeProjectAssignment, PayrollAllocation, RoleApprovalLimit
from app.governance_models import Role, UserRole, Permission, RolePermission, ApprovalRule, ApprovalRuleStep
from app.routers.hr_router import allocate_payroll, post_payroll_to_accounting
from app.workflows import request_approval, act_on_approval
from app.accounting import ensure_default_accounts


def db():
    e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); return sessionmaker(bind=e)()


def test_payroll_uses_employee_project_assignment_wbs_and_cost_code():
    s=db(); c=Company(code='I66',name='Integration Co'); s.add(c); s.flush()
    p=Project(company_id=c.id,code='P66',name='Project 66',budget=100000); s.add(p); s.flush()
    e=Employee(company_id=c.id,employee_code='E66',name='Worker',base_salary=12000); s.add(e); s.flush()
    s.add(EmployeeProfile(company_id=c.id,employee_id=e.id,basic_salary=12000))
    from app.construction_models import ConstructionSite, WBSNode, ConstructionCostCode
    site=ConstructionSite(company_id=c.id,project_id=p.id,code='S66',name='Site 66'); s.add(site); s.flush()
    wbs=WBSNode(company_id=c.id,project_id=p.id,code='W66',name='Labor'); s.add(wbs); s.flush()
    cc=ConstructionCostCode(company_id=c.id,code='LAB66',name='Labor',category='labor'); s.add(cc); s.flush()
    s.add(EmployeeProjectAssignment(company_id=c.id,employee_id=e.id,project_id=p.id,site_id=site.id,wbs_id=wbs.id,cost_code_id=cc.id,allocation_percent=100,start_date=date(2026,1,1),is_primary=True))
    run=PayrollRun(company_id=c.id,period_label='2026-08',start_date=date(2026,8,1),end_date=date(2026,8,31),status='approved'); s.add(run); s.flush()
    line=PayrollLine(company_id=c.id,payroll_run_id=run.id,employee_id=e.id,gross=12000,deductions=0,net=12000); s.add(line); s.commit()
    class U: id=1
    out=allocate_payroll(run.id,c.id,s,U())
    a=s.query(PayrollAllocation).one(); pc=s.query(ProjectCost).one()
    assert a.project_id==p.id and a.site_id==site.id and a.wbs_id==wbs.id and a.cost_code_id==cc.id
    assert pc.source_type=='payroll_allocation' and pc.amount==Decimal('12000.000000')


def test_payroll_posts_once_to_gl():
    s=db(); c=Company(code='G66',name='GL Co'); s.add(c); s.flush(); ensure_default_accounts(s,c.id)
    e=Employee(company_id=c.id,employee_code='E1',name='Worker',base_salary=5000); s.add(e); s.flush()
    run=PayrollRun(company_id=c.id,period_label='2026-08',start_date=date(2026,8,1),end_date=date(2026,8,31),status='approved'); s.add(run); s.flush()
    s.add(PayrollLine(company_id=c.id,payroll_run_id=run.id,employee_id=e.id,gross=5000,deductions=0,net=5000)); s.commit()
    class U: id=1
    out=post_payroll_to_accounting(run.id,c.id,s,U())
    assert out['status']=='posted' and s.query(JournalEntry).filter_by(source_type='payroll_run',source_id=run.id).count()==1
    out2=post_payroll_to_accounting(run.id,c.id,s,U())
    assert out2['status']=='already_posted' and s.query(JournalEntry).filter_by(source_type='payroll_run',source_id=run.id).count()==1


def test_approval_limit_is_enforced_from_role():
    s=db(); c=Company(code='A66',name='Approval Co'); s.add(c); s.flush()
    u=User(username='mgr',full_name='Manager',password_hash='x',role=RoleEnum.employee); s.add(u); s.flush()
    r=Role(code='proc_mgr66',name='Procurement Manager'); s.add(r); s.flush(); s.add(UserRole(user_id=u.id,role_id=r.id,company_id=c.id))
    perm=Permission(code='p66:approve',description='approve'); s.add(perm); s.flush(); s.add(RolePermission(role_id=r.id,permission_id=perm.id))
    s.add(RoleApprovalLimit(role_id=r.id,company_id=c.id,document_type='purchase_order',max_amount=10000));
    rule=ApprovalRule(company_id=c.id,document_type='purchase_order',name='PO'); s.add(rule); s.flush(); s.add(ApprovalRuleStep(rule_id=rule.id,sequence=1,required_permission='p66:approve')); s.commit()
    req=request_approval(s,company_id=c.id,branch_id=None,document_type='purchase_order',document_id=1,requested_by_id=u.id,amount=20000); s.commit()
    try:
        act_on_approval(s,req.id,u.id,'approved')
        assert False, 'approval should have been blocked'
    except PermissionError as exc:
        assert 'Approval limit exceeded' in str(exc)
