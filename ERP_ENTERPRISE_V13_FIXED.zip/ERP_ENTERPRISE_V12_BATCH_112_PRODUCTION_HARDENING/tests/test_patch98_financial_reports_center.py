from pathlib import Path


def test_financial_reports_center_is_tenant_aware_and_comprehensive():
    route = Path('app/routers/financial_reporting_ui.py').read_text(encoding='utf-8')
    template = Path('templates/financial_reports_hub.html').read_text(encoding='utf-8')
    assert 'operation_id="ui_financial_reports_center"' in route
    assert '_report_ctx(db,user,branch_id)' in route
    assert "\"branch_id\":bid" in route
    required = [
        '/accounting/reports/trial-balance', '/accounting/reports/income-statement',
        '/accounting/reports/balance-sheet', '/accounting/reports/cash-flow',
        '/accounting/reports/equity', '/accounting/reports/general-ledger',
        '/accounting/reports/ar-aging', '/accounting/reports/ap-aging',
        '/accounting/reports/project-profitability', '/advanced-finance/reports/profitability',
        '/accounting/reports/budget-vs-actual', '/accounting/reports/validation',
        '/accounting/reports/control-check', '/accounting/reports/inventory-reconciliation',
        '/accounting/reports/orphan-accounts', '/accounting/reports/audit', '/finance',
        '/advanced-finance/bank-reconciliation', '/pro-finance/cost-center-report',
        '/pro-finance/tax-report', '/pro-finance/cost-centers', '/pro-finance/taxes',
        '/pro-finance/accruals', '/pro-finance/assets', '/pro-finance/withholding',
    ]
    assert all(x in template for x in required)
    assert "set suffix = ('?branch_id=' ~ branch_id) if branch_id else ''" in template
