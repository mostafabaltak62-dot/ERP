from pathlib import Path
from app.security_hardening import validate_same_origin, login_allowed
from app.celery_security import tenant_task_context
from app.governance import get_request_context

class Req:
    method = "POST"
    url = type("URL", (), {"scheme":"https"})()
    headers = {"host":"erp.example.com", "origin":"https://evil.example"}


def test_cross_origin_state_change_blocked():
    assert validate_same_origin(Req()) is False


def test_same_origin_state_change_allowed():
    r = Req(); r.headers = {"host":"erp.example.com", "origin":"https://erp.example.com"}
    assert validate_same_origin(r) is True


def test_missing_origin_is_rejected_by_default():
    r = Req(); r.headers = {"host":"erp.example.com"}
    assert validate_same_origin(r) is False


def test_login_throttle_eventually_blocks():
    # Use a unique key to avoid interference from other tests.
    ip, username = "198.51.100.77", "phase42-unique-user"
    assert all(login_allowed(ip, username) for _ in range(5))
    assert login_allowed(ip, username) is False


def test_background_jobs_require_tenant_context():
    try:
        with tenant_task_context(42, branch_id=7, request_id="test-job"):
            ctx = get_request_context()
            assert ctx["company_id"] == 42
            assert ctx["branch_id"] == 7
    finally:
        assert get_request_context() == {}


def test_phase42_docs_and_requirements_present():
    root = Path(__file__).parents[1]
    assert (root / "docs_PHASE42_SECURITY_AND_ASYNC.md").exists()
    assert "celery" in (root / "requirements.txt").read_text().lower()
    assert "redis" in (root / "requirements.txt").read_text().lower()
