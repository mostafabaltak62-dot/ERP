from datetime import datetime, date
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, User, RoleEnum
from app.enterprise_models import Currency, ExchangeRate, Company, Project, WorkflowDefinition, WorkflowStep
from app.enterprise_services import fx_rate, start_workflow, decide_workflow, claim_idempotency


def make_db():
    e=create_engine('sqlite:///:memory:', connect_args={'check_same_thread':False}); Base.metadata.create_all(e); return sessionmaker(bind=e)()

def test_fx_is_historical_and_decimal():
    db=make_db(); db.add_all([Currency(code='EGP',name='Egyptian Pound'),Currency(code='USD',name='US Dollar')]); db.flush()
    egp,usd=db.query(Currency).all(); db.add(ExchangeRate(from_currency_id=usd.id,to_currency_id=egp.id,rate=Decimal('50.123456789012'),effective_at=datetime(2026,1,1))); db.commit()
    assert fx_rate(db,usd.id,egp.id,datetime(2026,2,1)) == Decimal('50.123456789012')

def test_workflow_advances_and_completes():
    db=make_db(); u=User(username='u',full_name='U',password_hash='x',role=RoleEnum.admin); db.add(u); db.flush(); company=Company(code='C1',name='Company 1'); db.add(company); db.flush()
    wf=WorkflowDefinition(company_id=company.id,document_type='payment',name='Payment Approval'); db.add(wf); db.flush(); db.add_all([WorkflowStep(company_id=company.id,workflow_id=wf.id,sequence=1,name='Finance'),WorkflowStep(company_id=company.id,workflow_id=wf.id,sequence=2,name='Final')]); db.commit()
    inst=start_workflow(db,'payment',99,Decimal('100')); db.commit(); assert inst.current_step==1
    decide_workflow(db,inst.id,u.id,True); db.commit(); assert inst.current_step==2 and inst.status=='pending'
    decide_workflow(db,inst.id,u.id,True); db.commit(); assert inst.status=='approved'

def test_idempotency_rejects_reuse_with_changed_payload():
    db=make_db(); u=User(username='u',full_name='U',password_hash='x',role=RoleEnum.admin); db.add(u); db.flush(); company=Company(code='C1',name='Company 1'); db.add(company); db.commit();
    from app.governance import set_request_context, clear_request_context
    set_request_context(company_id=company.id, user_id=u.id)
    row,created=claim_idempotency(db,'abc',u.id,'/api/v1/payments',{'amount':'10'}); db.commit(); assert created
    row2,created2=claim_idempotency(db,'abc',u.id,'/api/v1/payments',{'amount':'10'}); assert not created2 and row2.id==row.id
    import pytest
    with pytest.raises(ValueError): claim_idempotency(db,'abc',u.id,'/api/v1/payments',{'amount':'11'})
    clear_request_context()


def test_workflow_instance_is_tenant_scoped():
    db=make_db()
    c1=Company(code='C1',name='Company 1'); c2=Company(code='C2',name='Company 2'); db.add_all([c1,c2]); db.flush()
    wf1=WorkflowDefinition(company_id=c1.id,document_type='payment',name='P1'); wf2=WorkflowDefinition(company_id=c2.id,document_type='payment',name='P2')
    db.add_all([wf1,wf2]); db.flush()
    db.add_all([WorkflowStep(company_id=c1.id,workflow_id=wf1.id,sequence=1,name='S1'), WorkflowStep(company_id=c2.id,workflow_id=wf2.id,sequence=1,name='S2')]); db.commit()
    from app.governance import set_request_context, clear_request_context
    set_request_context(company_id=c1.id)
    a=start_workflow(db,'payment',500,Decimal('1')); db.commit()
    clear_request_context(); set_request_context(company_id=c2.id)
    b=start_workflow(db,'payment',500,Decimal('1')); db.commit()
    assert a.id != b.id
    clear_request_context()
