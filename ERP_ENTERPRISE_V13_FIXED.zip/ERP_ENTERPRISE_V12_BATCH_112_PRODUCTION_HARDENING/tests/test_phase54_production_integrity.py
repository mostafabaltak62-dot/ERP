from decimal import Decimal
from sqlalchemy.exc import IntegrityError
from app.models import FinanceVoucher, PaymentAllocation, SaleInvoice
from app.transaction_services import create_customer_receipt
from app.deep_transactions import reconcile_inventory_valuation
from app.governance import clear_request_context
from test_phase51_transactions import setup_db


def test_payment_idempotency_returns_same_voucher():
    db, company, user, customer, supplier, item, tax = setup_db()
    try:
        from app.transaction_services import create_sales_order, confirm_sales_order, deliver_sales_order, invoice_sales_delivery
        order=create_sales_order(db, company.id, user.id, customer.id, [{'item_id':item.id,'quantity':1,'unit_price':100}], 'credit')
        confirm_sales_order(db, order.id, company.id)
        delivery=deliver_sales_order(db, order.id, company.id, user.id)
        inv=invoice_sales_delivery(db, delivery.id, company.id, user.id, tax.id)
        db.flush()
        v1=create_customer_receipt(db, company.id, user.id, inv.id, Decimal('50'), idempotency_key='pay-test-1')
        v2=create_customer_receipt(db, company.id, user.id, inv.id, Decimal('50'), idempotency_key='pay-test-1')
        assert v1.id == v2.id
        assert db.query(FinanceVoucher).filter(FinanceVoucher.idempotency_key=='pay-test-1').count() == 1
        assert db.query(PaymentAllocation).filter(PaymentAllocation.sale_invoice_id==inv.id).count() == 1
        db.commit()
    finally:
        clear_request_context(); db.close()


def test_payment_allocation_database_rejects_zero():
    db, company, user, customer, supplier, item, tax = setup_db()
    try:
        voucher=FinanceVoucher(company_id=company.id, voucher_number='VCH-CHK-1', voucher_type='receipt', amount=Decimal('1'), description='x', account_code='1100')
        db.add(voucher); db.flush()
        db.add(PaymentAllocation(company_id=company.id, voucher_id=voucher.id, amount=Decimal('0')))
        try:
            db.flush()
            # SQLite supports CHECK; PostgreSQL does too. If the dialect is unusual, rollback safely.
            assert False, 'database accepted zero payment allocation'
        except IntegrityError:
            db.rollback()
        finally:
            clear_request_context()
    finally:
        db.close()


def test_inventory_reconciliation_api_service_shape():
    db, company, user, customer, supplier, item, tax = setup_db()
    try:
        rows=reconcile_inventory_valuation(db, company.id, user_id=user.id)
        assert isinstance(rows, list)
        assert rows and {'item_id','movement_value','valued_remaining','consumed_value','difference','status'} <= set(rows[0])
        db.rollback()
    finally:
        clear_request_context(); db.close()
