from datetime import datetime
from decimal import Decimal
import uuid
import pytest
from fastapi import HTTPException
from app.database import SessionLocal
from app.models import Account, AccountTypeEnum, AccountingPeriod, Customer, FinanceVoucher, JournalEntry, User
from app.enterprise_models import Company, Branch
from app.governance import set_request_context, clear_request_context
from app.routers.finance_router import create_voucher


def _setup():
    db=SessionLocal()
    c=Company(code='V60'+uuid.uuid4().hex[:6], name='Voucher 60', is_active=True); db.add(c); db.flush()
    b=Branch(company_id=c.id, code='B1'+uuid.uuid4().hex[:4], name='Branch 1', is_active=True); db.add(b); db.flush()
    db.add_all([
      Account(company_id=c.id, branch_id=b.id, code='1100', name='Cash', account_type=AccountTypeEnum.asset, statement_section='cash_and_equivalents', is_active=True),
      Account(company_id=c.id, branch_id=b.id, code='1200', name='AR', account_type=AccountTypeEnum.asset, statement_section='trade_receivables', is_active=True),
      Account(company_id=c.id, branch_id=b.id, code='2100', name='AP', account_type=AccountTypeEnum.liability, statement_section='trade_payables', is_active=True),
      Account(company_id=c.id, branch_id=b.id, code='5200', name='Expense', account_type=AccountTypeEnum.expense, statement_section='operating_expenses', is_active=True),
    ]); db.flush()
    period=AccountingPeriod(company_id=c.id, branch_id=b.id, name='V60-P-'+uuid.uuid4().hex[:6], start_date=datetime(2026,1,1), end_date=datetime(2026,12,31), is_closed=False); db.add(period)
    customer=Customer(company_id=c.id, code='C60'+uuid.uuid4().hex[:6], name='Customer 60', is_active=True); db.add(customer)
    user=User(username='v60-'+uuid.uuid4().hex[:8], full_name='Voucher Tester', password_hash='x', role='admin'); db.add(user); db.commit()
    set_request_context(company_id=c.id, branch_id=b.id, user_id=user.id)
    return db,c,b,user,customer


def test_voucher_requires_open_period_and_permission_is_route_level():
    db,c,b,user,customer=_setup()
    try:
        v=create_voucher(db=db,user=user,voucher_type='receipt',amount='100',description='Test receipt',account_code='1100',party_type='customer',party_id=str(customer.id),voucher_date='2026-03-01T10:00',idempotency_key='k60',expense_account_code='')
        assert v.status_code == 303
        voucher=db.query(FinanceVoucher).filter_by(company_id=c.id,idempotency_key='k60').one()
        entry=db.query(JournalEntry).filter_by(company_id=c.id,source_type='finance_voucher',source_id=voucher.id).one()
        assert entry.status == 'posted'
        assert db.query(JournalEntry).filter_by(company_id=c.id,source_type='finance_voucher',source_id=voucher.id).count()==1
    finally:
        clear_request_context(); db.close()


def test_invalid_date_and_empty_description_are_rejected():
    db,c,b,user,customer=_setup()
    try:
        with pytest.raises(HTTPException) as e:
            create_voucher(db=db,user=user,voucher_type='receipt',amount='100',description=' ',account_code='1100',party_type='customer',party_id=str(customer.id),voucher_date='bad',idempotency_key='k61')
        assert e.value.status_code in (422,)
    finally:
        clear_request_context(); db.close()
