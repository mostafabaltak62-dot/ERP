from app.time_utils import utcnow
from datetime import date, datetime
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
import app.enterprise_models, app.governance_models, app.hr_models, app.document_models, app.construction_models, app.enterprise_plus_models
from app.enterprise_models import Company, Employee, Project, ProjectCost
from app.enterprise_plus_models import WorkSchedule, OvertimeRule, EmployeeContract, ExpenseClaim, ProjectTimesheet, ProjectTask, QualityInspection, QualityDefect, MaintenancePlan, MaintenanceWorkOrder, SignatureRequest, SignatureSigner

def db():
    e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); return sessionmaker(bind=e)()

def test_enterprise_plus_schema_and_core_relationships():
    s=db(); c=Company(code='P69',name='Plus'); s.add(c); s.flush(); e=Employee(company_id=c.id,employee_code='E1',name='Worker',base_salary=24000); p=Project(company_id=c.id,code='PR1',name='Project',budget=100000); s.add_all([e,p]); s.flush()
    sch=WorkSchedule(company_id=c.id,code='STD',name='Standard',daily_hours=8,weekly_hours=48); ot=OvertimeRule(company_id=c.id,code='OT',name='Standard OT'); s.add_all([sch,ot]); s.flush()
    contract=EmployeeContract(company_id=c.id,employee_id=e.id,contract_no='C1',start_date=date(2026,1,1),salary=24000,schedule_id=sch.id,overtime_rule_id=ot.id,status='active'); s.add(contract)
    task=ProjectTask(company_id=c.id,project_id=p.id,code='T1',title='Concrete',progress=25); s.add(task); s.commit()
    assert contract.id and task.status=='todo'

def test_expense_and_timesheet_have_project_cost_traceability():
    s=db(); c=Company(code='P70',name='Trace'); s.add(c); s.flush(); e=Employee(company_id=c.id,employee_code='E1',name='Worker',base_salary=24000); p=Project(company_id=c.id,code='PR1',name='Project',budget=100000); s.add_all([e,p]); s.flush()
    ex=ExpenseClaim(company_id=c.id,employee_id=e.id,project_id=p.id,expense_date=date(2026,8,25),category='Travel',amount=500,status='approved'); ts=ProjectTimesheet(company_id=c.id,employee_id=e.id,project_id=p.id,work_date=date(2026,8,25),hours=8,status='approved'); s.add_all([ex,ts]); s.flush()
    hourly=Decimal('24000')/Decimal('30')/Decimal('8'); s.add(ProjectCost(company_id=c.id,project_id=p.id,cost_type='employee_expense',source_type='expense_claim',source_id=ex.id,amount=500,cost_date=utcnow())); s.add(ProjectCost(company_id=c.id,project_id=p.id,cost_type='labor_timesheet',source_type='timesheet',source_id=ts.id,amount=hourly*8,cost_date=utcnow())); s.commit()
    rows=s.query(ProjectCost).filter_by(project_id=p.id).all(); assert sum(Decimal(str(r.amount)) for r in rows)==Decimal('1300')

def test_quality_defect_and_sequential_signature_model():
    s=db(); c=Company(code='P71',name='Quality'); s.add(c); s.flush(); p=Project(company_id=c.id,code='PR1',name='Project',budget=100000); s.add(p); s.flush()
    qi=QualityInspection(company_id=c.id,project_id=p.id,inspection_no='Q1',inspection_type='SIR',inspection_date=date(2026,8,25)); s.add(qi); s.flush(); defect=QualityDefect(company_id=c.id,inspection_id=qi.id,defect_no='NCR1',description='Crack'); s.add(defect)
    sr=SignatureRequest(company_id=c.id,project_id=p.id,document_id=1,title='Approval'); s.add(sr); s.flush(); s.add_all([SignatureSigner(request_id=sr.id,signer_order=1,signer_name='A'),SignatureSigner(request_id=sr.id,signer_order=2,signer_name='B')]); s.commit()
    assert defect.status=='open'; assert s.query(SignatureSigner).filter_by(request_id=sr.id).count()==2
