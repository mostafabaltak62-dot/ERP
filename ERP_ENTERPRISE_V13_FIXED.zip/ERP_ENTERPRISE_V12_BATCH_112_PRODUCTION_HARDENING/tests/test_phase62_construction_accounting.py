from decimal import Decimal
from datetime import date
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
from app.enterprise_models import Company, Project, Contract, ProgressCertificate
from app.construction_models import BOQLine, ConstructionAdvance, SubcontractorProgress
from app.construction_services import create_boq_revision, create_progress_certificate, approve_certificate, create_advance, create_subcontractor_progress, approve_subcontractor_progress
from app.accounting import ensure_default_accounts

def setup():
    import app.construction_models
    e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); S=sessionmaker(bind=e); db=S()
    c=Company(code='C62',name='Commercial Co'); db.add(c); db.flush()
    p=Project(company_id=c.id,code='P62',name='Tower'); db.add(p); db.flush()
    customer=Contract(company_id=c.id,contract_number='CUST62',contract_type='customer',project_id=p.id,value=100000); db.add(customer)
    sub=Contract(company_id=c.id,contract_number='SUB62',contract_type='subcontractor',project_id=p.id,value=50000); db.add(sub); db.flush()
    ensure_default_accounts(db,c.id); db.commit()
    return db,c,p,customer,sub

def test_client_certificate_posts_revenue_retention_and_advance_recovery():
    db,c,p,customer,sub=setup()
    rev,_=create_boq_revision(db,c.id,p.id,1,date(2026,3,1),'',1,[{'item_code':'W1','description':'Work','unit':'m2','contract_qty':100,'contract_rate':1000}])
    line=db.query(BOQLine).filter_by(revision_id=rev.id).one()
    create_advance(db,c.id,p.id,customer.id,'received',500,date(2026,3,1),'ADV-PC',user_id=1)
    cert=create_progress_certificate(db,c.id,p.id,'PC62',date(2026,3,31),1,[{'boq_line_id':line.id,'current_qty':10,'cumulative_qty':10}],10,500,contract_id=customer.id)
    posted=approve_certificate(db,c.id,cert.id,1)
    assert posted.status=='posted' and posted.journal_entry_id
    from app.models import JournalEntry, JournalLine
    je=db.get(JournalEntry,posted.journal_entry_id)
    assert je.status=='posted'
    assert sum(x.debit for x in je.lines)==sum(x.credit for x in je.lines)
    codes={db.get(__import__('app.models',fromlist=['Account']).Account,x.account_id).code for x in je.lines}
    assert {'1200','1210','2300','4100'} <= codes
    adv=db.query(ConstructionAdvance).filter_by(company_id=c.id,project_id=p.id,direction='received').one()
    assert adv.recovered_amount==Decimal('500.00')

def test_advance_posts_and_is_idempotently_linked():
    db,c,p,customer,sub=setup()
    adv=create_advance(db,c.id,p.id,customer.id,'received',10000,date(2026,3,1), 'ADV62', user_id=1)
    assert adv.journal_entry_id
    assert db.query(ConstructionAdvance).filter_by(journal_entry_id=adv.journal_entry_id).one().id==adv.id

def test_subcontractor_certificate_posts_cost_payable_retention_and_advance_recovery():
    db,c,p,customer,sub=setup()
    create_advance(db,c.id,p.id,sub.id,'payable',1000,date(2026,3,1),'ADV-SUB',user_id=1)
    row=create_subcontractor_progress(db,c.id,p.id,sub.id,'SP62',date(2026,3,31),10000,500,1000,200,user_id=1)
    posted=approve_subcontractor_progress(db,c.id,row.id,1)
    assert posted.status=='posted' and posted.journal_entry_id
    from app.models import JournalEntry
    je=db.get(JournalEntry,posted.journal_entry_id)
    assert sum(x.debit for x in je.lines)==sum(x.credit for x in je.lines)
    adv=db.query(ConstructionAdvance).filter_by(company_id=c.id,project_id=p.id,direction='payable').one()
    assert adv.recovered_amount==Decimal('1000.00')
