from pathlib import Path

def test_material_flow_template_has_completed_workflow_controls():
    text = Path('templates/site_operations_material_flow.html').read_text(encoding='utf-8')
    for phrase in ('لا يمكن استهلاك المواد قبل تسجيل استلامها', 'تكلفة الاستهلاك', 'هالك / إرجاع فائض', 'آخر الحركات'):
        assert phrase in text

def test_material_flow_service_uses_receipts_for_site_availability():
    text = Path('app/field_ops_services.py').read_text(encoding='utf-8')
    start = text.index('def _site_issued_available')
    end = text.index('\ndef _site_material_unit_cost', start)
    body = text[start:end]
    assert 'SiteMaterialReceipt.quantity' in body
    assert 'SiteMaterialConsumption.quantity' in body
    assert 'SiteMaterialAdjustment.quantity' in body
