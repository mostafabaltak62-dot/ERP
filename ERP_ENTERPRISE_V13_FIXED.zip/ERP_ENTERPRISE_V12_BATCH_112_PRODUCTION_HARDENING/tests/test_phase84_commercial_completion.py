import os
from decimal import Decimal
from app.database import SessionLocal, Base, engine
from app.main import app
from app.models import User, Customer, Item, ItemTypeEnum, PurchaseOrder, PurchaseOrderLine
from app.enterprise_models import Company, Branch
from app.governance_models import ApprovalRule, ApprovalRuleStep, ApprovalRequest
from app.commercial_completion_models import CustomerCreditPolicy, ProcurementRequest, ProcurementRequestLine
from app.auth import hash_password
from fastapi.testclient import TestClient


def _tenant(db):
    c=db.query(Company).filter_by(code='DEFAULT').first()
    b=db.query(Branch).filter_by(company_id=c.id,code='MAIN').first()
    return c,b


def test_phase84_models_and_routes_are_registered():
    assert 'customer_credit_policies' in Base.metadata.tables
    assert 'procurement_requests' in Base.metadata.tables
    assert 'rfqs' in Base.metadata.tables
    assert 'budget_control_policies' in Base.metadata.tables
    with TestClient(app) as client:
        r=client.get('/health/live')
        assert r.status_code==200


def test_credit_policy_blocks_sales_order_service():
    from app.transaction_services import create_sales_order
    db=SessionLocal()
    try:
        c,b=_tenant(db)
        user=db.query(User).filter_by(username='admin').first()
        if not user:
            user=User(username='admin',full_name='Admin',password_hash=hash_password('A'*12+'1!'),is_active=True,role='admin'); db.add(user); db.flush()
        customer=Customer(company_id=c.id,code='C84',name='Credit Test',is_active=True); db.add(customer)
        item=Item(company_id=c.id,code='I84',name='Item 84',item_type=ItemTypeEnum.service,sale_price=100,purchase_price=50,is_active=True); db.add(item); db.flush()
        db.add(CustomerCreditPolicy(company_id=c.id,customer_id=customer.id,credit_limit=50,block_on_overlimit=True))
        db.commit()
        from fastapi import HTTPException
        try:
            create_sales_order(db,c.id,user.id,customer.id,[{'item_id':item.id,'quantity':1,'unit_price':100}])
            assert False, 'credit limit should block'
        except HTTPException as exc:
            assert exc.status_code==409
    finally:
        db.rollback(); db.close()


def test_approval_rule_can_create_request():
    from app.workflows import request_approval
    db=SessionLocal()
    try:
        c,b=_tenant(db); user=db.query(User).filter_by(username='admin').first(); assert user
        rule=ApprovalRule(company_id=c.id,document_type='purchase_order',name='P84',is_active=True,priority=1)
        db.add(rule); db.flush(); db.add(ApprovalRuleStep(rule_id=rule.id,sequence=1,required_permission='purchases:approve'))
        db.flush()
        req=request_approval(db,company_id=c.id,branch_id=b.id,document_type='purchase_order',document_id=99999,requested_by_id=user.id,amount=Decimal('100'))
        assert req and req.status=='pending'
        db.rollback()
    finally: db.close()
