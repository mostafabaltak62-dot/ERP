from pathlib import Path


def test_item_master_has_company_scoped_identity_and_numeric_governance():
    text = Path('app/models.py').read_text(encoding='utf-8')
    migration = Path('alembic/versions/p64_inventory_items_governance.py').read_text(encoding='utf-8')
    assert 'UniqueConstraint("company_id", "code", name="uq_item_company_code")' in text
    assert 'UniqueConstraint("company_id", "barcode", name="uq_item_company_barcode")' in text
    assert 'ck_item_conversion_factor_positive' in text
    assert 'ck_item_tax_rate_range' in text
    assert "revision = 'p64_inventory_items_governance'" in migration
    assert "down_revision = 'p63_accounting_period_governance'" in migration


def test_inventory_item_page_hardens_validation_and_stock_listing():
    text = Path('app/routers/inventory_router.py').read_text(encoding='utf-8')
    template = Path('templates/inventory_list.html').read_text(encoding='utf-8')
    assert '_validate_item_numbers' in text
    assert '_checkbox' in text
    assert 'الباركود مستخدم بالفعل داخل الشركة الحالية' in text
    assert 'لا يمكن إنشاء حركة لصنف موقوف' in text
    assert 'with_for_update()' in text
    assert 'Item.barcode.ilike(like)' in text
    assert 'running balance' not in template.lower()  # stock ledger owns running balance, not item master
