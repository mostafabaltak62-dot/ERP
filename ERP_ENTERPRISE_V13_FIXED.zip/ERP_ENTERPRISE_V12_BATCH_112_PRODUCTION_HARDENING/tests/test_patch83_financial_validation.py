from datetime import date, datetime
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, Account, AccountTypeEnum, JournalEntry, JournalLine
from app.enterprise_models import Company, Branch
from app.financial_reporting import validate_financials

def setup():
    e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); db=sessionmaker(bind=e)()
    c=Company(code='P83',name='Validation Co'); db.add(c); db.flush()
    b1=Branch(company_id=c.id,code='B1',name='Branch 1',is_active=True); b2=Branch(company_id=c.id,code='B2',name='Branch 2',is_active=True); db.add_all([b1,b2]); db.flush()
    cash=Account(company_id=c.id,code='1100',name='Cash',account_type=AccountTypeEnum.asset,normal_balance='debit',statement_section='cash_and_equivalents',cash_flow_category='operating')
    rev=Account(company_id=c.id,code='4100',name='Revenue',account_type=AccountTypeEnum.revenue,normal_balance='credit',statement_section='revenue',cash_flow_category='operating')
    db.add_all([cash,rev]); db.flush(); return db,c,b1,b2,cash,rev

def post(db,c,b,num,dt,pairs):
    e=JournalEntry(company_id=c.id,branch_id=b.id,entry_number=num,entry_date=dt,description=num,status='draft'); db.add(e); db.flush()
    for a,d,cr in pairs: db.add(JournalLine(company_id=c.id,entry_id=e.id,account_id=a.id,debit=d,credit=cr))
    db.flush(); e.status='posted'; db.commit()

def test_validation_ignores_out_of_period_bad_posting():
    db,c,b1,b2,cash,rev=setup(); post(db,c,b1,'OK',datetime(2026,1,2),[(cash,100,0),(rev,0,100)]); post(db,c,b1,'BAD-OUTSIDE',datetime(2025,12,1),[(cash,0,0),(rev,0,0)])
    r=validate_financials(db,c.id,date(2026,1,1),date(2026,1,31),b1.id)
    assert r['journal_integrity_ok'] is True and r['journal_exceptions']==[]

def test_validation_detects_bad_posted_entry_in_scope():
    db,c,b1,b2,cash,rev=setup(); post(db,c,b1,'BAD',datetime(2026,1,2),[(cash,100,0),(rev,0,90)])
    r=validate_financials(db,c.id,date(2026,1,1),date(2026,1,31),b1.id)
    assert r['overall'] is False and r['journal_integrity_ok'] is False

def test_validation_branch_isolation():
    db,c,b1,b2,cash,rev=setup(); post(db,c,b2,'BAD-OTHER',datetime(2026,1,2),[(cash,100,0),(rev,0,90)]); post(db,c,b1,'GOOD',datetime(2026,1,3),[(cash,100,0),(rev,0,100)])
    r=validate_financials(db,c.id,date(2026,1,1),date(2026,1,31),b1.id)
    assert r['journal_integrity_ok'] is True and r['journal_exceptions']==[]
