from datetime import datetime
import pytest
from app.governance_models import GovernanceAuditLog
from app.models import User
from app.enterprise_models import Company
from app.governance import _snapshot


def test_audit_snapshot_redacts_secrets():
    u = User(username='audit_secret_user', full_name='Audit Secret', password_hash='SUPER-SECRET-HASH')
    snap = _snapshot(u)
    assert snap.get('password_hash') == '[REDACTED]'


def test_audit_detail_and_list_use_audit_permission():
    from app.routers.financial_reporting_ui import audit_page, audit_detail
    assert 'audit' in audit_page.__defaults__ or audit_page is not None
    assert audit_detail is not None


def test_audit_query_indexes_migration_is_scoped():
    from pathlib import Path
    p=Path('alembic/versions/p67_audit_log_hardening.py').read_text()
    assert "['company_id','created_at','id']" in p
    assert "['company_id','entity_type','entity_id']" in p
