from pathlib import Path


def test_login_template_has_operational_controls():
    html = Path("templates/login.html").read_text(encoding="utf-8")
    for marker in ["Enter your name", "togglePassword", "newLogin", "rememberUser", "autocomplete=\"current-password\"", "loginButton"]:
        assert marker in html


def test_login_submit_trims_username():
    src = Path("app/routers/auth_router.py").read_text(encoding="utf-8")
    assert "username = username.strip()" in src
