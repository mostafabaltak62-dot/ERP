from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, Customer, Supplier, Item, ItemTypeEnum
from app.enterprise_models import Company, Branch, Project, Contract, AnalyticalDimension, DimensionValue, Notification
from app.core_services import create_project, create_contract, add_dimension_value, global_search, mark_notification_read
from app.governance import set_request_context, clear_request_context


def make_db():
    e=create_engine('sqlite:///:memory:', connect_args={'check_same_thread':False}); Base.metadata.create_all(e); return sessionmaker(bind=e)()


def test_core_project_and_contract_are_tenant_scoped():
    db=make_db(); c1=Company(code='C1',name='One'); c2=Company(code='C2',name='Two'); db.add_all([c1,c2]); db.flush()
    p=create_project(db,c1.id,None,'P001','Project One',budget=Decimal('1000')); db.commit()
    assert p.company_id == c1.id
    import pytest
    with pytest.raises(ValueError, match='Project does not belong'):
        create_contract(db,c2.id,'C-001','service',project_id=p.id,value=Decimal('500'))


def test_dimensions_and_global_search_are_company_scoped():
    db=make_db(); c1=Company(code='C1',name='One'); c2=Company(code='C2',name='Two'); db.add_all([c1,c2]); db.flush()
    db.add_all([Customer(company_id=c1.id,code='CUS1',name='Alpha Customer'), Customer(company_id=c2.id,code='CUS2',name='Alpha Customer')])
    db.add_all([Item(company_id=c1.id,code='IT1',name='Alpha Item',item_type=ItemTypeEnum.product)])
    dim=AnalyticalDimension(company_id=c1.id,code='CC',name='Cost Center'); db.add(dim); db.flush()
    v=add_dimension_value(db,c1.id,dim.id,'MAIN','Main'); db.commit()
    rows=global_search(db,c1.id,'Alpha')
    assert {r['entity'] for r in rows} == {'customer','item'}
    assert all(r['id'] != 2 for r in rows if r['entity']=='customer')
    assert v.company_id == c1.id


def test_notification_is_user_owned_and_readable_once():
    db=make_db(); c=Company(code='C1',name='One'); db.add(c); db.flush()
    n=Notification(company_id=c.id,user_id=7,notification_type='system',title='Test',message='Hello'); db.add(n); db.commit()
    row=mark_notification_read(db,7,n.id); db.commit(); assert row.is_read is True
    try: mark_notification_read(db,8,n.id); assert False
    except ValueError: pass
