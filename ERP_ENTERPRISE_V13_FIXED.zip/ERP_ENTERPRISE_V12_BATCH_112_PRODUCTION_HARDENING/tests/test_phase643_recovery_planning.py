from datetime import date
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
import app.construction_models
from app.enterprise_models import Company, Project, ProjectCost
from app.construction_services import (
    create_wbs, create_activity, create_schedule_baseline, create_progress_period,
    set_activity_progress, create_time_phased_budget, evaluate_performance_alerts,
    create_recovery_plan, add_recovery_action, approve_recovery_plan,
    update_recovery_action, close_recovery_plan
)

def test_phase643_recovery_plan_lifecycle():
    e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); S=sessionmaker(bind=e); db=S()
    c=Company(code='C643',name='Recovery Co'); db.add(c); db.flush(); p=Project(company_id=c.id,code='P643',name='Tower',budget=100000); db.add(p); db.flush()
    w=create_wbs(db,c.id,p.id,'03','Concrete',100000)
    a=create_activity(db,c.id,p.id,'A-01','Concrete',date(2026,8,1),date(2026,9,30),100000,wbs_id=w.id)
    b=create_schedule_baseline(db,c.id,p.id,1,date(2026,8,1),[{'activity_id':a.id,'planned_start':date(2026,8,1),'planned_finish':date(2026,9,30),'budget_amount':100000}])
    create_time_phased_budget(db,c.id,p.id,date(2026,8,25),40000,b.id,a.id)
    period=create_progress_period(db,c.id,p.id,date(2026,8,25),b.id); set_activity_progress(db,c.id,p.id,period.id,a.id,30)
    db.add(ProjectCost(company_id=c.id,project_id=p.id,cost_type='labor',source_type='test',source_id=643,amount=35000)); db.flush()
    alerts=evaluate_performance_alerts(db,c.id,p.id,date(2026,8,25),b.id)['alerts']
    plan=create_recovery_plan(db,c.id,p.id,'RP-001','Recover concrete productivity',date(2026,9,30),alert_id=alerts[0].id,target_cpi=Decimal('0.95'),target_spi=Decimal('0.95'))
    action=add_recovery_action(db,c.id,plan.id,'ACT-001','Re-sequence concrete crews',date(2026,9,1))
    assert plan.status=='draft'
    approve_recovery_plan(db,c.id,plan.id,7); assert plan.status=='approved'
    update_recovery_action(db,c.id,action.id,completion_percent=100,evidence='Daily report attached')
    close_recovery_plan(db,c.id,plan.id,7); assert plan.status=='closed'
