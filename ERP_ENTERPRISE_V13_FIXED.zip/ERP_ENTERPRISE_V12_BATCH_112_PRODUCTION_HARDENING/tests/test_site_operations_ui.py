from fastapi.testclient import TestClient
from app.main import app


def test_site_operations_routes_exist():
    paths = {r.path for r in app.routes}
    assert "/site-operations" in paths
    assert "/site-operations/daily-labor" in paths
    assert "/site-operations/equipment" in paths
    assert "/site-operations/material-requisitions" in paths


def test_site_operations_is_separate_from_inventory():
    paths = {r.path for r in app.routes}
    assert "/inventory" in paths
    assert "/site-operations" in paths
    assert "/site-operations" != "/inventory"
