from datetime import date
from decimal import Decimal
import uuid

from app.database import SessionLocal
from app.models import User, RoleEnum
from app.enterprise_models import Company, UserCompanyAccess, Project, ProjectCost
from app.construction_models import ConstructionEVMSnapshot
from app.routers.auth_router import _dashboard_data


def _snapshot(company_id, project_id, status_date, pv, ev, ac, eac, vac):
    return ConstructionEVMSnapshot(
        company_id=company_id, project_id=project_id, status_date=status_date,
        pv=Decimal(str(pv)), ev=Decimal(str(ev)), ac=Decimal(str(ac)), bac=Decimal('1000'),
        cpi=Decimal('1'), spi=Decimal('1'), cv=Decimal('0'), sv=Decimal('0'),
        eac=Decimal(str(eac)), etc=Decimal('0'), vac=Decimal(str(vac)),
        tcpi_bac=Decimal('1'), tcpi_eac=Decimal('1')
    )


def test_dashboard_uses_all_visible_projects_and_portfolio_evm():
    db = SessionLocal()
    suffix = uuid.uuid4().hex[:10]
    try:
        company = Company(code=f'DASH-{suffix}', name='Dashboard Co')
        other = Company(code=f'OTHER-{suffix}', name='Other Co')
        user = User(username=f'dash_{suffix}', full_name='Dashboard Admin', password_hash='x', role=RoleEnum.admin, is_active=True)
        db.add_all([company, other, user]); db.flush()
        db.add(UserCompanyAccess(user_id=user.id, company_id=company.id, branch_id=None))
        projects = []
        for i in range(13):
            p = Project(company_id=company.id, code=f'P{i:02d}-{suffix}', name=f'Project {i}', budget=Decimal('100'))
            projects.append(p)
        hidden = Project(company_id=other.id, code=f'X-{suffix}', name='Other tenant', budget=Decimal('9999'))
        db.add_all(projects + [hidden]); db.flush()
        for p in projects:
            db.add(ProjectCost(company_id=company.id, project_id=p.id, cost_type='test', amount=Decimal('10')))
        db.add(ProjectCost(company_id=other.id, project_id=hidden.id, cost_type='test', amount=Decimal('9999')))
        db.add_all([
            _snapshot(company.id, projects[0].id, date(2026, 8, 1), 100, 80, 100, 130, -30),
            _snapshot(company.id, projects[1].id, date(2026, 8, 2), 200, 180, 150, 160, 40),
        ])
        db.commit()

        data = _dashboard_data(db, user, company.id, None)
        assert data['metrics']['project_count'] == 13
        assert data['metrics']['project_value'] == 1300.0
        assert data['metrics']['actual_cost'] == 130.0
        assert round(data['metrics']['cpi'], 4) == round(260 / 250, 4)
        assert round(data['metrics']['spi'], 4) == round(260 / 300, 4)
        assert data['metrics']['eac'] == 290.0
        assert data['metrics']['vac'] == 10.0
        assert all(row['project'].company_id == company.id for row in data['projects'])
    finally:
        db.rollback()
        db.close()


def test_dashboard_http_render_export_and_new_project_page(client):
    from app.auth import create_access_token
    db = SessionLocal(); suffix = uuid.uuid4().hex[:10]
    try:
        company = Company(code=f'HTTP-{suffix}', name='HTTP Dashboard Co')
        user = User(username=f'http_{suffix}', full_name='HTTP Admin', password_hash='x', role=RoleEnum.admin, is_active=True)
        db.add_all([company, user]); db.flush()
        db.add(UserCompanyAccess(user_id=user.id, company_id=company.id, branch_id=None)); db.commit()
        token = create_access_token(user)
        client.cookies.set('access_token', token)
        headers = {'X-Company-ID': str(company.id)}
        r = client.get('/', headers=headers)
        assert r.status_code == 200
        assert 'HTTP Dashboard Co' in r.text
        assert '/dashboard/export.csv' in r.text
        r = client.get('/dashboard/export.csv', headers=headers)
        assert r.status_code == 200 and 'Project Count' in r.text
        r = client.get('/projects/new', headers=headers)
        assert r.status_code == 200
        assert 'إضافة مشروع جديد' in r.text
    finally:
        client.cookies.clear()
        db.rollback(); db.close()
