from datetime import date
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
import app.construction_models
from app.enterprise_models import Company, Project
from app.construction_services import (create_activity, create_schedule_update_period, create_schedule_update_line,
    resource_curves, ConstructionRecoveryPlan, link_recovery_activity, ConstructionEOTClaim, submit_eot_claim, approve_eot_claim)

def db_setup():
    e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); S=sessionmaker(bind=e); db=S()
    c=Company(code='C053',name='Controls Co'); db.add(c); db.flush(); p=Project(company_id=c.id,code='P053',name='Project',budget=1000); db.add(p); db.flush(); return db,c,p

def test_schedule_update_and_resource_curves():
    db,c,p=db_setup(); a=create_activity(db,c.id,p.id,'A1','Activity',date(2026,9,1),date(2026,9,5),1000)
    period=create_schedule_update_period(db,c.id,p.id,date(2026,9,5)); row=create_schedule_update_line(db,c.id,p.id,period.id,a.id,date(2026,9,2),date(2026,9,7),50)
    assert row.finish_variance_days==2 and a.actual_finish==date(2026,9,7) and a.status=='in_progress'

def test_recovery_link_governance():
    db,c,p=db_setup(); a=create_activity(db,c.id,p.id,'A1','Activity',date(2026,9,1),date(2026,9,5),1000)
    plan=ConstructionRecoveryPlan(company_id=c.id,project_id=p.id,plan_no='RP-1',title='Recovery',target_date=date(2026,9,5)); db.add(plan); db.flush()
    link=link_recovery_activity(db,c.id,p.id,plan.id,a.id,target_finish=date(2026,9,4),target_progress=100,acceleration_factor='1.25')
    assert link.activity_id==a.id and link.acceleration_factor == Decimal('1.25')

def test_eot_requires_approved_tia():
    db,c,p=db_setup(); claim=ConstructionEOTClaim(company_id=c.id,project_id=p.id,claim_no='EOT-1',claimed_days=5); db.add(claim); db.flush(); submit_eot_claim(db,c.id,claim.id,1)
    try: approve_eot_claim(db,c.id,claim.id,3,1); assert False
    except ValueError as e: assert 'approved time impact' in str(e)
