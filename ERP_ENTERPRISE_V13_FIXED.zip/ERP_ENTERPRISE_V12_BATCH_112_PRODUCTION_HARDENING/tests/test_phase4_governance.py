import datetime
from decimal import Decimal
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from app.models import Base, User, RoleEnum, Customer
from app.enterprise_models import Currency, Company, Branch, UserCompanyAccess
from app.governance_models import Permission, Role, RolePermission, UserRole, ApprovalRule, ApprovalRuleStep, ApprovalRequest, ApprovalAction, GovernanceAuditLog
from app.governance import set_request_context, clear_request_context
from app.workflows import request_approval, act_on_approval


def make_db():
    e = create_engine('sqlite:///:memory:', connect_args={'check_same_thread': False})
    Base.metadata.create_all(e)
    return sessionmaker(bind=e)()


def setup_tenant(db):
    ccy = Currency(code='EGP', name='Egyptian Pound'); db.add(ccy); db.flush()
    company = Company(code='C1', name='Company 1', base_currency_id=ccy.id); db.add(company); db.flush()
    branch = Branch(company_id=company.id, code='B1', name='Branch 1'); db.add(branch)
    user = User(username='approver', full_name='Approver', password_hash='x', role=RoleEnum.employee); db.add(user); db.flush()
    db.add(UserCompanyAccess(user_id=user.id, company_id=company.id, branch_id=branch.id));
    perm = Permission(code='journal:post', description='Post journals'); db.add(perm); db.flush()
    role = Role(code='finance', name='Finance'); db.add(role); db.flush()
    db.add(RolePermission(role_id=role.id, permission_id=perm.id)); db.add(UserRole(user_id=user.id, role_id=role.id, company_id=company.id, branch_id=branch.id));
    db.commit()
    return company, branch, user, role


def test_tenant_stamping_and_audit():
    db = make_db(); company, branch, user, _ = setup_tenant(db)
    set_request_context(request_id='req-1', user_id=user.id, company_id=company.id, branch_id=branch.id, ip_address='127.0.0.1')
    row = Customer(code='CUST1', name='Tenant Customer'); db.add(row); db.commit()
    assert row.company_id == company.id
    audit = db.execute(select(GovernanceAuditLog).where(GovernanceAuditLog.entity_type == 'Customer')).scalars().first()
    assert audit and audit.user_id == user.id and audit.company_id == company.id
    clear_request_context(); db.close()


def test_generic_multilevel_approval():
    db = make_db(); company, branch, user, _ = setup_tenant(db)
    rule = ApprovalRule(company_id=company.id, document_type='purchase_order', name='PO approval', min_amount=Decimal('1000'), priority=1)
    db.add(rule); db.flush()
    db.add_all([
        ApprovalRuleStep(rule_id=rule.id, sequence=1, required_permission='journal:post'),
        ApprovalRuleStep(rule_id=rule.id, sequence=2, required_permission='journal:post'),
    ]); db.commit()
    req = request_approval(db, company_id=company.id, branch_id=branch.id, document_type='purchase_order', document_id=10, requested_by_id=user.id, amount=Decimal('5000'))
    db.commit(); assert req.status == 'pending' and req.current_sequence == 1
    req = act_on_approval(db, req.id, user.id, 'approved'); db.commit(); assert req.current_sequence == 2 and req.status == 'pending'
    req = act_on_approval(db, req.id, user.id, 'approved'); db.commit(); assert req.status == 'approved'
    assert db.query(ApprovalAction).filter_by(request_id=req.id).count() == 2
    db.close()
