from datetime import datetime, timedelta
from decimal import Decimal

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models import Base, Account, AccountTypeEnum, JournalEntry, JournalLine, BankReconciliation, BankReconciliationItem
from app.enterprise_models import Company
from app.accounting import create_entry
from app.governance import set_request_context, clear_request_context


def setup():
    e = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(e)
    S = sessionmaker(bind=e)
    db = S()
    c = Company(code="BR76", name="Bank Rec Hardening")
    db.add(c); db.flush()
    bank = Account(company_id=c.id, code="1110", name="Bank", account_type=AccountTypeEnum.asset,
                   is_active=True, statement_section="cash_and_equivalents")
    revenue = Account(company_id=c.id, code="4100", name="Revenue", account_type=AccountTypeEnum.revenue, is_active=True)
    db.add_all([bank, revenue]); db.flush()
    return db, c, bank, revenue


def post(db, c, bank, revenue, dt, amount):
    set_request_context(request_id="br76", user_id=1, company_id=c.id, branch_id=None, ip_address=None)
    create_entry(db, "BR76", 1, [(bank.code, Decimal(amount), Decimal("0")),
                                 (revenue.code, Decimal("0"), Decimal(amount))],
                 source_type="test", source_id=1, entry_date=dt, company_id=c.id)
    db.commit(); clear_request_context()


def test_credit_statement_matches_bank_gl_debit():
    from app.routers.advanced_finance_router import _find_bank_match_candidate
    db, c, bank, revenue = setup()
    dt = datetime(2026, 1, 10)
    post(db, c, bank, revenue, dt, "100")
    rec = BankReconciliation(company_id=c.id, bank_account_id=bank.id, bank_account_code=bank.code,
                            statement_date=dt, statement_balance=Decimal("100"), book_balance=0,
                            difference=0, reconciliation_number="BR76-1")
    db.add(rec); db.flush()
    item = BankReconciliationItem(company_id=c.id, reconciliation_id=rec.id, transaction_date=dt,
                                  amount=Decimal("100"), direction="credit")
    db.add(item); db.flush()
    candidate = _find_bank_match_candidate(db, rec, item, c.id, None)
    assert candidate is not None
    assert candidate.account_id == bank.id


def test_debit_statement_matches_bank_gl_credit():
    from app.routers.advanced_finance_router import _find_bank_match_candidate
    db, c, bank, revenue = setup()
    dt = datetime(2026, 1, 10)
    # Manually create a posted withdrawal: bank credited, counter-account debited.
    set_request_context(request_id="br76b", user_id=1, company_id=c.id, branch_id=None, ip_address=None)
    create_entry(db, "BR76", 1, [(revenue.code, Decimal("50"), Decimal("0")),
                                 (bank.code, Decimal("0"), Decimal("50"))],
                 source_type="test", source_id=2, entry_date=dt, company_id=c.id)
    db.commit(); clear_request_context()
    rec = BankReconciliation(company_id=c.id, bank_account_id=bank.id, bank_account_code=bank.code,
                            statement_date=dt, statement_balance=Decimal("-50"), book_balance=0,
                            difference=0, reconciliation_number="BR76-2")
    db.add(rec); db.flush()
    item = BankReconciliationItem(company_id=c.id, reconciliation_id=rec.id, transaction_date=dt,
                                  amount=Decimal("50"), direction="debit")
    db.add(item); db.flush()
    assert _find_bank_match_candidate(db, rec, item, c.id, None) is not None


def test_match_window_is_symmetric():
    from app.routers.advanced_finance_router import _find_bank_match_candidate
    db, c, bank, revenue = setup()
    item_dt = datetime(2026, 1, 10)
    post(db, c, bank, revenue, item_dt + timedelta(days=8), "100")
    rec = BankReconciliation(company_id=c.id, bank_account_id=bank.id, bank_account_code=bank.code,
                            statement_date=item_dt + timedelta(days=8), statement_balance=100,
                            book_balance=0, difference=0, reconciliation_number="BR76-3")
    db.add(rec); db.flush()
    item = BankReconciliationItem(company_id=c.id, reconciliation_id=rec.id, transaction_date=item_dt,
                                  amount=100, direction="credit")
    db.add(item); db.flush()
    assert _find_bank_match_candidate(db, rec, item, c.id, None) is None


def test_gl_line_cannot_be_reused_across_reconciliations():
    from app.routers.advanced_finance_router import _find_bank_match_candidate
    db, c, bank, revenue = setup()
    dt = datetime(2026, 1, 10)
    post(db, c, bank, revenue, dt, "100")
    line = db.query(JournalLine).filter(JournalLine.account_id == bank.id).first()
    rec1 = BankReconciliation(company_id=c.id, bank_account_id=bank.id, bank_account_code=bank.code,
                              statement_date=dt, statement_balance=100, book_balance=0, difference=0,
                              reconciliation_number="BR76-4")
    rec2 = BankReconciliation(company_id=c.id, bank_account_id=bank.id, bank_account_code=bank.code,
                              statement_date=dt, statement_balance=100, book_balance=0, difference=0,
                              reconciliation_number="BR76-5")
    db.add_all([rec1, rec2]); db.flush()
    used = BankReconciliationItem(company_id=c.id, reconciliation_id=rec1.id, transaction_date=dt,
                                  amount=100, direction="credit", matched_journal_line_id=line.id,
                                  status="matched")
    candidate_item = BankReconciliationItem(company_id=c.id, reconciliation_id=rec2.id, transaction_date=dt,
                                            amount=100, direction="credit")
    db.add_all([used, candidate_item]); db.flush()
    assert _find_bank_match_candidate(db, rec2, candidate_item, c.id, None) is None
