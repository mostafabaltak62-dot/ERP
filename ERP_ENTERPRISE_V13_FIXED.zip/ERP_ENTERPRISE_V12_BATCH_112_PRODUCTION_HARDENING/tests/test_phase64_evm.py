from decimal import Decimal
from datetime import date
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
import app.construction_models
from app.enterprise_models import Company, Project, ProjectCost
from app.construction_services import create_activity, create_schedule_baseline, create_progress_period, set_activity_progress, create_time_phased_budget, construction_evm

def test_phase64_evm_full_chain():
 e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); S=sessionmaker(bind=e); db=S()
 c=Company(code='C64',name='EVM Co'); db.add(c); db.flush(); p=Project(company_id=c.id,code='P64',name='Tower',budget=100000); db.add(p); db.flush()
 a=create_activity(db,c.id,p.id,'A-01','Concrete',date(2026,8,1),date(2026,9,30),100000)
 b=create_schedule_baseline(db,c.id,p.id,1,date(2026,8,1),[{'activity_id':a.id,'planned_start':date(2026,8,1),'planned_finish':date(2026,9,30),'budget_amount':100000}])
 create_time_phased_budget(db,c.id,p.id,date(2026,8,25),40000,b.id,a.id)
 period=create_progress_period(db,c.id,p.id,date(2026,8,25),b.id); set_activity_progress(db,c.id,p.id,period.id,a.id,30)
 db.add(ProjectCost(company_id=c.id,project_id=p.id,cost_type='labor',source_type='test',source_id=64,amount=35000)); db.flush()
 x=construction_evm(db,c.id,p.id,date(2026,8,25),b.id,'cpi')
 assert x['pv']==Decimal('40000.00'); assert x['ev']==Decimal('30000.00'); assert x['ac']==Decimal('35000.00'); assert x['bac']==Decimal('100000.00')
 assert x['cpi'] == Decimal('0.85714286'); assert x['spi']==Decimal('0.75000000'); assert x['cv']==Decimal('-5000.00'); assert x['sv']==Decimal('-10000.00'); assert x['eac']==Decimal('116666.67'); assert x['vac']==Decimal('-16666.67')
