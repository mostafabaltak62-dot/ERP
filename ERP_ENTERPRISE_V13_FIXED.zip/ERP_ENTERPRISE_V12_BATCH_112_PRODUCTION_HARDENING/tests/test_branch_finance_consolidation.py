from datetime import date, datetime
from app.financial_reporting import trial_balance, cash_flow
from app.models import Account, AccountTypeEnum, JournalEntry, JournalLine
from app.enterprise_models import Company, Branch


def test_branch_cash_is_separate_and_consolidated():
    from app.database import SessionLocal
    db=SessionLocal()
    c=Company(code='BC',name='Branch Co',is_active=True); db.add(c); db.flush()
    b1=Branch(company_id=c.id,code='01',name='Branch 01'); b2=Branch(company_id=c.id,code='02',name='Branch 02'); db.add_all([b1,b2]); db.flush()
    cash=Account(company_id=c.id,code='1100',name='Cash',account_type=AccountTypeEnum.asset,statement_section='cash_and_equivalents',is_active=True)
    rev=Account(company_id=c.id,code='4100',name='Revenue',account_type=AccountTypeEnum.revenue,statement_section='revenue',cash_flow_category='operating',is_active=True)
    db.add_all([cash,rev]); db.flush()
    for branch, amount, num in ((b1,100,'J01'),(b2,250,'J02')):
        e=JournalEntry(company_id=c.id,branch_id=branch.id,entry_number=num,description='sale',entry_date=datetime(2026,1,1),status='draft')
        db.add(e); db.flush(); db.add_all([
            JournalLine(company_id=c.id,branch_id=branch.id,entry_id=e.id,account_id=cash.id,debit=amount,credit=0),
            JournalLine(company_id=c.id,branch_id=branch.id,entry_id=e.id,account_id=rev.id,debit=0,credit=amount),
        ]); db.flush(); e.status='posted'; e.posted_at=datetime(2026,1,1)
    db.commit()
    assert cash_flow(db,c.id,date(2026,1,1),date(2026,1,31),b1.id)['closing_cash'] == 100
    assert cash_flow(db,c.id,date(2026,1,1),date(2026,1,31),b2.id)['closing_cash'] == 250
    assert cash_flow(db,c.id,date(2026,1,1),date(2026,1,31),None)['closing_cash'] == 350
    db.close()
