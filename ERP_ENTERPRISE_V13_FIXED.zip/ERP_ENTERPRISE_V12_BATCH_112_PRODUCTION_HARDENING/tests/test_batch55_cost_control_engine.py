from datetime import date
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
from app.enterprise_models import Company, Project
from app.construction_models import ConstructionCostCode, WBSNode, ConstructionCostBudgetLine
from app.construction_services import (create_cost_budget_revision, approve_cost_budget_revision,
    build_time_phased_cost, create_cost_forecast_version, approve_cost_forecast_version, calculate_cost_variance)

def setup():
    import app.construction_models
    e=create_engine('sqlite:///:memory:')
    Base.metadata.create_all(e)
    S=sessionmaker(bind=e); db=S()
    c=Company(code='C55', name='Cost Engine Co'); db.add(c); db.flush()
    p=Project(company_id=c.id, code='P55', name='Project 55', budget=100000); db.add(p); db.flush()
    cc=ConstructionCostCode(company_id=c.id, code='01', name='Civil', category='material', is_active=True); db.add(cc); db.flush()
    w=WBSNode(company_id=c.id, project_id=p.id, code='1', name='Civil', level=1, budget_amount=1000, is_active=True); db.add(w); db.flush()
    db.add(ConstructionCostBudgetLine(company_id=c.id,project_id=p.id,cost_code_id=cc.id,wbs_id=w.id,description='Base',budget_amount=1000,budget_date=date(2026,9,1),status='active'))
    db.commit(); return db,c,p,cc,w

def test_budget_revision_governance():
    db,c,p,cc,w=setup()
    r=create_cost_budget_revision(db,c.id,p.id,date(2026,9,1),'Approved scope change',7,[{'cost_code_id':cc.id,'wbs_id':w.id,'period_date':date(2026,10,1),'delta_amount':250}])
    assert r.revision_no==1 and r.status=='draft'
    approve_cost_budget_revision(db,c.id,r.id,8)
    assert r.status=='approved' and r.approved_by_id==8

def test_time_phased_cost_is_upsert_and_nonnegative():
    db,c,p,cc,w=setup()
    r=build_time_phased_cost(db,c.id,p.id,date(2026,9,1),cc.id,w.id,500,100,50)
    assert Decimal(str(r.budget_amount))==Decimal('500.00')
    build_time_phased_cost(db,c.id,p.id,date(2026,9,1),cc.id,w.id,700,120,80)
    assert Decimal(str(r.budget_amount))==Decimal('700.00')

def test_forecast_version_and_variance():
    db,c,p,cc,w=setup()
    v=create_cost_forecast_version(db,c.id,p.id,date(2026,9,1),7,'manual',[{'cost_code_id':cc.id,'wbs_id':w.id,'etc_amount':300,'eac_amount':900}])
    assert v.version_no==1 and v.total_etc==Decimal('300.00')
    approve_cost_forecast_version(db,c.id,v.id,8)
    assert v.status=='approved'
    row=calculate_cost_variance(db,c.id,p.id,date(2026,9,1))
    assert row.status in {'on_track','watch','critical','unbudgeted'}
