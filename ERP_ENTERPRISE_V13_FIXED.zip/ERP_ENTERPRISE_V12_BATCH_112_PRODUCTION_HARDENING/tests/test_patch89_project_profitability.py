from datetime import date
from decimal import Decimal

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models import Base
from app.enterprise_models import Company, Project, ProjectCost, Contract, ProgressCertificate
from app.construction_models import ConstructionCostBudgetLine, ConstructionAuthoritativeBudgetLine
from app.construction_services import project_profitability


def setup():
    import app.construction_models  # register construction tables
    e = create_engine('sqlite:///:memory:')
    Base.metadata.create_all(e)
    S = sessionmaker(bind=e)
    db = S()
    c = Company(code='P89', name='Project Profitability Co')
    db.add(c); db.flush()
    p = Project(company_id=c.id, code='PR89', name='Tower 89', budget=999999)
    db.add(p); db.flush()
    return db, c, p


def test_project_profitability_uses_authoritative_budget_and_posted_revenue_only():
    db, c, p = setup()
    db.add_all([
        ConstructionCostBudgetLine(company_id=c.id, project_id=p.id, description='legacy', budget_amount=90000, status='active'),
        ConstructionAuthoritativeBudgetLine(company_id=c.id, project_id=p.id, period_date=date(2026,1,1), base_amount=100000, revision_amount=20000, approved_budget=120000),
        ProjectCost(company_id=c.id, project_id=p.id, cost_type='material', source_type='test', source_id=1, amount=30000),
        ProjectCost(company_id=c.id, project_id=p.id, cost_type='labor', source_type='test', source_id=2, amount=10000),
        ProgressCertificate(company_id=c.id, project_id=p.id, certificate_number='POSTED', certificate_date=date(2026,8,1), gross_amount=70000, retention_amount=0, advance_recovery=0, net_amount=70000, status='posted'),
        ProgressCertificate(company_id=c.id, project_id=p.id, certificate_number='DRAFT', certificate_date=date(2026,8,2), gross_amount=50000, retention_amount=0, advance_recovery=0, net_amount=50000, status='draft'),
    ])
    db.commit()
    r = project_profitability(db, c.id, p.id)
    assert r['budget'] == Decimal('120000.00')
    assert r['certified_revenue'] == Decimal('70000.00')
    assert r['actual'] == Decimal('40000.00')
    assert r['actual_profit'] == Decimal('30000.00')
    assert r['actual_margin_pct'] == Decimal('42.86')
    assert r['eac'] == Decimal('120000.00')
    assert r['forecast_profit'] == Decimal('-50000.00')
    assert r['variance_at_completion'] == Decimal('0.00')


def test_project_profitability_rejects_cross_company_project():
    db, c1, p1 = setup()
    c2 = Company(code='P89B', name='Other Co')
    db.add(c2); db.flush()
    p2 = Project(company_id=c2.id, code='PR89', name='Other Project', budget=1000)
    db.add(p2); db.commit()
    try:
        project_profitability(db, c1.id, p2.id)
        assert False
    except ValueError as exc:
        assert str(exc) == 'Project not found'
