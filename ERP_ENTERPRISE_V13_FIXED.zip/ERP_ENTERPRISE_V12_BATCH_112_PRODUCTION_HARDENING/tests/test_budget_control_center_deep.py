from datetime import date
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
from app.enterprise_models import Company, Project, ProjectCost
from app.construction_models import ConstructionCostBudgetLine, ConstructionCostBudgetRevision, ConstructionCostBudgetRevisionLine, ConstructionCommitment
from app.commercial_completion_models import BudgetControlPolicy
from app.construction_services import approve_cost_budget_revision, create_commitment, authoritative_budget_total


def setup():
    import app.construction_models, app.commercial_completion_models
    e=create_engine('sqlite:///:memory:')
    Base.metadata.create_all(e)
    S=sessionmaker(bind=e); db=S()
    c=Company(code='BC74',name='Budget Center'); db.add(c); db.flush()
    p=Project(company_id=c.id,code='P74',name='Budget Project',budget=1000); db.add(p); db.flush()
    db.add(ConstructionCostBudgetLine(company_id=c.id,project_id=p.id,description='Base',budget_amount=1000,budget_date=date(2026,9,1),status='active'))
    db.commit(); return db,c,p


def test_authoritative_budget_is_used_after_approved_revision():
    db,c,p=setup()
    assert authoritative_budget_total(db,c.id,p.id)==Decimal('1000.00')
    r=ConstructionCostBudgetRevision(company_id=c.id,project_id=p.id,revision_no=1,revision_date=date(2026,9,1),reason='Increase',created_by_id=1,status='draft')
    db.add(r); db.flush(); db.add(ConstructionCostBudgetRevisionLine(company_id=c.id,revision_id=r.id,period_date=date(2026,9,1),delta_amount=500)); db.commit()
    approve_cost_budget_revision(db,c.id,r.id,1)
    assert authoritative_budget_total(db,c.id,p.id)==Decimal('1500.00')


def test_budget_policy_blocks_commitment_using_actual_plus_open_commitment():
    db,c,p=setup(); db.add(BudgetControlPolicy(company_id=c.id,project_id=p.id,tolerance_percent=0,block_over_budget=True,warning_percent=80,is_active=True)); db.add(ProjectCost(company_id=c.id,project_id=p.id,cost_type='material',amount=900)); db.commit()
    try:
        create_commitment(db,c.id,p.id,'Too large',200,date(2026,9,1))
        assert False
    except ValueError as e:
        assert 'budget-control' in str(e).lower()


def test_budget_policy_tolerance_allows_controlled_overrun():
    db,c,p=setup(); db.add(BudgetControlPolicy(company_id=c.id,project_id=p.id,tolerance_percent=10,block_over_budget=True,warning_percent=80,is_active=True)); db.commit()
    row=create_commitment(db,c.id,p.id,'Within tolerance',1050,date(2026,9,1)); assert row.committed_amount==Decimal('1050.00')
