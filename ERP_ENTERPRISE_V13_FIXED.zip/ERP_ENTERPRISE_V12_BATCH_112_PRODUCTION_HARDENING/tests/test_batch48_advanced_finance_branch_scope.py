from datetime import datetime
from decimal import Decimal
from app.database import SessionLocal
from app.models import Account, AccountTypeEnum, CostCenter, TaxRate, AccrualEntry, WithholdingTaxRate, FixedAsset
from app.enterprise_models import Company, Branch


def test_advanced_finance_masters_are_company_and_branch_scoped():
    db=SessionLocal()
    c=Company(code='AF48',name='Advanced Finance 48',is_active=True); db.add(c); db.flush()
    b1=Branch(company_id=c.id,code='A',name='Branch A'); b2=Branch(company_id=c.id,code='B',name='Branch B'); db.add_all([b1,b2]); db.flush()
    cc1=CostCenter(company_id=c.id,branch_id=b1.id,code='CC01',name='A Center')
    cc2=CostCenter(company_id=c.id,branch_id=b2.id,code='CC01',name='B Center')
    tx1=TaxRate(company_id=c.id,branch_id=b1.id,code='VAT',name='VAT A',rate=Decimal('14'),tax_account_code='2200',tax_direction='output')
    tx2=TaxRate(company_id=c.id,branch_id=b2.id,code='VAT',name='VAT B',rate=Decimal('15'),tax_account_code='2200',tax_direction='output')
    db.add_all([cc1,cc2,tx1,tx2]); db.commit()
    assert db.query(CostCenter).filter(CostCenter.company_id==c.id,CostCenter.branch_id==b1.id).one().name == 'A Center'
    assert db.query(CostCenter).filter(CostCenter.company_id==c.id,CostCenter.branch_id==b2.id).one().name == 'B Center'
    assert db.query(TaxRate).filter(TaxRate.company_id==c.id,TaxRate.branch_id==b1.id).one().rate == Decimal('14')
    assert db.query(TaxRate).filter(TaxRate.company_id==c.id,TaxRate.branch_id==b2.id).one().rate == Decimal('15')
    db.close()
