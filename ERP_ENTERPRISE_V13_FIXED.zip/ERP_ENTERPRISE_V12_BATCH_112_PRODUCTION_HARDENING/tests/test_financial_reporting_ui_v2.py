from datetime import datetime
from app.models import User, RoleEnum
from app.enterprise_models import Company
from app.governance_models import GovernanceAuditLog
from app.database import SessionLocal
from app.main import app
from fastapi.testclient import TestClient


def test_financial_reporting_routes_registered_and_protected():
    paths = {r.path for r in app.routes}
    assert "/accounting/reports" in paths
    assert "/accounting/reports/general-ledger" in paths
    assert "/accounting/reports/account-statement/{account_id}" in paths
    assert "/accounting/reports/audit" in paths
    assert "/accounting/reports/audit/{audit_id}" in paths


def test_governance_audit_scope_is_company_filtered():
    db=SessionLocal()
    c1=Company(code="AUD1",name="Audit One"); c2=Company(code="AUD2",name="Audit Two")
    db.add_all([c1,c2]); db.flush()
    db.add_all([
        GovernanceAuditLog(company_id=c1.id, action="create", entity_type="Invoice", entity_id="1", request_id="r1", created_at=datetime(2026,1,1)),
        GovernanceAuditLog(company_id=c2.id, action="create", entity_type="Invoice", entity_id="2", request_id="r2", created_at=datetime(2026,1,1)),
    ]); db.commit()
    rows=db.query(GovernanceAuditLog).filter(GovernanceAuditLog.company_id==c1.id).all()
    assert len(rows)==1 and rows[0].entity_id=="1"
    db.close()
