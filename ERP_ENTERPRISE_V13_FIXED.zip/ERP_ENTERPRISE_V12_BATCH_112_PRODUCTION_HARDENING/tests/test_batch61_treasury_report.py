from datetime import datetime, date
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, Account, AccountTypeEnum, JournalEntry, JournalLine
from app.enterprise_models import Company
from app.accounting import create_entry
from app.governance import set_request_context, clear_request_context
from app.financial_reporting import cash_flow


def setup():
    e=create_engine("sqlite:///:memory:")
    Base.metadata.create_all(e)
    S=sessionmaker(bind=e); db=S(); c=Company(code="TR61",name="Treasury Co"); db.add(c); db.flush()
    cash=Account(company_id=c.id,code="1100",name="Cash",account_type=AccountTypeEnum.asset,is_active=True,statement_section="cash_and_equivalents")
    bank=Account(company_id=c.id,code="1200",name="Bank",account_type=AccountTypeEnum.asset,is_active=True,statement_section="cash_and_equivalents")
    rev=Account(company_id=c.id,code="4100",name="Revenue",account_type=AccountTypeEnum.revenue,is_active=True,statement_section="revenue")
    exp=Account(company_id=c.id,code="5100",name="Expense",account_type=AccountTypeEnum.expense,is_active=True,statement_section="operating_expenses")
    db.add_all([cash,bank,rev,exp]); db.flush(); return db,c,cash,bank,rev,exp


def post(db,c,num,dt,pairs):
    set_request_context(request_id="tr61",user_id=1,company_id=c.id,branch_id=None,ip_address=None)
    create_entry(db,num,1,[(a.code,d,cr) for a,d,cr in pairs],source_type="test_treasury",source_id=abs(hash((num,c.id)))%100000000,entry_date=dt)
    db.commit(); clear_request_context()


def test_treasury_authoritative_cash_reconciles():
    db,c,cash,bank,rev,exp=setup()
    post(db,c,"OPEN",datetime(2026,1,1),[(cash,"1000","0"),(rev,"0","1000")])
    post(db,c,"OUT",datetime(2026,1,10),[(exp,"250","0"),(cash,"0","250")])
    post(db,c,"BANK",datetime(2026,1,20),[(bank,"500","0"),(rev,"0","500")])
    cf=cash_flow(db,c.id,date(2026,1,1),date(2026,1,31))
    assert Decimal(str(cf["closing_cash"])) == Decimal("1250.00")


def test_treasury_date_validation_and_tenant_scope():
    db,c,cash,bank,rev,exp=setup()
    post(db,c,"J",datetime(2026,2,1),[(cash,"100","0"),(rev,"0","100")])
    set_request_context(request_id="tr61",user_id=1,company_id=c.id,branch_id=None,ip_address=None)
    from app.routers.commercial_workspace_router import treasury_report
    # Function-level invariant: invalid date range must be rejected before querying rows.
    try:
        treasury_report(None,"2026-03-10","2026-03-01","",db,None)
    except Exception as exc:
        assert getattr(exc,"status_code",None) == 422
    else:
        raise AssertionError("invalid treasury date range was accepted")
    clear_request_context()
