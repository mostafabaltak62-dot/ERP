# -*- coding: utf-8 -*-
"""
Phase 4 merge -- HTTP-level regression tests.

The 42 tests that shipped with the PHASE5_6 package all call service-layer
functions directly (create_sales_order(), run_company_valuation(), etc.) and
never go through FastAPI's routing/middleware stack. Because of that, a
critical bug slipped through: the request-context middleware in app/main.py
never initialized request.state.user for anonymous requests, so EVERY page
-- including /login itself -- returned HTTP 500 for a first-time visitor.
No amount of service-layer testing could have caught that; only a real
HTTP request through TestClient exercises the middleware chain that
actually broke.

These tests exist specifically to close that gap and to prevent any
regression in the auth/middleware pipeline going forward, per directive
section 31 ("An endpoint returning HTTP 200 does not mean the feature is
correct" applies in both directions -- here, unit tests passing didn't mean
the app worked over HTTP).
"""
import os
import uuid

os.environ.setdefault("ERP_ENV", "development")
os.environ["DATABASE_URL"] = f"sqlite:///./test_http_{uuid.uuid4().hex[:8]}.db"

import pytest
def test_login_page_loads_for_anonymous_visitor(client):
    """This is the exact request that returned HTTP 500 before the fix:
    a fresh visitor with no cookie at all hitting the login page."""
    resp = client.get("/login")
    assert resp.status_code == 200


def test_root_redirects_or_denies_anonymous_visitor(client):
    """An anonymous visitor must never see protected content, and must
    never trigger a 500 -- only 200 (public), 303/307 (redirect to login),
    or 401/403 (denied) are acceptable."""
    resp = client.get("/", follow_redirects=False)
    assert resp.status_code in (200, 303, 307, 401, 403)


def test_protected_pages_do_not_500_when_anonymous(client):
    """Sweep the main module pages anonymously. None of them should ever
    crash with a 500 -- that was the actual production-breaking bug."""
    for path in ["/sales", "/purchases", "/inventory", "/accounting",
                 "/finance", "/users", "/pro-finance/assets", "/enterprise/taxes"]:
        resp = client.get(path, follow_redirects=False)
        assert resp.status_code != 500, f"{path} returned 500 for an anonymous visitor"


def test_admin_login_and_full_page_sweep(client):
    """End-to-end: log in as the bootstrapped admin, then confirm every
    core module page renders (200) with a valid session."""
    login = client.post("/login", data={
        "username": "admin",
        "password": os.environ["ERP_BOOTSTRAP_ADMIN_PASSWORD"],
    }, follow_redirects=False)
    assert login.status_code in (200, 303, 302), login.text

    for path in ["/", "/sales", "/purchases", "/inventory", "/accounting",
                 "/finance", "/users", "/pro-finance/assets", "/enterprise/taxes"]:
        resp = client.get(path)
        assert resp.status_code == 200, f"{path} -> {resp.status_code} after authenticated login"


def test_openapi_schema_is_served(client):
    """Sanity check that the app's route table is intact and serving."""
    resp = client.get("/openapi.json")
    assert resp.status_code == 200
    paths = resp.json()["paths"]
    assert len(paths) > 50  # this package has ~100+ endpoints; a big drop signals a wiring break
