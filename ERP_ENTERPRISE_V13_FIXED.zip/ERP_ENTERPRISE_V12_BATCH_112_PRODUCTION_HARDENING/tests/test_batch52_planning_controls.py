from datetime import date
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
import app.construction_models
from app.enterprise_models import Company, Project
from app.construction_services import create_activity, add_schedule_resource, create_schedule_update_period, approve_schedule_update_period, lock_schedule_update_period, add_resource_period, resource_histogram

def test_schedule_period_lock_and_resource_histogram():
    e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); S=sessionmaker(bind=e); db=S()
    c=Company(code='C052',name='Controls Co'); db.add(c); db.flush()
    p=Project(company_id=c.id,code='P052',name='Project',budget=1000); db.add(p); db.flush()
    a=create_activity(db,c.id,p.id,'A1','Activity',date(2026,9,1),date(2026,9,5),1000)
    r=add_schedule_resource(db,c.id,p.id,a.id,'labor','Crew',10,0,100)
    period=create_schedule_update_period(db,c.id,p.id,date(2026,9,1))
    add_resource_period(db,c.id,p.id,r.id,date(2026,9,1),4,3)
    add_resource_period(db,c.id,p.id,r.id,date(2026,9,2),6,7)
    approve_schedule_update_period(db,c.id,period.id,1); lock_schedule_update_period(db,c.id,period.id,1)
    try:
        add_resource_period(db,c.id,p.id,r.id,date(2026,9,1),5,5)
        assert False
    except ValueError:
        pass
    h=resource_histogram(db,c.id,p.id)
    assert len(h)==2 and h[0]['planned_units']==Decimal('4.00') and h[1]['actual_units']==Decimal('7.00')
