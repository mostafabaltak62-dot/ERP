from pathlib import Path

def test_inventory_reconciliation_uses_ending_valuation_not_double_consumption():
    text=Path('app/accounting_controls.py').read_text(encoding='utf-8')
    assert 'r["difference"] = _money(r["movement_value"] - r["valued_remaining"])' in text

def test_inventory_gl_difference_is_release_gate_but_cogs_is_diagnostic():
    text=Path('app/accounting_controls.py').read_text(encoding='utf-8')
    assert 'gl_exception = (inventory_difference not in (None, ZERO))' in text
    page=Path('templates/inventory_reconciliation.html').read_text(encoding='utf-8')
    assert 'تشخيص' in page

def test_inventory_reconciliation_page_is_company_consolidated_until_branch_valuation_exists():
    text=Path('app/routers/accounting_router.py').read_text(encoding='utf-8')
    assert 'inventory_control(db,cid,as_of=as_of)' in text
