import os

from fastapi.testclient import TestClient
from app.main import app
from app.database import SessionLocal
from app.enterprise_models import Company


def test_bearer_mobile_request_enters_tenant_security_layer(client):
    db = SessionLocal()
    try:
        company_id = db.query(Company.id).filter(Company.code == "DEFAULT").order_by(Company.id).first()[0]
    finally:
        db.close()
    login = client.post("/api/v1/mobile/auth/login", json={
        "username": "admin",
        "password": os.environ["ERP_BOOTSTRAP_ADMIN_PASSWORD"],
        "company_id": company_id,
    })
    assert login.status_code == 200, login.text
    token = login.json()["access_token"]

    response = client.get(
        "/api/v1/mobile/dashboard",
        headers={"Authorization": f"Bearer {token}", "X-Company-ID": "1"},
    )
    assert response.status_code in (200, 403), response.text
    assert response.status_code != 500


def test_malformed_bearer_token_is_not_a_server_error():
    with TestClient(app) as isolated_client:
        response = isolated_client.get(
        "/api/v1/mobile/dashboard",
            follow_redirects=False,
            headers={"Authorization": "Bearer not-a-valid-token"},
        )
    assert response.status_code in (302, 307, 401, 403)
    assert response.status_code != 500
