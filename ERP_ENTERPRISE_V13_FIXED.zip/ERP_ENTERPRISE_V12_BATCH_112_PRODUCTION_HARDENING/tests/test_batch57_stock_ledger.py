from pathlib import Path


def test_stock_ledger_has_auditable_controls():
    router = Path("app/routers/commercial_workspace_router.py").read_text(encoding="utf-8")
    template = Path("templates/stock_ledger.html").read_text(encoding="utf-8")
    assert 'def stock_ledger(' in router
    assert 'StockMovement.company_id == cid' in router
    assert 'running balance' in router
    assert 'stock-ledger/export' in router
    assert 'page_size = max(25' in router
    assert 'total_count' in router
    assert 'تصدير CSV' in template
    assert 'الرصيد بعد الحركة' in template
    assert 'page={{ page+1 }}' in template


def test_stock_ledger_rejects_invalid_ranges_and_scopes_filters():
    text = Path("app/routers/commercial_workspace_router.py").read_text(encoding="utf-8")
    assert 'تاريخ البداية لا يمكن أن يكون بعد تاريخ النهاية' in text
    assert 'الصنف غير موجود في الشركة الحالية' in text
    assert 'المخزن غير موجود في الشركة الحالية' in text
    assert 'MovementTypeEnum(movement_type)' in text
