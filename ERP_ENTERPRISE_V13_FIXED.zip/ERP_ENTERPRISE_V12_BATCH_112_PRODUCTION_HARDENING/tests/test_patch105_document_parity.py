import json
from datetime import date
from types import SimpleNamespace
from io import BytesIO
from pathlib import Path
from openpyxl import load_workbook
from app.routers.construction_document_forms_router import FORM_TYPES, FORM_SCHEMAS, _excel_response, _pdf_response

def _row(status='draft'):
    return SimpleNamespace(form_no='SIR-1-2026-0001',status=status,submission_type='new',discipline='مدني',zone='A',level='01',issue_date=date(2026,9,2),due_date=date(2026,9,5),current_revision=2,contractor_representative='المقاول',consultant_representative='الاستشاري')

def test_excel_contains_all_control_metadata_and_decision_status():
    row=_row('approved_with_comments'); meta=FORM_TYPES['SIR']; schema=FORM_SCHEMAS['SIR']; data={f[0]:'VALUE' for sec in schema for f in sec['fields']}
    wb=load_workbook(BytesIO(_excel_response(row,SimpleNamespace(name='P'),meta,schema,data).body),read_only=True)
    vals=[c.value for rr in wb.active.iter_rows() for c in rr]
    for expected in [row.form_no,'معتمد مع ملاحظات / Approved as Noted',row.contractor_representative,row.consultant_representative,'2']: assert expected in vals

def test_pdf_contains_same_control_metadata_markers():
    row=_row('revision_required'); meta=FORM_TYPES['SIR']; schema=FORM_SCHEMAS['SIR']; data={f[0]:'VALUE' for sec in schema for f in sec['fields']}
    body=_pdf_response(row,SimpleNamespace(name='P'),meta,schema,data).body
    assert body.startswith(b'%PDF-') and len(body)>1000
    assert b'/Font' in body

def test_print_and_edit_templates_expose_issue_revision_and_representatives():
    for name in ['construction_document_print.html','construction_document_edit.html','construction_document_forms.html']:
        text=Path('templates',name).read_text()
        assert 'ممثل المقاول' in text and 'ممثل الاستشاري' in text
        assert 'تاريخ الإصدار' in text
