from datetime import datetime
from decimal import Decimal
from app.models import TaxRate, TaxTransaction, JournalEntry
from app.enterprise_models import Company
from app.database import SessionLocal


def _user(db, company):
    u=User(username=f"tax47_{company.id}", full_name="Tax Auditor", role=RoleEnum.admin, company_id=company.id, is_active=True)
    db.add(u); db.flush(); return u


def test_tax_report_filters_company_and_only_posted_entries():
    db=SessionLocal(); c1=Company(code="T47A",name="Tax A"); c2=Company(code="T47B",name="Tax B"); db.add_all([c1,c2]); db.flush()
    rate=TaxRate(company_id=c1.id,code=f"VAT47{c1.id}",name="VAT",rate=Decimal("14"),tax_account_code="2200",tax_direction="output"); db.add(rate); db.flush()
    je1=JournalEntry(company_id=c1.id,entry_number=f"J47P{c1.id}",description="posted",status="posted",entry_date=datetime(2026,1,10)); je2=JournalEntry(company_id=c1.id,entry_number=f"J47D{c1.id}",description="draft",status="draft",entry_date=datetime(2026,1,11)); db.add_all([je1,je2]); db.flush()
    db.add_all([TaxTransaction(company_id=c1.id,tax_rate_id=rate.id,source_type="sale_invoice",source_id=1,taxable_amount=100,tax_amount=14,tax_direction="output",journal_entry_id=je1.id,created_at=datetime(2026,1,10)), TaxTransaction(company_id=c1.id,tax_rate_id=rate.id,source_type="sale_invoice",source_id=2,taxable_amount=200,tax_amount=28,tax_direction="output",journal_entry_id=je2.id,created_at=datetime(2026,1,11)), TaxTransaction(company_id=c2.id,tax_rate_id=rate.id,source_type="sale_invoice",source_id=3,taxable_amount=300,tax_amount=42,tax_direction="output",created_at=datetime(2026,1,10))]); db.commit()
    # Mirror report predicate without HTTP auth setup.
    from sqlalchemy import or_, and_
    rows=db.query(TaxTransaction).join(TaxRate, TaxRate.id==TaxTransaction.tax_rate_id).join(JournalEntry, JournalEntry.id==TaxTransaction.journal_entry_id, isouter=True).filter(TaxTransaction.company_id==c1.id, TaxRate.company_id==c1.id, or_(and_(TaxTransaction.journal_entry_id.is_(None),TaxTransaction.created_at>=datetime(2026,1,1),TaxTransaction.created_at<datetime(2026,2,1)), and_(JournalEntry.status=="posted",JournalEntry.entry_date>=datetime(2026,1,1),JournalEntry.entry_date<datetime(2026,2,1)))).all()
    assert len(rows)==1 and rows[0].source_id==1
    db.close()


def test_tax_report_rejects_reversed_dates():
    from app.routers.pro_ledger_router import _tax_period
    try: _tax_period("2026-02-01", "2026-01-01")
    except Exception as exc: assert getattr(exc,"status_code",None)==400
    else: assert False
