from datetime import datetime, date
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, Account, AccountTypeEnum, PeriodClosingEntry
from app.enterprise_models import Company
from app.accounting import create_entry
from app.financial_reporting import changes_in_equity
from app.governance import set_request_context, clear_request_context


def test_equity_statement_excludes_period_closing_transfer_and_keeps_profit():
    e = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(e)
    S = sessionmaker(bind=e); db = S()
    c = Company(code="EQ88", name="Equity Co"); db.add(c); db.flush()
    cap = Account(company_id=c.id, code="3100", name="رأس المال", account_type=AccountTypeEnum.equity, is_active=True)
    retained = Account(company_id=c.id, code="3200", name="الأرباح المحتجزة", account_type=AccountTypeEnum.equity, is_active=True)
    cash = Account(company_id=c.id, code="1000", name="Cash", account_type=AccountTypeEnum.asset, is_active=True)
    sales = Account(company_id=c.id, code="4000", name="Sales", account_type=AccountTypeEnum.revenue, is_active=True)
    expense = Account(company_id=c.id, code="6000", name="Expense", account_type=AccountTypeEnum.expense, is_active=True)
    db.add_all([cap, retained, cash, sales, expense]); db.flush()

    set_request_context(request_id="eq88", user_id=1, company_id=c.id, branch_id=None, ip_address=None)
    create_entry(db, "OPEN", 1, [(cap.code, 0, 1000), (cash.code, 1000, 0)], "test", 1, datetime(2025,12,31))
    create_entry(db, "CONTRIB", 1, [(cash.code, 500, 0), (cap.code, 0, 500)], "test", 2, datetime(2026,1,5))
    create_entry(db, "SALE", 1, [(cash.code, 1000, 0), (sales.code, 0, 1000)], "test", 3, datetime(2026,1,10))
    create_entry(db, "EXP", 1, [(expense.code, 400, 0), (cash.code, 0, 400)], "test", 4, datetime(2026,1,20))
    closing = create_entry(db, "CLOSE", 1, [(sales.code, 1000, 0), (expense.code, 0, 400), (retained.code, 0, 600)], "period_close", 99, datetime(2026,1,31))
    db.add(PeriodClosingEntry(company_id=c.id, period_id=99, closing_entry_id=closing.id, retained_earnings_account_code="3200", created_by_id=1))
    db.commit(); clear_request_context()

    r = changes_in_equity(db, c.id, date(2026,1,1), date(2026,1,31))
    assert Decimal(str(r["opening_equity"])) == Decimal("1000.00")
    assert Decimal(str(r["equity_movements"])) == Decimal("500.00")
    assert Decimal(str(r["profit_for_period"])) == Decimal("600.00")
    assert Decimal(str(r["closing_equity"])) == Decimal("2100.00")
    assert r["reconciles"] is True
