from decimal import Decimal
import pytest
from fastapi import HTTPException
from sqlalchemy import func
from app.models import PurchaseOrder, PurchaseOrderLine, PurchaseReceipt, StockMovement, MovementTypeEnum, PaymentAllocation
from app.enterprise_models import PurchaseReceiptLine, PurchaseMatchLine
from app.warehouse_models import Warehouse
from app.deep_transactions import receive_purchase_order
from app.transaction_services import create_purchase_invoice, create_supplier_payment
from app.governance import clear_request_context
from test_phase51_transactions import setup_db

def make_po(db, company, supplier, item, qty=Decimal('10'), price=Decimal('70')):
    wh=Warehouse(company_id=company.id,branch_id=1,code='WH-P2P',name='P2P Warehouse',is_active=True); db.add(wh); db.flush()
    po=PurchaseOrder(company_id=company.id,branch_id=1,po_number=f'PO-P2P-{qty}',supplier_id=supplier.id,payment_method='credit',warehouse_id=wh.id,created_by_id=1,approval_status='approved'); db.add(po); db.flush()
    line=PurchaseOrderLine(company_id=company.id,po_id=po.id,item_id=item.id,quantity=qty,unit_price=price,line_total=qty*price); db.add(line); db.flush(); return po,line

def test_partial_multiple_grns_and_cumulative_match():
    db,c,u,cu,s,i,t=setup_db()
    try:
        po,l=make_po(db,c,s,i); r1=receive_purchase_order(db,c.id,po.id,u.id,{str(l.id):Decimal('4')}); r2=receive_purchase_order(db,c.id,po.id,u.id,{str(l.id):Decimal('6')})
        inv=create_purchase_invoice(db,c.id,u.id,s.id,[{'item_id':i.id,'po_line_id':l.id,'quantity':7,'unit_price':70}],po_id=po.id,tax_rate_id=t.id)
        ms=db.query(PurchaseMatchLine).filter(PurchaseMatchLine.purchase_invoice_id==inv.id).all(); assert len(ms)==2; assert sum((x.matched_quantity for x in ms),Decimal())==Decimal('7'); assert r1.receipt_number!=r2.receipt_number; db.commit()
    finally: clear_request_context(); db.close()

def test_cannot_invoice_more_than_received_cumulatively():
    db,c,u,cu,s,i,t=setup_db()
    try:
        po,l=make_po(db,c,s,i,Decimal('5')); receive_purchase_order(db,c.id,po.id,u.id,{str(l.id):Decimal('5')})
        create_purchase_invoice(db,c.id,u.id,s.id,[{'item_id':i.id,'po_line_id':l.id,'quantity':3,'unit_price':70}],po_id=po.id)
        with pytest.raises(HTTPException): create_purchase_invoice(db,c.id,u.id,s.id,[{'item_id':i.id,'po_line_id':l.id,'quantity':3,'unit_price':70}],po_id=po.id)
        db.rollback()
    finally: clear_request_context(); db.close()

def test_po_invoice_does_not_duplicate_inventory_and_payment_allocates():
    db,c,u,cu,s,i,t=setup_db()
    try:
        po,l=make_po(db,c,s,i,Decimal('4')); receive_purchase_order(db,c.id,po.id,u.id,{str(l.id):Decimal('4')})
        before=db.query(func.coalesce(func.sum(StockMovement.quantity),0)).filter(StockMovement.company_id==c.id,StockMovement.item_id==i.id,StockMovement.movement_type==MovementTypeEnum.in_).scalar()
        inv=create_purchase_invoice(db,c.id,u.id,s.id,[{'item_id':i.id,'po_line_id':l.id,'quantity':4,'unit_price':70}],po_id=po.id)
        after=db.query(func.coalesce(func.sum(StockMovement.quantity),0)).filter(StockMovement.company_id==c.id,StockMovement.item_id==i.id,StockMovement.movement_type==MovementTypeEnum.in_).scalar(); assert before==after
        pay=create_supplier_payment(db,c.id,u.id,inv.id,Decimal('100')); db.commit(); assert pay.amount==Decimal('100.000000'); assert db.query(PaymentAllocation).filter(PaymentAllocation.purchase_invoice_id==inv.id).one().amount==Decimal('100.000000')
    finally: clear_request_context(); db.close()

def test_po_invoice_header_discount_rejected_without_variance_policy():
    db,c,u,cu,s,i,t=setup_db()
    try:
        po,l=make_po(db,c,s,i,Decimal('2')); receive_purchase_order(db,c.id,po.id,u.id,{str(l.id):Decimal('2')})
        with pytest.raises(HTTPException): create_purchase_invoice(db,c.id,u.id,s.id,[{'item_id':i.id,'po_line_id':l.id,'quantity':2,'unit_price':70}],po_id=po.id,discount=Decimal('1'))
        db.rollback()
    finally: clear_request_context(); db.close()
