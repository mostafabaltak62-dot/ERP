from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
from app.governance import DEFAULT_PERMISSION_CODES, ensure_default_permissions
from app.governance_models import Permission, AssetDepreciationRun, RecurringJournalTemplate


def make_db():
    e=create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(e)
    return sessionmaker(bind=e)()


def test_default_permissions_are_seedable_and_idempotent():
    db=make_db()
    ensure_default_permissions(db)
    first = db.query(Permission).count()
    ensure_default_permissions(db)
    second = db.query(Permission).count()
    assert first == second
    codes = {p.code for p in db.query(Permission).all()}
    assert {c for c, _, _ in DEFAULT_PERMISSION_CODES}.issubset(codes)


def test_merged_governance_models_have_tenant_scope():
    assert "company_id" in AssetDepreciationRun.__table__.c
    assert "company_id" in RecurringJournalTemplate.__table__.c
