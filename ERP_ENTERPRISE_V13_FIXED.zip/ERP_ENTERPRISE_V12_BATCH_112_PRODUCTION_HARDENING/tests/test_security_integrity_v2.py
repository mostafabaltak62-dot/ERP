import os
import pytest
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from fastapi import HTTPException

from app.models import Base, User, RoleEnum, Item, ItemTypeEnum, StockMovement, MovementTypeEnum, JournalEntry, JournalLine, Account, AccountTypeEnum
from app.enterprise_models import Company
from app.accounting import create_entry
from app.inventory_valuation import issue
from app.auth import create_access_token, decode_token, revoke_access_token, revoke_user_access_tokens


def fresh():
    e = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(e)
    return sessionmaker(bind=e)()


def test_journal_balance_rejected_before_save():
    db = fresh()
    c = Company(code="C1", name="C1", is_active=True); db.add(c); db.flush()
    a1 = Account(company_id=c.id, code="1000", name="A", account_type=AccountTypeEnum.asset, is_active=True)
    a2 = Account(company_id=c.id, code="2000", name="B", account_type=AccountTypeEnum.liability, is_active=True)
    db.add_all([a1, a2]); db.commit()
    with pytest.raises(HTTPException):
        create_entry(db, "bad", 1, [("1000", 100, 0), ("2000", 0, 90)], company_id=c.id)
    assert db.query(JournalEntry).count() == 0


def test_negative_stock_movement_rejected_by_database():
    db = fresh()
    c = Company(code="C1", name="C1", is_active=True); db.add(c); db.flush()
    item = Item(company_id=c.id, code="I1", name="Item", item_type=ItemTypeEnum.product); db.add(item); db.commit()
    with pytest.raises(Exception):
        db.add(StockMovement(company_id=c.id, item_id=item.id, movement_type=MovementTypeEnum.out, quantity=-1, unit_cost=1, total_cost=-1)); db.commit()


def test_inventory_issue_rejects_overdraw_and_locks_item():
    db = fresh(); c = Company(code="C1", name="C1", is_active=True); db.add(c); db.flush()
    item = Item(company_id=c.id, code="I1", name="Item", item_type=ItemTypeEnum.product); db.add(item); db.flush()
    db.add(StockMovement(company_id=c.id, item_id=item.id, movement_type=MovementTypeEnum.in_, quantity=5, unit_cost=10, total_cost=50)); db.commit()
    with pytest.raises(HTTPException):
        issue(db, c.id, item.id, 6, "test", 1)


def test_access_token_revocation_and_authorization_version():
    db = fresh(); u=User(username="u", full_name="U", password_hash="x", role=RoleEnum.employee, is_active=True); db.add(u); db.commit()
    token=create_access_token(u)
    assert decode_token(token) is not None
    revoke_access_token(token)
    assert decode_token(token) is None
    token2=create_access_token(u)
    assert decode_token(token2) is not None
    revoke_user_access_tokens(u.id)
    assert decode_token(token2) is None


def test_reversal_creates_opposite_balanced_entry():
    db = fresh()
    c = Company(code="C2", name="C2", is_active=True); db.add(c); db.flush()
    a1 = Account(company_id=c.id, code="1000", name="A", account_type=AccountTypeEnum.asset, is_active=True)
    a2 = Account(company_id=c.id, code="2000", name="B", account_type=AccountTypeEnum.liability, is_active=True)
    db.add_all([a1, a2]); db.commit()
    e = create_entry(db, "original", 1, [("1000", 100, 0), ("2000", 0, 100)], company_id=c.id)
    from app.accounting import create_reversing_entry
    rev = create_reversing_entry(db, e.id, 1, "Correction")
    db.commit()
    assert rev.status == "posted"
    assert [(x.debit, x.credit) for x in rev.lines] == [(Decimal("0.000000"), Decimal("100.000000")), (Decimal("100.000000"), Decimal("0.000000"))]
