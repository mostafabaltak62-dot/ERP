from datetime import date, datetime
from decimal import Decimal

from app.database import SessionLocal
from app.financial_reporting import cash_flow
from app.models import Account, AccountTypeEnum, JournalEntry, JournalLine
from app.enterprise_models import Company


def _entry(db, company_id, number, when, lines):
    e = JournalEntry(company_id=company_id, entry_number=number, description=number,
                     entry_date=datetime.combine(when, datetime.min.time()), status="draft")
    db.add(e); db.flush()
    for account_id, debit, credit in lines:
        db.add(JournalLine(company_id=company_id, entry_id=e.id, account_id=account_id,
                           debit=debit, credit=credit))
    db.flush(); e.status = "posted"; e.posted_at = e.entry_date
    return e


def test_cash_flow_includes_historically_used_inactive_cash_accounts():
    db = SessionLocal()
    try:
        c = Company(code="CF94A", name="CF94A", is_active=True); db.add(c); db.flush()
        cash = Account(company_id=c.id, code="1194", name="Legacy Cash", account_type=AccountTypeEnum.asset,
                       statement_section="cash_and_equivalents", is_active=False)
        rev = Account(company_id=c.id, code="4194", name="Revenue", account_type=AccountTypeEnum.revenue,
                      statement_section="revenue", cash_flow_category="operating", is_active=True)
        db.add_all([cash, rev]); db.flush()
        _entry(db, c.id, "CF94-OPEN", date(2026, 1, 1), [(cash.id, 100, 0), (rev.id, 0, 100)])
        db.commit()
        r = cash_flow(db, c.id, date(2026, 2, 1), date(2026, 2, 28))
        assert r["opening_cash"] == Decimal("100.00")
        assert r["closing_cash"] == Decimal("100.00")
        assert r["reconciles"] is True
    finally:
        db.close()


def test_cash_flow_flags_unmapped_counterpart_and_marks_mixed_classification():
    db = SessionLocal()
    try:
        c = Company(code="CF94B", name="CF94B", is_active=True); db.add(c); db.flush()
        cash = Account(company_id=c.id, code="1195", name="Cash", account_type=AccountTypeEnum.asset,
                       statement_section="cash_and_equivalents", is_active=True)
        operating = Account(company_id=c.id, code="5295", name="Operating Expense", account_type=AccountTypeEnum.expense,
                            statement_section="operating_expenses", cash_flow_category="operating", is_active=True)
        unmapped = Account(company_id=c.id, code="1695", name="Other Asset", account_type=AccountTypeEnum.asset,
                           statement_section="other_current_assets", cash_flow_category="investing", is_active=True)
        db.add_all([cash, operating, unmapped]); db.flush()
        _entry(db, c.id, "CF94-MIX", date(2026, 2, 5), [
            (cash.id, 100, 0), (operating.id, 0, 50), (unmapped.id, 0, 50)
        ])
        db.commit()
        r = cash_flow(db, c.id, date(2026, 2, 1), date(2026, 2, 28))
        assert r["net_change"] == Decimal("100.00")
        assert r["mapping_complete"] is True
        assert not r["mapping_exceptions"]
        assert r["rows"][0]["classification"] == "mixed"
    finally:
        db.close()


def test_cash_flow_flags_unmapped_cash_counterpart():
    db = SessionLocal()
    try:
        c = Company(code="CF94C", name="CF94C", is_active=True); db.add(c); db.flush()
        cash = Account(company_id=c.id, code="1196", name="Cash", account_type=AccountTypeEnum.asset,
                       statement_section="cash_and_equivalents", is_active=True)
        asset = Account(company_id=c.id, code="1696", name="Unmapped Asset", account_type=AccountTypeEnum.asset,
                        statement_section="other_current_assets", cash_flow_category=None, is_active=True)
        db.add_all([cash, asset]); db.flush()
        _entry(db, c.id, "CF94-UNMAP", date(2026, 3, 5), [(cash.id, 0, 75), (asset.id, 75, 0)])
        db.commit()
        r = cash_flow(db, c.id, date(2026, 3, 1), date(2026, 3, 31))
        assert r["closing_cash"] == Decimal("-75.00")
        assert r["net_change"] == Decimal("-75.00")
        assert r["mapping_complete"] is False
        assert r["mapping_exceptions"][0]["account_code"] == "1696"
    finally:
        db.close()
