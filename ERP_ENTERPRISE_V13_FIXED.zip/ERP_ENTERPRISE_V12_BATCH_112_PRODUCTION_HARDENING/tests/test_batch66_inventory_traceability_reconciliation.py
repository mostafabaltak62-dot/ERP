from pathlib import Path

def test_traceability_model_and_migration_are_present():
    model=Path('app/enterprise_models.py').read_text(encoding='utf-8')
    migration=Path('alembic/versions/p66_inventory_traceability_reconciliation.py').read_text(encoding='utf-8')
    assert 'class InventoryTraceability(Base):' in model
    assert 'track_serial' in Path('app/models.py').read_text(encoding='utf-8')
    assert 'uq_inventory_trace_movement_serial' in migration
    assert "revision='p66_inventory_traceability_reconciliation'" in migration

def test_movement_engine_calls_traceability_for_tracked_items():
    text=Path('app/inventory_transactions.py').read_text(encoding='utf-8')
    assert 'attach_traceability' in text
    assert 'serial_numbers=None, lot_no=None, expiry_date=None' in text

def test_valuation_reconciliation_uses_operational_date_and_signed_movements():
    text=Path('app/deep_transactions.py').read_text(encoding='utf-8')
    assert 'StockMovement.operational_date <= as_of' in text
    assert 'else_=-StockMovement.total_cost' in text
    assert 'def reconcile_inventory_to_gl' in text

def test_traceability_rejects_duplicate_or_expired_serials():
    text=Path('app/inventory_traceability.py').read_text(encoding='utf-8')
    assert 'Serial already exists' in text
    assert 'Serial is not currently in stock' in text
    assert 'Cannot issue expired stock' in text
