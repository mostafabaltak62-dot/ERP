from pathlib import Path

def test_inventory_transaction_engine_has_governance_fields_and_indexes():
    model=Path('app/models.py').read_text(encoding='utf-8')
    migration=Path('alembic/versions/p65_inventory_transaction_engine.py').read_text(encoding='utf-8')
    assert 'operational_date = Column(DateTime' in model
    assert 'source_type = Column(String(60)' in model
    assert 'transfer_id = Column(String(40)' in model
    assert 'reversal_of_id = Column(Integer, ForeignKey("stock_movements.id"' in model
    assert 'ck_stock_movement_nonnegative_total_cost' in migration
    assert "revision='p65_inventory_transaction_engine'" in migration

def test_inventory_transaction_helper_enforces_scope_and_negative_stock_policy():
    text=Path('app/inventory_transactions.py').read_text(encoding='utf-8')
    assert 'Item.company_id==company_id' in text
    assert 'Warehouse.company_id==company_id' in text
    assert 'not item.allow_negative_stock' in text
    assert 'source_type and source_id is not None' in text

def test_item_update_helper_is_not_recursive():
    text=Path('app/routers/inventory_router.py').read_text(encoding='utf-8')
    assert 'item = db.query(Item).filter(Item.id == item_id, Item.company_id == cid).with_for_update().first()' in text
    assert 'item = _item_for_update(db, item_id, cid)' not in text

def test_transfer_uses_single_transfer_identity():
    text=Path('app/routers/commercial_workspace_router.py').read_text(encoding='utf-8')
    assert 'transfer_id = ref' in text
    assert 'transfer_id=transfer_id' in text
    assert 'create_movement(db' in text
