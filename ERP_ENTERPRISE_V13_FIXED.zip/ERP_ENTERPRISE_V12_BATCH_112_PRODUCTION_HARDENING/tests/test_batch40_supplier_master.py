from app.routers.purchases_router import _clean_supplier_payload
from fastapi import HTTPException
import pytest

def payload(**kw):
    base=dict(code=' sup-006 ',name=' مورد اختبار ',phone='',email='TEST@EXAMPLE.COM',address='',legal_name='',supplier_type='company',contact_person='',tax_number='',registration_number='',country='',city='',postal_code='',payment_terms_days='30',preferred_payment_method='',currency_code='egp',credit_limit='1000.50',bank_name='',bank_account_name='',bank_account_number='',iban='',swift_code='')
    base.update(kw); return _clean_supplier_payload(**base)

def test_supplier_payload_normalizes_business_fields():
    p=payload()
    assert p['code']=='SUP-006' and p['email']=='test@example.com' and p['currency_code']=='EGP'
    assert p['payment_terms_days']==30

def test_supplier_payload_rejects_invalid_credit_and_code():
    with pytest.raises(HTTPException): payload(code='x')
    with pytest.raises(HTTPException): payload(credit_limit='-1')

def test_supplier_payload_rejects_invalid_currency_and_type():
    with pytest.raises(HTTPException): payload(currency_code='EGYPT')
    with pytest.raises(HTTPException): payload(supplier_type='unknown')
