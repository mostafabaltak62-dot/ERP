from decimal import Decimal
from app.models import PurchaseOrder, PurchaseOrderLine, PurchaseReceipt, JournalEntry, StockMovement, MovementTypeEnum
from app.warehouse_models import Warehouse
from app.accounting import ensure_default_accounts
from app.deep_transactions import receive_purchase_order, validate_three_way_match, create_sales_return, create_purchase_return, ar_aging, ap_aging, reconcile_ar_ap
from app.transaction_services import create_sales_order, confirm_sales_order, deliver_sales_order, invoice_sales_delivery, create_purchase_invoice
from app.governance import clear_request_context
from test_phase51_transactions import setup_db


def test_purchase_receipt_and_three_way_match():
    db, company, user, customer, supplier, item, tax = setup_db()
    try:
        wh = Warehouse(company_id=company.id, branch_id=1, code='WH1', name='Main Warehouse', is_active=True)
        db.add(wh); db.flush()
        po = PurchaseOrder(company_id=company.id, po_number='PO-TEST-1', supplier_id=supplier.id, payment_method='credit', warehouse_id=wh.id, created_by_id=user.id)
        db.add(po); db.flush()
        pol = PurchaseOrderLine(company_id=company.id, po_id=po.id, item_id=item.id, quantity=Decimal('4'), unit_price=Decimal('70'), line_total=Decimal('280'))
        db.add(pol); db.flush()
        receipt = receive_purchase_order(db, company.id, po.id, user.id)
        inv = create_purchase_invoice(db, company.id, user.id, supplier.id, [{'item_id': item.id, 'quantity': 4, 'unit_price': 70}], po_id=po.id, tax_rate_id=tax.id)
        matches = db.query(type(receipt)).count()
        assert matches == 1
        assert validate_three_way_match(db, company.id, inv.id)
        db.commit()
    finally:
        clear_request_context(); db.close()


def test_sales_return_restores_inventory_and_reverses_cogs():
    db, company, user, customer, supplier, item, tax = setup_db()
    try:
        order=create_sales_order(db, company.id, user.id, customer.id, [{'item_id':item.id,'quantity':2,'unit_price':100}], 'credit')
        confirm_sales_order(db, order.id, company.id)
        delivery=deliver_sales_order(db, order.id, company.id, user.id)
        inv=invoice_sales_delivery(db, delivery.id, company.id, user.id, tax.id)
        ret=create_sales_return(db, company.id, user.id, inv.id, [{'invoice_line_id': inv.lines[0].id, 'quantity': 1}])
        db.commit()
        assert ret.total_amount == Decimal('110.000000')
        assert ret.cogs_reversal == Decimal('60.000000')
        assert db.query(StockMovement).filter(StockMovement.item_id==item.id, StockMovement.movement_type==MovementTypeEnum.in_).count() == 2
    finally:
        clear_request_context(); db.close()


def test_purchase_return_and_aging_reconcile():
    db, company, user, customer, supplier, item, tax = setup_db()
    try:
        inv=create_purchase_invoice(db, company.id, user.id, supplier.id, [{'item_id':item.id,'quantity':3,'unit_price':70}], tax_rate_id=tax.id)
        ret=create_purchase_return(db, company.id, user.id, inv.id, [{'invoice_line_id': inv.lines[0].id, 'quantity': 1}])
        db.commit()
        assert ret.total_amount == Decimal('77.000000')
        assert len(ap_aging(db, company.id)) == 1
        # No AR invoices in this scenario; AP/AR reconciliation records are authoritative snapshots.
        recs=reconcile_ar_ap(db, company.id, user_id=user.id)
        db.commit()
        assert len(recs) == 2
    finally:
        clear_request_context(); db.close()
