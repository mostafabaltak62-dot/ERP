from pathlib import Path

import pytest

from app import security_hardening
from app.core_settings import _required

ROOT = Path(__file__).parents[1]


def test_security_hardening_defines_module_logger():
    assert security_hardening.logger.name == "app.security_hardening"


@pytest.mark.parametrize(
    "value",
    [
        "GENERATE_A_RANDOM_SECRET_AT_LEAST_32_CHARS",
        "postgresql+psycopg://USER:PASSWORD@HOST:5432/erp",
        "CHANGE_ME_run_python_-c_import_secrets_print_secrets.token_urlsafe_48",
    ],
)
def test_placeholder_values_are_rejected(value):
    with pytest.raises(RuntimeError):
        _required(value, "X", 20)


def test_env_example_is_never_accepted_as_real_config():
    for line in (ROOT / ".env.example").read_text(encoding="utf-8").splitlines():
        if line.startswith(("JWT_SECRET_KEY=", "ENCRYPTION_KEY=", "DATABASE_URL=")):
            with pytest.raises(RuntimeError):
                _required(line.split("=", 1)[1], "X", 20)


def test_pytest_not_in_runtime_requirements():
    assert "pytest" not in (ROOT / "requirements.txt").read_text().lower()
