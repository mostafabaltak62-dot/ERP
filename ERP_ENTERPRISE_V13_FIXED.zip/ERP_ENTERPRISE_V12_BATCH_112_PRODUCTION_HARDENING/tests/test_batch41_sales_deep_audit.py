from decimal import Decimal
import datetime
import pytest
from fastapi import HTTPException
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models import Base, Item, ItemTypeEnum, StockMovement, MovementTypeEnum
from app.enterprise_models import Company, Currency
from app.governance import set_request_context, clear_request_context
from app.routers.sales_router import _safe_csv, _parse_iso_date
from app.routers.inventory_router import compute_stock


def test_sales_csv_formula_values_are_neutralized():
    assert _safe_csv('=2+2') == "'=2+2"
    assert _safe_csv('+cmd') == "'+cmd"
    assert _safe_csv('-danger') == "'-danger"
    assert _safe_csv('@SUM(A1)') == "'@SUM(A1)"
    assert _safe_csv('INV-001') == 'INV-001'


def test_sales_date_filter_rejects_invalid_date():
    with pytest.raises(HTTPException) as exc:
        _parse_iso_date('2026-99-99', 'تاريخ البداية')
    assert exc.value.status_code == 422
    assert _parse_iso_date('2026-08-31', 'تاريخ البداية') == datetime.date(2026, 8, 31)


def test_stock_calculation_is_company_scoped_for_sales_validation():
    clear_request_context()
    engine = create_engine('sqlite:///:memory:')
    Base.metadata.create_all(engine)
    S = sessionmaker(bind=engine)
    db = S()
    try:
        c1 = Currency(code='EGP', name='EGP', decimal_places=2, is_active=True)
        c2 = Currency(code='USD', name='USD', decimal_places=2, is_active=True)
        db.add_all([c1, c2]); db.flush()
        co1 = Company(code='C1', name='C1', base_currency_id=c1.id, is_active=True)
        co2 = Company(code='C2', name='C2', base_currency_id=c2.id, is_active=True)
        db.add_all([co1, co2]); db.flush()
        i1 = Item(company_id=co1.id, code='I1', name='I1', item_type=ItemTypeEnum.product)
        i2 = Item(company_id=co2.id, code='I2', name='I2', item_type=ItemTypeEnum.product)
        db.add_all([i1, i2]); db.flush()
        db.add_all([
            StockMovement(company_id=co1.id, item_id=i1.id, movement_type=MovementTypeEnum.in_, quantity=Decimal('5'), unit_cost=0, total_cost=0),
            StockMovement(company_id=co2.id, item_id=i2.id, movement_type=MovementTypeEnum.in_, quantity=Decimal('999'), unit_cost=0, total_cost=0),
        ])
        db.commit()
        assert compute_stock(db, i1.id, co1.id) == Decimal('5')
    finally:
        clear_request_context(); db.close()


def test_document_sequence_is_global_when_document_number_column_is_global_unique():
    from app.accounting import next_number
    clear_request_context()
    engine = create_engine('sqlite:///:memory:')
    Base.metadata.create_all(engine)
    S = sessionmaker(bind=engine)
    db = S()
    try:
        c1 = Currency(code='EGP', name='EGP', decimal_places=2, is_active=True)
        c2 = Currency(code='USD', name='USD', decimal_places=2, is_active=True)
        db.add_all([c1, c2]); db.flush()
        co1 = Company(code='C1', name='C1', base_currency_id=c1.id, is_active=True)
        co2 = Company(code='C2', name='C2', base_currency_id=c2.id, is_active=True)
        db.add_all([co1, co2]); db.flush()
        assert next_number(db, 'sales_invoice', 'INV', co1.id) == 'INV-000001'
        assert next_number(db, 'sales_invoice', 'INV', co2.id) == 'INV-000002'
    finally:
        clear_request_context(); db.close()
