from datetime import datetime
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, Account, AccountTypeEnum, JournalEntry, JournalLine, BankReconciliation, BankReconciliationItem
from app.enterprise_models import Company
from app.accounting import create_entry
from app.governance import set_request_context, clear_request_context

def setup():
    e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); S=sessionmaker(bind=e); db=S()
    c=Company(code='BR62',name='Bank Rec Co'); db.add(c); db.flush()
    b=Account(company_id=c.id,code='1110',name='Bank',account_type=AccountTypeEnum.asset,is_active=True,statement_section='cash_and_equivalents'); r=Account(company_id=c.id,code='4100',name='Revenue',account_type=AccountTypeEnum.revenue,is_active=True); db.add_all([b,r]); db.flush(); return db,c,b,r

def post(db,c,b,r,dt,amt):
    set_request_context(request_id='br62',user_id=1,company_id=c.id,branch_id=None,ip_address=None)
    create_entry(db,'BR62',1,[(b.code,Decimal(amt),'0'),(r.code,Decimal('0'),Decimal(amt))],source_type='test',source_id=1,entry_date=dt,company_id=c.id); db.commit(); clear_request_context()

def test_reconciliation_recalculates_items():
    from app.routers.advanced_finance_router import _recalculate_bank_reconciliation
    db,c,b,r=setup(); post(db,c,b,r,datetime(2026,1,1),100)
    rec=BankReconciliation(company_id=c.id,bank_account_id=b.id,bank_account_code='1110',statement_date=datetime(2026,1,2),statement_balance=Decimal('80'),book_balance=0,difference=0,reconciliation_number='BR1'); db.add(rec); db.flush()
    db.add(BankReconciliationItem(company_id=c.id,reconciliation_id=rec.id,transaction_date=datetime(2026,1,2),amount=Decimal('20'),direction='debit')); db.flush(); _recalculate_bank_reconciliation(db,rec)
    assert Decimal(str(rec.book_balance))==Decimal('100.00'); assert Decimal(str(rec.difference))==Decimal('0.00')

def test_tenant_safe_account_linkage():
    db,c,b,r=setup(); other=Company(code='BR62B',name='Other'); db.add(other); db.flush(); foreign=Account(company_id=other.id,code='1110',name='Foreign',account_type=AccountTypeEnum.asset,is_active=True,statement_section='cash_and_equivalents'); db.add(foreign); db.flush()
    rec=BankReconciliation(company_id=c.id,bank_account_id=b.id,bank_account_code='1110',statement_date=datetime(2026,1,1),statement_balance=0,book_balance=0,difference=0,reconciliation_number='BR2'); db.add(rec); db.commit()
    assert rec.bank_account_id==b.id and rec.bank_account_id!=foreign.id
