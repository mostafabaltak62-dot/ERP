from datetime import datetime
from pathlib import Path
from sqlalchemy import create_engine, inspect
from sqlalchemy.orm import sessionmaker

from app.models import Base
from app.enterprise_models import Company, Branch
from app.governance_models import GovernanceAuditLog
from app.routers.financial_reporting_ui import _audit_query


def db_setup():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    db = Session()
    c = Company(code="P93C", name="Patch 93 Company", is_active=True)
    db.add(c); db.flush()
    b1 = Branch(company_id=c.id, code="B1", name="Branch 1", is_active=True)
    b2 = Branch(company_id=c.id, code="B2", name="Branch 2", is_active=True)
    db.add_all([b1, b2]); db.flush()
    db.add_all([
        GovernanceAuditLog(company_id=c.id, branch_id=b1.id, action="update", entity_type="Invoice", entity_id="1", request_id="r1", created_at=datetime(2026, 1, 10)),
        GovernanceAuditLog(company_id=c.id, branch_id=b2.id, action="update", entity_type="Invoice", entity_id="2", request_id="r2", created_at=datetime(2026, 1, 10)),
        GovernanceAuditLog(company_id=c.id, branch_id=None, action="create", entity_type="Company", entity_id=str(c.id), request_id="r3", created_at=datetime(2026, 1, 10)),
    ])
    db.commit()
    return db, c, b1, b2


def test_audit_query_is_branch_scoped():
    db, c, b1, b2 = db_setup()
    q, s, e = _audit_query(db, c.id, "2026-01-01", "2026-01-31", branch_id=b1.id)
    rows = q.order_by(GovernanceAuditLog.id).all()
    assert len(rows) == 1
    assert rows[0].branch_id == b1.id
    assert rows[0].entity_id == "1"
    db.close()


def test_audit_query_company_wide_keeps_company_records_only():
    db, c, b1, b2 = db_setup()
    q, _, _ = _audit_query(db, c.id, "2026-01-01", "2026-01-31")
    assert q.count() == 3
    db.close()


def test_audit_routes_and_exports_are_registered():
    from app.main import app
    paths = {r.path for r in app.routes}
    assert "/accounting/reports/audit" in paths
    assert "/accounting/reports/audit/export.csv" in paths
    assert "/accounting/reports/audit/export/{fmt}" in paths
    assert "/accounting/reports/audit/{audit_id}" in paths
    assert "/finance/audit" in paths


def test_audit_page_contains_branch_filter_and_structured_exports():
    text = Path("templates/audit_v2.html").read_text()
    assert 'name="branch_id"' in text
    assert "/accounting/reports/audit/export/xlsx" in text
    assert "/accounting/reports/audit/export/pdf" in text
    assert "branch_id={{branch_id or ''}}" in text


def test_audit_log_migration_adds_branch_query_index():
    text = Path("alembic/versions/p93_enterprise_audit_log_branch_query.py").read_text()
    assert "p83_financial_validation" in text
    assert "company_branch_created" in text
    assert "['company_id', 'branch_id', 'created_at', 'id']" in text
