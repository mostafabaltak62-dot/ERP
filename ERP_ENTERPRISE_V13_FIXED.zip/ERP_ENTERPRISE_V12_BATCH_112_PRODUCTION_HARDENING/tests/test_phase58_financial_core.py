from decimal import Decimal
from datetime import datetime, date
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, Account, AccountTypeEnum, JournalEntry, JournalLine, User
from app.enterprise_models import Company, Currency, Branch, Budget, BudgetLine, Project, ProjectCost, ProjectForecast
from app.models import CostCenter

def setup():
    e=create_engine("sqlite:///:memory:")
    Base.metadata.create_all(e)
    S=sessionmaker(bind=e); db=S()
    c=Company(code="C58",name="Core Test"); db.add(c); db.flush()
    cur=Currency(code="TST",name="Test",decimal_places=2); db.add(cur); db.flush(); c.base_currency_id=cur.id
    a=Account(company_id=c.id,code="6000",name="Cost",account_type=AccountTypeEnum.expense,is_active=True)
    db.add(a); db.flush()
    return db,c,a

def test_budget_and_actual_are_tenant_scoped():
    db,c,a=setup()
    b=Budget(company_id=c.id,code="B26",name="FY26",fiscal_year=2026,scenario="baseline",status="approved")
    db.add(b); db.flush()
    line=BudgetLine(company_id=c.id,budget_id=b.id,account_id=a.id,period=1,budget_amount=Decimal("1000"))
    db.add(line)
    e=JournalEntry(company_id=c.id,entry_number="J58",entry_date=datetime(2026,1,15),description="Cost",status="draft")
    db.add(e); db.flush()
    db.add(JournalLine(company_id=c.id,entry_id=e.id,account_id=a.id,debit=Decimal("750"),credit=0))
    db.flush()
    e.status="posted"
    db.commit()
    assert db.query(BudgetLine).filter_by(company_id=c.id,budget_id=b.id).one().budget_amount == Decimal("1000.000000")
    assert db.query(JournalLine).filter_by(company_id=c.id,account_id=a.id).one().debit == Decimal("750.000000")

def test_project_forecast_profit_is_numeric_and_unique():
    db,c,a=setup()
    p=Project(company_id=c.id,code="P58",name="Project 58",budget=Decimal("5000"))
    db.add(p); db.flush()
    f=ProjectForecast(company_id=c.id,project_id=p.id,as_of_date=date(2026,1,31),
        budget_cost=Decimal("3000"),committed_cost=Decimal("3200"),actual_cost=Decimal("2800"),
        forecast_final_cost=Decimal("3500"),forecast_revenue=Decimal("6000"),forecast_profit=Decimal("2500"))
    db.add(f); db.commit()
    assert f.forecast_profit == Decimal("2500")
