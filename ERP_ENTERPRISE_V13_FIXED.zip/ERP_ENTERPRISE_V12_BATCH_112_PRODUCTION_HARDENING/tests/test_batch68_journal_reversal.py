import pytest
from datetime import datetime, timedelta
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from fastapi import HTTPException
from app.models import Base, JournalEntry, JournalReversal, Account, AccountTypeEnum, AccountingPeriod, PeriodClosingEntry
from app.enterprise_models import Company, Branch
from app.accounting import create_entry, create_reversing_entry
from app.governance import route_permission


def fresh():
    e = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(e)
    return sessionmaker(bind=e)()


def setup_company(db):
    c = Company(code="REV", name="Reversal Co", is_active=True); db.add(c); db.flush()
    a1 = Account(company_id=c.id, code="1000", name="Cash", account_type=AccountTypeEnum.asset, is_active=True)
    a2 = Account(company_id=c.id, code="2000", name="Payable", account_type=AccountTypeEnum.liability, is_active=True)
    db.add_all([a1, a2]); db.commit()
    return c


def test_reversal_requires_posted_and_is_balanced_and_audited():
    db = fresh(); c = setup_company(db)
    e = create_entry(db, "original", 1, [("1000", 100, 0), ("2000", 0, 100)], company_id=c.id)
    rev = create_reversing_entry(db, e.id, 2, "Correction", e.entry_date + timedelta(hours=1))
    db.commit()
    assert rev.source_type == "reversal"
    assert [(x.debit, x.credit) for x in rev.lines] == [(0, 100), (100, 0)]
    assert db.query(JournalReversal).filter_by(original_entry_id=e.id).count() == 1


def test_reversal_rejects_operational_entry_and_reversal_chain():
    db = fresh(); c = setup_company(db)
    op = create_entry(db, "sale", 1, [("1000", 100, 0), ("2000", 0, 100)], "sale_invoice", 9, company_id=c.id)
    with pytest.raises(HTTPException) as exc:
        create_reversing_entry(db, op.id, 1, "wrong")
    assert exc.value.status_code == 409
    manual = create_entry(db, "manual", 1, [("1000", 100, 0), ("2000", 0, 100)], "manual", 10, company_id=c.id)
    rev = create_reversing_entry(db, manual.id, 1, "first")
    db.flush()
    with pytest.raises(HTTPException) as exc2:
        create_reversing_entry(db, rev.id, 1, "second")
    assert exc2.value.status_code == 409


def test_reversal_rejects_backdating_before_original_and_double_reverse():
    db = fresh(); c = setup_company(db)
    when = datetime(2026, 9, 1, 10, 0, 0)
    e = create_entry(db, "original", 1, [("1000", 50, 0), ("2000", 0, 50)], company_id=c.id, entry_date=when)
    with pytest.raises(HTTPException) as exc:
        create_reversing_entry(db, e.id, 1, "late", when - timedelta(minutes=1))
    assert exc.value.status_code == 422
    rev = create_reversing_entry(db, e.id, 1, "valid", when + timedelta(minutes=1))
    assert rev.id
    db.rollback()


def test_route_permissions_separate_view_from_reverse():
    assert route_permission("GET", "/enterprise/reversals") == "journal:view"
    assert route_permission("POST", "/enterprise/journal/10/reverse") == "journal:reverse"
