from pathlib import Path


def test_postgres_rls_migration_exists_and_fails_closed():
    p = Path(__file__).parents[1] / "alembic/versions/5b9c2d7e1a11_postgresql_native_rls_phase41.py"
    text = p.read_text()
    assert "ENABLE ROW LEVEL SECURITY" in text
    assert "FORCE ROW LEVEL SECURITY" in text
    assert "current_setting('app.company_id'" in text
    assert "WITH CHECK" in text


def test_db_context_publishes_authorized_tenant_transactionally():
    p = Path(__file__).parents[1] / "app/tenant_db.py"
    text = p.read_text()
    assert "after_begin" in text
    assert "set_config('app.company_id'" in text
    assert "set_config('app.branch_id'" in text
    assert "-1" in text
