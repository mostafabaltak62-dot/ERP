from app.routers.construction_document_forms_router import FORM_TYPES, FORM_SCHEMAS

def test_every_requested_form_has_official_schema():
    expected={'SIR','MIR','MT','DWG','LITER','BOQ','RFI','V.O','QS','SNA','DOC','POUR','INITIAL_HANDOVER','FINAL_HANDOVER','LOG'}
    assert expected.issubset(FORM_SCHEMAS)
    assert all(FORM_SCHEMAS[k] for k in expected)

def test_pour_form_has_all_trade_approvals():
    keys={f[0] for sec in FORM_SCHEMAS['POUR'] for f in sec['fields']}
    assert {'civil','architectural','electrical','mechanical'}.issubset(keys)

def test_requested_form_types_remain_registered():
    assert 'SIR' in FORM_TYPES and 'FINAL_HANDOVER' in FORM_TYPES
