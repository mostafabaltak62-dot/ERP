from datetime import datetime
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models import Base, Account, AccountTypeEnum, JournalLine, BankReconciliation, BankReconciliationItem
from app.enterprise_models import Company


def setup():
    e = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(e)
    S = sessionmaker(bind=e)
    db = S()
    c = Company(code="BR77", name="Bank Statement Rec")
    db.add(c); db.flush()
    bank = Account(company_id=c.id, code="1110", name="Bank", account_type=AccountTypeEnum.asset,
                   is_active=True, statement_section="cash_and_equivalents")
    db.add(bank); db.flush()
    return db, c, bank


def test_matched_gl_line_is_unique():
    db, c, bank = setup()
    line = JournalLine(company_id=c.id, entry_id=1, account_id=bank.id, debit=100, credit=0)
    db.add(line); db.flush()
    rec1 = BankReconciliation(company_id=c.id, bank_account_id=bank.id, bank_account_code=bank.code,
                              statement_date=datetime(2026,1,10), statement_balance=100,
                              book_balance=100, difference=0, reconciliation_number="BR77-1")
    rec2 = BankReconciliation(company_id=c.id, bank_account_id=bank.id, bank_account_code=bank.code,
                              statement_date=datetime(2026,1,11), statement_balance=100,
                              book_balance=100, difference=0, reconciliation_number="BR77-2")
    db.add_all([rec1, rec2]); db.flush()
    a = BankReconciliationItem(company_id=c.id, reconciliation_id=rec1.id, transaction_date=datetime(2026,1,10),
                               amount=Decimal("100"), direction="credit", matched_journal_line_id=line.id, status="matched")
    b = BankReconciliationItem(company_id=c.id, reconciliation_id=rec2.id, transaction_date=datetime(2026,1,11),
                               amount=Decimal("100"), direction="credit", matched_journal_line_id=line.id, status="matched")
    db.add(a); db.flush()
    db.add(b)
    try:
        db.flush()
        assert False, "duplicate matched journal line must be rejected"
    except Exception:
        db.rollback()


def test_unmatched_statement_line_remains_reconcilable():
    db, c, bank = setup()
    rec = BankReconciliation(company_id=c.id, bank_account_id=bank.id, bank_account_code=bank.code,
                             statement_date=datetime(2026,1,10), statement_balance=90,
                             book_balance=100, difference=-10, reconciliation_number="BR77-3")
    db.add(rec); db.flush()
    item = BankReconciliationItem(company_id=c.id, reconciliation_id=rec.id, transaction_date=datetime(2026,1,10),
                                  amount=Decimal("10"), direction="debit", status="unmatched")
    db.add(item); db.commit()
    assert item.matched_journal_line_id is None
    assert item.status == "unmatched"
