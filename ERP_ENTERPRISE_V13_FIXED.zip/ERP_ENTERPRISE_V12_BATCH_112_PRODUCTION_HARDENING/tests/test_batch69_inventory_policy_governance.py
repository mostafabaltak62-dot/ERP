from decimal import Decimal
from pathlib import Path

from app.commercial_completion_models import InventoryPolicy
from app.enterprise_models import InventoryValuationPolicy, InventoryCostLayer, InventoryCostConsumption
from app.inventory_valuation import get_policy, receive, issue
from app.governance import clear_request_context, set_request_context
from test_phase51_transactions import setup_db


def test_company_default_inventory_policy_seeds_item_valuation_policy():
    db, company, user, customer, supplier, item, tax = setup_db()
    try:
        db.add(InventoryPolicy(company_id=company.id, warehouse_id=None, costing_method="fifo", allow_negative_stock=False))
        db.flush()
        policy = get_policy(db, company.id, item.id)
        assert policy.method == "fifo"
        assert policy.allow_negative is False
    finally:
        clear_request_context(); db.close()


def test_standard_cost_is_supported_and_uses_item_standard_cost():
    db, company, user, customer, supplier, item, tax = setup_db()
    try:
        item.standard_cost = Decimal("75")
        db.add(InventoryValuationPolicy(company_id=company.id, item_id=item.id, method="standard", allow_negative=False))
        db.flush()
        receive(db, company.id, item.id, Decimal("10"), Decimal("90"), "receipt69", 6901)
        cost, _ = issue(db, company.id, item.id, Decimal("4"), "issue69", 6902)
        assert cost == Decimal("300.000000")
        consumed = db.query(InventoryCostConsumption).filter_by(source_id=6902).all()
        assert sum((x.total_cost for x in consumed), Decimal("0")) == Decimal("300.000000")
    finally:
        clear_request_context(); db.close()


def test_patch69_contains_policy_governance_and_bootstrap_fixes():
    migration = Path("alembic/versions/p69_inventory_policy_governance.py").read_text(encoding="utf-8")
    main = Path("app/main.py").read_text(encoding="utf-8")
    assert "uq_inventory_policy_company_default" in migration
    assert "if admin is None:" in main
    assert 'path in {"/api/v1/mobile/auth/login"' in main
