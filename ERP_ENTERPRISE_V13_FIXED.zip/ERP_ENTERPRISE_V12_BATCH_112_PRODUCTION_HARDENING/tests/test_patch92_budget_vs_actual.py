from datetime import datetime
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.models import Base, Account, AccountTypeEnum, JournalEntry, JournalLine, CostCenter, JournalLineCostCenter
from app.enterprise_models import Company, Branch, Budget, BudgetLine, Project
from app.financial_reporting import budget_vs_actual


def setup():
    e = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(e)
    S = sessionmaker(bind=e)
    db = S()
    c = Company(code="BVA92", name="Budget Actual")
    db.add(c); db.flush()
    br1 = Branch(company_id=c.id, code="B1", name="Branch 1", is_active=True)
    br2 = Branch(company_id=c.id, code="B2", name="Branch 2", is_active=True)
    db.add_all([br1, br2]); db.flush()
    exp = Account(company_id=c.id, branch_id=None, code="6100", name="Expense", account_type=AccountTypeEnum.expense, is_active=True)
    rev = Account(company_id=c.id, branch_id=None, code="4100", name="Revenue", account_type=AccountTypeEnum.revenue, is_active=True)
    db.add_all([exp, rev]); db.flush()
    return db, c, br1, br2, exp, rev


def test_budget_vs_actual_is_monthly_normal_balance_and_branch_scoped():
    db, c, br1, br2, exp, rev = setup()
    b = Budget(company_id=c.id, branch_id=br1.id, code="BVA-26", name="FY26", fiscal_year=2026, scenario="baseline", status="approved")
    db.add(b); db.flush()
    db.add_all([
        BudgetLine(company_id=c.id, budget_id=b.id, account_id=exp.id, period=1, budget_amount=1000, forecast_amount=1100),
        BudgetLine(company_id=c.id, budget_id=b.id, account_id=exp.id, period=2, budget_amount=500),
        BudgetLine(company_id=c.id, budget_id=b.id, account_id=rev.id, period=1, budget_amount=2000),
    ])
    e1 = JournalEntry(company_id=c.id, branch_id=br1.id, entry_number="BVA-J1", entry_date=datetime(2026,1,15), description="expense", status="draft")
    e2 = JournalEntry(company_id=c.id, branch_id=br1.id, entry_number="BVA-J2", entry_date=datetime(2026,2,15), description="expense", status="draft")
    e3 = JournalEntry(company_id=c.id, branch_id=br2.id, entry_number="BVA-J3", entry_date=datetime(2026,1,20), description="other branch", status="draft")
    db.add_all([e1,e2,e3]); db.flush()
    db.add_all([
        JournalLine(company_id=c.id, branch_id=br1.id, entry_id=e1.id, account_id=exp.id, debit=1200, credit=0),
        JournalLine(company_id=c.id, branch_id=br1.id, entry_id=e2.id, account_id=exp.id, debit=400, credit=0),
        JournalLine(company_id=c.id, branch_id=br1.id, entry_id=e1.id, account_id=rev.id, debit=0, credit=1500),
        JournalLine(company_id=c.id, branch_id=br2.id, entry_id=e3.id, account_id=exp.id, debit=900, credit=0),
    ])
    db.flush(); e1.status=e2.status=e3.status="posted"
    db.commit()
    r = budget_vs_actual(db, c.id, b.id, br1.id)
    jan_exp = next(x for x in r["rows"] if x["account_id"] == exp.id and x["period"] == 1)
    feb_exp = next(x for x in r["rows"] if x["account_id"] == exp.id and x["period"] == 2)
    jan_rev = next(x for x in r["rows"] if x["account_id"] == rev.id and x["period"] == 1)
    assert jan_exp["actual"] == Decimal("1200.00")
    assert jan_exp["variance"] == Decimal("200.00")
    assert feb_exp["actual"] == Decimal("400.00")
    assert jan_rev["actual"] == Decimal("1500.00")
    assert jan_rev["variance"] == Decimal("-500.00")
    assert r["summary"]["actual"] == Decimal("3100.00")


def test_budget_vs_actual_cost_center_uses_allocated_amount_not_whole_account():
    db, c, br1, _, exp, _ = setup()
    cc = CostCenter(company_id=c.id, branch_id=br1.id, code="CC1", name="Cost Center 1", is_active=True)
    db.add(cc); db.flush()
    b = Budget(company_id=c.id, branch_id=br1.id, code="BVA-CC", name="CC Budget", fiscal_year=2026, scenario="baseline", status="approved")
    db.add(b); db.flush()
    line = BudgetLine(company_id=c.id, budget_id=b.id, account_id=exp.id, cost_center_id=cc.id, period=1, budget_amount=600)
    db.add(line)
    e = JournalEntry(company_id=c.id, branch_id=br1.id, entry_number="BVA-CC-J", entry_date=datetime(2026,1,10), description="allocated", status="draft")
    db.add(e); db.flush()
    jl = JournalLine(company_id=c.id, branch_id=br1.id, entry_id=e.id, account_id=exp.id, debit=1000, credit=0)
    db.add(jl); db.flush(); e.status="posted"
    db.add(JournalLineCostCenter(company_id=c.id, journal_line_id=jl.id, cost_center_id=cc.id, amount=700))
    db.commit()
    r = budget_vs_actual(db, c.id, b.id, br1.id)
    row = r["rows"][0]
    assert row["actual"] == Decimal("700.00")
    assert row["variance"] == Decimal("100.00")


def test_project_only_budget_line_is_explicitly_unreconciled():
    db, c, br1, _, exp, _ = setup()
    p = Project(company_id=c.id, branch_id=br1.id, code="P92", name="Project 92", budget=1000)
    db.add(p); db.flush()
    b = Budget(company_id=c.id, branch_id=br1.id, code="BVA-P", name="Project Budget", fiscal_year=2026, scenario="baseline", status="approved")
    db.add(b); db.flush()
    db.add(BudgetLine(company_id=c.id, budget_id=b.id, account_id=exp.id, project_id=p.id, period=1, budget_amount=1000))
    db.commit()
    r = budget_vs_actual(db, c.id, b.id, br1.id)
    assert r["rows"][0]["status"] == "project_dimension_unavailable"
    assert len(r["exceptions"]) == 1
    assert r["summary"]["actual"] == Decimal("0.00")
