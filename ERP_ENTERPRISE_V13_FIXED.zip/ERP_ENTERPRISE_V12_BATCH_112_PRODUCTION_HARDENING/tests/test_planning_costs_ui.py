from app.main import app

def test_planning_and_costs_are_separate_ui_routes():
    paths={r.path for r in app.routes}
    assert '/planning-costs/planning' in paths
    assert '/planning-costs/costs' in paths
    assert '/projects/command-center' in paths
    assert '/planning-costs/planning' != '/projects/command-center'
