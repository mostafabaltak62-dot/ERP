from pathlib import Path

ROOT = Path(__file__).parents[1]


def test_enterprise_plus_does_not_accept_client_company_id_in_create_models():
    text = (ROOT / "app/routers/enterprise_plus_router.py").read_text(encoding="utf-8")
    assert "def _current_company_id" in text
    assert "company_id:int;" not in text
    assert "d.company_id" not in text


def test_production_uses_a_non_superuser_application_role():
    compose = (ROOT / "docker-compose.production.yml").read_text(encoding="utf-8")
    assert "ERP_APP_DB_USER" in compose
    assert "ERP_APP_DB_PASSWORD" in compose
    assert "POSTGRES_ADMIN_USER" in compose
    assert "configure_postgres_app_role.py" in compose


def test_migrations_have_no_unconditional_recreate_always():
    for path in (ROOT / "alembic/versions").glob("*.py"):
        text = path.read_text(encoding="utf-8")
        assert "recreate=\"always\"" not in text
        assert "recreate='always'" not in text
