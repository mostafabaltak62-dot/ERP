import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from fastapi import HTTPException

from app.models import Base, User, RoleEnum, Account, AccountTypeEnum, JournalLine
from app.enterprise_models import Company, Branch, UserCompanyAccess
from app.governance import set_request_context, clear_request_context
from app.routers.accounting_router import create_account, edit_account, _account_candidates

@pytest.fixture()
def db_user():
    engine=create_engine('sqlite:///:memory:', connect_args={'check_same_thread':False})
    Base.metadata.create_all(engine)
    db=sessionmaker(bind=engine)()
    c=Company(code='C96', name='Patch 96 Company'); db.add(c); db.flush()
    b1=Branch(company_id=c.id, code='B1', name='Branch 1'); b2=Branch(company_id=c.id, code='B2', name='Branch 2'); db.add_all([b1,b2]); db.flush()
    u=User(username='u96', full_name='User 96', password_hash='x', role=RoleEnum.admin)
    db.add(u); db.flush()
    db.add(UserCompanyAccess(user_id=u.id, company_id=c.id, branch_id=None, can_manage=True)); db.commit()
    set_request_context(user_id=u.id, company_id=c.id, branch_id=None, request_id='r96')
    yield db,u,c,b1,b2
    clear_request_context(); db.close()

def test_create_global_and_branch_accounts_allow_same_code(db_user):
    db,u,c,b1,b2=db_user
    create_account(db=db,user=u,code='1200',name='Global Receivables',account_type='asset',parent_id='',normal_balance='debit',statement_section='trade_receivables',cash_flow_category='',branch_id='')
    create_account(db=db,user=u,code='1200',name='B1 Receivables',account_type='asset',parent_id='',normal_balance='debit',statement_section='trade_receivables',cash_flow_category='',branch_id=str(b1.id))
    assert db.query(Account).filter_by(company_id=c.id,code='1200').count()==2

def test_duplicate_same_scope_rejected(db_user):
    db,u,c,b1,b2=db_user
    create_account(db=db,user=u,code='1300',name='Inventory',account_type='asset',parent_id='',normal_balance='debit',statement_section='inventory',cash_flow_category='',branch_id=str(b1.id))
    with pytest.raises(HTTPException) as e:
        create_account(db=db,user=u,code='1300',name='Inventory 2',account_type='asset',parent_id='',normal_balance='debit',statement_section='inventory',cash_flow_category='',branch_id=str(b1.id))
    assert e.value.status_code==409

def test_parent_must_be_same_type_and_compatible_scope(db_user):
    db,u,c,b1,b2=db_user
    create_account(db=db,user=u,code='1000',name='Assets',account_type='asset',parent_id='',normal_balance='debit',statement_section='asset',cash_flow_category='',branch_id='')
    parent=db.query(Account).filter_by(company_id=c.id,code='1000',branch_id=None).one()
    with pytest.raises(HTTPException) as e:
        create_account(db=db,user=u,code='2000',name='Payables',account_type='liability',parent_id=str(parent.id),normal_balance='credit',statement_section='trade_payables',cash_flow_category='',branch_id=str(b1.id))
    assert e.value.status_code==422

def test_edit_prevents_hierarchy_cycle_and_type_change_after_use(db_user):
    db,u,c,b1,b2=db_user
    a=Account(company_id=c.id,code='1000',name='A',account_type=AccountTypeEnum.asset,normal_balance='debit',statement_section='asset')
    child=Account(company_id=c.id,code='1100',name='Child',account_type=AccountTypeEnum.asset,normal_balance='debit',statement_section='asset',parent=a)
    db.add_all([a,child]); db.commit()
    with pytest.raises(HTTPException) as e:
        edit_account(a.id,db=db,user=u,name='A',account_type='asset',parent_id=str(child.id),normal_balance='debit',statement_section='asset',cash_flow_category='')
    assert e.value.status_code==422
    jl=JournalLine(company_id=c.id,branch_id=None,entry_id=1,account_id=a.id,debit=1,credit=0)
    # No FK enforcement needed for this guard; the route only checks account_id usage.
    db.add(jl); db.commit()
    with pytest.raises(HTTPException) as e:
        edit_account(a.id,db=db,user=u,name='A',account_type='liability',parent_id='',normal_balance='credit',statement_section='liability',cash_flow_category='')
    assert e.value.status_code==409

def test_branch_candidates_never_cross_other_branch(db_user):
    db,u,c,b1,b2=db_user
    g=Account(company_id=c.id,code='1000',name='Global',account_type=AccountTypeEnum.asset,is_active=True)
    x=Account(company_id=c.id,branch_id=b1.id,code='1100',name='B1',account_type=AccountTypeEnum.asset,is_active=True)
    y=Account(company_id=c.id,branch_id=b2.id,code='1200',name='B2',account_type=AccountTypeEnum.asset,is_active=True)
    db.add_all([g,x,y]); db.commit()
    rows=_account_candidates(db,c.id,b1.id)
    assert {r.id for r in rows}=={g.id,x.id}
