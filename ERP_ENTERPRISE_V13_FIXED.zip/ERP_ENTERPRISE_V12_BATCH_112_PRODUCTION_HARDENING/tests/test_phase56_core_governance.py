from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, User, RoleEnum
from app.enterprise_models import Company, DocumentAttachment, Notification, WorkflowDefinition, WorkflowStep, WorkflowInstance
from app.core_services import create_document_attachment, list_document_attachments, create_notification
from app.enterprise_services import create_workflow_definition, decide_workflow_hardened
from app.governance import set_request_context, clear_request_context


def make_db():
    e=create_engine('sqlite:///:memory:', connect_args={'check_same_thread':False})
    Base.metadata.create_all(e)
    return sessionmaker(bind=e)()


def test_document_versions_are_tenant_scoped_and_incremented():
    db=make_db(); c=Company(code='C1',name='One'); db.add(c); db.flush()
    a=create_document_attachment(db,c.id,1,'invoice',7,'a.pdf','s/a.pdf'); db.commit()
    b=create_document_attachment(db,c.id,1,'invoice',7,'a-v2.pdf','s/a-v2.pdf'); db.commit()
    assert a.version == 1 and b.version == 2
    assert [x.version for x in list_document_attachments(db,c.id,'invoice',7)] == [2,1]


def test_workflow_enforces_required_permission_and_advances():
    db=make_db(); c=Company(code='C1',name='One'); db.add(c); db.flush()
    wf=create_workflow_definition(db,c.id,'purchase_order','PO Approval',[
        {'sequence':1,'name':'Finance','required_permission':'purchase:approve','min_amount':Decimal('0'),'max_amount':None},
        {'sequence':2,'name':'Management','required_permission':'purchase:final','min_amount':None,'max_amount':None},
    ])
    inst=WorkflowInstance(company_id=c.id,workflow_id=wf.id,document_type='purchase_order',document_id=99,current_step=1)
    db.add(inst); db.flush(); set_request_context(company_id=c.id)
    try:
        import pytest
        with pytest.raises(ValueError,match='Missing approval permission'):
            decide_workflow_hardened(db,inst.id,1,True,has_permission=lambda code: False)
        row=decide_workflow_hardened(db,inst.id,1,True,has_permission=lambda code: code=='purchase:approve')
        assert row.status=='pending' and row.current_step==2
    finally:
        clear_request_context()


def test_notification_requires_nonempty_content():
    db=make_db(); c=Company(code='C1',name='One'); db.add(c); db.flush()
    import pytest
    with pytest.raises(ValueError): create_notification(db,c.id,1,'system',' ','message')
