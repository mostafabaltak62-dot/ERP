from decimal import Decimal
from datetime import date
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
from app.enterprise_models import Company, Project, Contract, BOQItem, ProgressCertificate, ProjectCost
from app.construction_models import ConstructionCostCode, WBSNode, BOQRevision, BOQLine, ConstructionMeasurement, ConstructionMeasurementLine, ConstructionVariation, ConstructionProgressCertificateLine
from app.construction_services import create_cost_code, create_wbs, create_boq_revision, record_measurement, approve_measurement, add_variation, approve_variation, create_progress_certificate, project_control

def setup():
    import app.construction_models  # register tables
    e=create_engine('sqlite:///:memory:'); Base.metadata.create_all(e); S=sessionmaker(bind=e); db=S()
    c=Company(code='C60',name='Construction Co'); db.add(c); db.flush()
    p=Project(company_id=c.id,code='P60',name='Tower',budget=Decimal('100000')); db.add(p); db.flush()
    return db,c,p

def test_boq_measurement_progress_and_variation_control():
    db,c,p=setup()
    cc=create_cost_code(db,c.id,'MAT-01','Concrete','material')
    wbs=create_wbs(db,c.id,p.id,'1.1','Structure',50000)
    rev,total=create_boq_revision(db,c.id,p.id,1,date(2026,1,1),'Initial',1,[{'item_code':'C-01','description':'Concrete','unit':'m3','contract_qty':Decimal('100'),'contract_rate':Decimal('500'),'wbs_id':wbs.id,'cost_code_id':cc.id}])
    assert total==Decimal('50000.00')
    line=db.query(BOQLine).filter_by(revision_id=rev.id).one()
    m,amt=record_measurement(db,c.id,p.id,'M-001',date(2026,1,10),1,[{'boq_line_id':line.id,'current_qty':Decimal('20'),'cumulative_qty':Decimal('20')}])
    assert amt==Decimal('10000.00')
    approve_measurement(db,c.id,m.id)
    v=add_variation(db,c.id,p.id,'VO-001','Additional concrete',Decimal('5000'))
    approve_variation(db,c.id,v.id,1)
    cert=create_progress_certificate(db,c.id,p.id,'PC-001',date(2026,1,31),1,[{'boq_line_id':line.id,'current_qty':Decimal('20'),'cumulative_qty':Decimal('20')}],10,Decimal('1000'))
    assert cert.gross_amount==Decimal('10000.00')
    assert cert.retention_amount==Decimal('1000.00')
    assert cert.net_amount==Decimal('8000.00')
    ctl=project_control(db,c.id,p.id)
    assert ctl['revised_contract_value']==Decimal('55000.00')

def test_measurement_cannot_exceed_contract_quantity():
    db,c,p=setup(); rev,_=create_boq_revision(db,c.id,p.id,1,date(2026,1,1),'',1,[{'item_code':'X','description':'Work','unit':'m2','contract_qty':Decimal('10'),'contract_rate':Decimal('100')}])
    line=db.query(BOQLine).filter_by(revision_id=rev.id).one()
    try: record_measurement(db,c.id,p.id,'M-002',date(2026,1,2),1,[{'boq_line_id':line.id,'current_qty':Decimal('11'),'cumulative_qty':Decimal('11')}])
    except ValueError as e: assert 'exceeds contract' in str(e)
    else: raise AssertionError('Expected quantity guard')
