import os
from datetime import date
from app.database import SessionLocal
from app.enterprise_models import Company, Branch, Project, Contract, ProgressCertificate
from app.construction_models import SubcontractorProgress


def test_command_center_and_project_subpages_are_real_html(client):
    login = client.post('/login', data={'username':'admin','password':os.environ['ERP_BOOTSTRAP_ADMIN_PASSWORD']}, follow_redirects=False)
    assert login.status_code in (200, 302, 303)
    db=SessionLocal()
    try:
        company=db.query(Company).filter_by(code='DEFAULT').first()
        assert company
        branch=db.query(Branch).filter_by(company_id=company.id, code='MAIN').first()
        p=Project(company_id=company.id,branch_id=branch.id,code='UI-CC-01',name='Command Center UI Test',budget=100000,status='active')
        db.add(p); db.flush()
        db.add(Contract(company_id=company.id,project_id=p.id,contract_number='CUS-UI-01',contract_type='customer',value=150000,status='active'))
        db.add(Contract(company_id=company.id,project_id=p.id,contract_number='SUB-UI-01',contract_type='subcontractor',value=50000,status='active'))
        db.commit(); pid=p.id
    finally: db.close()

    for path in [f'/projects/command-center?project_id={pid}', f'/projects/command-center/certificates?project_id={pid}', f'/projects/command-center/documents?project_id={pid}']:
        r=client.get(path)
        assert r.status_code == 200, (path, r.text[:500])
        assert 'text/html' in r.headers.get('content-type','')

    db=SessionLocal()
    try:
        p=db.query(Project).filter_by(id=pid).first(); assert p
        # The fixture data remains project-specific; no other project is queried by the page contract.
        assert db.query(ProgressCertificate).filter_by(company_id=p.company_id, project_id=pid).count() == 0
        assert db.query(SubcontractorProgress).filter_by(company_id=p.company_id, project_id=pid).count() == 0
    finally: db.close()
