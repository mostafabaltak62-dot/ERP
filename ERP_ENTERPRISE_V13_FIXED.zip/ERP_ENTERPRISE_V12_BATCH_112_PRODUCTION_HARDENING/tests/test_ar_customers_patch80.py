from datetime import datetime
from decimal import Decimal
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base, Customer, SaleInvoice, FinanceVoucher, PaymentAllocation
from app.enterprise_models import Company, SalesReturn
from app.commercial_completion_models import CustomerCreditPolicy
from app.deep_transactions import ar_aging


def setup():
    e=create_engine('sqlite:///:memory:')
    Base.metadata.create_all(e)
    S=sessionmaker(bind=e); db=S()
    c=Company(code='P80', name='AR Co'); db.add(c); db.flush()
    cust=Customer(company_id=c.id, code='C80', name='Customer 80'); db.add(cust); db.flush()
    pol=CustomerCreditPolicy(company_id=c.id, customer_id=cust.id, payment_terms_days=30, credit_limit=100000, is_active=True)
    db.add(pol); db.commit(); return db,c,cust


def test_ar_aging_uses_terms_and_as_of_payments_and_returns():
    db,c,cust=setup()
    inv=SaleInvoice(company_id=c.id, invoice_number='SI80', customer_id=cust.id,
                    invoice_date=datetime(2026,1,1), subtotal=1000, tax_amount=0, total_amount=1000, status='posted')
    db.add(inv); db.flush()
    v=FinanceVoucher(company_id=c.id, voucher_number='V80', voucher_type='receipt', voucher_date=datetime(2026,1,20), amount=200, description='pay', account_code='1100', party_type='customer', party_id=cust.id)
    db.add(v); db.flush(); db.add(PaymentAllocation(company_id=c.id, voucher_id=v.id, sale_invoice_id=inv.id, amount=200))
    ret=SalesReturn(company_id=c.id, return_number='SR80', sale_invoice_id=inv.id, customer_id=cust.id,
                    return_date=datetime(2026,1,25), status='posted', subtotal=100, tax_amount=0, total_amount=100)
    db.add(ret); db.commit()
    rows=ar_aging(db,c.id,datetime(2026,2,15))
    assert len(rows)==1
    r=rows[0]
    assert r['outstanding']==Decimal('700.00')
    assert r['due_date'].isoformat()=='2026-01-31'
    assert r['overdue_days']==15
    assert r['bucket']=='1-30'


def test_ar_aging_excludes_future_payment_and_nonposted_invoice():
    db,c,cust=setup()
    draft=SaleInvoice(company_id=c.id, invoice_number='D80', customer_id=cust.id, invoice_date=datetime(2026,1,1), subtotal=500, total_amount=500, status='draft')
    posted=SaleInvoice(company_id=c.id, invoice_number='P80', customer_id=cust.id, invoice_date=datetime(2026,1,1), subtotal=500, total_amount=500, status='posted')
    db.add_all([draft,posted]); db.flush()
    v=FinanceVoucher(company_id=c.id, voucher_number='V81', voucher_type='receipt', voucher_date=datetime(2026,3,1), amount=500, description='future', account_code='1100', party_type='customer', party_id=cust.id)
    db.add(v); db.flush(); db.add(PaymentAllocation(company_id=c.id, voucher_id=v.id, sale_invoice_id=posted.id, amount=500)); db.commit()
    rows=ar_aging(db,c.id,datetime(2026,2,1))
    assert [r['invoice_number'] for r in rows]==['P80']
    assert rows[0]['outstanding']==Decimal('500.00')


def test_ar_aging_customer_filter_and_customer_name_are_authoritative():
    db,c,cust=setup()
    other=Customer(company_id=c.id, code='C81', name='Other Customer'); db.add(other); db.flush()
    for n,customer in [('A81',cust),('A82',other)]:
        db.add(SaleInvoice(company_id=c.id, invoice_number=n, customer_id=customer.id,
                           invoice_date=datetime(2026,1,1), subtotal=100, tax_amount=0,
                           total_amount=100, status='posted'))
    db.commit()
    rows=ar_aging(db,c.id,datetime(2026,2,1),customer_id=cust.id)
    assert [r['invoice_number'] for r in rows] == ['A81']
    assert rows[0]['customer_name'] == 'Customer 80'
    assert rows[0]['original'] == Decimal('100.00')


def test_ar_aging_does_not_cross_branch_on_allocations():
    from app.enterprise_models import Branch
    db,c,cust=setup()
    b1=Branch(company_id=c.id, code='B1', name='Branch 1', is_active=True)
    b2=Branch(company_id=c.id, code='B2', name='Branch 2', is_active=True)
    db.add_all([b1,b2]); db.flush()
    inv=SaleInvoice(company_id=c.id, branch_id=b1.id, invoice_number='BR80', customer_id=cust.id,
                    invoice_date=datetime(2026,1,1), subtotal=1000, tax_amount=0, total_amount=1000, status='posted')
    db.add(inv); db.flush()
    v=FinanceVoucher(company_id=c.id, branch_id=b2.id, voucher_number='VB80', voucher_type='receipt',
                     voucher_date=datetime(2026,1,20), amount=500, description='wrong branch', account_code='1100',
                     party_type='customer', party_id=cust.id)
    db.add(v); db.flush()
    db.add(PaymentAllocation(company_id=c.id, branch_id=b2.id, voucher_id=v.id, sale_invoice_id=inv.id, amount=500))
    db.commit()
    rows=ar_aging(db,c.id,datetime(2026,2,1),branch_id=b1.id)
    assert len(rows)==1
    assert rows[0]['outstanding'] == Decimal('1000.00')


def test_ar_aging_never_reports_negative_outstanding_from_overpayment_or_returns():
    db,c,cust=setup()
    inv=SaleInvoice(company_id=c.id, invoice_number='OV80', customer_id=cust.id,
                    invoice_date=datetime(2026,1,1), subtotal=1000, tax_amount=0, total_amount=1000, status='posted')
    db.add(inv); db.flush()
    v=FinanceVoucher(company_id=c.id, voucher_number='OVV80', voucher_type='receipt', voucher_date=datetime(2026,1,10),
                     amount=1200, description='overpay', account_code='1100', party_type='customer', party_id=cust.id)
    db.add(v); db.flush(); db.add(PaymentAllocation(company_id=c.id, voucher_id=v.id, sale_invoice_id=inv.id, amount=1200))
    db.commit()
    assert ar_aging(db,c.id,datetime(2026,2,1)) == []
