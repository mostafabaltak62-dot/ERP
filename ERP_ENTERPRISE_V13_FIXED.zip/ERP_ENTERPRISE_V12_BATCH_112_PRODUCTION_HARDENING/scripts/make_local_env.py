"""Create a safe local .env (SQLite, development mode) with fresh random secrets.

Never overwrites an existing .env. Prints the generated admin credentials once.
"""
import secrets
import sys
from pathlib import Path

target = Path(__file__).resolve().parents[1] / ".env"
if target.exists():
    print(".env already exists - left untouched.")
    sys.exit(0)

admin_password = secrets.token_urlsafe(12)
target.write_text(
    "\n".join(
        [
            "ERP_ENV=development",
            "DATABASE_URL=sqlite:///./erp_local.db",
            f"JWT_SECRET_KEY={secrets.token_urlsafe(48)}",
            f"ENCRYPTION_KEY={secrets.token_urlsafe(48)}",
            "ERP_BOOTSTRAP_ADMIN_USERNAME=admin",
            f"ERP_BOOTSTRAP_ADMIN_PASSWORD={admin_password}",
            "ERP_CSRF_ALLOW_MISSING_ORIGIN=false",
            "",
        ]
    ),
    encoding="utf-8",
)
print("=" * 50)
print("Local .env created.")
print("Login URL : http://127.0.0.1:8000")
print("Username  : admin")
print(f"Password  : {admin_password}")
print("(also stored in .env - change it after first login)")
print("=" * 50)
