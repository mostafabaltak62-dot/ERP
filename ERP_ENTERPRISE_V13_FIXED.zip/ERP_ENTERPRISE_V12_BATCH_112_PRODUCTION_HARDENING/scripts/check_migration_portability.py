"""Static portability gate for Alembic migrations.

Fails on SQLite-only migration constructs that would break a fresh PostgreSQL
installation. Dialect-aware branches are allowed when both dialects are handled.
"""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
VERSIONS = ROOT / "alembic" / "versions"
issues = []
for path in sorted(VERSIONS.glob("*.py")):
    text = path.read_text(encoding="utf-8")
    if re.search(r"recreate\s*=\s*['\"]always['\"]", text):
        issues.append(f"{path}: batch_alter_table(recreate='always') is not portable to PostgreSQL")
    if re.search(r"\bINSERT\s+(OR\s+IGNORE|IGNORE)\b", text, re.I):
        # A dialect branch may contain the SQLite form; it must be paired with a
        # PostgreSQL ON CONFLICT/compatible branch in the same migration.
        if "ON CONFLICT" not in text.upper():
            issues.append(f"{path}: SQLite-only INSERT IGNORE form without PostgreSQL alternative")
    if re.search(r"\bREPLACE\s+INTO\b", text, re.I):
        issues.append(f"{path}: SQLite-specific REPLACE INTO")

if issues:
    print("Migration portability: FAIL")
    print("\n".join(issues))
    raise SystemExit(1)
print(f"Migration portability: PASS ({len(list(VERSIONS.glob('*.py')))} revisions scanned)")
