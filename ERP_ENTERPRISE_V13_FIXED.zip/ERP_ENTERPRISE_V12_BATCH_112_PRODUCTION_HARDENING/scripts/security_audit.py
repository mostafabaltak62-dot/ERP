"""Static security audit for SQL construction and secret leakage patterns."""
from __future__ import annotations
import ast
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
violations: list[str] = []

for path in APP.rglob("*.py"):
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in {"text", "literal_column"}:
            if node.args and isinstance(node.args[0], (ast.JoinedStr, ast.BinOp)):
                violations.append(f"{path}:{node.lineno}: dynamic SQL expression passed to {node.func.id}()")

for path in APP.rglob("*.py"):
    text = path.read_text(encoding="utf-8")
    if path.name != "database.py" and re.search(r"(?:postgresql|mysql)://[^\s\"']+", text, re.I):
        violations.append(f"{path}: possible hard-coded database URL")

if violations:
    print("SECURITY AUDIT FAILED")
    print("\n".join(violations))
    sys.exit(1)
print("SECURITY AUDIT PASS: no dynamic SQL construction or hard-coded DB URLs found in app/")
