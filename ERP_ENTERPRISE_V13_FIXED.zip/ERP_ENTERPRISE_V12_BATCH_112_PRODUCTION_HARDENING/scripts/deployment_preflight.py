"""Production deployment preflight checks.

The script is intentionally read-only. It verifies that the runtime dependencies
required by the deployment contract are reachable and that the schema is at the
expected Alembic head before application traffic is enabled.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from alembic.script import ScriptDirectory

from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, inspect, text

def expected_heads() -> list[str]:
    cfg = Config(str(Path(__file__).resolve().parents[1] / "alembic.ini"))
    script = ScriptDirectory.from_config(cfg)
    return sorted(script.get_heads())


def database_url() -> str:
    return os.getenv("DATABASE_URL") or os.getenv("ERP_DATABASE_URL") or "sqlite:///./erp.db"


def check_database(url: str) -> None:
    engine = create_engine(url, pool_pre_ping=True)
    with engine.connect() as connection:
        connection.execute(text("SELECT 1"))
        if connection.dialect.name == "postgresql":
            version = connection.execute(text("SHOW server_version")).scalar_one()
            if int(str(version).split(".")[0]) < 14:
                raise RuntimeError(f"PostgreSQL 14+ is required; found {version}")
    engine.dispose()


def check_storage() -> None:
    root = Path(os.getenv("ERP_DOCUMENT_STORAGE_PATH", "./storage/documents")).resolve()
    root.mkdir(parents=True, exist_ok=True)
    probe = root / ".write-probe"
    probe.write_text("ok", encoding="utf-8")
    probe.unlink()


def check_redis() -> None:
    broker = os.getenv("CELERY_BROKER_URL", "").strip()
    if not broker:
        from app.core_settings import redis_connection_url
        broker = redis_connection_url(0)
    if not broker:
        if os.getenv("ERP_ENV", "development").lower() == "production":
            raise RuntimeError("Redis broker configuration is required in production")
        return
    try:
        import redis
        redis.from_url(broker, socket_connect_timeout=3).ping()
    except ImportError as exc:
        raise RuntimeError("redis package is required for broker preflight") from exc


def check_postgres_rls(url: str) -> None:
    engine = create_engine(url, pool_pre_ping=True)
    if engine.dialect.name != "postgresql":
        engine.dispose()
        return
    with engine.connect() as connection:
        missing = connection.execute(text("""
            SELECT c.relname
            FROM pg_class c
            JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE c.relkind='r' AND n.nspname=current_schema()
              AND EXISTS (
                SELECT 1 FROM pg_attribute a
                WHERE a.attrelid=c.oid AND a.attname='company_id' AND NOT a.attisdropped
              )
              AND NOT c.relrowsecurity
            ORDER BY c.relname
        """)).scalars().all()
        if missing:
            raise RuntimeError("PostgreSQL RLS is not enabled on: " + ", ".join(missing))
    engine.dispose()


def check_head() -> str:
    heads = expected_heads()
    if len(heads) != 1:
        raise RuntimeError(f"Migration graph must have one head; found {heads!r}")
    expected = heads[0]
    engine = create_engine(database_url(), pool_pre_ping=True)
    try:
        with engine.connect() as connection:
            row = connection.execute(text("SELECT version_num FROM alembic_version")).scalar_one_or_none()
            if row != expected:
                raise RuntimeError(f"Database revision is {row!r}; expected {expected!r}")
    finally:
        engine.dispose()
    return expected


def main() -> int:
    try:
        url = database_url()
        check_database(url)
        check_storage()
        check_redis()
        check_postgres_rls(url)
        head = check_head()
    except Exception as exc:
        print(f"DEPLOYMENT PREFLIGHT: FAIL — {exc}", file=sys.stderr)
        return 1
    print(f"DEPLOYMENT PREFLIGHT: PASS — Alembic {head}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
