"""Create the least-privileged PostgreSQL login used by FastAPI.

The migration/admin role owns schema changes; the application role is explicitly
NOSUPERUSER/NOBYPASSRLS so PostgreSQL RLS is an effective second isolation boundary.
"""
import os
from psycopg import connect
from psycopg.sql import Identifier, SQL

admin_user = os.environ["POSTGRES_ADMIN_USER"]
admin_password = os.environ["POSTGRES_PASSWORD"]
app_user = os.environ.get("ERP_APP_DB_USER", "erp_app")
app_password = os.environ["ERP_APP_DB_PASSWORD"]
db_name = os.environ.get("POSTGRES_DB", "erp")

if not app_user.replace("_", "").isalnum():
    raise SystemExit("ERP_APP_DB_USER contains unsupported characters")

with connect(host="postgres", port=5432, dbname=db_name, user=admin_user, password=admin_password, autocommit=True) as conn:
    with conn.cursor() as cur:
        role = Identifier(app_user)
        db = Identifier(db_name)
        cur.execute(SQL("SELECT 1 FROM pg_roles WHERE rolname = %s"), (app_user,))
        exists = cur.fetchone() is not None
        if exists:
            cur.execute(SQL("ALTER ROLE {} WITH LOGIN NOSUPERUSER NOBYPASSRLS PASSWORD %s").format(role), (app_password,))
        else:
            cur.execute(SQL("CREATE ROLE {} LOGIN NOSUPERUSER NOBYPASSRLS PASSWORD %s").format(role), (app_password,))
        cur.execute(SQL("GRANT CONNECT ON DATABASE {} TO {}").format(db, role))
        cur.execute(SQL("GRANT USAGE ON SCHEMA public TO {}").format(role))
        cur.execute(SQL("GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO {}").format(role))
        cur.execute(SQL("GRANT USAGE, SELECT, UPDATE ON ALL SEQUENCES IN SCHEMA public TO {}").format(role))
        cur.execute(SQL("ALTER DEFAULT PRIVILEGES FOR ROLE {} IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO {}").format(Identifier(admin_user), role))
        cur.execute(SQL("ALTER DEFAULT PRIVILEGES FOR ROLE {} IN SCHEMA public GRANT USAGE, SELECT, UPDATE ON SEQUENCES TO {}").format(Identifier(admin_user), role))
        cur.execute(SQL("REVOKE BYPASSRLS FROM {}").format(role))
print(f"PostgreSQL application role ready: {app_user} (NOSUPERUSER, NOBYPASSRLS)")
