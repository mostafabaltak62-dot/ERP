"""Authoritative PostgreSQL production-readiness validation.
Read-only except when explicitly run after migrations in a disposable/staging database.
"""
from __future__ import annotations
import os, sys
from sqlalchemy import create_engine, text
from alembic.config import Config
from alembic.script import ScriptDirectory


def main() -> int:
    url = os.getenv("DATABASE_URL") or os.getenv("ERP_DATABASE_URL")
    if not url:
        print("POSTGRES VALIDATION: FAIL — DATABASE_URL is required", file=sys.stderr); return 2
    engine = create_engine(url, pool_pre_ping=True)
    if engine.dialect.name != "postgresql":
        print("POSTGRES VALIDATION: FAIL — PostgreSQL is required", file=sys.stderr); return 2
    cfg = Config("alembic.ini")
    expected = sorted(ScriptDirectory.from_config(cfg).get_heads())
    try:
        with engine.connect() as c:
            version = c.execute(text("SHOW server_version")).scalar_one()
            revision = c.execute(text("SELECT version_num FROM alembic_version")).scalar_one_or_none()
            if expected != [revision]:
                raise RuntimeError(f"revision {revision!r}; expected {expected!r}")
            rls_missing = c.execute(text("""
                SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
                WHERE c.relkind='r' AND n.nspname=current_schema()
                AND EXISTS (SELECT 1 FROM pg_attribute a WHERE a.attrelid=c.oid AND a.attname='company_id' AND NOT a.attisdropped)
                AND NOT c.relrowsecurity ORDER BY c.relname
            """)).scalars().all()
            if rls_missing:
                raise RuntimeError("RLS disabled on tenant tables: " + ", ".join(rls_missing))
            print(f"POSTGRES VALIDATION: PASS — PostgreSQL {version}, Alembic {revision}")
            return 0
    except Exception as exc:
        print(f"POSTGRES VALIDATION: FAIL — {exc}", file=sys.stderr); return 1
    finally:
        engine.dispose()

if __name__ == '__main__':
    raise SystemExit(main())
