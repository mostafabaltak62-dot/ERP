"""Static integration audit for the ERP release.

Checks wiring that unit tests commonly miss: every referenced Jinja template exists,
all HTTP business routes declare authentication/tenant dependencies, and the Alembic
head is synchronized with the release contract.
"""
from __future__ import annotations
import ast, re, sys
from pathlib import Path
from alembic.config import Config
from alembic.script import ScriptDirectory

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_HEAD = None


def template_audit():
    missing = []
    for py in (ROOT / "app").rglob("*.py"):
        text = py.read_text(encoding="utf-8")
        for name in re.findall(r"(?:TemplateResponse\([^,]+,\s*|render_template\(\s*)['\"]([^'\"]+)['\"]", text):
            if not (ROOT / "templates" / name).exists():
                missing.append(f"{py.relative_to(ROOT)} -> {name}")
    return missing


def route_dependency_audit():
    unprotected = []
    for py in (ROOT / "app/routers").glob("*.py"):
        text = py.read_text(encoding="utf-8")
        tree = ast.parse(text)
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            route = None
            decorator_text = ""
            for dec in node.decorator_list:
                src = ast.get_source_segment(text, dec) or ""
                decorator_text += src + " "
                if re.match(r"router\.(get|post|put|patch|delete)\(", src):
                    route = src
            if route:
                body = ast.get_source_segment(text, node) or ""
                if node.name in {"login_page", "login_submit", "logout", "refresh_session", "mobile_login", "mobile_refresh", "health", "forgot_password", "request_reset", "verify_reset", "complete_reset"}:
                    continue
                if not any(x in (body + decorator_text) for x in ("require_permission", "require_module", "get_current_user", "get_tenant_context", "Depends(")):
                    unprotected.append(f"{py.relative_to(ROOT)}:{node.lineno} {node.name}")
    return unprotected


def migration_head_audit():
    scripts = ScriptDirectory.from_config(Config(str(ROOT / "alembic.ini")))
    heads = scripts.get_heads()
    return heads


def main():
    missing = template_audit()
    unprotected = route_dependency_audit()
    heads = migration_head_audit()
    errors = []
    if missing: errors.append("Missing templates: " + "; ".join(missing))
    if unprotected: errors.append("Unprotected router functions: " + "; ".join(unprotected))
    if EXPECTED_HEAD is not None and heads != [EXPECTED_HEAD]: errors.append(f"Alembic heads {heads!r}; expected {[EXPECTED_HEAD]!r}")
    if errors:
        print("E2E INTEGRATION AUDIT: FAIL")
        for e in errors: print(" - " + e)
        return 1
    print(f"E2E INTEGRATION AUDIT: PASS — templates, route dependencies, Alembic {EXPECTED_HEAD or heads}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
