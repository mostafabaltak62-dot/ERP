#!/usr/bin/env python3
"""Release quality gate for the ERP codebase.

The gate intentionally checks failure-prone engineering contracts locally so CI and
local development use the same baseline even when optional linters are unavailable.
"""
from __future__ import annotations

import ast
import logging
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
ALEMBIC = ROOT / "alembic.ini"

FORBIDDEN_CALLS = {
    ("builtins", "eval"),
    ("builtins", "exec"),
    ("os", "system"),
    ("pickle", "load"),
    ("pickle", "loads"),
}
FORBIDDEN_IMPORTS = {"pickle", "marshal"}
SECRET_NAME = re.compile(r"(?:password|secret|api[_-]?key|token)", re.I)


def run(cmd: list[str], *, env: dict[str, str] | None = None) -> None:
    subprocess.run(cmd, cwd=ROOT, env=env, check=True)


def python_compile() -> None:
    run([sys.executable, "-m", "compileall", "-q", "app", "tests", "scripts"])


def security_scan() -> None:
    violations: list[str] = []
    for path in APP.rglob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        imported_modules: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imported_modules.update(alias.name.split(".")[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                imported_modules.add(node.module.split(".")[0])

            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name) and node.func.id in {"eval", "exec"}:
                    violations.append(f"{path}:{node.lineno}: dynamic code execution: {node.func.id}()")
                if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name):
                    pair = (node.func.value.id, node.func.attr)
                    if pair in FORBIDDEN_CALLS:
                        violations.append(f"{path}:{node.lineno}: forbidden security-sensitive call: {pair[0]}.{pair[1]}()")
                    if pair == ("subprocess", node.func.attr):
                        for kw in node.keywords:
                            if kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value is True:
                                violations.append(f"{path}:{node.lineno}: subprocess shell=True is prohibited")
                if isinstance(node.func, ast.Attribute) and node.func.attr == "load" and isinstance(node.func.value, ast.Name) and node.func.value.id == "yaml":
                    violations.append(f"{path}:{node.lineno}: yaml.load() is prohibited; use safe_load()")

            if isinstance(node, ast.Assign):
                targets = [t.id for t in node.targets if isinstance(t, ast.Name)]
                if any(SECRET_NAME.search(t) for t in targets):
                    if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str) and len(node.value.value) >= 8:
                        value = node.value.value.lower()
                        if value not in {"changeme", "password", "secret", "token", "your-password"}:
                            violations.append(f"{path}:{node.lineno}: possible hard-coded secret in {targets[0]}")

        for module in sorted(imported_modules & FORBIDDEN_IMPORTS):
            violations.append(f"{path}: prohibited import: {module}")

    if violations:
        raise SystemExit("Security gate failed:\n" + "\n".join(violations))


def migration_graph_check() -> None:
    from alembic.config import Config
    from alembic.script import ScriptDirectory

    cfg = Config(str(ALEMBIC))
    script = ScriptDirectory.from_config(cfg)
    heads = script.get_heads()
    if len(heads) != 1:
        raise SystemExit(f"Migration graph must have exactly one head; found {heads}")

    revisions = list(script.walk_revisions(base="base", head="heads"))
    ids = [rev.revision for rev in revisions]
    if len(ids) != len(set(ids)):
        raise SystemExit("Migration graph contains duplicate revision identifiers")


def schema_drift_check() -> None:
    from alembic.config import Config
    from alembic import command
    from sqlalchemy import create_engine, inspect
    from app.models import Base
    from app import account_security, construction_models, deep_transactions, document_models, enterprise_models, enterprise_plus_models, field_ops_models, governance_models, hr_models, warehouse_models  # noqa: F401

    logging.getLogger("alembic").setLevel(logging.ERROR)
    logging.getLogger("sqlalchemy").setLevel(logging.ERROR)
    with tempfile.TemporaryDirectory(prefix="erp_schema_gate_") as tmp:
        db_path = Path(tmp) / "fresh.db"
        url = f"sqlite:///{db_path}"
        env = os.environ.copy()
        env["DATABASE_URL"] = url
        cfg = Config(str(ALEMBIC))
        cfg.config_file_name = None
        cfg.set_main_option("script_location", str(ROOT / "alembic"))
        cfg.set_main_option("sqlalchemy.url", url)
        command.upgrade(cfg, "head")

        inspector = inspect(create_engine(url))
        model_tables = set(Base.metadata.tables)
        db_tables = set(inspector.get_table_names()) - {"alembic_version"}
        missing = sorted(model_tables - db_tables)
        extra = sorted(db_tables - model_tables)
        if missing or extra:
            raise SystemExit(f"Schema table drift detected. Missing={missing}, Extra={extra}")

        drift: list[str] = []
        for table_name in sorted(model_tables):
            model_columns = {c.name: c for c in Base.metadata.tables[table_name].columns}
            db_columns = {c["name"]: c for c in inspector.get_columns(table_name)}
            for column in sorted(set(model_columns) - set(db_columns)):
                drift.append(f"{table_name}.{column}: missing in database")
            for column in sorted(set(db_columns) - set(model_columns)):
                drift.append(f"{table_name}.{column}: extra in database")
            for column in sorted(set(model_columns) & set(db_columns)):
                if bool(model_columns[column].nullable) != bool(db_columns[column]["nullable"]):
                    drift.append(f"{table_name}.{column}: nullable mismatch")

            model_fks = {(fk.parent.name, fk.column.table.name, fk.column.name) for fk in Base.metadata.tables[table_name].foreign_keys}
            db_fks = set()
            for fk in inspector.get_foreign_keys(table_name):
                for local, remote in zip(fk.get("constrained_columns", []), fk.get("referred_columns", [])):
                    db_fks.add((local, fk.get("referred_table"), remote))
            if model_fks != db_fks:
                drift.append(f"{table_name}: foreign-key contract mismatch")

        if drift:
            raise SystemExit("Schema drift detected:\n" + "\n".join(drift[:100]))


def optional_tools() -> None:
    # CI installs these tools. Local environments may omit them; the built-in
    # gates above remain mandatory so developers are never blocked by tooling setup.
    ruff = ROOT / ".venv" / "bin" / "ruff"
    if ruff.exists():
        run([str(ruff), "check", "app", "tests", "scripts"])


def main() -> None:
    python_compile()
    security_scan()
    migration_graph_check()
    schema_drift_check()
    optional_tools()
    print("QUALITY GATE: PASS")


if __name__ == "__main__":
    main()
