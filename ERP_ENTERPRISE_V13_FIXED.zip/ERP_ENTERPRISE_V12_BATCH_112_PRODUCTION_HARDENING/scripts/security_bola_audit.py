"""Static BOLA/tenant review helper.

It reports direct ID lookups in routers/services so reviewers can verify that
company_id/branch/project scope is enforced either explicitly or by the global
SQLAlchemy tenant filter in app.governance.
"""
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parents[1] / "app"
patterns = [
    re.compile(r"db\.get\((\w+),\s*([^)]+)\)"),
    re.compile(r"db\.query\((\w+)\).*?\.filter\([^\n]*\.id\s*=="),
]
for path in sorted((ROOT / "routers").glob("*.py")):
    text = path.read_text(encoding="utf-8")
    for i, line in enumerate(text.splitlines(), 1):
        if any(p.search(line) for p in patterns):
            print(f"{path.relative_to(ROOT.parent)}:{i}: review ID lookup -> {line.strip()}")
