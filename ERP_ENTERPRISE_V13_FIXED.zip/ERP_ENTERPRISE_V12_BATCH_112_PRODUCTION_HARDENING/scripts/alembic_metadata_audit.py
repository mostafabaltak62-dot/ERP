"""Static guard for Alembic metadata imports.

Ensures every app module declaring SQLAlchemy models with Base is represented in
alembic/env.py without importing runtime service modules.
"""
from __future__ import annotations
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
ENV = ROOT / "alembic" / "env.py"

def declares_base_model(path: Path) -> bool:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except SyntaxError:
        return False
    for node in tree.body:
        if not isinstance(node, ast.ClassDef):
            continue
        for base in node.bases:
            if isinstance(base, ast.Name) and base.id == "Base":
                return True
            if isinstance(base, ast.Attribute) and base.attr == "Base":
                return True
    return False

model_modules = sorted(
    p.stem for p in APP.glob("*.py") if declares_base_model(p)
)
env_text = ENV.read_text(encoding="utf-8")
missing = [name for name in model_modules if f"from app import {name}" not in env_text and name != "models"]
if "from app import models" not in env_text:
    missing.append("models")

runtime_imports = [
    "from app import deep_transactions",
    "from app import transaction_services",
    "from app import accounting",
]
unsafe = [line for line in runtime_imports if line in env_text]

if missing or unsafe:
    if missing:
        print("Missing model imports:", ", ".join(missing))
    if unsafe:
        print("Unsafe runtime imports:", ", ".join(unsafe))
    raise SystemExit(1)

print(f"Alembic metadata audit passed: {len(model_modules)} model modules covered.")
