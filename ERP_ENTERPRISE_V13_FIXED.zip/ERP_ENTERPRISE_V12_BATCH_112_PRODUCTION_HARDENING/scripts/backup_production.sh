#!/usr/bin/env bash
set -euo pipefail

: "${PGHOST:?PGHOST is required}"
: "${PGPORT:=5432}"
: "${PGDATABASE:?PGDATABASE is required}"
: "${PGUSER:?PGUSER is required}"
: "${BACKUP_DIR:=./backups}"
: "${ERP_DOCUMENT_STORAGE_PATH:=./storage/documents}"

mkdir -p "$BACKUP_DIR"
timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
pg_dump --format=custom --no-owner --file="$BACKUP_DIR/erp_${timestamp}.dump"
tar -C "$(dirname "$ERP_DOCUMENT_STORAGE_PATH")" -czf "$BACKUP_DIR/documents_${timestamp}.tar.gz" "$(basename "$ERP_DOCUMENT_STORAGE_PATH")"
echo "Backup created: $BACKUP_DIR/erp_${timestamp}.dump"
echo "Documents archive: $BACKUP_DIR/documents_${timestamp}.tar.gz"
