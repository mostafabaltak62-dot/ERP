"""Release gate for migration/model drift.

Run with the same DATABASE_URL and security environment used by deployment.
The command deliberately delegates to Alembic's authoritative autogenerate
comparison and exits non-zero when drift is detected.
"""
import os
import subprocess
import sys

required = ("DATABASE_URL", "JWT_SECRET_KEY", "ENCRYPTION_KEY")
missing = [k for k in required if not os.getenv(k)]
if missing:
    print("ERROR: missing required environment variables: " + ", ".join(missing))
    raise SystemExit(2)
proc = subprocess.run([sys.executable, "-m", "alembic", "check"], text=True)
if proc.returncode:
    print("MODEL_MIGRATION_DRIFT: detected; deployment must stop until reviewed.")
raise SystemExit(proc.returncode)
