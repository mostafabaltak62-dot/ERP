"""Static tenant/query audit for the ERP codebase.

Flags ORM access patterns that need human review. It deliberately reports
findings instead of rewriting queries automatically, because a company filter
is not correct for global/system tables and blind rewrites can break ERP logic.
"""
from __future__ import annotations
import ast
from pathlib import Path
from collections import Counter

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"

GET_CALLS=[]
QUERY_FILES=Counter()
SKIPS=[]
for path in APP.rglob("*.py"):
    try:
        tree=ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except SyntaxError as exc:
        print(f"SYNTAX_ERROR {path}: {exc}")
        continue
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            name=node.func.attr
            if name == "get" and isinstance(node.func.value, ast.Name) and node.func.value.id in {"db","session"}:
                model = ast.unparse(node.args[0]) if node.args else "?"
                GET_CALLS.append((str(path.relative_to(ROOT)), node.lineno, model))
            if name == "query":
                QUERY_FILES[str(path.relative_to(ROOT))] += 1
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "execution_options":
            text=ast.unparse(node)
            if "skip_tenant_filter" in text:
                SKIPS.append((str(path.relative_to(ROOT)), node.lineno, text[:180]))

print("# Tenant & ORM Static Audit")
print(f"Direct Session.get calls: {len(GET_CALLS)}")
print(f"Files containing query() calls: {len(QUERY_FILES)}")
print(f"Explicit tenant-filter bypasses: {len(SKIPS)}")
print("\n## Direct Session.get review queue")
for f,l,m in GET_CALLS:
    print(f"- {f}:{l} -> {m}")
print("\n## Query hotspots")
for f,c in QUERY_FILES.most_common(25):
    print(f"- {f}: {c} query() calls")
print("\n## Explicit bypasses")
for f,l,t in SKIPS:
    print(f"- {f}:{l} -> {t}")
