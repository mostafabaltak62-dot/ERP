"""Live PostgreSQL proof that the configured application role cannot bypass RLS.

Usage requires two DSNs pointing at the same database:
ERP_RLS_ADMIN_DATABASE_URL=<admin/migration DSN>
ERP_RLS_APP_DATABASE_URL=<least-privileged app DSN>
"""
import os
import uuid
import psycopg
from psycopg.sql import Identifier, SQL

admin_dsn = os.environ.get("ERP_RLS_ADMIN_DATABASE_URL")
app_dsn = os.environ.get("ERP_RLS_APP_DATABASE_URL")
if not admin_dsn or not app_dsn:
    raise SystemExit("Set ERP_RLS_ADMIN_DATABASE_URL and ERP_RLS_APP_DATABASE_URL to run the live RLS proof")

name = f"_rls_proof_{uuid.uuid4().hex[:12]}"
t = Identifier(name)
try:
    with psycopg.connect(admin_dsn, autocommit=True) as admin:
        with admin.cursor() as cur:
            cur.execute(SQL("SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user"))
            superuser, bypass = cur.fetchone()
            if not superuser:
                raise RuntimeError("RLS proof admin connection must use a migration/admin role")
            cur.execute(SQL("CREATE TABLE {} (id integer primary key, company_id integer not null, value text not null)").format(t))
            cur.execute(SQL("INSERT INTO {} VALUES (1,1,'A'),(2,2,'B')").format(t))
            cur.execute(SQL("ALTER TABLE {} ENABLE ROW LEVEL SECURITY").format(t))
            cur.execute(SQL("ALTER TABLE {} FORCE ROW LEVEL SECURITY").format(t))
            cur.execute(SQL("CREATE POLICY {} ON {} USING (company_id = NULLIF(current_setting('app.company_id', true), '')::integer) WITH CHECK (company_id = NULLIF(current_setting('app.company_id', true), '')::integer)").format(Identifier(name + '_p'), t))
            # Grant to the configured app role explicitly through a safe identifier.
            app_user = os.environ.get("ERP_RLS_APP_USER")
            if not app_user or not app_user.replace('_','').isalnum():
                raise SystemExit("Set ERP_RLS_APP_USER to the configured application role")
            cur.execute(SQL("GRANT SELECT, INSERT, UPDATE, DELETE ON {} TO {}").format(t, Identifier(app_user)))
            cur.execute(SQL("SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = %s"), (app_user,))
            app_super, app_bypass = cur.fetchone()
            if app_super or app_bypass:
                raise AssertionError("Application role is superuser or BYPASSRLS")

    with psycopg.connect(app_dsn) as app:
        with app.cursor() as cur:
            cur.execute("SET LOCAL app.company_id = '1'")
            cur.execute(SQL("SELECT company_id, value FROM {} ORDER BY id").format(t))
            rows = cur.fetchall()
            assert rows == [(1, 'A')], rows
            try:
                cur.execute(SQL("INSERT INTO {} VALUES (3,2,'should-fail')").format(t))
            except psycopg.errors.InsufficientPrivilege:
                app.rollback()
            else:
                raise AssertionError("Cross-tenant INSERT was not rejected by RLS")
    print("LIVE POSTGRES RLS PROOF: PASS")
finally:
    with psycopg.connect(admin_dsn, autocommit=True) as admin:
        with admin.cursor() as cur:
            cur.execute(SQL("DROP TABLE IF EXISTS {} CASCADE").format(t))
