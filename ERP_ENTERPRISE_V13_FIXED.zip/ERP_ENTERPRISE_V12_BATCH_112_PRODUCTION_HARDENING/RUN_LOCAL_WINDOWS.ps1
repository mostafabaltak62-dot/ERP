$ErrorActionPreference = 'Stop'
if (-not (Test-Path '.venv')) { py -3 -m venv .venv }
& .\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
if (-not (Test-Path '.env')) {
  Copy-Item .env.example .env
  Write-Host 'Created .env from .env.example. Review it before production use.'
}
python -m alembic upgrade head
python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
