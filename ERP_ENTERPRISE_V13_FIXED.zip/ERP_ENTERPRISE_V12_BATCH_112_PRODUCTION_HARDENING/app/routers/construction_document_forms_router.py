import json
import hashlib
import os
import logging
import re
from pathlib import Path
from datetime import date
from fastapi import UploadFile, File, Form
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, FileResponse, Response
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field
from sqlalchemy import func
from sqlalchemy.exc import IntegrityError
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.units import mm
try:
    import arabic_reshaper
    from bidi.algorithm import get_display
except Exception:
    arabic_reshaper = None
    get_display = None
from sqlalchemy.orm import Session

from ..database import get_db
from ..auth import User
from ..governance import get_tenant_context, require_permission, scope_allows
from ..enterprise_models import Project
from ..document_models import ProjectDocument
from ..construction_document_forms_models import ConstructionDocumentForm, ConstructionDocumentFormDecision, ConstructionDocumentFormAttachment
from ..official_excel_form_layouts import EXCEL_FORM_LAYOUTS

logger = logging.getLogger(__name__)

router = APIRouter(prefix='/construction-document-forms', tags=['Construction Document Forms'])
templates = Jinja2Templates(directory='templates')

FORM_STORAGE_ROOT = Path(os.getenv('ERP_DOCUMENT_STORAGE_PATH', './storage/documents')).resolve() / 'official_forms'
FORM_ALLOWED_EXT = {'pdf','doc','docx','xls','xlsx','csv','jpg','jpeg','png','dwg','dxf','zip','txt'}

PDF_FONT = os.getenv('ERP_PDF_ARABIC_FONT', str(Path(__file__).resolve().parents[2] / 'static' / 'fonts' / 'NotoSansArabic-Regular.ttf'))
PDF_BOLD_FONT = os.getenv('ERP_PDF_ARABIC_BOLD_FONT', str(Path(__file__).resolve().parents[2] / 'static' / 'fonts' / 'NotoSansArabic-Bold.ttf'))
try:
    if Path(PDF_FONT).exists(): pdfmetrics.registerFont(TTFont('ERPArabic', PDF_FONT))
    if Path(PDF_BOLD_FONT).exists(): pdfmetrics.registerFont(TTFont('ERPArabicBold', PDF_BOLD_FONT))
except Exception:
    logger.exception('Failed to register optional construction PDF fonts')

def _pdf_ar(value):
    text = '' if value is None else str(value)
    if arabic_reshaper and get_display:
        return get_display(arabic_reshaper.reshape(text))
    return text

def _display_value(value):
    if value is None or value == '': return '—'
    if isinstance(value, (dict, list)): return json.dumps(value, ensure_ascii=False)
    return str(value)

STATUS_LABELS = {
    'draft':'مسودة / Draft', 'submitted':'مُرسل / Submitted', 'under_review':'قيد المراجعة / Under Review',
    'approved':'معتمد / Approved', 'approved_with_comments':'معتمد مع ملاحظات / Approved as Noted',
    'revision_required':'تعديل وإعادة تقديم / Revise & Resubmit', 'rejected':'مرفوض / Rejected',
    'accepted':'مقبول / Accepted', 'closed':'مغلق / Closed',
}

def _status_label(status):
    return STATUS_LABELS.get(status, status or '—')

def _excel_response(row, project, meta, schema, data):
    wb=Workbook(); ws=wb.active
    sheet_title=re.sub(r'[\\/*?:\[\]]',' ',meta['label_en'])[:31].strip() or 'Official Form'
    ws.title=sheet_title
    ws.sheet_view.rightToLeft=True; ws.freeze_panes='A8'; ws.page_setup.paperSize=ws.PAPERSIZE_A4; ws.page_setup.orientation='portrait'; ws.sheet_properties.pageSetUpPr.fitToPage=True; ws.page_setup.fitToWidth=1; ws.page_setup.fitToHeight=0; ws.sheet_view.showGridLines=False
    thin=Side(style='thin', color='000000'); border=Border(left=thin,right=thin,top=thin,bottom=thin)
    ws.merge_cells('A1:D1'); ws['A1']=project.name; ws['A1'].font=Font(bold=True,size=16); ws['A1'].alignment=Alignment(horizontal='center'); ws['A1'].border=border
    ws.merge_cells('A2:D2'); ws['A2']=f"{meta['label_ar']} — {meta['label_en']}"; ws['A2'].font=Font(bold=True,size=14); ws['A2'].alignment=Alignment(horizontal='center'); ws['A2'].border=border
    ws.merge_cells('A3:D3'); ws['A3']=row.form_no; ws['A3'].alignment=Alignment(horizontal='center'); ws['A3'].border=border
    meta_rows=[('الحالة',_status_label(row.status),'نوع التقديم',row.submission_type),('التخصص',row.discipline or '—','تاريخ الإصدار',row.issue_date or '—'),('Zone',row.zone or '—','Level',row.level or '—'),('تاريخ الاستحقاق',row.due_date or '—','الإصدار / Revision',row.current_revision),('ممثل المقاول',row.contractor_representative or '—','ممثل الاستشاري',row.consultant_representative or '—')]
    r=5
    for vals in meta_rows:
        for c,v in enumerate(vals,1):
            cell=ws.cell(r,c,_display_value(v)); cell.border=border; cell.alignment=Alignment(horizontal='right',vertical='top',wrap_text=True)
            if c in (1,3): cell.font=Font(bold=True)
        r+=1
    r+=1
    for sec in schema:
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=4); cell=ws.cell(r,1,sec['title']); cell.font=Font(bold=True,size=12); cell.alignment=Alignment(horizontal='right'); cell.border=border; r+=1
        for field in sec['fields']:
            ws.cell(r,1,field[1]).font=Font(bold=True); ws.cell(r,1).border=border; ws.cell(r,1).alignment=Alignment(horizontal='right',wrap_text=True)
            ws.merge_cells(start_row=r,start_column=2,end_row=r,end_column=4); v=_display_value(data.get(field[0])); ws.cell(r,2,v); ws.cell(r,2).border=border; ws.cell(r,2).alignment=Alignment(horizontal='right',vertical='top',wrap_text=True); r+=1
    if meta.get('decision'):
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=4); ws.cell(r,1,'قرار الاستشاري / Consultant Decision'); ws.cell(r,1).font=Font(bold=True); ws.cell(r,1).border=border; r+=1
        ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=4); ws.cell(r,1,_status_label(row.status)); ws.cell(r,1).border=border; ws.cell(r,1).alignment=Alignment(horizontal='center')
    for col,width in {'A':28,'B':28,'C':20,'D':28}.items(): ws.column_dimensions[col].width=width
    ws.print_title_rows='1:7'; ws.oddFooter.center.text='ERP Enterprise — Official Construction Document'
    out=BytesIO(); wb.save(out); return Response(content=out.getvalue(),media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',headers={'Content-Disposition':f'attachment; filename="{row.form_no}.xlsx"'})

def _pdf_response(row, project, meta, schema, data):
    out=BytesIO(); c=canvas.Canvas(out,pagesize=A4); w,h=A4
    font='ERPArabic' if 'ERPArabic' in pdfmetrics.getRegisteredFontNames() else 'Helvetica'; bold='ERPArabicBold' if 'ERPArabicBold' in pdfmetrics.getRegisteredFontNames() else font
    y=h-15*mm; right=w-15*mm; max_chars=88
    def wrapped(value):
        text=_display_value(value)
        return [text[i:i+max_chars] for i in range(0,len(text),max_chars)] or ['—']
    def text(value,size=9,is_bold=False):
        nonlocal y
        c.setFont(bold if is_bold else font,size)
        for line in wrapped(value):
            if y<18*mm: c.showPage(); y=h-15*mm; c.setFont(bold if is_bold else font,size)
            c.drawRightString(right,y,_pdf_ar(line)); y-=5.1*mm
        y-=0.8*mm
    text(project.name,15,True); text(f"{meta['label_ar']} — {meta['label_en']}",13,True); text(row.form_no,10,True)
    c.line(15*mm,y,right,y); y-=5*mm
    for label,value in [('الحالة',_status_label(row.status)),('نوع التقديم',row.submission_type),('التخصص',row.discipline or '—'),('Zone',row.zone or '—'),('Level',row.level or '—'),('تاريخ الإصدار',row.issue_date or '—'),('تاريخ الاستحقاق',row.due_date or '—'),('الإصدار',row.current_revision)]: text(f"{label}: {_display_value(value)}")
    for sec in schema:
        text(sec['title'],11,True)
        for field in sec['fields']: text(f"{field[1]}: {_display_value(data.get(field[0]))}")
    if meta.get('decision'):
        text('قرار الاستشاري / Consultant Decision',11,True)
        text(_status_label(row.status),10,True)
    text('ممثل المقاول / Contractor Representative: '+(row.contractor_representative or '................'))
    text('ممثل الاستشاري / Consultant Representative: '+(row.consultant_representative or '................'))
    c.save(); out.seek(0); return Response(content=out.getvalue(),media_type='application/pdf',headers={'Content-Disposition':f'attachment; filename="{row.form_no}.pdf"'})

def _safe_filename(name: str) -> str:
    return re.sub(r'[^A-Za-z0-9._ -]', '_', Path(name or 'file').name)[:255]

def _attachment_payload(row):
    return {'id':row.id,'file_name':row.file_name,'mime_type':row.mime_type,'file_size':row.file_size,'sha256':row.sha256,'attachment_type':row.attachment_type,'description':row.description,'uploaded_at':row.uploaded_at.isoformat() if row.uploaded_at else None}

FORM_TYPES = {
    'SIR': {'label_ar':'طلب معاينة موقعية','label_en':'Site Inspection Request','decision':True,'required':['description']},
    'MIR': {'label_ar':'طلب معاينة توريد مواد','label_en':'Material Inspection Request','decision':True,'required':['material','supplier']},
    'MT': {'label_ar':'خطاب تقديم توريدات','label_en':'Material Transmittal / Submittal','decision':True,'required':['material','technical_reference']},
    'DWG': {'label_ar':'رسومات هندسية','label_en':'Drawing Register','decision':True,'required':['drawing_no','revision']},
    'LITER': {'label_ar':'خطاب رسمي','label_en':'Letter / Correspondence','decision':False,'required':['subject']},
    'BOQ': {'label_ar':'جدول الكميات','label_en':'Bill of Quantities','decision':True,'required':['boq_reference']},
    'RFI': {'label_ar':'طلب استفسار فني','label_en':'Request for Information','decision':True,'required':['question']},
    'V.O': {'label_ar':'أمر تغيير','label_en':'Variation Order','decision':True,'required':['reason']},
    'QS': {'label_ar':'حصر الكميات','label_en':'Quantity Survey','decision':True,'required':['quantity_reference']},
    'SNA': {'label_ar':'قائمة ملاحظات','label_en':'Snag List','decision':True,'required':['snag_description','assigned_to']},
    'DOC': {'label_ar':'مستند / وثيقة','label_en':'Document / File','decision':False,'required':['subject']},
    'POUR': {'label_ar':'تصريح صب','label_en':'Pouring Permit','decision':True,'required':['pour_location']},
    'INITIAL_HANDOVER': {'label_ar':'محضر استلام ابتدائي','label_en':'Initial Taking Over Certificate','decision':True,'required':['handover_scope']},
    'FINAL_HANDOVER': {'label_ar':'محضر استلام نهائي','label_en':'Final Handover Certificate','decision':True,'required':['handover_scope']},
    'LOG': {'label_ar':'سجل متابعة','label_en':'Document / Site Log','decision':False,'required':['log_type']},
}

# Official field schemas used by the workspace. Each form keeps its own professional sections
# while still storing flexible, versionable data in data_json.
FORM_SCHEMAS = {
 'SIR': [
  {'title':'1. بيانات المشروع والمرجع','fields':[('client','المالك / Client','text',True),('consultant','الاستشاري / Consultant','text',True),('contractor','المقاول / Contractor','text',True),('reference_no','الرقم المرجعي','text',True),('description','وصف الأعمال المراد معاينتها','textarea',True)]},
  {'title':'2. تفاصيل المعاينة','fields':[('discipline_detail','التخصص','select',True,['مدني','معماري','كهرباء','ميكانيكا','متعدد التخصصات']),('zone_detail','الموقع / Zone','text',True),('level_detail','الطابق / Level','text',False),('inspection_date','تاريخ المعاينة المطلوب','date',True)]},
  {'title':'3. قرار الاستشاري','fields':[('consultant_comments','الملاحظات','textarea',False)]}],
 'MIR': [
  {'title':'1. بيانات التوريد','fields':[('material','المادة / Material','text',True),('supplier','المورد / Supplier','text',True),('manufacturer','المصنع / Manufacturer','text',False),('delivery_note','رقم إذن/فاتورة التوريد','text',True),('quantity','الكمية','number',True),('specification','المواصفة الفنية','textarea',True)]},
  {'title':'2. الاعتماد','fields':[('technical_reference','مرجع الاعتماد/الكتالوج','text',True),('sample_reference','مرجع العينة','text',False),('inspection_date','تاريخ المعاينة','date',True),('comments','ملاحظات','textarea',False)]}],
 'MT': [
  {'title':'1. بيانات التقديم الفني','fields':[('material','اسم المادة/النظام','text',True),('supplier','المورد','text',False),('manufacturer','المصنع','text',False),('technical_reference','المرجع الفني','text',True),('specification','المواصفات المقدمة','textarea',True)]},
  {'title':'2. المرفقات والمراجعة','fields':[('catalogue_reference','مرجع الكتالوج/العينة','text',False),('submission_purpose','الغرض من التقديم','textarea',True),('comments','ملاحظات','textarea',False)]}],
 'DWG': [
  {'title':'1. بيانات الرسم','fields':[('drawing_no','رقم الرسم','text',True),('drawing_title','عنوان الرسم','text',True),('revision','الإصدار / Revision','text',True),('drawing_discipline','التخصص','select',True,['مدني','معماري','كهرباء','ميكانيكا','تنسيق']),('drawing_scale','المقياس','text',False)]},
  {'title':'2. المراجعة','fields':[('drawing_purpose','الغرض من الإصدار','textarea',True),('supersedes','يحل محل إصدار','text',False),('comments','ملاحظات','textarea',False)]}],
 'LITER': [
  {'title':'1. بيانات الخطاب','fields':[('subject','الموضوع','text',True),('letter_no','رقم الخطاب','text',True),('from_party','من','text',True),('to_party','إلى','text',True),('letter_date','تاريخ الخطاب','date',True)]},
  {'title':'2. محتوى الخطاب','fields':[('body','نص/ملخص الخطاب','textarea',True),('action_required','الإجراء المطلوب','textarea',False)]}],
 'BOQ': [
  {'title':'1. مرجع جدول الكميات','fields':[('boq_reference','رقم/مرجع BOQ','text',True),('section','القسم','text',False),('item_code','كود البند','text',False),('item_description','وصف البند','textarea',True),('unit','الوحدة','text',True)]},
  {'title':'2. الكميات والتسعير','fields':[('quantity','الكمية','number',True),('unit_rate','سعر الوحدة','number',False),('currency','العملة','select',True,['EGP','USD','EUR','SAR']),('remarks','ملاحظات','textarea',False)]}],
 'RFI': [
  {'title':'1. الاستفسار الفني','fields':[('rfi_no','رقم RFI','text',True),('subject','الموضوع','text',True),('question','الاستفسار / Question','textarea',True),('drawing_reference','مرجع الرسم/المستند','text',False)]},
  {'title':'2. التأثير والرد','fields':[('impact','التأثير المتوقع على الوقت/التكلفة','textarea',False),('required_response_date','تاريخ الرد المطلوب','date',True),('proposed_solution','حل مقترح','textarea',False)]}],
 'V.O': [
  {'title':'1. أمر التغيير','fields':[('vo_no','رقم أمر التغيير','text',True),('reason','سبب التغيير','textarea',True),('change_description','وصف التغيير','textarea',True),('instruction_reference','مرجع التعليمات','text',False)]},
  {'title':'2. الأثر التجاري والزمني','fields':[('cost_impact','أثر التكلفة','number',False),('time_impact_days','أثر المدة بالأيام','number',False),('valuation_basis','أساس التسعير','textarea',False)]}],
 'QS': [
  {'title':'1. الحصر والقياس','fields':[('quantity_reference','مرجع الحصر','text',True),('work_description','وصف الأعمال','textarea',True),('unit','الوحدة','text',True),('contract_quantity','كمية العقد','number',False),('measured_quantity','الكمية المقاسة','number',True)]},
  {'title':'2. الاعتماد','fields':[('measurement_method','طريقة القياس','textarea',True),('drawing_reference','مرجع الرسم','text',False),('remarks','ملاحظات','textarea',False)]}],
 'SNA': [
  {'title':'1. الملاحظة','fields':[('snag_no','رقم الملاحظة','text',True),('snag_description','وصف العيب/الملاحظة','textarea',True),('assigned_to','المسؤول عن المعالجة','text',True),('location_detail','الموقع','text',True)]},
  {'title':'2. الإغلاق','fields':[('target_date','تاريخ الإغلاق المستهدف','date',True),('severity','الأولوية','select',True,['منخفضة','متوسطة','عالية','حرجة']),('close_evidence','دليل الإغلاق','textarea',False)]}],
 'DOC': [
  {'title':'1. بيانات الوثيقة','fields':[('subject','عنوان/موضوع الوثيقة','text',True),('document_reference','رقم الوثيقة','text',True),('document_category','التصنيف','text',True),('originator','الجهة الصادرة','text',True)]},
  {'title':'2. المحتوى','fields':[('summary','ملخص المحتوى','textarea',True),('retention_class','تصنيف الحفظ','text',False)]}],
 'POUR': [
  {'title':'1. بيانات الصبة','fields':[('pour_location','موقع الصب','text',True),('element','العنصر الإنشائي','text',True),('concrete_grade','رتبة الخرسانة','text',True),('pour_date','تاريخ الصب','date',True),('volume','الكمية التقديرية م³','number',True)]},
  {'title':'2. جاهزية التخصصات','fields':[('civil','اعتماد المدني','select',True,['جاهز','غير جاهز','ملاحظات']),('architectural','اعتماد المعماري','select',True,['جاهز','غير جاهز','ملاحظات']),('electrical','اعتماد الكهرباء','select',True,['جاهز','غير جاهز','ملاحظات']),('mechanical','اعتماد الميكانيكا','select',True,['جاهز','غير جاهز','ملاحظات'])]},
  {'title':'3. ملاحظات تصريح الصب','fields':[('comments','ملاحظات قبل الصب','textarea',False)]}],
 'INITIAL_HANDOVER': [
  {'title':'1. الاستلام الابتدائي','fields':[('handover_scope','نطاق الأعمال المستلمة','textarea',True),('completion_date','تاريخ اكتمال الأعمال','date',True),('taking_over_date','تاريخ الاستلام الابتدائي','date',True),('defects_liability_end','نهاية فترة الضمان','date',True)]},
  {'title':'2. حالة الملاحظات','fields':[('open_snags','الملاحظات المتبقية','textarea',False),('certificate_reference','مرجع المحضر','text',True)]}],
 'FINAL_HANDOVER': [
  {'title':'1. الاستلام النهائي','fields':[('handover_scope','نطاق الأعمال المستلمة','textarea',True),('initial_handover_reference','مرجع الاستلام الابتدائي','text',True),('final_handover_date','تاريخ الاستلام النهائي','date',True),('defects_closed','تأكيد معالجة جميع الملاحظات','select',True,['نعم','لا'])]},
  {'title':'2. الإقفال','fields':[('final_certificate_reference','مرجع الشهادة النهائية','text',True),('retention_release','إطلاق المحتجزات','textarea',False)]}],
 'LOG': [
  {'title':'1. سجل المتابعة','fields':[('log_type','نوع السجل','select',True,['Document Log','Site Log','RFI Log','Submittal Log','Drawing Log']),('entry_reference','المرجع','text',True),('from_party','من','text',False),('to_party','إلى','text',False),('entry_date','تاريخ الحركة','date',True)]},
  {'title':'2. الحالة والمتابعة','fields':[('action','الإجراء','textarea',True),('owner','المسؤول','text',True),('follow_up_date','تاريخ المتابعة','date',False),('status_note','ملاحظة الحالة','textarea',False)]}],
}

DECISIONS = {'approved','approved_as_noted','revise_and_resubmit','rejected','accepted','closed'}
STATUS_FROM_DECISION = {
    'approved':'approved','approved_as_noted':'approved_with_comments',
    'revise_and_resubmit':'revision_required','rejected':'rejected','accepted':'accepted','closed':'closed'
}

class FormIn(BaseModel):
    project_id:int
    form_type:str
    title:str=Field(min_length=2,max_length=255)
    submission_type:str='new'
    discipline:str|None=None
    zone:str|None=None
    level:str|None=None
    issue_date:date|None=None
    due_date:date|None=None
    contractor_representative:str|None=None
    consultant_representative:str|None=None
    data:dict=Field(default_factory=dict)

class DecisionIn(BaseModel):
    decision:str
    comments:str|None=None
    final:bool=False


def _project(db, company_id, user, project_id):
    p=db.query(Project).filter_by(id=project_id, company_id=company_id).first()
    if not p or not scope_allows(db,user.id,company_id=company_id,branch_id=p.branch_id,project_id=p.id):
        raise HTTPException(404,'Project not found or access denied')
    return p

def _form(db, company_id, form_id):
    row=db.query(ConstructionDocumentForm).filter_by(id=form_id,company_id=company_id).first()
    if not row: raise HTTPException(404,'Construction document form not found')
    return row

def _validate(data:FormIn):
    if data.form_type not in FORM_TYPES: raise HTTPException(422,'Unsupported construction form type')
    if data.submission_type not in {'new','resubmission'}: raise HTTPException(422,'Unsupported submission type')
    required = {k for k in FORM_TYPES[data.form_type]['required']}
    schema_fields={}
    for section in FORM_SCHEMAS.get(data.form_type, []):
        for field in section['fields']:
            schema_fields[field[0]]=field
            if field[3]: required.add(field[0])
    missing=[]
    for key in sorted(required):
        value=data.data.get(key)
        if value is None or (isinstance(value,str) and not value.strip()): missing.append(key)
    if missing: raise HTTPException(422, {'message':'Missing required form fields','fields':missing})
    non_negative={'quantity','unit_rate','contract_quantity','measured_quantity','volume','time_impact_days'}
    for key,field in schema_fields.items():
        if key not in data.data or data.data[key] in (None,''): continue
        value=data.data[key]; kind=field[2]
        if isinstance(value,str) and len(value)>10000: raise HTTPException(422,f'Field {key} exceeds maximum length')
        if kind=='select' and value not in (field[4] or []): raise HTTPException(422,f'Invalid value for field {key}')
        if kind=='number':
            try:
                numeric=float(value)
            except (TypeError,ValueError): raise HTTPException(422,f'Invalid numeric value for field {key}')
            if not __import__('math').isfinite(numeric): raise HTTPException(422,f'Invalid numeric value for field {key}')
            if key in non_negative and numeric < 0: raise HTTPException(422,f'Field {key} cannot be negative')
        if kind=='date':
            try: date.fromisoformat(str(value))
            except ValueError: raise HTTPException(422,f'Invalid date for field {key}')
    if data.form_type=='POUR':
        required_trade={'civil','architectural','electrical','mechanical'}
        if not required_trade.issubset(set(data.data)): raise HTTPException(422,'Pouring permit requires all trade checklist sections')

def _next_no(db,company_id,project_id,form_type):
    n=db.query(func.count(ConstructionDocumentForm.id)).filter_by(company_id=company_id,project_id=project_id,form_type=form_type).scalar() or 0
    return f'{form_type}-{project_id}-{date.today().year}-{n+1:04d}'

def _serialize(row):
    return {'id':row.id,'project_id':row.project_id,'document_id':row.document_id,'form_type':row.form_type,'form_no':row.form_no,'title':row.title,'status':row.status,'submission_type':row.submission_type,'discipline':row.discipline,'zone':row.zone,'level':row.level,'issue_date':row.issue_date.isoformat() if row.issue_date else None,'due_date':row.due_date.isoformat() if row.due_date else None,'data':json.loads(row.data_json or '{}'),'contractor_representative':row.contractor_representative,'consultant_representative':row.consultant_representative,'current_revision':row.current_revision,'document_register_url':f'/docs/documents/{row.document_id}' if row.document_id else None}

@router.get('/types')
def types(user:User=Depends(require_permission('documents:view'))):
    return [{'code':k,**v} for k,v in FORM_TYPES.items()]

@router.post('',status_code=201)
def create_form(payload:FormIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('documents:create'))):
    _validate(payload); p=_project(db,ctx['company_id'],user,payload.project_id)
    effective_issue_date = payload.issue_date or date.today()
    # The human-readable number is protected by a DB unique constraint; retry the complete transaction
    # on a concurrent sequence collision instead of leaking an IntegrityError/500.
    for attempt in range(3):
        try:
            no=_next_no(db,ctx['company_id'],p.id,payload.form_type)
            doc=ProjectDocument(company_id=ctx['company_id'],project_id=p.id,document_no=no,title=payload.title,document_type=payload.form_type,discipline=payload.discipline,status='draft',issue_date=effective_issue_date,due_date=payload.due_date,description=json.dumps(payload.data,ensure_ascii=False),created_by_id=user.id)
            db.add(doc); db.flush()
            row=ConstructionDocumentForm(company_id=ctx['company_id'],project_id=p.id,document_id=doc.id,form_type=payload.form_type,form_no=no,title=payload.title,submission_type=payload.submission_type,discipline=payload.discipline,zone=payload.zone,level=payload.level,issue_date=effective_issue_date,due_date=payload.due_date,data_json=json.dumps(payload.data,ensure_ascii=False),contractor_representative=payload.contractor_representative,consultant_representative=payload.consultant_representative,created_by_id=user.id)
            db.add(row); db.commit(); db.refresh(row)
            return _serialize(row)
        except IntegrityError:
            db.rollback()
            if attempt == 2:
                raise HTTPException(409,'Unable to allocate a unique official document number; please retry')

@router.get('/projects/{project_id}')
def list_forms(project_id:int,form_type:str|None=None,status:str|None=None,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('documents:view'))):
    _project(db,ctx['company_id'],user,project_id)
    q=db.query(ConstructionDocumentForm).filter_by(company_id=ctx['company_id'],project_id=project_id)
    if form_type:q=q.filter_by(form_type=form_type)
    if status:q=q.filter_by(status=status)
    return [_serialize(x) for x in q.order_by(ConstructionDocumentForm.id.desc()).limit(500).all()]

@router.get('/{form_id}')
def get_form(form_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('documents:view'))):
    row=_form(db,ctx['company_id'],form_id); _project(db,ctx['company_id'],user,row.project_id)
    result=_serialize(row)
    decisions=db.query(ConstructionDocumentFormDecision).filter_by(company_id=ctx['company_id'],form_id=row.id).order_by(ConstructionDocumentFormDecision.id).all()
    result['decisions']=[{'id':d.id,'decision':d.decision,'comments':d.comments,'decided_by_id':d.decided_by_id,'decided_at':d.decided_at.isoformat(),'final':d.is_final} for d in decisions]
    attachments=db.query(ConstructionDocumentFormAttachment).filter_by(company_id=ctx['company_id'],form_id=row.id).order_by(ConstructionDocumentFormAttachment.id.desc()).all()
    result['attachments']=[_attachment_payload(a) for a in attachments]
    return result

@router.put('/{form_id}')
def update_form(form_id:int, payload:FormIn, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission('documents:edit'))):
    row=_form(db,ctx['company_id'],form_id); _project(db,ctx['company_id'],user,row.project_id)
    if payload.project_id != row.project_id or payload.form_type != row.form_type: raise HTTPException(409,'Project and form type cannot be changed')
    if row.status not in {'draft','revision_required'}: raise HTTPException(409,'Only draft or revision-required forms can be edited')
    _validate(payload)
    row.title=payload.title; row.submission_type=payload.submission_type; row.issue_date=payload.issue_date or row.issue_date or date.today(); row.discipline=payload.discipline; row.zone=payload.zone; row.level=payload.level; row.due_date=payload.due_date; row.contractor_representative=payload.contractor_representative; row.consultant_representative=payload.consultant_representative; row.data_json=json.dumps(payload.data,ensure_ascii=False)
    if row.document_id:
        doc=db.query(ProjectDocument).filter_by(id=row.document_id,company_id=row.company_id).first()
        if doc: doc.title=payload.title; doc.discipline=payload.discipline; doc.issue_date=row.issue_date; doc.due_date=payload.due_date; doc.description=json.dumps(payload.data,ensure_ascii=False)
    db.commit(); db.refresh(row); return _serialize(row)

@router.post('/{form_id}/submit')
def submit_form(form_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('documents:edit'))):
    row=_form(db,ctx['company_id'],form_id); _project(db,ctx['company_id'],user,row.project_id)
    if row.status not in {'draft','revision_required'}: raise HTTPException(409,'Only draft or revision-required forms can be submitted')
    was_revision = row.status == 'revision_required'
    row.status='submitted'
    if was_revision: row.current_revision += 1
    doc=db.query(ProjectDocument).filter_by(id=row.document_id,company_id=row.company_id).first()
    if doc: doc.status='submitted'
    db.commit(); return {'id':row.id,'status':row.status}

@router.post('/{form_id}/decision')
def decide_form(form_id:int,payload:DecisionIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('documents:approve'))):
    if payload.decision not in DECISIONS: raise HTTPException(422,'Unsupported decision')
    row=_form(db,ctx['company_id'],form_id); _project(db,ctx['company_id'],user,row.project_id)
    if not FORM_TYPES[row.form_type]['decision']: raise HTTPException(422,'This form type does not use an approval decision workflow')
    if row.status not in {'submitted','under_review'}: raise HTTPException(409,'Form must be submitted before decision')
    row.status=STATUS_FROM_DECISION[payload.decision]
    db.add(ConstructionDocumentFormDecision(company_id=row.company_id,form_id=row.id,decision=payload.decision,comments=payload.comments,decided_by_id=user.id,is_final=payload.final or payload.decision in {'rejected','closed','accepted'}) )
    doc=db.query(ProjectDocument).filter_by(id=row.document_id,company_id=row.company_id).first()
    if doc: doc.status={'approved':'approved','approved_with_comments':'approved_with_comments','rejected':'rejected','accepted':'approved','closed':'closed','revision_required':'under_review'}[row.status]
    db.commit(); return {'id':row.id,'status':row.status,'decision':payload.decision}


@router.post('/{form_id}/attachments', status_code=201)
async def upload_attachment(form_id:int, attachment_type:str=Form('supporting_document'), description:str|None=Form(None), file:UploadFile=File(...), ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission('documents:create'))):
    row=_form(db,ctx['company_id'],form_id); _project(db,ctx['company_id'],user,row.project_id)
    safe=_safe_filename(file.filename or 'attachment')
    ext=Path(safe).suffix.lower().lstrip('.')
    if ext not in FORM_ALLOWED_EXT: raise HTTPException(415,'File extension is not allowed')
    max_bytes=int(os.getenv('ERP_DOCUMENT_MAX_BYTES','52428800'))
    blob=await file.read(max_bytes+1)
    if len(blob)>max_bytes: raise HTTPException(413,'File exceeds configured maximum size')
    digest=hashlib.sha256(blob).hexdigest()
    folder=FORM_STORAGE_ROOT / str(ctx['company_id']) / str(row.project_id) / str(row.id)
    folder.mkdir(parents=True,exist_ok=True)
    stored=folder / f'{digest[:16]}_{safe}'
    stored.write_bytes(blob)
    item=ConstructionDocumentFormAttachment(company_id=ctx['company_id'],form_id=row.id,file_name=safe,stored_path=str(stored),mime_type=file.content_type or 'application/octet-stream',file_size=len(blob),sha256=digest,attachment_type=(attachment_type or 'supporting_document')[:50],description=(description or '')[:2000] or None,uploaded_by_id=user.id)
    db.add(item); db.commit(); db.refresh(item)
    return _attachment_payload(item)

@router.get('/{form_id}/attachments')
def list_attachments(form_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('documents:view'))):
    row=_form(db,ctx['company_id'],form_id); _project(db,ctx['company_id'],user,row.project_id)
    rows=db.query(ConstructionDocumentFormAttachment).filter_by(company_id=ctx['company_id'],form_id=row.id).order_by(ConstructionDocumentFormAttachment.id.desc()).all()
    return [_attachment_payload(a) for a in rows]

@router.get('/{form_id}/attachments/{attachment_id}/download')
def download_attachment(form_id:int,attachment_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('documents:view'))):
    row=_form(db,ctx['company_id'],form_id); _project(db,ctx['company_id'],user,row.project_id)
    item=db.query(ConstructionDocumentFormAttachment).filter_by(id=attachment_id,company_id=ctx['company_id'],form_id=row.id).first()
    if not item: raise HTTPException(404,'Attachment not found')
    path=Path(item.stored_path).resolve()
    if not path.is_file() or FORM_STORAGE_ROOT not in path.parents: raise HTTPException(404,'Attachment file is unavailable')
    return FileResponse(path,media_type=item.mime_type,filename=item.file_name)

@router.get('/{form_id}/history')
def form_history(form_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('documents:view'))):
    row=_form(db,ctx['company_id'],form_id); _project(db,ctx['company_id'],user,row.project_id)
    decisions=db.query(ConstructionDocumentFormDecision).filter_by(company_id=ctx['company_id'],form_id=row.id).order_by(ConstructionDocumentFormDecision.decided_at.desc()).all()
    attachments=db.query(ConstructionDocumentFormAttachment).filter_by(company_id=ctx['company_id'],form_id=row.id).order_by(ConstructionDocumentFormAttachment.uploaded_at.desc()).all()
    events=[{'event':'created','at':row.created_at.isoformat(),'status':'draft'}]
    if row.issue_date: events.append({'event':'issued','at':row.issue_date.isoformat(),'status':row.status})
    events += [{'event':'decision','at':d.decided_at.isoformat(),'status':d.decision,'comments':d.comments} for d in decisions]
    events += [{'event':'attachment','at':a.uploaded_at.isoformat(),'status':a.attachment_type,'file_name':a.file_name} for a in attachments]
    return sorted(events,key=lambda x:x['at'],reverse=True)

@router.get('/ui/export/xlsx/{form_id}')
def export_xlsx(form_id:int, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission('documents:view'))):
    row=_form(db,ctx['company_id'],form_id); project=_project(db,ctx['company_id'],user,row.project_id)
    return _excel_response(row,project,FORM_TYPES[row.form_type],FORM_SCHEMAS.get(row.form_type,[]),json.loads(row.data_json or '{}'))

@router.get('/ui/export/pdf/{form_id}')
def export_pdf(form_id:int, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission('documents:view'))):
    row=_form(db,ctx['company_id'],form_id); project=_project(db,ctx['company_id'],user,row.project_id)
    return _pdf_response(row,project,FORM_TYPES[row.form_type],FORM_SCHEMAS.get(row.form_type,[]),json.loads(row.data_json or '{}'))

@router.get('/ui/edit/{form_id}', response_class=HTMLResponse)
def edit_form_ui(form_id:int, request:Request, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission('documents:edit'))):
    row=_form(db,ctx['company_id'],form_id); project=_project(db,ctx['company_id'],user,row.project_id)
    if row.status not in {'draft','revision_required'}: raise HTTPException(409,'Only draft or revision-required forms can be edited')
    return templates.TemplateResponse(request,'construction_document_edit.html',{'request':request,'user':user,'form':row,'project':project,'meta':FORM_TYPES[row.form_type],'schema':FORM_SCHEMAS.get(row.form_type,[]),'data':json.loads(row.data_json or '{}')})

@router.get('/ui/print/{form_id}', response_class=HTMLResponse)
def print_form(form_id:int, request:Request, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission('documents:view'))):
    row=_form(db,ctx['company_id'],form_id); project=_project(db,ctx['company_id'],user,row.project_id)
    return templates.TemplateResponse(request,'construction_document_print.html',{'request':request,'user':user,'form':row,'project':project,'meta':FORM_TYPES[row.form_type],'schema':FORM_SCHEMAS.get(row.form_type,[]),'data':json.loads(row.data_json or '{}'),'attachments':db.query(ConstructionDocumentFormAttachment).filter_by(company_id=ctx['company_id'],form_id=row.id).order_by(ConstructionDocumentFormAttachment.id.desc()).all()})

@router.get('/ui/official/{form_type}', response_class=HTMLResponse)
def official_excel_form_page(form_type:str, request:Request, project_id:int|None=None, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission('documents:view'))):
    if form_type not in FORM_TYPES or form_type not in EXCEL_FORM_LAYOUTS:
        raise HTTPException(404, 'Official Excel form layout not found')
    projects=[p for p in db.query(Project).filter_by(company_id=ctx['company_id']).order_by(Project.id.desc()).limit(500).all() if scope_allows(db,user.id,company_id=ctx['company_id'],branch_id=p.branch_id,project_id=p.id)]
    project=next((p for p in projects if p.id==project_id), projects[0] if projects else None)
    layout=EXCEL_FORM_LAYOUTS[form_type]
    merged={(r1,c1): (r1,c1,r2,c2) for r1,c1,r2,c2 in layout['merged']}
    covered={(r,c) for r1,c1,r2,c2 in layout['merged'] for r in range(r1,r2+1) for c in range(c1,c2+1) if (r,c)!=(r1,c1)}
    values={(r,c):v for r,vals in layout['rows'] for c,v in vals}
    cells=[]
    for r in range(1,layout['max_row']+1):
        for c in range(1,layout['max_col']+1):
            if (r,c) in covered: continue
            if (r,c) in merged:
                r1,c1,r2,c2=merged[(r,c)]
            else:
                r1,c1,r2,c2=r,c,r,c
            value=values.get((r,c),'')
            editable=(not value) and r>=5
            # Populate key control values from the active project without changing the workbook structure.
            if value.startswith('Project Name') and project: value=f"{value}\n{project.name}"
            cells.append({'r1':r1,'c1':c1,'rspan':r2-r1+1,'cspan':c2-c1+1,'row':r,'value':value,'editable':editable})
    return templates.TemplateResponse(request,'construction_document_official_excel.html',{'request':request,'user':user,'project':project,'form_type':form_type,'meta':FORM_TYPES[form_type],'layout':layout,'cells':cells})

@router.get('/ui/workspace',response_class=HTMLResponse)
def workspace(request:Request,project_id:int|None=None,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('documents:view'))):
    projects=[p for p in db.query(Project).filter_by(company_id=ctx['company_id']).order_by(Project.id.desc()).all() if scope_allows(db,user.id,company_id=ctx['company_id'],branch_id=p.branch_id,project_id=p.id)]
    project=next((p for p in projects if p.id==project_id),projects[0] if projects else None)
    rows=[] if not project else db.query(ConstructionDocumentForm).filter_by(company_id=ctx['company_id'],project_id=project.id).order_by(ConstructionDocumentForm.id.desc()).limit(50).all()
    return templates.TemplateResponse(request,'construction_document_forms.html',{'request':request,'user':user,'projects':projects,'project':project,'forms':rows,'types':FORM_TYPES,'schemas':FORM_SCHEMAS})
