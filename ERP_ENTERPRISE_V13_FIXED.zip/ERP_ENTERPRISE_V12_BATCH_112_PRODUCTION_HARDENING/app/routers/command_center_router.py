from decimal import Decimal
from datetime import date
from fastapi import APIRouter, Depends, Request, HTTPException, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import func
from sqlalchemy.orm import Session

from ..database import get_db
from ..auth import User
from ..governance import get_tenant_context, require_permission, scope_allows
from ..enterprise_models import Project, ProjectCost, ProgressCertificate, ProjectForecast, Contract
from ..construction_models import ConstructionVariation, ConstructionEVMSnapshot, SubcontractorProgress, BOQLine
from ..document_models import ProjectDocument
from ..construction_document_forms_models import ConstructionDocumentForm

router = APIRouter(prefix="/projects", tags=["command-center"])
templates = Jinja2Templates(directory="templates")


def _money(value):
    return Decimal(value or 0)


def _project_or_404(db, company_id, user_id, project_id, write=False):
    p = db.query(Project).filter(Project.company_id == company_id, Project.id == project_id).first()
    if not p:
        raise HTTPException(404, "Project not found")
    if not scope_allows(db, user_id, company_id=company_id, branch_id=p.branch_id, project_id=p.id, write=write):
        raise HTTPException(403, "Project access denied")
    return p


def _visible_projects(db, company_id, user_id, branch_id=None):
    q = db.query(Project).filter(Project.company_id == company_id)
    if branch_id is not None:
        q = q.filter((Project.branch_id == branch_id) | (Project.branch_id.is_(None)))
    projects = q.order_by(Project.id.desc()).all()
    return [p for p in projects if scope_allows(db, user_id, company_id=company_id, branch_id=p.branch_id, project_id=p.id)]


@router.get("/new", response_class=HTMLResponse)
def new_project_page(request: Request, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:manage"))):
    from ..enterprise_models import Branch
    from ..models import Customer
    branches_q = db.query(Branch).filter(Branch.company_id == ctx["company_id"], Branch.is_active.is_(True)).order_by(Branch.name)
    if ctx["branch_id"] is not None:
        branches_q = branches_q.filter(Branch.id == ctx["branch_id"])
    customers = db.query(Customer).filter(Customer.company_id == ctx["company_id"], Customer.is_active.is_(True)).order_by(Customer.name).all()
    return templates.TemplateResponse(request, "project_new.html", {
        "user": user, "branches": branches_q.all(), "customers": customers,
        "current_branch_id": ctx["branch_id"]
    })


@router.post("/new")
def create_project_page(code: str = Form(...), name: str = Form(...), budget: Decimal = Form(Decimal("0")),
                        branch_id: int | None = Form(None), customer_id: int | None = Form(None),
                        db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:manage"))):
    from ..enterprise_models import Branch
    from ..models import Customer
    company_id = ctx["company_id"]
    code, name = code.strip(), name.strip()
    if not code or not name: raise HTTPException(422, "كود واسم المشروع مطلوبان")
    if budget < 0: raise HTTPException(422, "ميزانية المشروع لا يمكن أن تكون سالبة")
    if ctx["branch_id"] is not None:
        branch_id = ctx["branch_id"]
    if branch_id is not None:
        branch = db.query(Branch).filter(Branch.id == branch_id, Branch.company_id == company_id, Branch.is_active.is_(True)).first()
        if not branch: raise HTTPException(422, "الفرع غير صالح ضمن الشركة الحالية")
    if customer_id is not None:
        customer = db.query(Customer).filter(Customer.id == customer_id, Customer.company_id == company_id, Customer.is_active.is_(True)).first()
        if not customer: raise HTTPException(422, "العميل غير صالح ضمن الشركة الحالية")
    if db.query(Project).filter(Project.company_id == company_id, Project.code == code).first():
        raise HTTPException(409, "كود المشروع مستخدم بالفعل ضمن الشركة الحالية")
    project = Project(company_id=company_id, branch_id=branch_id, customer_id=customer_id, code=code, name=name, budget=budget, status="draft")
    db.add(project); db.commit()
    return RedirectResponse(f"/projects/command-center?project_id={project.id}", status_code=303)


@router.get("/command-center", response_class=HTMLResponse)
def command_center(request: Request, project_id: int | None = None, db: Session = Depends(get_db),
                   ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:view"))):
    company_id, branch_id = ctx["company_id"], ctx["branch_id"]
    projects = _visible_projects(db, company_id, user.id, branch_id)
    selected = next((p for p in projects if p.id == project_id), None) if project_id else None
    if selected is None and projects:
        selected = projects[0]
    if selected is None:
        return templates.TemplateResponse(request, "construction_command_center.html", {
            "user": user, "projects": [], "project": None, "metrics": {}, "rows": [],
            "approvals": [], "documents": [], "customer_certs": [], "sub_certs": [],
            "customer_contracts": [], "sub_contracts": [], "boq_lines": []
        })
    if not scope_allows(db, user.id, company_id=company_id, branch_id=selected.branch_id, project_id=selected.id):
        raise HTTPException(403, "Project access denied")

    cost = _money(db.query(func.coalesce(func.sum(ProjectCost.amount), 0)).filter(ProjectCost.company_id == company_id, ProjectCost.project_id == selected.id).scalar())
    cert_gross = _money(db.query(func.coalesce(func.sum(ProgressCertificate.gross_amount), 0)).filter(ProgressCertificate.company_id == company_id, ProgressCertificate.project_id == selected.id, ProgressCertificate.status.in_(["approved", "posted"])).scalar())
    cert_pending = db.query(func.count(ProgressCertificate.id)).filter(ProgressCertificate.company_id == company_id, ProgressCertificate.project_id == selected.id, ProgressCertificate.status.in_(["draft", "submitted", "under_review"])).scalar() or 0
    sub_gross = _money(db.query(func.coalesce(func.sum(SubcontractorProgress.gross_amount), 0)).filter(SubcontractorProgress.company_id == company_id, SubcontractorProgress.project_id == selected.id, SubcontractorProgress.status.in_(["approved", "posted"])).scalar())
    sub_pending = db.query(func.count(SubcontractorProgress.id)).filter(SubcontractorProgress.company_id == company_id, SubcontractorProgress.project_id == selected.id, SubcontractorProgress.status.in_(["draft", "submitted", "under_review"])).scalar() or 0
    variations_open = db.query(func.count(ConstructionVariation.id)).filter(ConstructionVariation.company_id == company_id, ConstructionVariation.project_id == selected.id, ConstructionVariation.status.notin_(["approved", "rejected", "closed"])).scalar() or 0
    docs_open = db.query(func.count(ProjectDocument.id)).filter(ProjectDocument.company_id == company_id, ProjectDocument.project_id == selected.id, ProjectDocument.status.in_(["draft", "submitted", "under_review"])).scalar() or 0
    forecast = db.query(ProjectForecast).filter(ProjectForecast.company_id == company_id, ProjectForecast.project_id == selected.id).order_by(ProjectForecast.as_of_date.desc()).first()
    evm = db.query(ConstructionEVMSnapshot).filter(ConstructionEVMSnapshot.company_id == company_id, ConstructionEVMSnapshot.project_id == selected.id).order_by(ConstructionEVMSnapshot.status_date.desc()).first()
    budget = _money(selected.budget)
    forecast_cost = _money(forecast.forecast_final_cost if forecast else 0)
    variance = budget - cost
    percent_cost = (cost / budget * 100) if budget else Decimal(0)

    rows = []
    for p in projects[:12]:
        p_cost = _money(db.query(func.coalesce(func.sum(ProjectCost.amount), 0)).filter(ProjectCost.company_id == company_id, ProjectCost.project_id == p.id).scalar())
        pct = (p_cost / _money(p.budget) * 100) if p.budget else Decimal(0)
        rows.append({"project": p, "cost": p_cost, "pct": min(pct, Decimal(100))})
    recent_docs = db.query(ProjectDocument).filter(ProjectDocument.company_id == company_id, ProjectDocument.project_id == selected.id).order_by(ProjectDocument.id.desc()).limit(8).all()
    customer_certs = db.query(ProgressCertificate).filter(ProgressCertificate.company_id == company_id, ProgressCertificate.project_id == selected.id).order_by(ProgressCertificate.id.desc()).limit(20).all()
    sub_certs = db.query(SubcontractorProgress).filter(SubcontractorProgress.company_id == company_id, SubcontractorProgress.project_id == selected.id).order_by(SubcontractorProgress.id.desc()).limit(20).all()
    customer_contracts = db.query(Contract).filter(Contract.company_id == company_id, Contract.project_id == selected.id, Contract.contract_type == "customer").order_by(Contract.id.desc()).all()
    sub_contracts = db.query(Contract).filter(Contract.company_id == company_id, Contract.project_id == selected.id, Contract.contract_type == "subcontractor").order_by(Contract.id.desc()).all()
    boq_lines = db.query(BOQLine).filter(BOQLine.company_id == company_id, BOQLine.project_id == selected.id).order_by(BOQLine.id).limit(100).all()

    return templates.TemplateResponse(request, "construction_command_center.html", {
        "user": user, "projects": projects, "project": selected,
        "metrics": {"budget": budget, "actual": cost, "variance": variance, "percent_cost": percent_cost,
                     "forecast_cost": forecast_cost, "cert_gross": cert_gross, "cert_pending": cert_pending,
                     "sub_gross": sub_gross, "sub_pending": sub_pending, "variations_open": variations_open,
                     "docs_open": docs_open, "cpi": getattr(evm, "cpi", None) if evm else None,
                     "spi": getattr(evm, "spi", None) if evm else None, "eac": getattr(evm, "eac", None) if evm else forecast_cost,
                     "vac": getattr(evm, "vac", None) if evm else (budget - forecast_cost if budget else Decimal(0))},
        "rows": rows, "approvals": [], "documents": recent_docs, "customer_certs": customer_certs,
        "sub_certs": sub_certs, "customer_contracts": customer_contracts, "sub_contracts": sub_contracts,
        "boq_lines": boq_lines
    })


@router.get("/command-center/certificates", response_class=HTMLResponse)
def project_certificates(request: Request, project_id: int, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:view"))):
    p = _project_or_404(db, ctx["company_id"], user.id, project_id)
    customer = db.query(ProgressCertificate).filter_by(company_id=ctx["company_id"], project_id=p.id).order_by(ProgressCertificate.id.desc()).all()
    subcontractor = db.query(SubcontractorProgress).filter_by(company_id=ctx["company_id"], project_id=p.id).order_by(SubcontractorProgress.id.desc()).all()
    customer_contracts = db.query(Contract).filter_by(company_id=ctx["company_id"], project_id=p.id, contract_type="customer").order_by(Contract.id.desc()).all()
    sub_contracts = db.query(Contract).filter_by(company_id=ctx["company_id"], project_id=p.id, contract_type="subcontractor").order_by(Contract.id.desc()).all()
    boq_lines = db.query(BOQLine).filter_by(company_id=ctx["company_id"], project_id=p.id).order_by(BOQLine.id).limit(200).all()
    return templates.TemplateResponse(request, "project_certificates.html", {"user": user, "project": p, "customer_certs": customer, "sub_certs": subcontractor, "customer_contracts": customer_contracts, "sub_contracts": sub_contracts, "boq_lines": boq_lines})


@router.get("/command-center/documents", response_class=HTMLResponse)
def project_documents(request: Request, project_id: int, document_type: str | None = None,
                      status: str | None = None, q: str | None = None,
                      due: str | None = None, db: Session = Depends(get_db),
                      ctx=Depends(get_tenant_context), user: User = Depends(require_permission("documents:view"))):
    """Enterprise project document register with scoped filtering and operational KPIs."""
    p = _project_or_404(db, ctx["company_id"], user.id, project_id)
    base = db.query(ProjectDocument).filter_by(company_id=ctx["company_id"], project_id=p.id)
    if document_type:
        base = base.filter(ProjectDocument.document_type == document_type)
    if status:
        base = base.filter(ProjectDocument.status == status)
    if q:
        term = f"%{q.strip()}%"
        base = base.filter((ProjectDocument.document_no.ilike(term)) | (ProjectDocument.title.ilike(term)) | (ProjectDocument.external_reference.ilike(term)))
    if due == "overdue":
        base = base.filter(ProjectDocument.due_date.is_not(None), ProjectDocument.due_date < date.today(), ProjectDocument.status.notin_(["approved", "closed", "superseded"]))
    elif due == "upcoming":
        base = base.filter(ProjectDocument.due_date.is_not(None), ProjectDocument.due_date >= date.today())

    rows = base.order_by(ProjectDocument.updated_at.desc(), ProjectDocument.document_no).all()
    all_docs = db.query(ProjectDocument).filter_by(company_id=ctx["company_id"], project_id=p.id)
    total = all_docs.count()
    overdue = all_docs.filter(ProjectDocument.due_date.is_not(None), ProjectDocument.due_date < date.today(), ProjectDocument.status.notin_(["approved", "closed", "superseded"])).count()
    pending = all_docs.filter(ProjectDocument.status.in_(["draft", "submitted", "under_review", "pending_approval", "rejected"])).count()
    approved = all_docs.filter(ProjectDocument.status.in_(["approved", "closed"])).count()
    type_rows = db.query(ProjectDocument.document_type, func.count(ProjectDocument.id)).filter_by(company_id=ctx["company_id"], project_id=p.id).group_by(ProjectDocument.document_type).all()
    status_rows = db.query(ProjectDocument.status, func.count(ProjectDocument.id)).filter_by(company_id=ctx["company_id"], project_id=p.id).group_by(ProjectDocument.status).all()
    official_forms = db.query(ConstructionDocumentForm).filter_by(company_id=ctx["company_id"], project_id=p.id).all()
    form_by_document = {f.document_id:f for f in official_forms if f.document_id}
    official_metrics = {"total":len(official_forms),"draft":sum(1 for f in official_forms if f.status=="draft"),"submitted":sum(1 for f in official_forms if f.status in {"submitted","under_review","revision_required"}),"closed":sum(1 for f in official_forms if f.status in {"approved","approved_with_comments","accepted","closed"})}
    return templates.TemplateResponse(request, "project_documents.html", {
        "user": user, "project": p, "documents": rows,
        "filters": {"document_type": document_type or "", "status": status or "", "q": q or "", "due": due or ""},
        "metrics": {"total": total, "overdue": overdue, "pending": pending, "approved": approved},
        "type_rows": type_rows, "status_rows": status_rows, "today": date.today(),
        "form_by_document": form_by_document, "official_metrics": official_metrics,
    })
