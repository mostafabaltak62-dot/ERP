# -*- coding: utf-8 -*-
import datetime
from fastapi import APIRouter, Depends, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import func, or_
import csv
import io

from ..database import get_db
from ..models import (Customer, SaleInvoice, SaleInvoiceLine, Item, ItemTypeEnum,
                       StockMovement, MovementTypeEnum, User, ModulePermission, SequenceCounter)
from ..accounting import next_number, create_entry, D, money
from ..auth import require_module
from ..governance import get_request_context
from ..commercial_completion_models import CustomerCreditPolicy
from .inventory_router import compute_stock
from ..inventory_valuation import issue as issue_inventory

router = APIRouter(prefix="/sales")
templates = Jinja2Templates(directory="templates")


def _has_edit(db: Session, user: User, module_key: str) -> bool:
    if user.role.value == "admin":
        return True
    perm = db.query(ModulePermission).filter_by(user_id=user.id, module_key=module_key).first()
    return bool(perm and perm.can_edit)


def _next_invoice_number(db: Session) -> str:
    return next_number(db, "sales_invoice", "INV")


def _safe_csv(value):
    """Neutralize spreadsheet formulas while preserving exported business data."""
    text = "" if value is None else str(value)
    return "'" + text if text.lstrip().startswith(("=", "+", "-", "@")) else text


def _parse_iso_date(value: str | None, label: str):
    if not value:
        return None
    try:
        return datetime.date.fromisoformat(value)
    except ValueError:
        raise HTTPException(status_code=422, detail=f"{label} غير صحيح")


def _company_id_or_403():
    cid = get_request_context().get("company_id")
    if cid is None:
        raise HTTPException(status_code=403, detail="لم يتم تحديد الشركة الحالية")
    return int(cid)


# ---------------------------------------------------------------- عملاء
@router.get("/customers", response_class=HTMLResponse)
def customer_list(request: Request, q: str = "", db: Session = Depends(get_db),
                   user: User = Depends(require_module("sales"))):
    company_id = _company_id_or_403()
    query = db.query(Customer).filter(Customer.company_id == company_id)
    if q:
        like = f"%{q}%"
        query = query.filter((Customer.code.ilike(like)) | (Customer.name.ilike(like)))
    customers = query.order_by(Customer.name.asc(), Customer.id.desc()).all()
    can_edit = _has_edit(db, user, "sales")
    active_count = db.query(func.count(Customer.id)).filter(Customer.company_id == company_id, Customer.is_active.is_(True)).scalar() or 0
    inactive_count = db.query(func.count(Customer.id)).filter(Customer.company_id == company_id, Customer.is_active.is_(False)).scalar() or 0
    total_sales = db.query(func.coalesce(func.sum(SaleInvoice.total_amount), 0)).filter(
        SaleInvoice.company_id == company_id, SaleInvoice.status == "posted"
    ).scalar() or 0
    recent = db.query(Customer).filter(Customer.company_id == company_id).order_by(Customer.created_at.desc(), Customer.id.desc()).limit(5).all()
    invoice_counts = dict(db.query(SaleInvoice.customer_id, func.count(SaleInvoice.id)).filter(
        SaleInvoice.company_id == company_id, SaleInvoice.status == "posted"
    ).group_by(SaleInvoice.customer_id).all())
    sales_by_customer = dict(db.query(SaleInvoice.customer_id, func.coalesce(func.sum(SaleInvoice.total_amount), 0)).filter(
        SaleInvoice.company_id == company_id, SaleInvoice.status == "posted"
    ).group_by(SaleInvoice.customer_id).all())
    return templates.TemplateResponse(request, "customer_list.html", {
        "user": user, "customers": customers, "q": q, "can_edit": can_edit,
        "active_count": active_count, "inactive_count": inactive_count,
        "total_sales": total_sales, "recent": recent,
        "invoice_counts": invoice_counts, "sales_by_customer": sales_by_customer
    })


def _next_customer_code(db: Session) -> str:
    """Generate a human-friendly suggestion without assuming sequential IDs."""
    codes = [r[0] for r in db.query(Customer.code).filter(Customer.code.ilike("CUS-%")).all() if r[0]]
    highest = 0
    for value in codes:
        tail = value.upper().replace("CUS-", "", 1)
        if tail.isdigit():
            highest = max(highest, int(tail))
    return f"CUS-{highest + 1:03d}"


@router.get("/customers/new", response_class=HTMLResponse)
def new_customer_form(request: Request, db: Session = Depends(get_db), user: User = Depends(require_module("sales", need_edit=True))):
    return templates.TemplateResponse(request, "customer_form.html", {
        "user": user, "suggested_code": _next_customer_code(db), "edit_mode": False
    })


@router.post("/customers/new")
def create_customer(db: Session = Depends(get_db), user: User = Depends(require_module("sales", need_edit=True)),
                     code: str = Form(...), name: str = Form(...), phone: str = Form(""),
                     email: str = Form(""), address: str = Form("")):
    company_id = get_request_context().get("company_id")
    code, name = (code or "").strip().upper(), (name or "").strip()
    phone, email, address = (phone or "").strip(), (email or "").strip().lower(), (address or "").strip()
    if not code or len(code) > 30:
        raise HTTPException(status_code=400, detail="كود العميل مطلوب ويجب ألا يزيد عن 30 حرفًا")
    if not name or len(name) > 150:
        raise HTTPException(status_code=400, detail="اسم العميل مطلوب ويجب ألا يزيد عن 150 حرفًا")
    if email and ("@" not in email or email.startswith("@") or email.endswith("@")):
        raise HTTPException(status_code=400, detail="البريد الإلكتروني غير صحيح")
    # The database schema currently enforces global code uniqueness, so validate globally
    # before commit to avoid leaking a database IntegrityError to the user.
    if db.query(Customer).filter(func.lower(Customer.code) == code.lower()).first():
        raise HTTPException(status_code=400, detail="كود العميل مستخدم بالفعل")
    c = Customer(company_id=company_id, code=code, name=name,
                 phone=phone or None, email=email or None, address=address or None,
                 is_active=True)
    db.add(c)
    db.commit()
    db.refresh(c)
    return RedirectResponse(url=f"/sales/customers/{c.id}", status_code=303)


@router.get("/customers/{customer_id}", response_class=HTMLResponse)
def customer_profile(customer_id: int, request: Request, db: Session = Depends(get_db),
                     user: User = Depends(require_module("sales"))):
    company_id = get_request_context().get("company_id")
    customer = db.query(Customer).filter(Customer.id == customer_id, Customer.company_id == company_id).first()
    if not customer:
        raise HTTPException(status_code=404, detail="العميل غير موجود")
    invoices = db.query(SaleInvoice).filter(SaleInvoice.company_id == company_id, SaleInvoice.customer_id == customer.id).order_by(SaleInvoice.invoice_date.desc(), SaleInvoice.id.desc()).limit(20).all()
    invoice_count = db.query(func.count(SaleInvoice.id)).filter(SaleInvoice.company_id == company_id, SaleInvoice.customer_id == customer.id).scalar() or 0
    total_sales = db.query(func.coalesce(func.sum(SaleInvoice.total_amount), 0)).filter(
        SaleInvoice.company_id == company_id, SaleInvoice.customer_id == customer.id,
        SaleInvoice.status == "posted"
    ).scalar() or 0
    can_edit = _has_edit(db, user, "sales")
    return templates.TemplateResponse(request, "customer_profile.html", {"user": user, "customer": customer, "invoices": invoices, "invoice_count": invoice_count, "total_sales": total_sales, "can_edit": can_edit})


@router.get("/customers/{customer_id}/edit", response_class=HTMLResponse)
def edit_customer_form(customer_id: int, request: Request, db: Session = Depends(get_db), user: User = Depends(require_module("sales", need_edit=True))):
    customer = db.query(Customer).filter(Customer.id == customer_id, Customer.company_id == get_request_context().get("company_id")).first()
    if not customer: raise HTTPException(404, "العميل غير موجود")
    return templates.TemplateResponse(request, "customer_form.html", {"user": user, "customer": customer, "edit_mode": True})


@router.post("/customers/{customer_id}/edit")
def update_customer(customer_id: int, code: str = Form(...), name: str = Form(...), phone: str = Form(""), email: str = Form(""), address: str = Form(""), is_active: str = Form("on"), db: Session = Depends(get_db), user: User = Depends(require_module("sales", need_edit=True))):
    company_id = get_request_context().get("company_id")
    customer = db.query(Customer).filter(Customer.id == customer_id, Customer.company_id == company_id).first()
    if not customer: raise HTTPException(404, "العميل غير موجود")
    duplicate = db.query(Customer).filter(Customer.company_id == company_id, Customer.code == code.strip(), Customer.id != customer_id).first()
    if duplicate: raise HTTPException(400, "كود العميل مستخدم بالفعل")
    customer.code, customer.name = code.strip(), name.strip()
    customer.phone, customer.email, customer.address = phone.strip() or None, email.strip() or None, address.strip() or None
    customer.is_active = is_active == "on"
    db.commit()
    return RedirectResponse(f"/sales/customers/{customer.id}", 303)


@router.post("/customers/{customer_id}/toggle-status")
def toggle_customer_status(customer_id: int, db: Session = Depends(get_db), user: User = Depends(require_module("sales", need_edit=True))):
    customer = db.query(Customer).filter(Customer.id == customer_id, Customer.company_id == get_request_context().get("company_id")).first()
    if not customer: raise HTTPException(404, "العميل غير موجود")
    customer.is_active = not bool(customer.is_active)
    db.commit()
    return RedirectResponse("/sales/customers", 303)


# ---------------------------------------------------------------- فواتير
@router.get("", response_class=HTMLResponse)
def invoice_list(request: Request, q: str = "", status: str = "all", date_from: str = "", date_to: str = "", page: int = 1, db: Session = Depends(get_db),
                 user: User = Depends(require_module("sales"))):
    company_id = _company_id_or_403()
    allowed_statuses = {"all", "draft", "posted", "cancelled"}
    status = status if status in allowed_statuses else "all"
    date_from_v = _parse_iso_date(date_from, "تاريخ البداية")
    date_to_v = _parse_iso_date(date_to, "تاريخ النهاية")
    if date_from_v and date_to_v and date_from_v > date_to_v:
        raise HTTPException(status_code=422, detail="تاريخ البداية يجب أن يسبق تاريخ النهاية")

    query = db.query(SaleInvoice).filter(SaleInvoice.company_id == company_id)
    if q.strip():
        like = f"%{q.strip()}%"
        query = query.join(Customer).filter((SaleInvoice.invoice_number.ilike(like)) | (Customer.name.ilike(like)))
    if status != "all":
        query = query.filter(SaleInvoice.status == status)
    if date_from_v:
        query = query.filter(SaleInvoice.invoice_date >= datetime.datetime.combine(date_from_v, datetime.time.min))
    if date_to_v:
        query = query.filter(SaleInvoice.invoice_date < datetime.datetime.combine(date_to_v + datetime.timedelta(days=1), datetime.time.min))

    total_rows = query.count()
    page_size = 50
    page = max(1, page)
    invoices = query.order_by(SaleInvoice.invoice_date.desc(), SaleInvoice.id.desc()).offset((page - 1) * page_size).limit(page_size).all()
    customer_count = db.query(func.count(Customer.id)).filter(Customer.company_id == company_id, Customer.is_active.is_(True)).scalar() or 0
    posted_total = query.filter(SaleInvoice.status == "posted").with_entities(func.coalesce(func.sum(SaleInvoice.total_amount), 0)).scalar() or 0
    posted_count = query.filter(SaleInvoice.status == "posted").count()
    can_edit = _has_edit(db, user, "sales")
    return templates.TemplateResponse(request, "sales_list.html", {
        "user": user, "invoices": invoices, "q": q, "can_edit": can_edit,
        "customer_count": customer_count, "total_value": posted_total, "posted_count": posted_count,
        "status": status, "date_from": date_from, "date_to": date_to,
        "page": page, "page_size": page_size, "total_rows": total_rows
    })


@router.get("/export/csv")
def export_sales_invoices(q: str = "", status: str = "all", db: Session = Depends(get_db), user: User = Depends(require_module("sales"))):
    company_id = _company_id_or_403()
    query = db.query(SaleInvoice).filter(SaleInvoice.company_id == company_id)
    if q.strip():
        like = f"%{q.strip()}%"
        query = query.join(Customer).filter((SaleInvoice.invoice_number.ilike(like)) | (Customer.name.ilike(like)))
    if status in {"draft", "posted", "cancelled"}:
        query = query.filter(SaleInvoice.status == status)
    rows = query.order_by(SaleInvoice.invoice_date.desc(), SaleInvoice.id.desc()).all()
    out = io.StringIO(); w = csv.writer(out)
    w.writerow(["رقم الفاتورة", "العميل", "التاريخ", "طريقة الدفع", "الحالة", "الإجمالي"])
    for inv in rows:
        w.writerow([_safe_csv(inv.invoice_number), _safe_csv(inv.customer.name if inv.customer else ""), inv.invoice_date.isoformat() if inv.invoice_date else "", _safe_csv(inv.payment_method or ""), _safe_csv(inv.status), inv.total])
    return Response("\ufeff" + out.getvalue(), media_type="text/csv; charset=utf-8", headers={"Content-Disposition":"attachment; filename=sales_invoices.csv", "X-Content-Type-Options": "nosniff"})


@router.get("/new", response_class=HTMLResponse)
def new_invoice_form(request: Request, db: Session = Depends(get_db),
                      user: User = Depends(require_module("sales", need_edit=True))):
    customers = db.query(Customer).filter(Customer.company_id==get_request_context().get("company_id"), Customer.is_active == True).order_by(Customer.name).all()
    items = db.query(Item).filter(Item.company_id==get_request_context().get("company_id"), Item.is_active == True).order_by(Item.name).all()
    items_data = [{
        "id": it.id, "code": it.code, "name": it.name, "price": it.sale_price,
        "is_product": it.item_type == ItemTypeEnum.product,
        "stock": compute_stock(db, it.id, _company_id_or_403()) if it.item_type == ItemTypeEnum.product else None
    } for it in items]
    return templates.TemplateResponse(request, "invoice_form.html", {
        "user": user, "customers": customers, "items_data": items_data
    })


@router.post("/new")
async def create_invoice(request: Request, db: Session = Depends(get_db),
                         user: User = Depends(require_module("sales", need_edit=True))):
    """Create and post a sales invoice atomically.

    Client totals are treated as display-only: quantities, prices, discount and tax
    are recalculated and validated on the server before inventory and accounting are posted.
    """
    form = await request.form()
    customer_id = form.get("customer_id")
    payment_method = (form.get("payment_method") or "نقدي").strip()
    notes = (form.get("notes") or "").strip()
    item_ids = form.getlist("item_id[]")
    quantities = form.getlist("quantity[]")
    prices = form.getlist("unit_price[]")

    if not (len(item_ids) == len(quantities) == len(prices)):
        raise HTTPException(status_code=422, detail="بيانات بنود الفاتورة غير مكتملة أو غير متطابقة")
    if len(item_ids) > 500:
        raise HTTPException(status_code=422, detail="عدد بنود الفاتورة يتجاوز الحد المسموح (500)")
    allowed_payment_methods = {"نقدي", "بنكي", "تحويل بنكي", "آجل", "على الحساب"}
    if payment_method not in allowed_payment_methods:
        raise HTTPException(status_code=422, detail="طريقة الدفع غير مدعومة")

    def percent(value, label):
        try:
            result = D(value or 0)
        except Exception:
            raise HTTPException(status_code=422, detail=f"قيمة {label} غير صحيحة")
        if not result.is_finite() or result < 0 or result > 100:
            raise HTTPException(status_code=422, detail=f"{label} يجب أن تكون بين 0 و100")
        return result

    discount_percent = percent(form.get("discount_percent"), "الخصم")
    tax_percent = percent(form.get("tax_percent"), "الضريبة")

    if not customer_id:
        raise HTTPException(status_code=400, detail="لازم تختار عميل")

    company_id = _company_id_or_403()
    try:
        customer_id_int = int(customer_id)
    except (TypeError, ValueError):
        raise HTTPException(status_code=422, detail="معرف العميل غير صحيح")
    customer = db.query(Customer).filter(
        Customer.id == customer_id_int, Customer.company_id == company_id,
        Customer.is_active.is_(True)
    ).first()
    if not customer:
        raise HTTPException(status_code=422, detail="العميل غير صالح للشركة الحالية")

    # Aggregate duplicate item rows so stock is checked against the total requested quantity.
    aggregated = {}
    for iid, qty, price in zip(item_ids, quantities, prices):
        if not iid and not qty and not price:
            continue
        try:
            item_id = int(iid)
            qty_d = D(qty or 0)
            price_d = D(price or 0)
        except Exception:
            raise HTTPException(status_code=422, detail="أحد بنود الفاتورة يحتوي على قيمة غير صحيحة")
        if not qty_d.is_finite() or qty_d <= 0:
            raise HTTPException(status_code=422, detail="كمية كل بند يجب أن تكون أكبر من صفر")
        if not price_d.is_finite() or price_d < 0:
            raise HTTPException(status_code=422, detail="سعر الوحدة غير صالح")
        if item_id in aggregated:
            old_qty, old_price = aggregated[item_id]
            if old_price != price_d:
                # Keep duplicate lines deterministic by rejecting conflicting prices.
                raise HTTPException(status_code=422, detail="لا تكرر نفس الصنف بأسعار مختلفة في نفس الفاتورة")
            aggregated[item_id] = (old_qty + qty_d, price_d)
        else:
            aggregated[item_id] = (qty_d, price_d)

    if not aggregated:
        raise HTTPException(status_code=400, detail="لازم تضيف صنف واحد على الأقل")

    item_map = {
        item.id: item for item in db.query(Item).filter(
            Item.company_id == company_id,
            Item.id.in_(list(aggregated.keys())),
            Item.is_active.is_(True)
        ).all()
    }
    if set(item_map) != set(aggregated):
        raise HTTPException(status_code=422, detail="يوجد صنف غير صالح أو غير نشط للشركة الحالية")

    # Validate inventory before any posting.
    for item_id, (qty, _) in aggregated.items():
        item = item_map[item_id]
        if item.item_type == ItemTypeEnum.product:
            current_stock = D(compute_stock(db, item_id, company_id) or 0)
            if current_stock < qty:
                raise HTTPException(status_code=400, detail=f"المخزون غير كافٍ للصنف {item.name}. المتاح: {current_stock:g}")

    subtotal = money(sum((qty * price for qty, price in aggregated.values()), D(0)))
    discount_amount = money(subtotal * discount_percent / D(100))
    taxable = money(subtotal - discount_amount)
    tax_amount = money(taxable * tax_percent / D(100))
    total = money(taxable + tax_amount)

    # Credit policy check before creating accounting/inventory movements.
    policy = db.query(CustomerCreditPolicy).filter(
        CustomerCreditPolicy.company_id == company_id,
        CustomerCreditPolicy.customer_id == customer_id_int,
        CustomerCreditPolicy.is_active.is_(True)
    ).first()
    if payment_method in {"آجل", "على الحساب"} and policy and D(policy.credit_limit) > 0 and policy.block_on_overlimit:
        from ..transaction_services import _allocated
        outstanding = D(0)
        for existing in db.query(SaleInvoice).filter(
            SaleInvoice.company_id == company_id,
            SaleInvoice.customer_id == customer_id_int,
            SaleInvoice.status != "cancelled"
        ).all():
            outstanding += max(D(0), D(existing.total_amount or 0) - D(_allocated(db, "sale", existing.id, company_id)))
        if outstanding + total > D(policy.credit_limit):
            raise HTTPException(status_code=409, detail=f"تجاوز الحد الائتماني. المتاح: {money(D(policy.credit_limit)-outstanding)}")

    try:
        invoice = SaleInvoice(
            company_id=company_id,
            branch_id=get_request_context().get("branch_id"),
            invoice_number=_next_invoice_number(db),
            customer_id=customer_id_int,
            payment_method=payment_method,
            notes=notes or None,
            subtotal=subtotal,
            discount_amount=discount_amount,
            tax_amount=tax_amount,
            total_amount=total,
            status="posted",
            created_by_id=user.id,
        )
        db.add(invoice)
        db.flush()

        cogs = D(0)
        for item_id, (qty, price) in aggregated.items():
            item = item_map[item_id]
            db.add(SaleInvoiceLine(
                company_id=company_id, invoice_id=invoice.id, item_id=item_id,
                quantity=qty, unit_price=money(price), line_total=money(qty * price)
            ))
            if item.item_type == ItemTypeEnum.product:
                # Do not use Item.purchase_price for COGS. The enterprise valuation
                # engine is authoritative and may use FIFO or weighted-average cost.
                actual_cost, _consumptions = issue_inventory(
                    db, company_id, item_id, qty,
                    source_type="sale_invoice", source_id=invoice.id,
                    issued_at=invoice.invoice_date,
                )
                cogs += money(actual_cost)
                unit_cost = money(actual_cost / qty) if qty else D(0)
                db.add(StockMovement(
                    company_id=company_id, item_id=item_id,
                    movement_type=MovementTypeEnum.out, quantity=qty,
                    unit_cost=unit_cost, total_cost=money(actual_cost),
                    note=f"فاتورة مبيعات {invoice.invoice_number}", created_by_id=user.id
                ))

        # Accounts receivable/cash debit; sales + tax liability credit.
        debit_account = "1100" if payment_method == "نقدي" else ("1110" if payment_method in {"بنكي", "تحويل بنكي"} else "1200")
        accounting_lines = [(debit_account, total, D(0)), ("4100", D(0), taxable)]
        if tax_amount > 0:
            accounting_lines.append(("2200", D(0), tax_amount))
        if cogs > 0:
            accounting_lines.extend([("5100", cogs, D(0)), ("1300", D(0), cogs)])
        create_entry(db, f"فاتورة مبيعات {invoice.invoice_number}", user.id,
                     accounting_lines, "sale_invoice", invoice.id)
        db.commit()
    except HTTPException:
        db.rollback()
        raise
    except Exception:
        db.rollback()
        raise

    return RedirectResponse(url=f"/sales/{invoice.id}", status_code=303)


@router.get("/{invoice_id}", response_class=HTMLResponse)
def invoice_detail(invoice_id: int, request: Request, db: Session = Depends(get_db),
                    user: User = Depends(require_module("sales"))):
    invoice = db.query(SaleInvoice).filter(SaleInvoice.id == invoice_id, SaleInvoice.company_id == get_request_context().get("company_id")).first()
    if not invoice:
        raise HTTPException(status_code=404, detail="الفاتورة مش موجودة")
    return templates.TemplateResponse(request, "invoice_detail.html", {"user": user, "invoice": invoice})
