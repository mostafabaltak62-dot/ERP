# -*- coding: utf-8 -*-
import logging
import datetime
from decimal import Decimal, InvalidOperation
from fastapi import APIRouter, Depends, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import func
from sqlalchemy.exc import IntegrityError

from ..database import get_db
from ..models import User, Account, AccountTypeEnum, JournalEntry, JournalLine, ModulePermission, CostCenter, JournalLineCostCenter, AuditLog
from ..enterprise_models import Branch, UserCompanyAccess
from ..governance import resolve_tenant
from ..accounting import create_entry, money, D
from ..auth import require_module
from ..governance import require_permission, get_request_context
from ..financial_reporting import trial_balance, general_ledger, profit_and_loss, balance_sheet, cash_flow, changes_in_equity, validate_financials
from ..report_exports import excel_response, pdf_response
from ..accounting_controls import build_accounting_control_report, orphan_accounts

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/accounting")
templates = Jinja2Templates(directory="templates")


def _has_edit(db, user, key="accounting"):
    # SQLAlchemy may return either the Enum instance or its persisted string
    # depending on backend/test fixture coercion.
    role = getattr(getattr(user, "role", None), "value", getattr(user, "role", None))
    if role == "admin":
        return True
    p = db.query(ModulePermission).filter_by(user_id=user.id, module_key=key).first()
    return bool(p and p.can_edit)


def _money(v): return money(v).quantize(Decimal("0.01"))


def _dt(value):
    if not value: return None
    try: return datetime.datetime.fromisoformat(value)
    except ValueError: raise HTTPException(422, "التاريخ غير صحيح")


@router.get("", response_class=HTMLResponse)
def accounting_home(request: Request, branch_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(require_module("accounting"))):
    """Governed General Accounting workspace.

    The home page is a reporting/drill-down surface, so its account balances and
    recent entries must obey the same company/branch scope as the authoritative
    financial reports. Aggregation is performed in bulk to avoid N+1 queries.
    """
    from ..routers.financial_reporting_ui import _branches

    cid, bid = _account_tenant(db, user, branch_id) if branch_id is not None else _account_home_tenant(db, user)
    accounts = _account_home_rows(db, cid, bid)
    total_debit = _money(sum((r["debit"] for r in accounts), Decimal("0")))
    total_credit = _money(sum((r["credit"] for r in accounts), Decimal("0")))

    entries_q = db.query(JournalEntry).filter(
        JournalEntry.company_id == cid,
        JournalEntry.status == "posted",
    )
    if bid is not None:
        entries_q = entries_q.filter(JournalEntry.branch_id == bid)
    entries = entries_q.order_by(JournalEntry.entry_date.desc(), JournalEntry.id.desc()).limit(50).all()

    return templates.TemplateResponse(request, "accounting.html", {
        "user": user, "accounts": accounts, "entries": entries,
        "can_edit": _has_edit(db, user), "company_id": cid,
        "branch_id": bid, "branches": _branches(db, user, cid),
        "account_count": len(accounts), "total_debit": total_debit, "total_credit": total_credit,
        "entry_count": len(entries), "today_start": datetime.date.today().replace(month=1, day=1).isoformat(),
        "today_end": datetime.date.today().isoformat(),
    })


def _account_home_tenant(db, user):
    """Resolve the current accounting scope without forcing a branch for a company-wide view."""
    ctx = get_request_context()
    cid = ctx.get("company_id") or getattr(user, "company_id", None)
    if cid is None:
        raise HTTPException(403, "لم يتم تحديد الشركة الحالية ضمن نطاق المستخدم")
    cid = int(cid)
    active_branch = ctx.get("branch_id")
    accesses = db.query(UserCompanyAccess).filter(
        UserCompanyAccess.user_id == user.id,
        UserCompanyAccess.company_id == cid,
    ).all()
    if not accesses:
        raise HTTPException(403, "لا يوجد نطاق وصول للشركة الحالية")
    company_wide = any(a.branch_id is None for a in accesses)
    if active_branch is not None:
        return _account_tenant(db, user, int(active_branch))
    if company_wide:
        return cid, None
    branch_ids = sorted({a.branch_id for a in accesses if a.branch_id is not None})
    if len(branch_ids) == 1:
        return cid, branch_ids[0]
    raise HTTPException(400, "يجب تحديد الفرع قبل عرض المحاسبة العامة")


def _account_home_rows(db, cid, bid):
    """Bulk account activity for the General Accounting landing page."""
    q = db.query(Account).filter(Account.company_id == cid)
    if bid is not None:
        q = q.filter((Account.branch_id == bid) | (Account.branch_id.is_(None)))

    accounts = q.order_by(Account.code, Account.branch_id.desc()).all()
    if not accounts:
        return []
    account_ids = [a.id for a in accounts]
    totals_q = (db.query(
        JournalLine.account_id,
        func.coalesce(func.sum(JournalLine.debit), 0),
        func.coalesce(func.sum(JournalLine.credit), 0),
    ).join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
      .filter(
          JournalLine.company_id == cid,
          JournalEntry.company_id == cid,
          JournalEntry.status == "posted",
          JournalLine.account_id.in_(account_ids),
      ))
    if bid is not None:
        totals_q = totals_q.filter(JournalLine.branch_id == bid, JournalEntry.branch_id == bid)
    totals = {aid: (_money(d), _money(c)) for aid, d, c in totals_q.group_by(JournalLine.account_id).all()}

    rows = []
    for a in accounts:
        d, c = totals.get(a.id, (Decimal("0.00"), Decimal("0.00")))
        rows.append({"account": a, "debit": d, "credit": c, "balance": _money(d - c)})
    return rows


def _account_tenant(db, user, requested_branch_id=None):
    """Resolve account-master scope from governed company/branch access.

    Company-wide grants may explicitly select any active branch in that company;
    branch-only grants may select only their assigned branch.
    """
    ctx=get_request_context()
    cid=ctx.get("company_id") or getattr(user, "company_id", None)
    if cid is None:
        raise HTTPException(403, "لم يتم تحديد الشركة الحالية ضمن نطاق المستخدم")
    cid=int(cid)
    active_branch=ctx.get("branch_id")
    bid=int(requested_branch_id) if requested_branch_id not in (None, "") else (int(active_branch) if active_branch is not None else None)
    accesses=db.query(UserCompanyAccess).filter(UserCompanyAccess.user_id==user.id,UserCompanyAccess.company_id==cid).all()
    if not accesses: raise HTTPException(403,"لا يوجد نطاق وصول للشركة الحالية")
    company_wide=any(a.branch_id is None for a in accesses)
    if bid is not None:
        branch=db.query(Branch).filter(Branch.id==bid,Branch.company_id==cid,Branch.is_active.is_(True)).first()
        if not branch: raise HTTPException(403,"الفرع غير صالح أو غير نشط")
        if not company_wide and not any(a.branch_id==bid for a in accesses): raise HTTPException(403,"لا توجد صلاحية وصول لهذا الفرع")
        return cid,bid
    if company_wide: return cid,None
    branch_ids=sorted({a.branch_id for a in accesses if a.branch_id is not None})
    if len(branch_ids)==1: return cid,branch_ids[0]
    raise HTTPException(400,"يجب تحديد الفرع قبل إضافة حساب محاسبي")


def _account_branches(db, user, cid):
    q=(db.query(Branch).join(UserCompanyAccess, UserCompanyAccess.branch_id==Branch.id)
       .filter(UserCompanyAccess.user_id==user.id, UserCompanyAccess.company_id==cid, Branch.is_active.is_(True)))
    if db.query(UserCompanyAccess).filter(UserCompanyAccess.user_id==user.id, UserCompanyAccess.company_id==cid, UserCompanyAccess.branch_id.is_(None)).first():
        q=db.query(Branch).filter(Branch.company_id==cid, Branch.is_active.is_(True))
    return q.order_by(Branch.name).all()


def _account_candidates(db, cid, bid, exclude_id=None):
    q=db.query(Account).filter(Account.company_id==cid, Account.is_active.is_(True))
    if bid is not None:
        q=q.filter((Account.branch_id==bid)|(Account.branch_id.is_(None)))
    else:
        q=q.filter(Account.branch_id.is_(None))
    if exclude_id is not None: q=q.filter(Account.id!=exclude_id)
    return q.order_by(Account.branch_id.desc(), Account.code).all()


@router.get("/accounts/new", response_class=HTMLResponse)
def new_account_form(request: Request, branch_id:int|None=None, db: Session=Depends(get_db), user: User=Depends(require_module("accounting",need_edit=True))):
    cid, bid=_account_tenant(db,user,branch_id)
    return templates.TemplateResponse(request,"account_form.html",{"user":user,"accounts":_account_candidates(db,cid,bid),"branches":_account_branches(db,user,cid),"branch_id":bid,"company_id":cid})


@router.get("/accounts/{account_id}/edit", response_class=HTMLResponse)
def edit_account_form(account_id:int, request:Request, db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True))):
    cid, _=_account_tenant(db,user)
    account=db.query(Account).filter(Account.id==account_id, Account.company_id==cid).first()
    if not account: raise HTTPException(404,"الحساب غير موجود")
    # Global accounts are company-wide objects and require company-wide access;
    # branch-scoped users must not mutate them through an account_id alone.
    if account.branch_id is not None:
        _account_tenant(db,user,account.branch_id)
    elif not db.query(UserCompanyAccess.id).filter(
        UserCompanyAccess.user_id == user.id,
        UserCompanyAccess.company_id == cid,
        UserCompanyAccess.branch_id.is_(None),
    ).first():
        raise HTTPException(403, "لا توجد صلاحية على مستوى الشركة لتعديل الحساب العام")
    bid=account.branch_id
    return templates.TemplateResponse(request,"account_form.html",{"user":user,"accounts":_account_candidates(db,cid,bid,account_id),"branches":_account_branches(db,user,cid),"branch_id":bid,"company_id":cid,"account":account,"edit_mode":True})


@router.post("/accounts/{account_id}/edit")
def edit_account(account_id:int, db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True)), name:str=Form(...), account_type:str=Form(...), parent_id:str=Form(""), normal_balance:str=Form(""), statement_section:str=Form(""), cash_flow_category:str=Form("")):
    cid, _=_account_tenant(db,user)
    account=db.query(Account).filter(Account.id==account_id, Account.company_id==cid).first()
    if not account: raise HTTPException(404,"الحساب غير موجود")
    if account.branch_id is not None:
        _account_tenant(db,user,account.branch_id)
    elif not db.query(UserCompanyAccess.id).filter(
        UserCompanyAccess.user_id == user.id,
        UserCompanyAccess.company_id == cid,
        UserCompanyAccess.branch_id.is_(None),
    ).first():
        raise HTTPException(403, "لا توجد صلاحية على مستوى الشركة لتعديل الحساب العام")
    try: typ=AccountTypeEnum(account_type)
    except ValueError: raise HTTPException(422,"نوع الحساب غير صحيح")
    name=name.strip(); section=statement_section.strip(); flow=cash_flow_category.strip()
    if not name or len(name)>150: raise HTTPException(422,"اسم الحساب مطلوب وبحد أقصى 150 حرفًا")
    if section and len(section)>50: raise HTTPException(422,"قسم القوائم يتجاوز الحد المسموح")
    if flow not in ("", "operating", "investing", "financing"): raise HTTPException(422,"تصنيف التدفقات النقدية غير صحيح")
    used=db.query(JournalLine.id).filter(JournalLine.account_id==account.id).first() is not None
    if used and typ != account.account_type:
        raise HTTPException(409,"لا يمكن تغيير نوع حساب مستخدم في قيود مرحّلة؛ أنشئ حسابًا بديلًا حفاظًا على سلامة التقارير التاريخية")
    parent=None
    if parent_id:
        try: pid=int(parent_id)
        except ValueError: raise HTTPException(422,"الحساب الأب غير صالح")
        if pid==account.id: raise HTTPException(422,"لا يمكن أن يكون الحساب أبًا لنفسه")
        parent=db.query(Account).filter(Account.id==pid,Account.company_id==cid,Account.is_active.is_(True)).first()
        if not parent: raise HTTPException(422,"الحساب الأب غير صالح أو خارج نطاق الشركة")
        if account.branch_id is None and parent.branch_id is not None: raise HTTPException(422,"الحساب العام لا يمكن أن يتبع حسابًا خاصًا بفرع")
        if account.branch_id is not None and parent.branch_id not in (None, account.branch_id): raise HTTPException(422,"الحساب الأب يجب أن يكون عامًا أو تابعًا لنفس الفرع")
        if parent.account_type != typ: raise HTTPException(422,"نوع الحساب الأب يجب أن يطابق نوع الحساب")
        # Prevent cycles by walking ancestors inside the same tenant.
        seen=set(); cursor=parent
        while cursor is not None:
            if cursor.id in seen: raise HTTPException(409,"هيكل الحسابات يحتوي على دورة غير صالحة")
            seen.add(cursor.id)
            if cursor.id==account.id: raise HTTPException(422,"لا يمكن جعل أحد الحسابات الفرعية أبًا للحساب")
            cursor=cursor.parent
    account.name=name; account.parent_id=parent.id if parent else None
    account.account_type=typ
    account.normal_balance=normal_balance if normal_balance in ("debit","credit") else ("debit" if typ in (AccountTypeEnum.asset,AccountTypeEnum.expense) else "credit")
    account.statement_section=section or typ.value
    account.cash_flow_category=flow or None
    try:
        db.commit()
    except IntegrityError:
        db.rollback(); raise HTTPException(409,"تعذر حفظ الحساب بسبب تعارض في بيانات دليل الحسابات")
    return RedirectResponse("/accounting",303)


@router.post("/accounts/{account_id}/deactivate")
def deactivate_account(account_id:int, db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True))):
    cid=_company_id(user,db); account=db.query(Account).filter(Account.id==account_id,Account.company_id==cid).first()
    if not account: raise HTTPException(404,"الحساب غير موجود")
    # Mutation must enforce the account's branch/company-wide scope server-side,
    # not merely the company scope. This prevents branch-only users from mutating
    # another branch or a global account by changing account_id.
    if account.branch_id is not None:
        _account_tenant(db,user,account.branch_id)
    elif not db.query(UserCompanyAccess.id).filter(
        UserCompanyAccess.user_id == user.id,
        UserCompanyAccess.company_id == cid,
        UserCompanyAccess.branch_id.is_(None),
    ).first():
        raise HTTPException(403, "لا توجد صلاحية على مستوى الشركة لتعديل الحساب العام")
    if db.query(Account.id).filter(Account.company_id==cid,Account.parent_id==account.id,Account.is_active==True).first(): raise HTTPException(409,"لا يمكن إيقاف حساب أب له حسابات فرعية نشطة")
    account.is_active=False
    db.add(AuditLog(user_id=user.id,action="deactivate",entity_type="account",entity_id=account.id,description=f"إيقاف الحساب {account.code}"))
    db.commit(); return RedirectResponse("/accounting",303)

@router.post("/accounts/new")
def create_account(db: Session=Depends(get_db), user: User=Depends(require_module("accounting",need_edit=True)), code:str=Form(...), name:str=Form(...), account_type:str=Form(...), parent_id:str=Form(""), normal_balance:str=Form(""), statement_section:str=Form(""), cash_flow_category:str=Form(""), branch_id:str=Form("")):
    try: typ=AccountTypeEnum(account_type)
    except ValueError: raise HTTPException(422,"نوع الحساب غير صحيح")
    code,name=code.strip(),name.strip(); section=statement_section.strip(); flow=cash_flow_category.strip()
    if not code or not name: raise HTTPException(422,"كود الحساب واسم الحساب مطلوبان")
    if len(code)>30: raise HTTPException(422,"كود الحساب يتجاوز 30 حرفًا")
    if len(name)>150: raise HTTPException(422,"اسم الحساب يتجاوز 150 حرفًا")
    if section and len(section)>50: raise HTTPException(422,"قسم القوائم يتجاوز 50 حرفًا")
    if flow not in ("", "operating", "investing", "financing"): raise HTTPException(422,"تصنيف التدفقات النقدية غير صحيح")
    try: cid,bid=_account_tenant(db,user,branch_id or None)
    except ValueError: raise HTTPException(422,"الفرع غير صالح")
    # Account codes are unique per company + branch. This intentionally permits a
    # branch-specific code to coexist with a company-wide code, while preventing
    # duplicates in the exact reporting scope.
    if db.query(Account.id).filter(Account.code==code,Account.company_id==cid,Account.branch_id==bid).first():
        raise HTTPException(409,"كود الحساب مستخدم بالفعل داخل هذا النطاق")
    parent=None
    if parent_id:
        try: pid=int(parent_id)
        except ValueError: raise HTTPException(422,"الحساب الأب غير صالح")
        parent=db.query(Account).filter(Account.id==pid,Account.company_id==cid,Account.is_active.is_(True)).first()
        if not parent: raise HTTPException(422,"الحساب الأب غير صالح أو خارج نطاق الشركة")
        if bid is None and parent.branch_id is not None: raise HTTPException(422,"الحساب العام لا يمكن أن يتبع حسابًا خاصًا بفرع")
        if bid is not None and parent.branch_id not in (None,bid): raise HTTPException(422,"الحساب الأب يجب أن يكون عامًا أو تابعًا لنفس الفرع")
        if parent.account_type != typ: raise HTTPException(422,"نوع الحساب الأب يجب أن يطابق نوع الحساب")
    if normal_balance not in ("debit","credit"): normal_balance="debit" if typ in (AccountTypeEnum.asset,AccountTypeEnum.expense) else "credit"
    account=Account(company_id=cid,branch_id=bid,code=code,name=name,account_type=typ,parent_id=parent.id if parent else None,normal_balance=normal_balance,statement_section=section or typ.value,cash_flow_category=flow or ("operating" if typ in (AccountTypeEnum.revenue,AccountTypeEnum.expense) else None),is_active=True)
    db.add(account)
    try:
        db.commit()
    except IntegrityError:
        db.rollback(); raise HTTPException(409,"كود الحساب مستخدم بالفعل داخل هذا النطاق")
    return RedirectResponse("/accounting",303)


@router.get("/journal/new", response_class=HTMLResponse)
def new_journal_form(request: Request, branch_id: int | None = None,
                    db: Session = Depends(get_db),
                    user: User = Depends(require_module("accounting", need_edit=True))):
    """Render the governed manual-journal entry screen.

    The form is intentionally branch-aware: company-wide users may choose an
    active branch, while branch-only users are restricted by resolve_tenant().
    """
    cid, bid = _account_tenant(db, user, branch_id)
    accounts = _account_candidates(db, cid, bid)
    cc_q = db.query(CostCenter).filter(CostCenter.company_id == cid, CostCenter.is_active.is_(True))
    if bid is not None:
        cc_q = cc_q.filter((CostCenter.branch_id == bid) | (CostCenter.branch_id.is_(None)))
    else:
        cc_q = cc_q.filter(CostCenter.branch_id.is_(None))
    cost_centers = cc_q.order_by(CostCenter.branch_id.desc(), CostCenter.code).all()
    branches = _account_branches(db, user, cid)
    return templates.TemplateResponse(request, "journal_form.html", {
        "user": user, "accounts": accounts, "cost_centers": cost_centers,
        "branches": branches, "branch_id": bid, "company_id": cid,
        "today": datetime.datetime.now().strftime("%Y-%m-%dT%H:%M"),
    })


@router.post("/journal/new")
async def create_manual_journal(request: Request, db: Session = Depends(get_db),
                               user: User = Depends(require_module("accounting", need_edit=True)),
                               _journal_post_permission: User = Depends(require_permission("journal:post"))):
    """Validate and atomically post a manual journal in the governed tenant scope."""
    form = await request.form()
    description = str(form.get("description", "")).strip()
    reference = str(form.get("reference", "")).strip()
    entry_date_raw = str(form.get("entry_date", "")).strip()
    requested_branch = str(form.get("branch_id", "")).strip()

    if not description:
        raise HTTPException(422, "بيان القيد مطلوب")
    if len(description) > 255:
        raise HTTPException(422, "بيان القيد يتجاوز 255 حرفًا")
    if len(reference) > 100:
        raise HTTPException(422, "مرجع القيد يتجاوز 100 حرف")

    try:
        cid, bid = _account_tenant(db, user, requested_branch or None)
    except ValueError:
        raise HTTPException(422, "الفرع غير صالح")

    parsed_date = _dt(entry_date_raw) if entry_date_raw else None
    if parsed_date is None:
        raise HTTPException(422, "تاريخ القيد مطلوب")

    # A manual journal is a posting event, so it must land in an explicitly
    # defined open accounting period. create_entry() keeps the legacy behavior
    # for system workflows where periods may be bootstrapped later; the UI does
    # not allow bypassing period governance.
    from ..models import AccountingPeriod
    period_q = db.query(AccountingPeriod).filter(
        AccountingPeriod.company_id == cid,
        AccountingPeriod.start_date <= parsed_date,
        AccountingPeriod.end_date >= parsed_date,
    )
    if bid is not None:
        period_q = period_q.filter((AccountingPeriod.branch_id == bid) | (AccountingPeriod.branch_id.is_(None)))
    else:
        period_q = period_q.filter(AccountingPeriod.branch_id.is_(None))
    period = period_q.order_by(AccountingPeriod.branch_id.desc(), AccountingPeriod.start_date.desc()).first()
    if period is None:
        raise HTTPException(409, "لا توجد فترة محاسبية مفتوحة تغطي تاريخ القيد")
    if period.is_closed:
        raise HTTPException(409, f"الفترة المحاسبية {period.name} مغلقة ولا يمكن إضافة قيود إليها")

    account_ids = form.getlist("account_id[]")
    debits = form.getlist("debit[]")
    credits = form.getlist("credit[]")
    line_desc = form.getlist("line_description[]")
    cost_center_ids = form.getlist("cost_center_id[]")
    allocation_amounts = form.getlist("allocation_amount[]")

    if not account_ids:
        raise HTTPException(422, "أضف سطرين محاسبيين على الأقل")

    lines = []
    metadata = []
    for idx, aid_raw in enumerate(account_ids):
        aid_raw = str(aid_raw or "").strip()
        if not aid_raw:
            continue
        try:
            aid = int(aid_raw)
        except (TypeError, ValueError):
            raise HTTPException(422, "الحساب غير صالح")
        try:
            debit = Decimal(str(debits[idx] if idx < len(debits) else "0") or "0")
            credit = Decimal(str(credits[idx] if idx < len(credits) else "0") or "0")
        except InvalidOperation:
            raise HTTPException(422, "قيمة مدين/دائن غير صحيحة")
        if debit.is_nan() or debit.is_infinite() or credit.is_nan() or credit.is_infinite():
            raise HTTPException(422, "قيمة مدين/دائن غير صالحة")
        if debit < 0 or credit < 0 or (debit > 0 and credit > 0):
            raise HTTPException(422, "كل سطر يجب أن يكون مدينًا أو دائنًا فقط")
        if debit == 0 and credit == 0:
            continue

        acc = db.query(Account).filter(
            Account.id == aid, Account.company_id == cid, Account.is_active.is_(True)
        ).first()
        if not acc or (bid is None and acc.branch_id is not None) or (bid is not None and acc.branch_id not in (None, bid)):
            raise HTTPException(422, "الحساب غير صالح أو خارج نطاق الفرع الحالي")

        desc = str(line_desc[idx]).strip() if idx < len(line_desc) else ""
        if len(desc) > 255:
            raise HTTPException(422, "بيان السطر يتجاوز 255 حرفًا")

        cc_raw = str(cost_center_ids[idx] if idx < len(cost_center_ids) else "").strip()
        alloc_raw = str(allocation_amounts[idx] if idx < len(allocation_amounts) else "").strip()
        cc_id = None
        allocation = None
        if cc_raw:
            try:
                cc_id = int(cc_raw)
            except (TypeError, ValueError):
                raise HTTPException(422, "مركز التكلفة غير صالح")
            cc_q = db.query(CostCenter).filter(CostCenter.id == cc_id, CostCenter.company_id == cid, CostCenter.is_active.is_(True))
            if bid is not None:
                cc_q = cc_q.filter((CostCenter.branch_id == bid) | (CostCenter.branch_id.is_(None)))
            else:
                cc_q = cc_q.filter(CostCenter.branch_id.is_(None))
            if not cc_q.first():
                raise HTTPException(422, "مركز التكلفة غير صالح أو خارج نطاق الفرع الحالي")
            if alloc_raw:
                try:
                    allocation = Decimal(alloc_raw)
                except InvalidOperation:
                    raise HTTPException(422, "قيمة تخصيص مركز التكلفة غير صحيحة")
                if allocation.is_nan() or allocation.is_infinite() or allocation <= 0 or allocation > debit + credit:
                    raise HTTPException(422, "تخصيص مركز التكلفة يجب أن يكون ضمن قيمة السطر")
        elif alloc_raw:
            try:
                orphan_allocation = Decimal(alloc_raw)
            except InvalidOperation:
                raise HTTPException(422, "قيمة تخصيص مركز التكلفة غير صحيحة")
            if orphan_allocation.is_nan() or orphan_allocation.is_infinite() or orphan_allocation != 0:
                raise HTTPException(422, "لا يمكن إدخال تخصيص بدون مركز تكلفة")

        lines.append((acc.code, debit, credit))
        metadata.append({"description": desc or None, "cost_center_id": cc_id, "allocation_amount": allocation})

    if len(lines) < 2:
        raise HTTPException(422, "القيد يحتاج إلى سطرين محاسبيين على الأقل")
    total_debit = sum((x[1] for x in lines), Decimal("0"))
    total_credit = sum((x[2] for x in lines), Decimal("0"))
    if total_debit <= 0 or total_debit != total_credit:
        raise HTTPException(422, "القيد غير متوازن: إجمالي المدين يجب أن يساوي إجمالي الدائن")

    desc = f"{reference} - {description}" if reference else description
    entry = create_entry(
        db, desc, user.id, lines, "manual", None, parsed_date,
        company_id=cid, line_metadata=metadata, branch_id=bid
    )
    db.commit()
    return RedirectResponse(f"/accounting/journal/{entry.id}", 303)


@router.get("/journal/{entry_id}", response_class=HTMLResponse)
def journal_detail(entry_id:int, request:Request, db:Session=Depends(get_db), user:User=Depends(require_module("accounting"))):
    cid, bid = resolve_tenant(db, user)
    q=db.query(JournalEntry).filter(JournalEntry.id==entry_id, JournalEntry.company_id==cid)
    if bid is not None:
        q=q.filter((JournalEntry.branch_id==bid)|(JournalEntry.branch_id.is_(None)))
    entry=q.first()
    if not entry: raise HTTPException(404,"القيد غير موجود")
    total_debit=_money(sum(x.debit for x in entry.lines)); total_credit=_money(sum(x.credit for x in entry.lines))
    return templates.TemplateResponse(request,"journal_detail.html",{"user":user,"entry":entry,"total_debit":total_debit,"total_credit":total_credit,"company_id":cid,"branch_id":bid})


@router.get("/ledger/{account_id}", response_class=HTMLResponse)
def account_ledger(account_id: int, request: Request, db: Session = Depends(get_db), user: User = Depends(require_module("accounting"))):
    """Compatibility drill-down into the authoritative General Ledger report."""
    requested_branch = request.query_params.get("branch_id")
    try:
        requested_branch = int(requested_branch) if requested_branch else None
    except ValueError:
        raise HTTPException(422, "الفرع غير صالح")
    cid, bid = _account_tenant(db, user, requested_branch) if requested_branch is not None else _account_home_tenant(db, user)
    account_q = db.query(Account).filter(Account.id == account_id, Account.company_id == cid)
    if bid is not None:
        account_q = account_q.filter((Account.branch_id == bid) | (Account.branch_id.is_(None)))
    if not account_q.first():
        raise HTTPException(404, "الحساب غير موجود ضمن نطاق الشركة/الفرع الحالي")
    start = request.query_params.get("start_date") or ""
    end = request.query_params.get("end_date") or ""
    if start and end:
        from urllib.parse import urlencode
        qs = urlencode({"start_date": start, "end_date": end, "account_id": account_id, **({"branch_id": bid} if bid is not None else {})})
        return RedirectResponse(f"/accounting/reports/general-ledger?{qs}", 307)
    return RedirectResponse(f"/accounting/reports/account-statement/{account_id}" + (f"?branch_id={bid}" if bid is not None else ""), 307)


def _report_context(report, user, **kwargs): return {"user":user,"report":report,**kwargs}


# NOTE: The HTML page routes for trial-balance / income-statement / balance-sheet /
# cash-flow / equity / validation used to be defined here, but they duplicated the
# same paths as app/routers/financial_reporting_ui.py (also mounted at
# prefix="/accounting/reports"). Because this router was registered first in
# app/main.py, these older, non-branch-aware handlers silently shadowed the newer
# branch-consolidation-aware handlers in financial_reporting_ui.py, so multi-branch
# filtering never actually worked from the Financial Reports hub. They were removed
# here so the richer implementation in financial_reporting_ui.py is reachable.
# The underlying report functions (trial_balance, profit_and_loss, balance_sheet,
# cash_flow, changes_in_equity) are still used below by export_report().


@router.get("/reports/control-check", response_class=HTMLResponse)
def accounting_control_check(request:Request,start_date:str="",end_date:str="",branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid=_company_id(user,db); s=_dt(start_date).date() if start_date else datetime.date.today().replace(month=1,day=1); e=_dt(end_date).date() if end_date else datetime.date.today()
    if s>e: raise HTTPException(422,"تاريخ البداية يجب ألا يتجاوز تاريخ النهاية")
    if branch_id is not None:
        # Company-wide grants may explicitly select an active branch; the generic
        # resolve_tenant() requires an exact branch access row and therefore is too
        # strict for this governed reporting use-case.
        _, branch_id = _account_tenant(db, user, int(branch_id))
    report=build_accounting_control_report(db,cid,s,e,branch_id)
    branches=[]
    try:
        from ..routers.financial_reporting_ui import _branches
        branches=_branches(db,user,cid)
    except Exception:
        logger.exception("Failed to load branch options for accounting control check")
    return templates.TemplateResponse(request,"accounting_control_check.html",{"user":user,**report,"start_date":s.isoformat(),"end_date":e.isoformat(),"branch_id":branch_id,"branches":branches})

@router.get("/reports/inventory-reconciliation", response_class=HTMLResponse)
def inventory_reconciliation_page(request:Request,as_of_date:str="",db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    from ..accounting_controls import inventory_control
    cid=_company_id(user,db)
    try: as_of=datetime.date.fromisoformat(as_of_date) if as_of_date else datetime.date.today()
    except ValueError: raise HTTPException(422,"تاريخ التسوية غير صحيح؛ استخدم YYYY-MM-DD")
    report=inventory_control(db,cid,as_of=as_of)
    return templates.TemplateResponse(request,"inventory_reconciliation.html",{"user":user,"as_of_date":as_of.isoformat(),**report})

@router.get("/reports/inventory-reconciliation/export/{fmt}")
def inventory_reconciliation_export(fmt:str,as_of_date:str="",db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    if fmt not in ("xlsx","pdf"): raise HTTPException(404,"صيغة التقرير غير مدعومة")
    from ..accounting_controls import inventory_control
    cid=_company_id(user,db)
    try: as_of=datetime.date.fromisoformat(as_of_date) if as_of_date else datetime.date.today()
    except ValueError: raise HTTPException(422,"تاريخ التسوية غير صحيح؛ استخدم YYYY-MM-DD")
    report=inventory_control(db,cid,as_of=as_of)
    headers=["المعرف","قيمة حركة المخزون","التقييم التاريخي","التكلفة المستهلكة","فرق الحركة/التقييم","الحالة"]
    data=[(r["item_id"],r["movement_value"],r["valued_remaining"],r["consumed_value"],r["difference"],r["status"]) for r in report["rows"]]
    data += [("","إجمالي قيمة المخزون",report["valuation"],"","",""),("GL 1300","الرصيد",report["inventory_gl"],"الفرق",report["inventory_difference"],"PASS" if report["inventory_difference"]==0 else "FAIL"),("GL 5100","تشخيص التكلفة المستهلكة",report["cogs_gl"],"الفرق",report["cogs_difference"],"DIAGNOSTIC")]
    title="تسوية المخزون مع الأستاذ العام"
    return excel_response(title,headers,data,"inventory_reconciliation.xlsx") if fmt=="xlsx" else pdf_response(title,headers,data,"inventory_reconciliation.pdf")

@router.get("/reports/orphan-accounts", response_class=HTMLResponse)
def orphan_accounts_page(request:Request,branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid=_company_id(user,db)
    if branch_id is not None:
        _, branch_id=_account_tenant(db,user,int(branch_id))
    rows=orphan_accounts(db,cid,branch_id)
    return templates.TemplateResponse(request,"orphan_accounts.html",{"user":user,"rows":rows,"branch_id":branch_id})

@router.get("/reports/control-check/export/{fmt}")
def export_control_check(fmt:str,start_date:str="",end_date:str="",branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    if fmt not in ("xlsx","pdf"): raise HTTPException(404,"صيغة التقرير غير مدعومة")
    cid=_company_id(user,db); s=_dt(start_date).date() if start_date else datetime.date.today().replace(month=1,day=1); e=_dt(end_date).date() if end_date else datetime.date.today();
    if s>e: raise HTTPException(422,"تاريخ البداية يجب ألا يتجاوز تاريخ النهاية")
    if branch_id is not None:
        from ..governance import resolve_tenant
        _, branch_id=resolve_tenant(db,user,cid,int(branch_id))
    r=build_accounting_control_report(db,cid,s,e,branch_id)
    headers=["الفحص","النتيجة","التفاصيل"]; data=[(n,"PASS" if ok else "FAIL",d) for n,ok,d in r["checks"]]
    data += [("ملخص",f"{r['passed']}/{r['total']}","Accounting Compliance Checklist")]
    return excel_response("Accounting Control",headers,data,"accounting_control.xlsx") if fmt=="xlsx" else pdf_response("Accounting Control",headers,data,"accounting_control.pdf")


def _company_id(user,db):
    cid=getattr(user,"company_id",None)
    if cid is not None:return cid
    try:
        from ..governance import get_request_context
        cid=get_request_context().get("company_id")
    except Exception: cid=None
    if cid is None:
        raise HTTPException(status_code=403, detail="لم يتم تحديد الشركة الحالية ضمن نطاق المستخدم")
    return cid


# ---- Authoritative exports ----
@router.get("/reports/{report_name}/export/{fmt}")
def export_report(report_name:str,fmt:str,start_date:str="",end_date:str="",as_of_date:str="",branch_id:int|None=None,account_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid=_company_id(user,db); fmt=fmt.lower()
    if branch_id is not None:
        _, branch_id=_account_tenant(db,user,int(branch_id))
    if fmt not in ("xlsx","pdf"): raise HTTPException(404,"صيغة التقرير غير مدعومة")
    s=_dt(start_date).date() if start_date else datetime.date.today().replace(month=1,day=1); e=_dt(end_date).date() if end_date else datetime.date.today()
    headers=[]; data=[]; title=report_name
    if report_name=="trial-balance":
        rows=trial_balance(db,cid,s,e,branch_id); title="ميزان المراجعة"; headers=["الكود","الحساب","الافتتاحي","مدين","دائن","الرصيد"]
        data=[(r["code"],r["name"],r["opening_balance"],r["debit"],r["credit"],r["closing_balance"]) for r in rows]
    elif report_name=="income-statement":
        r=profit_and_loss(db,cid,s,e,branch_id); title="قائمة الدخل"; headers=["البند","المبلغ"]; data=[*( (x["name"],x["amount"]) for x in r["revenue_lines"]), ("إجمالي الإيرادات",r["revenue_total"]), *( (x["name"],x["amount"]) for x in r["expense_lines"]), ("إجمالي المصروفات",r["expense_total"]),("صافي الربح",r["net_profit"])]
    elif report_name=="balance-sheet":
        r=balance_sheet(db,cid,_dt(as_of_date).date() if as_of_date else e,branch_id); title="قائمة المركز المالي"; headers=["القسم","الحساب","المبلغ"]; data=[]
        for sec,key in (("الأصول","assets"),("الخصوم","liabilities"),("حقوق الملكية","equity")):
            data += [(sec,x["name"],x["amount"]) for x in r[key]]
        data += [("صافي الربح", "ربح الفترة", r["current_profit"]),("الإجمالي","الأصول",r["asset_total"]),("الإجمالي","الخصوم وحقوق الملكية",r["liability_equity_total"])]
    elif report_name=="cash-flow":
        r=cash_flow(db,cid,s,e,branch_id); title="قائمة التدفقات النقدية"; headers=["النشاط","المبلغ"]; data=[("التشغيل",r["operating"]),("الاستثمار",r["investing"]),("التمويل",r["financing"]),("صافي التغير",r["net_change"]),("الرصيد الافتتاحي",r["opening_cash"]),("الرصيد الختامي",r["closing_cash"])]
    elif report_name=="equity":
        r=changes_in_equity(db,cid,s,e,branch_id); title="قائمة التغيرات في حقوق الملكية"; headers=["البند","المبلغ"]; data=[("رصيد أول المدة",r["opening_equity"]),("حركة حقوق الملكية",r["equity_movements"]),("ربح الفترة",r["profit_for_period"]),("رصيد آخر المدة",r["closing_equity"])]
    elif report_name=="ledger":
        if not start_date or not end_date: raise HTTPException(422,"حدد الفترة وتاريخ البداية والنهاية")
        if account_id is not None:
            aq=db.query(Account).filter(Account.id==account_id, Account.company_id==cid)
            if branch_id is not None:
                aq=aq.filter((Account.branch_id==branch_id)|(Account.branch_id.is_(None)))
            if not aq.first(): raise HTTPException(404,"الحساب غير موجود ضمن نطاق الشركة/الفرع الحالي")
        rows=general_ledger(db,cid,s,e,account_id,branch_id); title="الأستاذ العام"; headers=["التاريخ","رقم القيد","الحساب","البيان","مدين","دائن","الرصيد"]; data=[(x["date"],x["entry_number"],x["account_code"],x["description"],x["debit"],x["credit"],x["running_balance"]) for x in rows]
    else: raise HTTPException(404,"التقرير غير موجود")
    filename=report_name+('.xlsx' if fmt=='xlsx' else '.pdf')
    return excel_response(title,headers,data,filename) if fmt=='xlsx' else pdf_response(title,headers,data,filename)
