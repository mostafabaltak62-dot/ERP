# -*- coding: utf-8 -*-
from fastapi import APIRouter, Depends, Request, Form, HTTPException, status
import os
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import date

from ..database import get_db
from ..models import User, ModulePermission, RoleEnum, MODULES
from ..auth import verify_password, create_access_token, get_current_user, hash_password, issue_refresh_token, revoke_refresh_token, revoke_access_token, revoke_user_access_tokens, validate_password_policy
from ..governance import require_permission, get_tenant_context, scope_allows, _has_permission
from ..security_hardening import login_rate_limit

# A freshly generated bcrypt hash gives non-existent usernames the same
# password-hash workload as real users, reducing timing-based enumeration.
_DUMMY_PASSWORD_HASH = hash_password("__ERP_Dummy9Password__")
from ..governance_models import Role, Permission, RolePermission, UserRole, ApprovalRequest, ApprovalRuleStep, GovernanceAuditLog
from ..enterprise_models import Company, Branch, Project, UserCompanyAccess, ProjectCost
from ..construction_models import ConstructionSite, ConstructionEVMSnapshot
from ..hr_models import UserScope
from ..document_models import ProjectDocument

router = APIRouter()
templates = Jinja2Templates(directory="templates")


@router.get("/login", response_class=HTMLResponse)
def login_page(request: Request, error: str = ""):
    return templates.TemplateResponse(request, "login.html", {"error": error})


@router.post("/login")
def login_submit(request: Request, db: Session = Depends(get_db),
                  username: str = Form(...), password: str = Form(...)):
    username = username.strip()
    client_ip = request.client.host if request.client else "unknown"
    allowed, retry_after = login_rate_limit(client_ip, username)
    if not allowed:
        raise HTTPException(status_code=429, detail="Too many login attempts", headers={"Retry-After": str(retry_after)})
    user = db.query(User).filter(User.username == username).first()
    password_hash = user.password_hash if user and user.password_hash else _DUMMY_PASSWORD_HASH
    password_ok = verify_password(password, password_hash)
    if not user or not user.is_active or not password_ok:
        return RedirectResponse(url="/login?error=بيانات+الدخول+غير+صحيحة", status_code=status.HTTP_303_SEE_OTHER)
    token = create_access_token(user)
    refresh_token, refresh_expires = issue_refresh_token(db, user)
    resp = RedirectResponse(url="/", status_code=status.HTTP_303_SEE_OTHER)
    secure = os.getenv("ERP_ENV", "development").lower() == "production"
    resp.set_cookie("access_token", token, httponly=True, secure=secure, max_age=3600, samesite="lax", path="/")
    resp.set_cookie("refresh_token", refresh_token, httponly=True, secure=secure, max_age=max(1, int((refresh_expires - __import__('app.time_utils', fromlist=['utcnow']).utcnow()).total_seconds())), samesite="lax", path="/")
    return resp


@router.get("/logout")
def logout(request: Request, db: Session = Depends(get_db)):
    revoke_access_token(request.cookies.get("access_token", ""))
    revoke_refresh_token(db, request.cookies.get("refresh_token"))
    resp = RedirectResponse(url="/login", status_code=status.HTTP_303_SEE_OTHER)
    resp.delete_cookie("access_token", path="/")
    resp.delete_cookie("refresh_token", path="/")
    return resp


@router.post("/auth/refresh")
def refresh_session(request: Request, db: Session = Depends(get_db)):
    from ..auth import rotate_refresh_token
    result = rotate_refresh_token(db, request.cookies.get("refresh_token"))
    if not result:
        raise HTTPException(status_code=401, detail="Refresh token is invalid or expired")
    user, raw, expires = result
    token = create_access_token(user)
    resp = RedirectResponse(url="/", status_code=status.HTTP_303_SEE_OTHER)
    secure = os.getenv("ERP_ENV", "development").lower() == "production"
    resp.set_cookie("access_token", token, httponly=True, secure=secure, max_age=3600, samesite="lax", path="/")
    resp.set_cookie("refresh_token", raw, httponly=True, secure=secure, max_age=max(1, int((expires - __import__('app.time_utils', fromlist=['utcnow']).utcnow()).total_seconds())), samesite="lax", path="/")
    return resp


def _dashboard_data(db: Session, user: User, company_id: int, branch_id: int | None):
    """Build dashboard metrics from the *resolved* tenant and visible scope only."""
    company = db.get(Company, company_id)
    project_q = db.query(Project).filter(Project.company_id == company_id)
    if branch_id is not None:
        from sqlalchemy import or_
        project_q = project_q.filter(or_(Project.branch_id == branch_id, Project.branch_id.is_(None)))
    candidates = project_q.order_by(Project.id.desc()).all()
    projects = [p for p in candidates if scope_allows(db, user.id, company_id=company_id, branch_id=p.branch_id, project_id=p.id)]
    project_ids = [p.id for p in projects]

    cost_by_project = {}
    if project_ids:
        rows = (db.query(ProjectCost.project_id, func.coalesce(func.sum(ProjectCost.amount), 0))
                  .filter(ProjectCost.company_id == company_id, ProjectCost.project_id.in_(project_ids))
                  .group_by(ProjectCost.project_id).all())
        cost_by_project = {pid: float(amount or 0) for pid, amount in rows}

    dashboard_projects = []
    total_budget = 0.0
    total_actual = 0.0
    for project in projects:
        budget = float(project.budget or 0)
        actual = cost_by_project.get(project.id, 0.0)
        total_budget += budget
        total_actual += actual
        pct = (actual / budget * 100.0) if budget else 0.0
        dashboard_projects.append({"project": project, "actual": actual, "budget": budget, "pct": pct})

    # Only approvals that belong to the resolved branch and that the current
    # user can actually act on are exposed on the dashboard.
    approval_q = db.query(ApprovalRequest).filter(ApprovalRequest.company_id == company_id, ApprovalRequest.status == "pending")
    if branch_id is not None:
        from sqlalchemy import or_
        approval_q = approval_q.filter(or_(ApprovalRequest.branch_id == branch_id, ApprovalRequest.branch_id.is_(None)))
    pending_approvals = 0
    for req in approval_q.all():
        step = (db.query(ApprovalRuleStep)
                  .filter_by(rule_id=req.rule_id, sequence=req.current_sequence).first())
        if step and _has_permission(db, user.id, step.required_permission, company_id, branch_id):
            pending_approvals += 1

    document_count = 0
    if project_ids:
        document_count = (db.query(func.count(ProjectDocument.id))
                           .filter(ProjectDocument.company_id == company_id, ProjectDocument.project_id.in_(project_ids)).scalar() or 0)

    # Portfolio EVM is calculated from the latest snapshot of every visible
    # project, not from one arbitrary project's latest reading.
    evm_rows = []
    if project_ids:
        latest_dates = (db.query(ConstructionEVMSnapshot.project_id.label('project_id'),
                                 func.max(ConstructionEVMSnapshot.status_date).label('status_date'))
                        .filter(ConstructionEVMSnapshot.company_id == company_id,
                                ConstructionEVMSnapshot.project_id.in_(project_ids))
                        .group_by(ConstructionEVMSnapshot.project_id).subquery())
        evm_rows = (db.query(ConstructionEVMSnapshot)
                      .join(latest_dates, (ConstructionEVMSnapshot.project_id == latest_dates.c.project_id) &
                                           (ConstructionEVMSnapshot.status_date == latest_dates.c.status_date))
                      .filter(ConstructionEVMSnapshot.company_id == company_id).all())
    if evm_rows:
        pv = sum(float(x.pv or 0) for x in evm_rows)
        ev = sum(float(x.ev or 0) for x in evm_rows)
        ac = sum(float(x.ac or 0) for x in evm_rows)
        eac = sum(float(x.eac or 0) for x in evm_rows if x.eac is not None)
        vac = sum(float(x.vac or 0) for x in evm_rows if x.vac is not None)
        cpi = (ev / ac) if ac else None
        spi = (ev / pv) if pv else None
    else:
        cpi = spi = eac = vac = None

    activity_q = db.query(GovernanceAuditLog).filter(GovernanceAuditLog.company_id == company_id)
    if branch_id is not None:
        from sqlalchemy import or_
        activity_q = activity_q.filter(or_(GovernanceAuditLog.branch_id == branch_id, GovernanceAuditLog.branch_id.is_(None)))
    recent_activity = activity_q.order_by(GovernanceAuditLog.id.desc()).limit(6).all()

    metrics = {
        "project_count": len(projects), "project_value": total_budget, "actual_cost": total_actual,
        "pending_approvals": pending_approvals, "document_count": document_count,
        "cpi": cpi, "spi": spi, "eac": eac, "vac": vac,
    }
    return {"company": company, "metrics": metrics, "projects": dashboard_projects,
            "recent_activity": recent_activity, "project_ids": project_ids}


@router.get("/", response_class=HTMLResponse)
def dashboard(request: Request, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(get_current_user)):
    """Tenant-safe executive dashboard using actual, scope-filtered ERP data."""
    if user.role == RoleEnum.admin:
        allowed_keys = {m[0] for m in MODULES}
    else:
        perms = db.query(ModulePermission).filter_by(user_id=user.id, can_view=True).all()
        allowed_keys = {p.module_key for p in perms}
    modules_view = [{"key": k, "label": label, "allowed": k in allowed_keys} for k, label in MODULES]
    data = _dashboard_data(db, user, ctx["company_id"], ctx["branch_id"])
    return templates.TemplateResponse(request, "dashboard.html", {
        "user": user, "modules": modules_view, "metrics": data["metrics"],
        "projects": data["projects"], "recent_activity": data["recent_activity"],
        "company": data["company"], "today": date.today()
    })


@router.get("/dashboard/export.csv")
def dashboard_export_csv(db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(get_current_user)):
    """Export only metrics/projects visible to the current tenant and user scope."""
    import csv, io
    data = _dashboard_data(db, user, ctx["company_id"], ctx["branch_id"])
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(["Company", data["company"].name if data["company"] else ""])
    writer.writerow(["Project Count", data["metrics"]["project_count"]])
    writer.writerow(["Project Value", data["metrics"]["project_value"]])
    writer.writerow(["Actual Cost", data["metrics"]["actual_cost"]])
    writer.writerow([])
    writer.writerow(["Project Code", "Project Name", "Budget", "Actual Cost", "Cost %"])
    for row in data["projects"]:
        writer.writerow([row["project"].code, row["project"].name, row["budget"], row["actual"], round(row["pct"], 2)])
    return Response(out.getvalue(), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": "attachment; filename=dashboard.csv"})

@router.get("/users", response_class=HTMLResponse)
def users_page(request: Request, db: Session = Depends(get_db), user: User = Depends(require_permission("admin:users"))):
    all_users = db.query(User).order_by(User.id).all()
    perms_by_user = {}
    for u in all_users:
        perms_by_user[u.id] = {p.module_key: p for p in u.permissions}
    companies = db.query(Company).filter(Company.is_active.is_(True)).order_by(Company.name).all()
    branches = db.query(Branch).filter(Branch.is_active.is_(True)).order_by(Branch.company_id, Branch.name).all()
    projects = db.query(Project).order_by(Project.company_id, Project.name).all()
    sites = db.query(ConstructionSite).filter(ConstructionSite.status == "active").order_by(ConstructionSite.project_id, ConstructionSite.name).all()
    scopes_by_user = {u.id: db.query(UserScope).filter(UserScope.user_id == u.id).all() for u in all_users}
    governance_by_user = {}
    for u in all_users:
        governance_by_user[u.id] = set(db.query(Permission.code).join(RolePermission, RolePermission.permission_id == Permission.id).join(UserRole, UserRole.role_id == RolePermission.role_id).filter(UserRole.user_id == u.id, UserRole.is_active.is_(True), Permission.is_active.is_(True)).all())
        governance_by_user[u.id] = {x[0] for x in governance_by_user[u.id]}
    governance_permissions = db.query(Permission).filter(Permission.is_active.is_(True)).order_by(Permission.code).all()
    return templates.TemplateResponse(request, "users.html", {
        "user": user, "all_users": all_users,
        "modules": MODULES, "perms_by_user": perms_by_user, "roles": list(RoleEnum),
        "managers": [u for u in all_users if u.is_active and u.id != user.id],
        "companies": companies, "branches": branches, "projects": projects, "sites": sites,
        "scopes_by_user": scopes_by_user, "governance_by_user": governance_by_user,
        "governance_permissions": governance_permissions,
        "branch_map": {b.id: b for b in branches}, "project_map": {p.id: p for p in projects}, "site_map": {s.id: s for s in sites}, "company_map": {c.id: c for c in companies},
        "permission_presets": {
            "engineer": "مهندس", "supervisor": "مشرف موقع", "finance": "إدارة مالية",
            "procurement": "مشتريات", "hr": "موارد بشرية", "warehouse": "مخازن",
            "project_manager": "مدير مشروع", "viewer": "قراءة فقط"
        }
    })


@router.post("/users/create")
def create_user(db: Session = Depends(get_db), user: User = Depends(require_permission("admin:users")),
                 username: str = Form(...), full_name: str = Form(...),
                 employee_code: str = Form(""), job_title: str = Form(""), department: str = Form(""), manager_user_id: int | None = Form(None), phone: str = Form(""),
                 email: str = Form(""), password: str = Form(...), role: str = Form(...)):
    username = username.strip(); email = email.strip() or None; phone = phone.strip() or None; employee_code = employee_code.strip() or None
    if db.query(User).filter(User.username == username).first():
        return RedirectResponse(url="/users?error=اسم+المستخدم+موجود+بالفعل", status_code=303)
    if employee_code and db.query(User).filter(User.employee_code == employee_code).first():
        return RedirectResponse(url="/users?error=كود+الموظف+مستخدم+بالفعل", status_code=303)
    if email and db.query(User).filter(User.email == email).first():
        return RedirectResponse(url="/users?error=البريد+الإلكتروني+مستخدم+بالفعل", status_code=303)
    if phone and db.query(User).filter(User.phone == phone).first():
        return RedirectResponse(url="/users?error=رقم+الهاتف+مستخدم+بالفعل", status_code=303)
    try:
        validate_password_policy(password)
        user_role = RoleEnum(role)
    except (ValueError, TypeError):
        raise HTTPException(status_code=422, detail="Password must be 12+ chars and include upper, lower and numeric characters")
    if manager_user_id is not None:
        manager = db.get(User, manager_user_id)
        if not manager or not manager.is_active: raise HTTPException(422, "المدير المباشر غير صالح")
    if email and db.query(User).filter(User.email == email).first(): raise HTTPException(409, "البريد الإلكتروني مستخدم بالفعل")
    if phone and db.query(User).filter(User.phone == phone).first(): raise HTTPException(409, "رقم الهاتف مستخدم بالفعل")
    new_user = User(username=username, full_name=full_name.strip(), employee_code=employee_code,
                     job_title=job_title.strip() or None, department=department.strip() or None, manager_user_id=manager_user_id, phone=phone,
                     email=email, password_hash=hash_password(password), role=user_role)
    db.add(new_user); db.flush()
    # New accounts receive the current main company/branch access only; business
    # permissions and project/site scope remain an explicit admin decision.
    company = db.query(Company).filter(Company.is_active.is_(True)).order_by(Company.id).first()
    branch = db.query(Branch).filter(Branch.company_id == company.id, Branch.is_active.is_(True)).order_by(Branch.id).first() if company else None
    if company:
        db.add(UserCompanyAccess(user_id=new_user.id, company_id=company.id, branch_id=branch.id if branch else None, can_manage=False))
    db.commit()
    return RedirectResponse(url="/users", status_code=303)


@router.post("/users/{target_id}/profile")
def update_user_profile(target_id: int, full_name: str = Form(...), employee_code: str = Form(""), job_title: str = Form(""), department: str = Form(""), manager_user_id: int | None = Form(None), email: str = Form(""), phone: str = Form(""), role: str = Form(...), is_active: str = Form("on"), password: str = Form(""), db: Session = Depends(get_db), user: User = Depends(require_permission("admin:users"))):
    target = db.get(User, target_id)
    if not target: raise HTTPException(404, "المستخدم مش موجود")
    if manager_user_id == target_id: raise HTTPException(422, "لا يمكن للمستخدم إدارة نفسه")
    if manager_user_id is not None:
        manager = db.get(User, manager_user_id)
        if not manager or not manager.is_active: raise HTTPException(422, "المدير المباشر غير صالح")
        target_companies = {x[0] for x in db.query(UserCompanyAccess.company_id).filter(UserCompanyAccess.user_id == target_id).all()}
        manager_companies = {x[0] for x in db.query(UserCompanyAccess.company_id).filter(UserCompanyAccess.user_id == manager_user_id).all()}
        if target_companies and not (target_companies & manager_companies): raise HTTPException(422, "المدير المباشر خارج نطاق شركات المستخدم")
    try: new_role = RoleEnum(role)
    except ValueError: raise HTTPException(422, "دور غير صالح")
    code = employee_code.strip() or None
    if code and db.query(User).filter(User.employee_code == code, User.id != target_id).first(): raise HTTPException(409, "كود الموظف مستخدم بالفعل")
    target.full_name = full_name.strip(); target.employee_code = code; target.job_title = job_title.strip() or None; target.department = department.strip() or None; target.manager_user_id = manager_user_id
    target.email = email.strip() or None; target.phone = phone.strip() or None; target.role = new_role
    if target.id != user.id: target.is_active = (is_active == "on")
    if password:
        validate_password_policy(password); target.password_hash = hash_password(password)
    db.commit()
    revoke_user_access_tokens(target.id)
    return RedirectResponse(url="/users", status_code=303)


PERMISSION_CODE_MAP = {
    "accounting": ["journal:view", "journal:create", "journal:post", "journal:reverse"],
    "sales": ["sales:view", "sales:create", "sales:edit", "sales:post", "sales:cancel", "sales:reverse"],
    "purchases": ["purchases:view", "purchases:create", "purchases:edit", "purchases:post", "purchases:cancel", "purchases:reverse"],
    "inventory": ["inventory:view", "inventory:create", "inventory:edit", "inventory:adjust", "inventory:transfer", "inventory:post"],
    "reports": ["reports:view"],
    "construction": ["construction:view", "construction:manage", "construction:approve", "project:scope"],
    "documents": ["documents:view", "documents:create", "documents:edit", "documents:approve"],
    "hr": ["hr:view", "hr:create", "hr:edit", "hr:approve", "hr:payroll", "hr:access", "hr:documents"],
}

def _sync_custom_governance_role(db, target_id: int, permission_codes: set[str]):
    target = db.get(User, target_id)
    if not target: raise HTTPException(404, "المستخدم مش موجود")
    role = db.query(Role).filter(Role.code == f"user_custom_{target_id}").first()
    if not role:
        role = Role(code=f"user_custom_{target_id}", name=f"صلاحيات مخصصة - {target.full_name}", is_system=False, is_active=True)
        db.add(role); db.flush()
    role.name = f"صلاحيات مخصصة - {target.full_name}"; role.is_active = True
    db.query(UserRole).filter(UserRole.user_id == target_id, UserRole.role_id == role.id).update({"is_active": False}, synchronize_session=False)
    existing_assignment = db.query(UserRole).filter_by(user_id=target_id, role_id=role.id, company_id=None, branch_id=None).first()
    if existing_assignment:
        existing_assignment.is_active = True
    else:
        db.add(UserRole(user_id=target_id, role_id=role.id, company_id=None, branch_id=None, is_active=True))
    db.query(RolePermission).filter(RolePermission.role_id == role.id).delete(synchronize_session=False)
    if permission_codes:
        perms = db.query(Permission).filter(Permission.code.in_(sorted(permission_codes)), Permission.is_active.is_(True)).all()
        db.add_all([RolePermission(role_id=role.id, permission_id=p.id) for p in perms])


def _governance_codes_from_modules(db, target_id: int):
    codes=set()
    for p in db.query(ModulePermission).filter_by(user_id=target_id).all():
        if not p.can_view and not p.can_edit: continue
        mapped=PERMISSION_CODE_MAP.get(p.module_key, [])
        if p.can_view:
            codes.update([c for c in mapped if c.endswith(":view")])
        if p.can_edit:
            codes.update([c for c in mapped if not c.endswith(":view")])
            # Editing a module grants its operational actions, but not admin/security actions.
            if p.module_key == "construction": codes.add("construction:approve")
            if p.module_key == "documents": codes.add("documents:approve")
    return codes

PERMISSION_PRESETS = {
    "engineer": {"construction": (True, True), "inventory": (True, False), "reports": (True, False), "documents": (True, True)},
    "supervisor": {"construction": (True, True), "inventory": (True, True), "reports": (True, False), "documents": (True, True)},
    "finance": {"accounting": (True, True), "reports": (True, True), "sales": (True, False), "purchases": (True, False)},
    "procurement": {"purchases": (True, True), "inventory": (True, True), "reports": (True, False)},
    "hr": {"hr": (True, True), "reports": (True, False)},
    "warehouse": {"inventory": (True, True), "purchases": (True, False), "reports": (True, False)},
    "project_manager": {"construction": (True, True), "reports": (True, True), "inventory": (True, False), "purchases": (True, False), "documents": (True, True)},
    "viewer": {m[0]: (True, False) for m in MODULES},
}

@router.post("/users/{target_id}/permissions/preset")
def apply_permission_preset(target_id: int, preset: str = Form(...), db: Session = Depends(get_db), user: User = Depends(require_permission("admin:permissions"))):
    target = db.get(User, target_id)
    if not target: raise HTTPException(404, "المستخدم مش موجود")
    rules = PERMISSION_PRESETS.get(preset)
    if rules is None: raise HTTPException(422, "Preset غير صالح")
    for module_key, _ in MODULES:
        can_view, can_edit = rules.get(module_key, (False, False))
        perm = db.query(ModulePermission).filter_by(user_id=target_id, module_key=module_key).first()
        if not perm:
            perm = ModulePermission(user_id=target_id, module_key=module_key); db.add(perm)
        perm.can_view, perm.can_edit = can_view, can_edit
    _sync_custom_governance_role(db, target_id, _governance_codes_from_modules(db, target_id))
    db.commit()
    revoke_user_access_tokens(target_id)
    return RedirectResponse(url="/users", status_code=303)


@router.post("/users/{target_id}/permissions")
async def update_permissions(target_id: int, request: Request, db: Session = Depends(get_db),
                               user: User = Depends(require_permission("admin:permissions"))):
    target = db.query(User).filter(User.id == target_id).first()
    if not target:
        raise HTTPException(status_code=404, detail="المستخدم مش موجود")

    form = await request.form()
    for module_key, _ in MODULES:
        can_view = form.get(f"view_{module_key}") == "on"
        can_edit = form.get(f"edit_{module_key}") == "on"
        perm = db.query(ModulePermission).filter_by(user_id=target_id, module_key=module_key).first()
        if not perm:
            perm = ModulePermission(user_id=target_id, module_key=module_key)
            db.add(perm)
        perm.can_view = can_view or can_edit  # التعديل يستلزم صلاحية العرض تلقائيًا
        perm.can_edit = can_edit
    _sync_custom_governance_role(db, target_id, _governance_codes_from_modules(db, target_id))
    db.commit()
    revoke_user_access_tokens(target_id)
    return RedirectResponse(url="/users", status_code=303)


@router.post("/users/{target_id}/governance-permissions")
async def update_governance_permissions(target_id: int, request: Request, db: Session = Depends(get_db), user: User = Depends(require_permission("admin:permissions"))):
    target = db.get(User, target_id)
    if not target: raise HTTPException(404, "المستخدم مش موجود")
    form = await request.form()
    codes = {p.code for p in db.query(Permission).filter(Permission.is_active.is_(True)).all() if form.get(f"perm_{p.code.replace(':', '_')}") == "on"}
    _sync_custom_governance_role(db, target_id, codes)
    db.commit()
    revoke_user_access_tokens(target_id)
    return RedirectResponse(url="/users", status_code=303)


@router.post("/users/{target_id}/scope")
def add_user_scope(target_id: int, company_id: int | None = Form(None), branch_id: int | None = Form(None), project_id: int | None = Form(None), site_id: int | None = Form(None), can_view: str = Form("on"), can_edit: str = Form(""), can_approve: str = Form(""), db: Session = Depends(get_db), user: User = Depends(require_permission("admin:permissions"))):
    target = db.get(User, target_id)
    if not target: raise HTTPException(404, "المستخدم مش موجود")
    if company_id is None and branch_id is None and project_id is None and site_id is None:
        raise HTTPException(422, "حدد نطاقًا واحدًا على الأقل")
    if branch_id is not None:
        branch = db.get(Branch, branch_id)
        if not branch or not branch.is_active or (company_id is not None and branch.company_id != company_id): raise HTTPException(422, "الفرع غير صالح")
        company_id = branch.company_id
    if project_id is not None:
        project = db.get(Project, project_id)
        if not project or (company_id is not None and project.company_id != company_id): raise HTTPException(422, "المشروع غير صالح")
        company_id = project.company_id
        if branch_id is not None and project.branch_id not in (None, branch_id): raise HTTPException(422, "المشروع لا يتبع الفرع المحدد")
    if site_id is not None:
        site = db.get(ConstructionSite, site_id)
        if not site or (project_id is not None and site.project_id != project_id): raise HTTPException(422, "الموقع غير صالح")
        if project_id is None: project_id = site.project_id
        project = db.get(Project, project_id); company_id = project.company_id
    existing = db.query(UserScope).filter_by(user_id=target_id, company_id=company_id, branch_id=branch_id, project_id=project_id, site_id=site_id).first()
    if existing:
        existing.can_view = can_view == "on"; existing.can_edit = can_edit == "on"; existing.can_approve = can_approve == "on"
    else:
        db.add(UserScope(user_id=target_id, company_id=company_id, branch_id=branch_id, project_id=project_id, site_id=site_id, can_view=can_view == "on", can_edit=can_edit == "on", can_approve=can_approve == "on"))
    db.commit()
    return RedirectResponse(url="/users", status_code=303)


@router.post("/users/{target_id}/scope/{scope_id}/delete")
def delete_user_scope(target_id: int, scope_id: int, db: Session = Depends(get_db), user: User = Depends(require_permission("admin:permissions"))):
    scope = db.query(UserScope).filter(UserScope.id == scope_id, UserScope.user_id == target_id).first()
    if not scope: raise HTTPException(404, "نطاق الوصول غير موجود")
    db.delete(scope); db.commit()
    return RedirectResponse(url="/users", status_code=303)
