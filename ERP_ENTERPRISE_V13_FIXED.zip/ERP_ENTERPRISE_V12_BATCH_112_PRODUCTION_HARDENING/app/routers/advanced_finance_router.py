from ..time_utils import utcnow
# -*- coding: utf-8 -*-
import datetime
from decimal import Decimal, InvalidOperation
from fastapi import APIRouter, Depends, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import func
from sqlalchemy.exc import IntegrityError
import csv
import io

from ..database import get_db
from ..models import (User, ModulePermission, FinanceVoucher, Customer, Supplier,
                      SaleInvoice, PurchaseOrder, PaymentAllocation, BankReconciliation,
                      Account, AccountTypeEnum, JournalLine, JournalEntry, AuditLog, BankReconciliationItem)
from ..accounting import next_number, create_entry
from ..auth import require_module
from ..governance import get_request_context
from ..financial_reporting import profit_and_loss
from ..enterprise_models import Branch, UserCompanyAccess

router = APIRouter(prefix="/advanced-finance", tags=["advanced-finance"])
templates = Jinja2Templates(directory="templates")


def money(v):
    return Decimal(str(v or 0)).quantize(Decimal("0.01"))

# اختصار موحّد للأرقام العشرية لتفادي أخطاء التقريب وNameError في مسارات المدفوعات.
D = Decimal


def can_edit(db, user):
    if user.role.value == "admin": return True
    p = db.query(ModulePermission).filter_by(user_id=user.id, module_key="accounting").first()
    return bool(p and p.can_edit)


def scope(db):
    ctx=get_request_context(); cid=ctx.get("company_id"); bid=ctx.get("branch_id")
    if cid is None: raise HTTPException(403,"لم يتم تحديد الشركة الحالية")
    return cid,bid

def invoice_paid(db, invoice_id):
    return money(db.query(func.coalesce(func.sum(PaymentAllocation.amount), 0)).filter(
        PaymentAllocation.sale_invoice_id == invoice_id).scalar() or 0)


def po_paid(db, po_id):
    return money(db.query(func.coalesce(func.sum(PaymentAllocation.amount), 0)).filter(
        PaymentAllocation.purchase_order_id == po_id).scalar() or 0)


@router.get("/ar", response_class=HTMLResponse)
def ar(request: Request, db: Session = Depends(get_db), user: User = Depends(require_module("accounting"))):
    cid,bid=scope(db)
    iq=db.query(SaleInvoice).filter(SaleInvoice.company_id==cid)
    if bid is not None: iq=iq.filter(SaleInvoice.branch_id==bid)
    invoices = iq.order_by(SaleInvoice.invoice_date.desc()).limit(500).all()
    rows=[]
    total=paid=due=0
    for inv in invoices:
        t=money(inv.total); p=invoice_paid(db, inv.id); d=money(max(t-p,0))
        if d > 0:
            rows.append({"invoice":inv,"total":t,"paid":p,"due":d})
            total += t; paid += p; due += d
    return templates.TemplateResponse(request,"ar_aging.html",{"user":user,"rows":rows,"total":money(total),"paid":money(paid),"due":money(due),"can_edit":can_edit(db,user)})


@router.get("/ap", response_class=HTMLResponse)
def ap(request: Request, db: Session = Depends(get_db), user: User = Depends(require_module("accounting"))):
    """Compatibility entry point: AP is invoice/subledger based, not PO based."""
    return RedirectResponse("/accounting/reports/ap-aging", status_code=307)


def _parse_statement_date(value: str | None, end_of_day: bool = False):
    if not value:
        return None
    try:
        dt = datetime.datetime.fromisoformat(value)
        if end_of_day and len(value) == 10:
            dt = dt.replace(hour=23, minute=59, second=59, microsecond=999999)
        return dt
    except ValueError:
        raise HTTPException(400, "صيغة التاريخ غير صحيحة")


def _statement_period_rows(rows, date_from=None, date_to=None, query="", transaction_type="all"):
    filtered = []
    q = (query or "").strip().lower()
    for row in rows:
        if date_from and row["date"] < date_from:
            continue
        if date_to and row["date"] > date_to:
            continue
        if transaction_type != "all" and row.get("type") != transaction_type:
            continue
        if q and q not in str(row.get("ref", "")).lower() and q not in str(row.get("description", "")).lower():
            continue
        filtered.append(row)
    return filtered


def _statement_summary(rows):
    total_debit = sum((money(r.get("debit", 0)) for r in rows), Decimal("0.00"))
    total_credit = sum((money(r.get("credit", 0)) for r in rows), Decimal("0.00"))
    return money(total_debit), money(total_credit)


def _statement_opening_balance(all_rows, date_from):
    """Return the actual balance immediately before the selected period."""
    if not date_from:
        return Decimal("0.00")
    prior = [r for r in all_rows if r.get("date") and r["date"] < date_from]
    return money(prior[-1]["balance"] if prior else 0)


def _customer_statement_rows(db, cid, bid, customer_id):
    iq = db.query(SaleInvoice).filter(
        SaleInvoice.company_id == cid,
        SaleInvoice.customer_id == customer_id,
    )
    if bid is not None:
        iq = iq.filter(SaleInvoice.branch_id == bid)

    rows = []
    invoice_count = 0
    for inv in iq.order_by(SaleInvoice.invoice_date, SaleInvoice.id).all():
        # لا نعرض الفواتير الملغاة كحركة مدينة في كشف الحساب.
        if str(inv.status or "").lower() in {"cancelled", "void", "draft"}:
            continue
        invoice_count += 1
        invoice_total = money(inv.total)
        rows.append({
            "date": inv.invoice_date,
            "ref": inv.invoice_number,
            "description": inv.notes or "فاتورة مبيعات",
            "debit": invoice_total,
            "credit": Decimal("0.00"),
            "type": "invoice",
            "type_label": "فاتورة مبيعات",
            "link": f"/sales/{inv.id}",
        })
        allocations = db.query(PaymentAllocation).filter(
            PaymentAllocation.company_id == cid,
            PaymentAllocation.sale_invoice_id == inv.id,
        ).all()
        for a in allocations:
            if bid is not None and a.branch_id not in (None, bid):
                continue
            voucher_number = a.voucher.voucher_number if a.voucher else "-"
            rows.append({
                "date": a.voucher.voucher_date if a.voucher else a.created_at,
                "ref": voucher_number,
                "description": (a.voucher.description if a.voucher and a.voucher.description else "سند قبض / تحصيل"),
                "debit": Decimal("0.00"),
                "credit": money(a.amount),
                "type": "payment",
                "type_label": "تحصيل",
                "link": None,
            })

    rows.sort(key=lambda r: (r["date"] or datetime.datetime.min, r["ref"] or ""))
    balance = Decimal("0.00")
    for r in rows:
        balance += money(r["debit"]) - money(r["credit"])
        r["balance"] = money(balance)
    return rows


def _supplier_statement_rows(db, cid, bid, supplier_id):
    oq = db.query(PurchaseOrder).filter(PurchaseOrder.company_id == cid, PurchaseOrder.supplier_id == supplier_id)
    if bid is not None:
        oq = oq.filter(PurchaseOrder.branch_id == bid)
    rows = []
    for po in oq.order_by(PurchaseOrder.order_date, PurchaseOrder.id).all():
        if not po.receipts:
            continue
        rows.append({
            "date": po.order_date, "ref": po.po_number, "description": po.notes or "مشتريات / أمر شراء مستلم",
            "debit": Decimal("0.00"), "credit": money(po.total), "type": "purchase",
            "type_label": "مشتريات", "link": f"/purchases/{po.id}"
        })
        for a in db.query(PaymentAllocation).filter(
            PaymentAllocation.company_id == cid,
            PaymentAllocation.purchase_order_id == po.id,
        ).all():
            if bid is not None and a.branch_id not in (None, bid):
                continue
            voucher_number = a.voucher.voucher_number if a.voucher else "-"
            rows.append({
                "date": a.voucher.voucher_date if a.voucher else a.created_at,
                "ref": voucher_number,
                "description": (a.voucher.description if a.voucher and a.voucher.description else "سداد للمورد"),
                "debit": money(a.amount), "credit": Decimal("0.00"), "type": "payment",
                "type_label": "سداد", "link": None
            })
    rows.sort(key=lambda r: (r["date"] or datetime.datetime.min, r["ref"] or ""))
    balance = Decimal("0.00")
    for r in rows:
        balance += money(r["credit"]) - money(r["debit"])
        r["balance"] = money(balance)
    return rows


def _statement_context(request, user, title, party, all_rows, rows, date_from, date_to, query, transaction_type):
    # الأرصدة المالية تحسب حسب الفترة فقط، ولا تتغير بسبب بحث نصي أو فلتر عرض.
    period_rows = _statement_period_rows(all_rows, date_from, date_to, "", "all")
    opening_balance = _statement_opening_balance(all_rows, date_from)
    period_debit, period_credit = _statement_summary(period_rows)
    is_supplier = "مورد" in title
    movement = period_credit - period_debit if is_supplier else period_debit - period_credit
    closing_balance = money(opening_balance + movement)

    displayed_debit, displayed_credit = _statement_summary(rows)
    total_invoices = sum(1 for r in all_rows if r.get("type") in {"invoice", "purchase"})
    total_collections = sum((money(r["credit"] if not is_supplier else r["debit"]) for r in period_rows if r.get("type") == "payment"), Decimal("0.00"))
    outstanding = closing_balance

    return {
        "user": user, "title": title, "party": party, "rows": rows,
        "opening_balance": opening_balance, "period_debit": period_debit,
        "period_credit": period_credit, "balance": closing_balance,
        "displayed_debit": money(displayed_debit), "displayed_credit": money(displayed_credit),
        "total_transactions": len(rows), "total_invoices": total_invoices,
        "total_collections": money(total_collections), "outstanding": money(outstanding),
        "has_transactions": bool(all_rows),
        "statement_status": ("settled" if closing_balance == 0 else ("credit" if closing_balance < 0 else "due")),
        "date_from": date_from.strftime("%Y-%m-%d") if date_from else "",
        "date_to": date_to.strftime("%Y-%m-%d") if date_to else "",
        "query": query or "", "transaction_type": transaction_type or "all",
    }


@router.get("/customer/{customer_id}", response_class=HTMLResponse)
def customer_statement(customer_id: int, request: Request, date_from: str = None, date_to: str = None, q: str = "", transaction_type: str = "all", db: Session = Depends(get_db), user: User = Depends(require_module("accounting"))):
    cid, bid = scope(db)
    customer = db.query(Customer).filter(Customer.id == customer_id, Customer.company_id == cid).first()
    if not customer:
        raise HTTPException(404, "العميل غير موجود")
    start = _parse_statement_date(date_from)
    end = _parse_statement_date(date_to, end_of_day=True)
    all_rows = _customer_statement_rows(db, cid, bid, customer_id)
    rows = _statement_period_rows(all_rows, start, end, q, transaction_type)
    ctx = _statement_context(request, user, "كشف حساب عميل", customer, all_rows, rows, start, end, q, transaction_type)
    ctx["party_kind"] = "customer"
    return templates.TemplateResponse(request, "party_statement_v2.html", ctx)


@router.get("/supplier/{supplier_id}", response_class=HTMLResponse)
def supplier_statement(supplier_id: int, request: Request, date_from: str = None, date_to: str = None, q: str = "", transaction_type: str = "all", db: Session = Depends(get_db), user: User = Depends(require_module("accounting"))):
    cid, bid = scope(db)
    supplier = db.query(Supplier).filter(Supplier.id == supplier_id, Supplier.company_id == cid).first()
    if not supplier:
        raise HTTPException(404, "المورد غير موجود")
    start = _parse_statement_date(date_from)
    end = _parse_statement_date(date_to, end_of_day=True)
    all_rows = _supplier_statement_rows(db, cid, bid, supplier_id)
    rows = _statement_period_rows(all_rows, start, end, q, transaction_type)
    ctx = _statement_context(request, user, "كشف حساب مورد", supplier, all_rows, rows, start, end, q, transaction_type)
    ctx["party_kind"] = "supplier"
    return templates.TemplateResponse(request, "party_statement_v2.html", ctx)


@router.get("/{party_kind}/{party_id}/statement/export/csv")
def export_party_statement_csv(party_kind: str, party_id: int, date_from: str = None, date_to: str = None, q: str = "", transaction_type: str = "all", db: Session = Depends(get_db), user: User = Depends(require_module("accounting"))):
    cid, bid = scope(db)
    start = _parse_statement_date(date_from)
    end = _parse_statement_date(date_to, end_of_day=True)
    if party_kind == "supplier":
        party = db.query(Supplier).filter(Supplier.id == party_id, Supplier.company_id == cid).first()
        if not party: raise HTTPException(404, "المورد غير موجود")
        all_rows = _supplier_statement_rows(db, cid, bid, party_id)
    elif party_kind == "customer":
        party = db.query(Customer).filter(Customer.id == party_id, Customer.company_id == cid).first()
        if not party: raise HTTPException(404, "العميل غير موجود")
        all_rows = _customer_statement_rows(db, cid, bid, party_id)
    else:
        raise HTTPException(404, "نوع الحساب غير صحيح")
    rows = _statement_period_rows(all_rows, start, end, q, transaction_type)
    def _csv_safe(value):
        # منع Formula Injection عند فتح الملف في Excel/LibreOffice.
        text = "" if value is None else str(value)
        return "'" + text if text[:1] in ("=", "+", "-", "@") else text

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["التاريخ", "المرجع", "البيان", "مدين", "دائن", "الرصيد"])
    for r in rows:
        writer.writerow([
            r["date"].strftime("%Y-%m-%d") if r["date"] else "",
            _csv_safe(r["ref"]),
            _csv_safe(r["description"]),
            f'{money(r["debit"]):.2f}',
            f'{money(r["credit"]):.2f}',
            f'{money(r["balance"]):.2f}'
        ])
    filename = f"statement_{party_kind}_{party_id}.csv"
    return StreamingResponse(iter(["\ufeff" + output.getvalue()]), media_type="text/csv; charset=utf-8", headers={"Content-Disposition": f'attachment; filename="{filename}"'})


def cash_accounts_for_scope(db,cid,bid=None):
    q=db.query(Account).filter(Account.company_id==cid,Account.is_active==True,Account.account_type==AccountTypeEnum.asset,Account.statement_section=="cash_and_equivalents")
    if bid is not None: q=q.filter((Account.branch_id==bid)|(Account.branch_id.is_(None)))
    return q.order_by(Account.branch_id.desc(),Account.code).all()

@router.get("/allocation/customer/{invoice_id}", response_class=HTMLResponse)
def customer_payment_form(invoice_id:int, request:Request, db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True))):
    cid,bid=scope(db)
    iq=db.query(SaleInvoice).filter(SaleInvoice.id==invoice_id,SaleInvoice.company_id==cid)
    if bid is not None: iq=iq.filter(SaleInvoice.branch_id==bid)
    inv=iq.first()
    if not inv: raise HTTPException(404,"الفاتورة غير موجودة")
    due=money(inv.total-invoice_paid(db,invoice_id))
    accounts=cash_accounts_for_scope(db,cid,bid)
    return templates.TemplateResponse(request,"allocation_form.html",{"user":user,"mode":"customer","document":inv,"due":due,"accounts":accounts})


@router.post("/allocation/customer/{invoice_id}")
def customer_payment(invoice_id:int, request:Request=None, db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True)),
                     amount:str=Form(...), account_code:str=Form("1100"), voucher_date:str=Form(""), description:str=Form("تحصيل من عميل")):
    cid,bid=scope(db)
    iq=db.query(SaleInvoice).filter(SaleInvoice.id==invoice_id,SaleInvoice.company_id==cid)
    if bid is not None: iq=iq.filter(SaleInvoice.branch_id==bid)
    inv=iq.first()
    if not inv: raise HTTPException(404,"الفاتورة غير موجودة")
    try: a=Decimal(amount)
    except InvalidOperation: raise HTTPException(400,"المبلغ غير صحيح")
    due=Decimal(str(money(inv.total-invoice_paid(db,invoice_id))))
    if a<=0 or a>due: raise HTTPException(400,f"المبلغ يجب ألا يتجاوز المتبقي {due}")
    dt=datetime.datetime.fromisoformat(voucher_date) if voucher_date else utcnow()
    v=FinanceVoucher(company_id=cid,branch_id=bid,voucher_number=next_number(db,"voucher","VCH"),voucher_type="receipt",voucher_date=dt,amount=money(a),description=description.strip(),account_code=account_code,party_type="customer",party_id=inv.customer_id,created_by_id=user.id)
    db.add(v); db.flush()
    create_entry(db,description.strip(),user.id,[(account_code,a,D(0)),("1200",D(0),a)],"finance_voucher",v.id,dt,company_id=cid,branch_id=bid)
    db.add(PaymentAllocation(company_id=cid,branch_id=bid,voucher_id=v.id,sale_invoice_id=inv.id,amount=money(a)))
    db.commit(); return RedirectResponse(f"/advanced-finance/customer/{inv.customer_id}",303)


@router.get("/allocation/supplier/{po_id}", response_class=HTMLResponse)
def supplier_payment_form(po_id:int, request:Request, db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True))):
    cid,bid=scope(db)
    oq=db.query(PurchaseOrder).filter(PurchaseOrder.id==po_id,PurchaseOrder.company_id==cid)
    if bid is not None: oq=oq.filter(PurchaseOrder.branch_id==bid)
    po=oq.first()
    if not po: raise HTTPException(404,"أمر الشراء غير موجود")
    due=money(po.total-po_paid(db,po_id))
    accounts=cash_accounts_for_scope(db,cid,bid)
    return templates.TemplateResponse(request,"allocation_form.html",{"user":user,"mode":"supplier","document":po,"due":due,"accounts":accounts})


@router.post("/allocation/supplier/{po_id}")
def supplier_payment(po_id:int, db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True)),
                     amount:str=Form(...), account_code:str=Form("1100"), voucher_date:str=Form(""), description:str=Form("سداد للمورد")):
    cid,bid=scope(db)
    oq=db.query(PurchaseOrder).filter(PurchaseOrder.id==po_id,PurchaseOrder.company_id==cid)
    if bid is not None: oq=oq.filter(PurchaseOrder.branch_id==bid)
    po=oq.first()
    if not po: raise HTTPException(404,"أمر الشراء غير موجود")
    if not po.receipts: raise HTTPException(400,"لا يمكن سداد أمر شراء قبل استلامه")
    try: a=Decimal(amount)
    except InvalidOperation: raise HTTPException(400,"المبلغ غير صحيح")
    due=Decimal(str(money(po.total-po_paid(db,po_id))))
    if a<=0 or a>due: raise HTTPException(400,f"المبلغ يجب ألا يتجاوز المتبقي {due}")
    dt=datetime.datetime.fromisoformat(voucher_date) if voucher_date else utcnow()
    v=FinanceVoucher(company_id=cid,branch_id=bid,voucher_number=next_number(db,"voucher","VCH"),voucher_type="payment",voucher_date=dt,amount=money(a),description=description.strip(),account_code=account_code,party_type="supplier",party_id=po.supplier_id,created_by_id=user.id)
    db.add(v); db.flush()
    create_entry(db,description.strip(),user.id,[("2100",a,D(0)),(account_code,D(0),a)],"finance_voucher",v.id,dt,company_id=cid,branch_id=bid)
    db.add(PaymentAllocation(company_id=cid,branch_id=bid,voucher_id=v.id,purchase_order_id=po.id,amount=money(a)))
    db.commit(); return RedirectResponse(f"/advanced-finance/supplier/{po.supplier_id}",303)


@router.get("/bank-reconciliation", response_class=HTMLResponse)
def bank_reconciliation(request:Request, db:Session=Depends(get_db), user:User=Depends(require_module("accounting"))):
    cid,bid=scope(db)
    rq=db.query(BankReconciliation).filter(BankReconciliation.company_id==cid)
    if bid is not None: rq=rq.filter(BankReconciliation.branch_id==bid)
    recs=rq.order_by(BankReconciliation.statement_date.desc()).limit(500).all()
    for rec in recs:
        _recalculate_bank_reconciliation(db, rec)
    db.commit()
    open_count=sum(1 for r in recs if r.status == "open")
    closed_count=sum(1 for r in recs if r.status == "closed")
    exception_count=sum(1 for r in recs if abs(Decimal(str(r.difference or 0))) > Decimal("0.005"))
    return templates.TemplateResponse(request,"bank_reconciliation.html",{
        "user":user,"recs":recs,"can_edit":can_edit(db,user),
        "open_count":open_count,"closed_count":closed_count,"exception_count":exception_count,
    })


@router.get("/bank-reconciliation/new", response_class=HTMLResponse)
def bank_rec_form(request:Request, db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True))):
    cid,bid=scope(db)
    aq=db.query(Account).filter(Account.company_id==cid,Account.is_active.is_(True),Account.statement_section=="cash_and_equivalents")
    if bid is not None: aq=aq.filter((Account.branch_id==bid)|(Account.branch_id.is_(None)))
    accounts=aq.order_by(Account.code).all()
    return templates.TemplateResponse(request,"bank_reconciliation_form.html",{"user":user,"accounts":accounts})


def _bank_rec_scope_query(db, cid, bid, rec_id=None, open_only=False):
    q = db.query(BankReconciliation).filter(BankReconciliation.company_id == cid)
    if rec_id is not None:
        q = q.filter(BankReconciliation.id == rec_id)
    if bid is not None:
        q = q.filter(BankReconciliation.branch_id == bid)
    if open_only:
        q = q.filter(BankReconciliation.status == "open")
    return q


def _find_bank_match_candidates(db, rec, item, cid, bid):
    """Return unused posted GL lines that exactly match a statement item.

    Matching is intentionally deterministic and tenant/branch scoped. The caller
    must refuse ambiguous matches instead of silently choosing an arbitrary line.
    """
    sign = JournalLine.debit - JournalLine.credit if item.direction == "credit" else JournalLine.credit - JournalLine.debit
    window_start = item.transaction_date - datetime.timedelta(days=7)
    window_end = min(item.transaction_date + datetime.timedelta(days=7), rec.statement_date)
    q=(db.query(JournalLine).join(JournalEntry,JournalEntry.id==JournalLine.entry_id)
       .filter(JournalLine.company_id==cid,JournalEntry.company_id==cid,JournalEntry.status=="posted",
               JournalLine.account_id==rec.bank_account_id,
               func.abs(sign-item.amount) <= Decimal("0.005"),
               JournalEntry.entry_date >= window_start,
               JournalEntry.entry_date <= window_end))
    if bid is not None:
        q=q.filter(JournalEntry.branch_id==bid,JournalLine.branch_id==bid)
    used_ids = db.query(BankReconciliationItem.matched_journal_line_id).filter(
        BankReconciliationItem.company_id == cid,
        BankReconciliationItem.matched_journal_line_id.isnot(None),
        BankReconciliationItem.status == "matched",
    ).all()
    used_ids = {row[0] for row in used_ids}
    candidates=q.order_by(JournalEntry.entry_date.asc(),JournalLine.id.asc()).all()
    return [x for x in candidates if x.id not in used_ids]


def _find_bank_match_candidate(db, rec, item, cid, bid):
    candidates = _find_bank_match_candidates(db, rec, item, cid, bid)
    return candidates[0] if len(candidates) == 1 else None

def _recalculate_bank_reconciliation(db, rec):
    """Recompute book and adjusted-bank difference from authoritative posted GL + statement items."""
    account_id = rec.bank_account_id
    if not account_id:
        account = db.query(Account).filter(Account.company_id == rec.company_id,
                                           Account.code == rec.bank_account_code,
                                           Account.is_active.is_(True)).first()
        if not account:
            raise HTTPException(400, "حساب البنك غير موجود أو غير نشط")
        account_id = account.id
        rec.bank_account_id = account.id

    q = (db.query(func.coalesce(func.sum(JournalLine.debit - JournalLine.credit), 0))
         .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
         .filter(JournalEntry.company_id == rec.company_id,
                 JournalLine.company_id == rec.company_id,
                 JournalLine.account_id == account_id,
                 JournalEntry.status == "posted",
                 JournalEntry.entry_date <= rec.statement_date))
    if rec.branch_id is not None:
        q = q.filter(JournalEntry.branch_id == rec.branch_id,
                     JournalLine.branch_id == rec.branch_id)
    book = Decimal(str(q.scalar() or 0))
    statement_adjustments = db.query(func.coalesce(func.sum(
        __import__('sqlalchemy').case((BankReconciliationItem.direction == "credit", BankReconciliationItem.amount),
                                       else_=-BankReconciliationItem.amount)), 0)).filter(
        BankReconciliationItem.company_id == rec.company_id,
        BankReconciliationItem.reconciliation_id == rec.id,
        BankReconciliationItem.status != "matched",
    ).scalar() or 0
    adjusted_book = book + Decimal(str(statement_adjustments))
    rec.book_balance = money(book)
    rec.difference = money(Decimal(str(rec.statement_balance)) - adjusted_book)
    return rec


@router.post("/bank-reconciliation/new")
def create_bank_rec(db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True)),
                    statement_date:str=Form(...), statement_balance:str=Form(...), notes:str=Form(""), bank_account_id:int=Form(0)):
    try:
        sd=datetime.datetime.fromisoformat(statement_date)
        sb=Decimal(statement_balance)
    except (ValueError,InvalidOperation):
        raise HTTPException(400,"بيانات التسوية غير صحيحة")
    if not sb.is_finite(): raise HTTPException(422,"رصيد كشف البنك يجب أن يكون رقمًا صالحًا")
    cid,bid=scope(db)
    aq=db.query(Account).filter(Account.company_id==cid, Account.is_active.is_(True),
                                Account.statement_section=="cash_and_equivalents")
    if bank_account_id:
        aq=aq.filter(Account.id==bank_account_id)
    else:
        aq=aq.filter(Account.code=="1110")
    if bid is not None:
        aq=aq.filter((Account.branch_id==bid)|(Account.branch_id.is_(None)))
    bank=aq.order_by(Account.branch_id.desc()).first()
    if not bank: raise HTTPException(400,"حساب البنك غير موجود أو غير متاح ضمن النطاق الحالي")
    notes = notes.strip()
    if len(notes) > 255:
        raise HTTPException(422, "الملاحظات تتجاوز الحد المسموح")
    duplicate_q = db.query(BankReconciliation).filter(
        BankReconciliation.company_id == cid,
        BankReconciliation.bank_account_id == bank.id,
        BankReconciliation.statement_date == sd,
    )
    if bid is not None:
        duplicate_q = duplicate_q.filter(BankReconciliation.branch_id == bid)
    else:
        duplicate_q = duplicate_q.filter(BankReconciliation.branch_id.is_(None))
    if duplicate_q.first():
        raise HTTPException(409, "توجد تسوية بالفعل لنفس حساب البنك وتاريخ الكشف")
    rec=BankReconciliation(company_id=cid,branch_id=bid,reconciliation_number=next_number(db,"bank_reconciliation","BR"),
                           bank_account_code=bank.code,bank_account_id=bank.id,statement_date=sd,
                           statement_balance=money(sb),book_balance=money(0),difference=money(0),notes=notes or None,created_by_id=user.id)
    db.add(rec); db.flush(); _recalculate_bank_reconciliation(db,rec)
    db.add(AuditLog(user_id=user.id,action="create",entity_type="bank_reconciliation",entity_id=rec.id,
                    description=f"إنشاء تسوية بنك {rec.reconciliation_number}"))
    db.commit(); return RedirectResponse("/advanced-finance/bank-reconciliation",303)


@router.get("/bank-reconciliation/{rec_id}", response_class=HTMLResponse)
def bank_rec_detail(rec_id:int, request:Request, db:Session=Depends(get_db), user:User=Depends(require_module("accounting"))):
    cid,bid=scope(db)
    rec=_bank_rec_scope_query(db,cid,bid,rec_id).first()
    if not rec: raise HTTPException(404,"التسوية غير موجودة")
    _recalculate_bank_reconciliation(db,rec)
    db.commit()
    adjusted_book = money(Decimal(str(rec.book_balance or 0)) + sum(
        (Decimal(str(i.amount)) if i.direction == "credit" else -Decimal(str(i.amount)))
        for i in rec.items if i.status != "matched"
    ))
    unmatched_count = sum(1 for i in rec.items if i.status != "matched")
    return templates.TemplateResponse(request,"bank_reconciliation_detail.html",{
        "user":user,"rec":rec,"items":rec.items,"can_edit":can_edit(db,user),
        "adjusted_book":adjusted_book,"unmatched_count":unmatched_count,
    })

@router.post("/bank-reconciliation/{rec_id}/items")
def add_bank_item(rec_id:int, db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True)),
                  transaction_date:str=Form(...), reference:str=Form(""), description:str=Form(""), amount:Decimal=Form(...), direction:str=Form("credit")):
    cid,bid=scope(db)
    rec=_bank_rec_scope_query(db,cid,bid,rec_id,open_only=True).first()
    if not rec: raise HTTPException(404,"التسوية غير موجودة أو مغلقة")
    try: dt=datetime.datetime.fromisoformat(transaction_date)
    except ValueError: raise HTTPException(422,"تاريخ الحركة غير صحيح")
    if dt > rec.statement_date: raise HTTPException(422,"تاريخ حركة الكشف لا يمكن أن يتجاوز تاريخ الكشف")
    try: amount=Decimal(str(amount))
    except InvalidOperation: raise HTTPException(422,"المبلغ غير صحيح")
    if not amount.is_finite(): raise HTTPException(422,"المبلغ يجب أن يكون رقمًا صالحًا")
    reference = reference.strip()
    description = description.strip()
    if len(reference) > 100 or len(description) > 255:
        raise HTTPException(422,"المرجع أو البيان يتجاوز الحد المسموح")
    if amount<=0 or direction not in ("debit","credit"): raise HTTPException(400,"بيانات حركة البنك غير صحيحة")
    item=BankReconciliationItem(company_id=rec.company_id,branch_id=rec.branch_id,reconciliation_id=rec.id,
                                transaction_date=dt,reference=reference or None,description=description or None,
                                amount=money(amount),direction=direction)
    db.add(item); db.flush(); _recalculate_bank_reconciliation(db,rec)
    db.add(AuditLog(user_id=user.id,action="create",entity_type="bank_reconciliation_item",entity_id=item.id,
                    description=f"إضافة حركة كشف للتسوية {rec.reconciliation_number}"))
    db.commit(); return RedirectResponse(f"/advanced-finance/bank-reconciliation/{rec.id}",303)

@router.post("/bank-reconciliation/{rec_id}/items/{item_id}/match")
def match_bank_item(rec_id:int,item_id:int,db:Session=Depends(get_db),user:User=Depends(require_module("accounting",need_edit=True))):
    cid,bid=scope(db)
    rec=_bank_rec_scope_query(db,cid,bid,rec_id,open_only=True).first()
    if not rec: raise HTTPException(404,"التسوية غير موجودة أو مغلقة")
    item=db.query(BankReconciliationItem).filter(BankReconciliationItem.id==item_id,
        BankReconciliationItem.reconciliation_id==rec.id,BankReconciliationItem.company_id==cid).first()
    if not item: raise HTTPException(404,"حركة الكشف غير موجودة")
    if item.status=="matched": raise HTTPException(400,"الحركة تمت مطابقتها بالفعل")
    candidates = _find_bank_match_candidates(db, rec, item, cid, bid)
    if not candidates:
        raise HTTPException(404,"لم يتم العثور على حركة محاسبية مطابقة بالمبلغ والنطاق والتاريخ")
    if len(candidates) > 1:
        raise HTTPException(409,"توجد أكثر من حركة محاسبية محتملة؛ لا يمكن إجراء مطابقة تلقائية آمنة")
    candidate = candidates[0]
    item.matched_journal_line_id=candidate.id; item.status="matched"
    db.add(AuditLog(user_id=user.id,action="match",entity_type="bank_reconciliation_item",entity_id=item.id,
                    description=f"مطابقة حركة كشف مع القيد {candidate.entry_id}"))
    db.commit(); return RedirectResponse(f"/advanced-finance/bank-reconciliation/{rec.id}",303)

@router.post("/bank-reconciliation/{rec_id}/items/{item_id}/unmatch")
def unmatch_bank_item(rec_id:int,item_id:int,db:Session=Depends(get_db),user:User=Depends(require_module("accounting",need_edit=True))):
    cid,bid=scope(db)
    rec=_bank_rec_scope_query(db,cid,bid,rec_id,open_only=True).first()
    if not rec: raise HTTPException(404,"التسوية غير موجودة أو مغلقة")
    item=db.query(BankReconciliationItem).filter(
        BankReconciliationItem.id==item_id,
        BankReconciliationItem.reconciliation_id==rec.id,
        BankReconciliationItem.company_id==cid).first()
    if not item: raise HTTPException(404,"حركة الكشف غير موجودة")
    if item.status != "matched" or item.matched_journal_line_id is None:
        raise HTTPException(400,"الحركة غير مطابقة بالفعل")
    matched_line_id=item.matched_journal_line_id
    item.matched_journal_line_id=None
    item.status="unmatched"
    db.add(AuditLog(user_id=user.id,action="unmatch",entity_type="bank_reconciliation_item",entity_id=item.id,
                    description=f"إلغاء مطابقة حركة كشف {item.id} مع القيد {matched_line_id} في التسوية {rec.reconciliation_number}"))
    db.commit()
    return RedirectResponse(f"/advanced-finance/bank-reconciliation/{rec.id}",303)


@router.post("/bank-reconciliation/{rec_id}/close")
def close_bank_rec(rec_id:int, db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True))):
    cid,bid=scope(db)
    rec=_bank_rec_scope_query(db,cid,bid,rec_id).first()
    if not rec: raise HTTPException(404,"التسوية غير موجودة")
    if rec.status=="closed": raise HTTPException(400,"التسوية مغلقة بالفعل")
    _recalculate_bank_reconciliation(db,rec)
    if abs(rec.difference)>Decimal("0.005"): raise HTTPException(400,"لا يمكن إغلاق التسوية قبل تصفير الفرق بين كشف البنك والدفاتر")
    unmatched=db.query(BankReconciliationItem).filter(BankReconciliationItem.reconciliation_id==rec.id,
        BankReconciliationItem.company_id==cid,BankReconciliationItem.status!="matched").count()
    if unmatched: raise HTTPException(400,"لا يمكن إغلاق التسوية مع وجود حركات كشف غير مطابقة")
    rec.status="closed"; rec.closed_at=utcnow()
    db.add(AuditLog(user_id=user.id,action="close",entity_type="bank_reconciliation",entity_id=rec.id,
                    description=f"إغلاق تسوية بنك {rec.reconciliation_number}"))
    db.commit(); return RedirectResponse("/advanced-finance/bank-reconciliation",303)


@router.get("/reports/profitability", response_class=HTMLResponse, operation_id="advanced_profitability_report")
def profitability(request:Request, start_date:str="", end_date:str="", branch_id:int|None=None, db:Session=Depends(get_db), user:User=Depends(require_module("reports"))):
    """Authoritative profitability report.

    The old implementation hard-coded account codes 4100/5100, ignored tenant/branch
    scope and date filters, and could therefore produce materially wrong results.
    This report now derives from the same posted-entry P&L engine used by the
    financial reporting center, keeping profitability reconciled with the GL.
    """
    cid, scoped_bid = scope(db)
    if branch_id is not None:
        # Branch selection must be validated against the current tenant/access scope.
        requested = int(branch_id)
        access = db.query(UserCompanyAccess).filter(
            UserCompanyAccess.user_id == user.id,
            UserCompanyAccess.company_id == cid,
            UserCompanyAccess.branch_id == requested,
        ).first()
        if user.role.value != "admin" and not access:
            # A company-wide access grant (branch_id NULL) permits selecting any active branch.
            company_access = db.query(UserCompanyAccess).filter(
                UserCompanyAccess.user_id == user.id,
                UserCompanyAccess.company_id == cid,
                UserCompanyAccess.branch_id.is_(None),
            ).first()
            if not company_access:
                raise HTTPException(403, "لا تملك صلاحية عرض هذا الفرع")
        branch = db.query(Branch).filter(Branch.id == requested, Branch.company_id == cid, Branch.is_active.is_(True)).first()
        if not branch:
            raise HTTPException(404, "الفرع غير موجود أو غير نشط")
        scoped_bid = requested

    today = datetime.date.today()
    try:
        start = datetime.date.fromisoformat(start_date) if start_date else today.replace(month=1, day=1)
        end = datetime.date.fromisoformat(end_date) if end_date else today
    except (TypeError, ValueError):
        raise HTTPException(422, "صيغة التاريخ غير صحيحة؛ استخدم YYYY-MM-DD")
    if start > end:
        raise HTTPException(422, "تاريخ البداية يجب ألا يتجاوز تاريخ النهاية")

    report = profit_and_loss(db, cid, start, end, scoped_bid)
    revenue = money(report["revenue_total"])
    cogs = money(sum((r["amount"] for r in report["expense_lines"] if r["statement_section"] == "cost_of_sales"), Decimal("0")))
    operating_expenses = money(report["operating_expenses"])
    gross = money(report["gross_profit"])
    operating_profit = money(report["operating_profit"])
    net_profit = money(report["net_profit"])

    def pct(value, base):
        return (value / base * Decimal("100")).quantize(Decimal("0.01")) if base else Decimal("0.00")

    branches = db.query(Branch).filter(Branch.company_id == cid, Branch.is_active.is_(True))
    if user.role.value != "admin" and not db.query(UserCompanyAccess).filter(
        UserCompanyAccess.user_id == user.id, UserCompanyAccess.company_id == cid, UserCompanyAccess.branch_id.is_(None)).first():
        allowed_ids = [x.branch_id for x in db.query(UserCompanyAccess).filter(
            UserCompanyAccess.user_id == user.id, UserCompanyAccess.company_id == cid, UserCompanyAccess.branch_id.is_not(None)).all()]
        branches = branches.filter(Branch.id.in_(allowed_ids)) if allowed_ids else branches.filter(Branch.id == -1)
    branches = branches.order_by(Branch.name).all()

    metrics = [
        {"label":"إجمالي الإيرادات", "value":revenue, "class":"revenue"},
        {"label":"تكلفة المبيعات", "value":cogs, "class":"cost"},
        {"label":"مجمل الربح", "value":gross, "class":"profit", "pct":pct(gross, revenue)},
        {"label":"المصروفات التشغيلية", "value":operating_expenses, "class":"cost"},
        {"label":"صافي الربح", "value":net_profit, "class":"net", "pct":pct(net_profit, revenue)},
    ]
    return templates.TemplateResponse(request, "profitability.html", {
        "user":user, "report":report, "metrics":metrics, "revenue":revenue, "cogs":cogs,
        "gross":gross, "operating_expenses":operating_expenses, "operating_profit":operating_profit,
        "net_profit":net_profit, "gross_margin_pct":pct(gross, revenue), "net_margin_pct":pct(net_profit, revenue),
        "start_date":start, "end_date":end, "branch_id":scoped_bid, "branches":branches, "section":"accounting",
    })
