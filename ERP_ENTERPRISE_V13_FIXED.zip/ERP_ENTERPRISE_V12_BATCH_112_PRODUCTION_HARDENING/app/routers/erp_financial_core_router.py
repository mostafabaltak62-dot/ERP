from datetime import date
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from sqlalchemy import func
from ..database import get_db
from ..models import User, Account, AccountTypeEnum, JournalLine, JournalEntry, CostCenter
from ..enterprise_models import Budget, BudgetLine, Project, ProjectCost, ProjectForecast, Contract
from ..financial_reporting import budget_vs_actual
from ..governance import require_permission, get_tenant_context

router=APIRouter(prefix="/api/v1/financial-core", tags=["ERP Financial Core"])

class CostCenterIn(BaseModel):
    code:str=Field(min_length=2,max_length=40); name:str=Field(min_length=2,max_length=150); branch_id:int|None=None; parent_id:int|None=None
class BudgetIn(BaseModel):
    code:str=Field(min_length=2,max_length=50); name:str=Field(min_length=2,max_length=180); fiscal_year:int=Field(ge=2000,le=2200); scenario:str=Field(default="baseline",min_length=2,max_length=30); currency_id:int|None=None
class BudgetLineIn(BaseModel):
    account_id:int; cost_center_id:int|None=None; project_id:int|None=None; period:int=Field(ge=1,le=12); budget_amount:Decimal; forecast_amount:Decimal|None=None

@router.post("/cost-centers",status_code=201)
def create_cost_center(data:CostCenterIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("core:manage"))):
    cid=ctx["company_id"]
    if data.parent_id and not db.query(CostCenter).filter_by(id=data.parent_id,company_id=cid).first(): raise HTTPException(422,"Invalid parent cost center")
    if db.query(CostCenter).filter_by(company_id=cid,code=data.code).first(): raise HTTPException(409,"Cost center code already exists")
    x=CostCenter(company_id=cid,branch_id=data.branch_id,code=data.code,name=data.name,parent_id=data.parent_id); db.add(x); db.commit(); db.refresh(x)
    return {"id":x.id,"code":x.code,"name":x.name}

@router.post("/budgets",status_code=201)
def create_budget(data:BudgetIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("core:manage"))):
    cid=ctx["company_id"]
    if db.query(Budget).filter_by(company_id=cid,code=data.code,scenario=data.scenario).first(): raise HTTPException(409,"Budget already exists")
    b=Budget(company_id=cid,branch_id=ctx.get("branch_id"),**data.model_dump()); db.add(b); db.commit(); db.refresh(b)
    return {"id":b.id,"code":b.code,"scenario":b.scenario,"status":b.status}

@router.post("/budgets/{budget_id}/lines",status_code=201)
def add_budget_line(budget_id:int,data:BudgetLineIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("core:manage"))):
    cid=ctx["company_id"]; b=db.query(Budget).filter_by(id=budget_id,company_id=cid).first()
    if not b: raise HTTPException(404,"Budget not found")
    a=db.query(Account).filter_by(id=data.account_id,company_id=cid,is_active=True).first()
    if not a: raise HTTPException(422,"Account does not belong to tenant or is inactive")
    if data.cost_center_id and not db.query(CostCenter).filter_by(id=data.cost_center_id,company_id=cid).first(): raise HTTPException(422,"Invalid cost center")
    if data.project_id and not db.query(Project).filter_by(id=data.project_id,company_id=cid).first(): raise HTTPException(422,"Invalid project")
    q=db.query(BudgetLine).filter_by(budget_id=budget_id,account_id=data.account_id,cost_center_id=data.cost_center_id,project_id=data.project_id,period=data.period).first()
    if q: raise HTTPException(409,"Budget line already exists")
    x=BudgetLine(company_id=cid,budget_id=budget_id,**data.model_dump()); db.add(x); db.commit(); db.refresh(x)
    return {"id":x.id}

@router.get("/budgets/{budget_id}/variance")
def budget_variance(budget_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("reports:view"))):
    cid=ctx["company_id"]; bid=ctx.get("branch_id")
    try: report=budget_vs_actual(db,cid,budget_id,bid)
    except ValueError as exc: raise HTTPException(404,str(exc))
    return {"budget_id":report["budget"].id,"scenario":report["budget"].scenario,"status":report["budget"].status,
            "summary":{k:str(v) for k,v in report["summary"].items()},
            "exceptions":report["exceptions"],
            "lines":[{"line_id":r["line_id"],"period":r["period"],"account_id":r["account_id"],
                      "account_code":r["account_code"],"cost_center_id":r["cost_center_id"],"project_id":r["project_id"],
                      "status":r["status"],"budget":str(r["budget"]),"forecast":str(r["forecast"]),
                      "actual":str(r["actual"]),"variance":str(r["variance"]),"forecast_variance":str(r["forecast_variance"])} for r in report["rows"]]}

@router.get("/projects/{project_id}/profitability")
def project_profitability(project_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("reports:view"))):
    cid=ctx["company_id"]; p=db.query(Project).filter_by(id=project_id,company_id=cid).first()
    if not p: raise HTTPException(404,"Project not found")
    cost=Decimal(str(db.query(func.coalesce(func.sum(ProjectCost.amount),0)).filter_by(company_id=cid,project_id=project_id).scalar() or 0))
    revenue=Decimal(str(db.query(func.coalesce(func.sum(Contract.value),0)).filter(Contract.company_id==cid,Contract.project_id==project_id,Contract.status!="cancelled").scalar() or 0))
    return {"project_id":p.id,"project_code":p.code,"budget":str(p.budget),"actual_cost":str(cost),"contracted_revenue":str(revenue),"estimated_profit":str(revenue-cost)}

@router.post("/projects/{project_id}/forecast",status_code=201)
def project_forecast(project_id:int,as_of_date:date,budget_cost:Decimal=0,committed_cost:Decimal=0,actual_cost:Decimal=0,forecast_final_cost:Decimal=0,forecast_revenue:Decimal=0,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("core:projects"))):
    cid=ctx["company_id"]
    if not db.query(Project).filter_by(id=project_id,company_id=cid).first(): raise HTTPException(404,"Project not found")
    profit=forecast_revenue-forecast_final_cost
    x=ProjectForecast(company_id=cid,project_id=project_id,as_of_date=as_of_date,budget_cost=budget_cost,committed_cost=committed_cost,actual_cost=actual_cost,forecast_final_cost=forecast_final_cost,forecast_revenue=forecast_revenue,forecast_profit=profit)
    db.add(x); db.commit(); db.refresh(x)
    return {"id":x.id,"forecast_profit":str(x.forecast_profit)}
