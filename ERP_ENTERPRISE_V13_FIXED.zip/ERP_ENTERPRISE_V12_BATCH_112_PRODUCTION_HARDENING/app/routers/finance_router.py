from ..governance_models import GovernanceAuditLog
from ..time_utils import utcnow
# -*- coding: utf-8 -*-
import datetime
import uuid
from decimal import Decimal, InvalidOperation
from fastapi import APIRouter, Depends, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import func
from ..database import get_db
from ..models import (User, ModulePermission, FinanceVoucher, Customer, Supplier, PurchaseOrder, SaleInvoice,
                      Account, AccountTypeEnum, JournalEntry, AccountingPeriod, AuditLog, PaymentAllocation, JournalLine)
from ..enterprise_models import Company, Branch, UserCompanyAccess
from ..accounting import next_number, create_entry, money, D, close_accounting_period, assert_open_period
from ..auth import require_module
from ..governance import get_request_context, resolve_tenant, require_permission
from ..financial_reporting import cash_flow

router=APIRouter(prefix="/finance", tags=["finance"])
templates=Jinja2Templates(directory="templates")

def can_edit(db,user):
    if user.role.value=="admin": return True
    p=db.query(ModulePermission).filter_by(user_id=user.id,module_key="accounting").first()
    return bool(p and p.can_edit)

def tenant_scope(db, user, requested_branch_id=None):
    ctx=get_request_context()
    cid=ctx.get("company_id")
    if cid is None:
        raise HTTPException(403,"لم يتم تحديد الشركة الحالية")
    bid=ctx.get("branch_id") if requested_branch_id is None else int(requested_branch_id)
    if requested_branch_id is not None:
        cid,bid=resolve_tenant(db,user,cid,bid)
    return cid,bid

def available_branches(db,user,cid):
    rows=(db.query(Branch).join(UserCompanyAccess,UserCompanyAccess.branch_id==Branch.id)
          .filter(UserCompanyAccess.user_id==user.id,UserCompanyAccess.company_id==cid,Branch.is_active==True)
          .order_by(Branch.name).all())
    # company-wide access can see all active branches
    if db.query(UserCompanyAccess).filter(UserCompanyAccess.user_id==user.id,UserCompanyAccess.company_id==cid,UserCompanyAccess.branch_id.is_(None)).first():
        rows=db.query(Branch).filter(Branch.company_id==cid,Branch.is_active==True).order_by(Branch.name).all()
    return rows

def cash_accounts(db,cid,bid=None):
    q=db.query(Account).filter(Account.company_id==cid,Account.is_active==True,Account.account_type==AccountTypeEnum.asset,Account.statement_section=="cash_and_equivalents")
    if bid is not None:
        q=q.filter((Account.branch_id==bid)|(Account.branch_id.is_(None))).order_by(Account.branch_id.desc(),Account.code)
    else:
        q=q.order_by(Account.code)
    return q.all()

def finance_metrics(db,cid,bid=None):
    q=db.query(JournalLine).join(JournalEntry,JournalEntry.id==JournalLine.entry_id).join(Account,Account.id==JournalLine.account_id).filter(
        JournalEntry.company_id==cid,JournalLine.company_id==cid,JournalEntry.status=="posted",Account.company_id==cid,Account.statement_section=="cash_and_equivalents",Account.is_active==True)
    if bid is not None: q=q.filter(JournalEntry.branch_id==bid,JournalLine.branch_id==bid)
    debit=q.with_entities(func.coalesce(func.sum(JournalLine.debit),0)).scalar() or 0
    credit=q.with_entities(func.coalesce(func.sum(JournalLine.credit),0)).scalar() or 0
    positions=[]
    for acc in cash_accounts(db,cid,bid):
        aq=db.query(func.coalesce(func.sum(JournalLine.debit-JournalLine.credit),0)).join(JournalEntry,JournalEntry.id==JournalLine.entry_id).filter(
            JournalEntry.company_id==cid,JournalEntry.status=="posted",JournalLine.company_id==cid,JournalLine.account_id==acc.id)
        if bid is not None: aq=aq.filter(JournalEntry.branch_id==bid,JournalLine.branch_id==bid)
        positions.append({"code":acc.code,"name":acc.name,"branch_id":acc.branch_id,"balance":money(aq.scalar() or 0)})
    today=datetime.date.today(); ytd_start=today.replace(month=1,day=1)
    cf=cash_flow(db,cid,ytd_start,today,bid)
    return {"cash_balance":money(Decimal(str(debit))-Decimal(str(credit))),"cash_positions":positions,"cash_flow":cf}

@router.get("", response_class=HTMLResponse)
def dashboard(request:Request, branch_id:int|None=None, db:Session=Depends(get_db), user:User=Depends(require_module("accounting"))):
    cid,bid=tenant_scope(db,user,branch_id)
    vq=db.query(FinanceVoucher).filter(FinanceVoucher.company_id==cid)
    if bid is not None: vq=vq.filter(FinanceVoucher.branch_id==bid)
    vouchers=vq.order_by(FinanceVoucher.id.desc()).limit(50).all()
    pq=db.query(AccountingPeriod).filter(AccountingPeriod.company_id==cid)
    if bid is not None: pq=pq.filter((AccountingPeriod.branch_id==bid)|(AccountingPeriod.branch_id.is_(None)))
    periods=pq.order_by(AccountingPeriod.start_date.desc()).all()
    branches=available_branches(db,user,cid)
    metrics=finance_metrics(db,cid,bid)
    pending_approvals=db.query(FinanceVoucher).filter(FinanceVoucher.company_id==cid).filter(FinanceVoucher.branch_id==bid if bid is not None else FinanceVoucher.branch_id.is_(None)).count()
    return templates.TemplateResponse(request,"finance.html",{"user":user,"vouchers":vouchers,"periods":periods,"can_edit":can_edit(db,user),"company_id":cid,"branch_id":bid,"branches":branches,"metrics":metrics,"is_consolidated":bid is None,"pending_approvals":pending_approvals})

@router.get("/voucher/new", response_class=HTMLResponse)
def voucher_form(request:Request, db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True))):
    cid,bid=tenant_scope(db,user)
    return templates.TemplateResponse(request,"voucher_form.html",{"user":user,"customers":db.query(Customer).filter(Customer.company_id==cid,Customer.is_active==True).all(),"suppliers":db.query(Supplier).filter(Supplier.company_id==cid,Supplier.is_active==True).all(),"cash_accounts":cash_accounts(db,cid,bid),"expense_accounts":db.query(Account).filter(Account.company_id==cid,Account.is_active==True,Account.account_type==AccountTypeEnum.expense,((Account.branch_id==bid)|(Account.branch_id.is_(None)))).order_by(Account.branch_id.desc(),Account.code).all(),"branch_id":bid,"branches":available_branches(db,user,cid),"idempotency_key":uuid.uuid4().hex})

@router.post("/voucher/new")
def create_voucher(db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True)),
                   _journal_post_permission: User=Depends(require_permission("journal:post")),
                   voucher_type:str=Form(...), amount:str=Form(...), description:str=Form(...), account_code:str=Form(...),
                   party_type:str=Form(""), party_id:str=Form(""), expense_account_code:str=Form(""), voucher_date:str=Form(""), idempotency_key:str=Form("")):
    cid,bid=tenant_scope(db,user)
    if idempotency_key:
        existing=db.query(FinanceVoucher).filter(FinanceVoucher.company_id==cid,FinanceVoucher.idempotency_key==idempotency_key).first()
        if existing:
            return RedirectResponse(f"/finance",303)
    try: a=Decimal(amount)
    except InvalidOperation: raise HTTPException(400,"المبلغ غير صحيح")
    if a<=0: raise HTTPException(400,"المبلغ يجب أن يكون أكبر من صفر")
    if voucher_type not in {"receipt","payment","expense"}: raise HTTPException(400,"نوع السند غير صحيح")
    cash_acc = db.query(Account).filter(Account.code==account_code,Account.company_id==cid,Account.is_active==True,((Account.branch_id==bid)|(Account.branch_id.is_(None)))).order_by(Account.branch_id.desc()).first()
    if not cash_acc: raise HTTPException(400,"حساب الخزينة/البنك غير صحيح")
    pid=None
    if party_id:
        try: pid=int(party_id)
        except (TypeError, ValueError): raise HTTPException(422,"الطرف غير صحيح")
    description = description.strip()
    if not description: raise HTTPException(422,"بيان السند مطلوب")
    if voucher_type=="receipt":
        if party_type!="customer" or not pid: raise HTTPException(400,"سند القبض يجب أن يرتبط بعميل")
        if not db.query(Customer).filter(Customer.id==pid,Customer.company_id==cid).first(): raise HTTPException(400,"العميل غير موجود")
        receivable_acc=db.query(Account).filter(Account.code=="1200",Account.company_id==cid,Account.is_active==True,((Account.branch_id==bid)|(Account.branch_id.is_(None)))).order_by(Account.branch_id.desc()).first()
        if not receivable_acc: raise HTTPException(422,"حساب العملاء 1200 غير موجود أو غير نشط")
        lines=[(cash_acc.code,a,D(0)),(receivable_acc.code,D(0),a)]
    elif voucher_type=="payment":
        if party_type!="supplier" or not pid: raise HTTPException(400,"سند الصرف للمورد يجب أن يرتبط بمورد")
        if not db.query(Supplier).filter(Supplier.id==pid,Supplier.company_id==cid).first(): raise HTTPException(400,"المورد غير موجود")
        payable_acc=db.query(Account).filter(Account.code=="2100",Account.company_id==cid,Account.is_active==True,((Account.branch_id==bid)|(Account.branch_id.is_(None)))).order_by(Account.branch_id.desc()).first()
        if not payable_acc: raise HTTPException(422,"حساب الموردين 2100 غير موجود أو غير نشط")
        lines=[(payable_acc.code,a,D(0)),(cash_acc.code,D(0),a)]
    else:
        if not expense_account_code: raise HTTPException(400,"اختر حساب المصروف")
        expense_acc=db.query(Account).filter(Account.code==expense_account_code,Account.company_id==cid,Account.is_active==True,Account.account_type==AccountTypeEnum.expense,((Account.branch_id==bid)|(Account.branch_id.is_(None)))).order_by(Account.branch_id.desc()).first()
        if not expense_acc: raise HTTPException(400,"حساب المصروف غير صحيح")
        lines=[(expense_acc.code,a,D(0)),(cash_acc.code,D(0),a)]
    try:
        dt=datetime.datetime.fromisoformat(voucher_date) if voucher_date else utcnow()
    except ValueError:
        raise HTTPException(422,"تاريخ السند غير صحيح")
    if dt.tzinfo is not None:
        dt=dt.replace(tzinfo=None)
    period=assert_open_period(db, dt, company_id=cid, branch_id=bid)
    if period is None:
        raise HTTPException(409,"لا توجد فترة محاسبية مفتوحة لهذا التاريخ والفرع")
    v=FinanceVoucher(voucher_number=next_number(db,"voucher", "VCH"),voucher_type=voucher_type,voucher_date=dt,amount=money(a),description=description,account_code=cash_acc.code,party_type=party_type or None,party_id=pid,expense_account_code=expense_account_code or None,created_by_id=user.id,company_id=cid,branch_id=bid,idempotency_key=(idempotency_key.strip() or None))
    db.add(v); db.flush()
    create_entry(db, description, user.id, lines, "finance_voucher", v.id, dt, company_id=cid, branch_id=bid)
    db.add(AuditLog(user_id=user.id, action="create_post", entity_type="finance_voucher", entity_id=v.id, description=f"ترحيل سند مالي {v.voucher_number}"))
    db.commit()
    return RedirectResponse(f"/finance",303)

def _parse_period_datetime(value: str, field_name: str) -> datetime.datetime:
    try:
        raw = (value or "").strip()
        if not raw:
            raise ValueError
        dt = datetime.datetime.fromisoformat(raw)
        if dt.tzinfo is not None:
            dt = dt.astimezone(datetime.timezone.utc).replace(tzinfo=None)
        return dt
    except (TypeError, ValueError, OverflowError):
        raise HTTPException(422, f"{field_name} غير صحيح")

@router.get("/period/new", response_class=HTMLResponse)
def period_form(request:Request, db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True))):
    cid,bid=tenant_scope(db,user)
    return templates.TemplateResponse(request,"period_form.html",{"user":user,"branch_id":bid,"existing_periods":db.query(AccountingPeriod).filter(AccountingPeriod.company_id==cid,((AccountingPeriod.branch_id==bid)|(AccountingPeriod.branch_id.is_(None)))).order_by(AccountingPeriod.start_date.desc()).limit(12).all()})

@router.post("/period/new")
def create_period(db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True)), name:str=Form(...), start_date:str=Form(...), end_date:str=Form(...)):
    cid,bid=tenant_scope(db,user)
    name=(name or "").strip()
    if not name: raise HTTPException(422,"اسم الفترة مطلوب")
    if len(name)>100: raise HTTPException(422,"اسم الفترة طويل جدًا")
    s=_parse_period_datetime(start_date,"تاريخ بداية الفترة")
    e=_parse_period_datetime(end_date,"تاريخ نهاية الفترة")
    if e<s: raise HTTPException(422,"تاريخ النهاية يجب أن يكون بعد أو مساويًا لتاريخ البداية")
    # A branch period conflicts with its branch and any company-wide period.
    # A company-wide period conflicts with every period in the company.
    overlap_q=db.query(AccountingPeriod).filter(AccountingPeriod.company_id==cid,AccountingPeriod.start_date<=e,AccountingPeriod.end_date>=s)
    if bid is not None:
        overlap_q=overlap_q.filter((AccountingPeriod.branch_id==bid)|(AccountingPeriod.branch_id.is_(None)))
    conflict=overlap_q.order_by(AccountingPeriod.start_date.asc()).first()
    if conflict:
        raise HTTPException(409,f"الفترة تتداخل مع الفترة المحاسبية {conflict.name}")
    duplicate=db.query(AccountingPeriod).filter(AccountingPeriod.company_id==cid,AccountingPeriod.branch_id==bid,AccountingPeriod.name==name).first()
    if duplicate:
        raise HTTPException(409,"اسم الفترة مستخدم بالفعل داخل نفس النطاق")
    period=AccountingPeriod(company_id=cid,branch_id=bid,name=name,start_date=s,end_date=e,is_closed=False)
    db.add(period); db.flush()
    db.add(AuditLog(user_id=user.id,action="create",entity_type="accounting_period",entity_id=period.id,description=f"إنشاء الفترة المحاسبية {name}"))
    db.commit()
    return RedirectResponse("/finance",303)

@router.post("/period/{period_id}/close")
def close_period(period_id:int, db:Session=Depends(get_db),
                 user:User=Depends(require_module("accounting",need_edit=True))):
    cid,bid=tenant_scope(db,user)
    close_accounting_period(db, period_id, user.id, company_id=cid, branch_id=bid)
    db.commit()
    return RedirectResponse("/finance",303)


@router.get("/party/{party_type}/{party_id}", response_class=HTMLResponse)
def party_statement(party_type:str,party_id:int,request:Request,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    if party_type not in {"customer","supplier"}: raise HTTPException(400,"نوع طرف غير صحيح")
    party_model=Customer if party_type=="customer" else Supplier
    party=db.query(party_model).filter_by(id=party_id).first()
    if not party: raise HTTPException(404,"الطرف غير موجود")
    rows=[]; balance=0.0
    if party_type=="customer":
        invoices=db.query(SaleInvoice).filter(SaleInvoice.customer_id==party_id).order_by(SaleInvoice.invoice_date,SaleInvoice.id).all()
        for inv in invoices:
            amount=money(inv.total); balance += amount
            rows.append({"date":inv.invoice_date,"number":inv.invoice_number,"description":f"فاتورة مبيعات {inv.invoice_number}","debit":amount,"credit":0.0,"balance":balance})
        receipts=db.query(FinanceVoucher).filter(FinanceVoucher.voucher_type=="receipt",FinanceVoucher.party_type=="customer",FinanceVoucher.party_id==party_id).order_by(FinanceVoucher.voucher_date,FinanceVoucher.id).all()
        for v in receipts:
            balance -= v.amount
            rows.append({"date":v.voucher_date,"number":v.voucher_number,"description":v.description,"debit":0.0,"credit":v.amount,"balance":balance})
    else:
        pos=db.query(PurchaseOrder).filter(PurchaseOrder.supplier_id==party_id).order_by(PurchaseOrder.order_date,PurchaseOrder.id).all()
        for po in pos:
            # الالتزام يظهر عند الاستلام فقط
            if not po.receipts: continue
            amount=money(po.total); balance += amount
            rows.append({"date":po.order_date,"number":po.po_number,"description":f"استلام مشتريات {po.po_number}","debit":0.0,"credit":amount,"balance":balance})
        payments=db.query(FinanceVoucher).filter(FinanceVoucher.voucher_type=="payment",FinanceVoucher.party_type=="supplier",FinanceVoucher.party_id==party_id).order_by(FinanceVoucher.voucher_date,FinanceVoucher.id).all()
        for v in payments:
            balance -= v.amount
            rows.append({"date":v.voucher_date,"number":v.voucher_number,"description":v.description,"debit":v.amount,"credit":0.0,"balance":balance})
    rows.sort(key=lambda x:(x["date"],x["number"]))
    running=0.0
    for r in rows:
        running += r["debit"]-r["credit"]; r["balance"]=running
    return templates.TemplateResponse(request,"party_statement.html",{"user":user,"party":party,"party_type":party_type,"rows":rows,"balance":running})

@router.get("/audit",response_class=HTMLResponse)
def audit(request:Request,db:Session=Depends(get_db),user:User=Depends(require_module("audit"))):
    # Compatibility entry point; the canonical enterprise audit workspace is
    # the tenant-aware financial reporting implementation.
    return RedirectResponse("/accounting/reports/audit", status_code=307)
