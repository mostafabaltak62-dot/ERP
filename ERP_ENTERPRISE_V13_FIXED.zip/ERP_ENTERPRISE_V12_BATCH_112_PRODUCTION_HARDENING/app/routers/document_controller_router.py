from ..time_utils import utcnow
import os, hashlib, uuid, re
from datetime import date, datetime
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Query, Form
from fastapi.responses import FileResponse, HTMLResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from ..database import get_db
from ..input_security import clean_text, safe_filename, detect_file_type
from ..auth import User
from ..governance import get_tenant_context, require_permission, scope_allows
from ..document_models import ProjectDocument, ProjectDocumentRevision, DocumentTransmittal, DocumentTransmittalLine, DocumentApproval, DocumentDistribution, DocumentReviewAssignment, DocumentReviewComment

router = APIRouter(prefix="/api/v1/document-controller", tags=["Construction Document Controller"])
STORAGE_ROOT = Path(os.getenv("ERP_DOCUMENT_STORAGE_PATH", "./storage/documents")).resolve()
ALLOWED_EXT = {"pdf","doc","docx","xls","xlsx","csv","jpg","jpeg","png","dwg","dxf","zip","txt"}
DOC_TYPES = {"DRAWING","SHOP_DRAWING","MATERIAL","MATERIAL_SUBMITTAL","SIR","MIR","MT","DOC","RFI","NCR","METHOD_STATEMENT","ITP","TEST_REPORT","LETTER_IN","LETTER_OUT","MINUTES","HANDOVER","DELIVERY_NOTE","APPROVAL","OTHER"}
STATUSES = {"draft","submitted","under_review","approved","approved_with_comments","rejected","closed","void"}

def _safe_name(name: str) -> str:
    name = Path(name or "file").name
    return re.sub(r"[^A-Za-z0-9._ -]", "_", name)[:255]

def _ext(name: str) -> str:
    return Path(name).suffix.lower().lstrip(".")

def _doc(db, company_id, document_id):
    row = db.query(ProjectDocument).filter_by(id=document_id, company_id=company_id).first()
    if not row: raise HTTPException(404, "Document not found")
    return row

def _revision(db, company_id, document_id, revision_id):
    row = db.query(ProjectDocumentRevision).filter_by(id=revision_id, company_id=company_id, document_id=document_id).first()
    if not row: raise HTTPException(404, "Revision not found")
    return row

def _validate_links(db, company_id, project_id, data):
    # Project-scoped references must belong to the same company and project.
    from ..enterprise_models import Contract, Project, Equipment
    from ..construction_models import ConstructionSite, WBSNode, BOQLine, ConstructionCostCode, ConstructionMeasurement, SiteMaterialIssue, EquipmentUsage, ConstructionLaborEntry, SubcontractorProgress
    from ..models import Item, PurchaseOrder
    checks=[
        (data.contract_id, Contract, "Contract", "project_id"), (data.site_id, ConstructionSite, "Site", "project_id"),
        (data.wbs_id, WBSNode, "WBS", "project_id"), (data.boq_line_id, BOQLine, "BOQ line", "project_id"),
        (data.measurement_id, ConstructionMeasurement, "Measurement", "project_id"), (data.progress_certificate_id, __import__('app.enterprise_models',fromlist=['ProgressCertificate']).ProgressCertificate, "Progress certificate", "project_id"),
        (data.subcontractor_progress_id, SubcontractorProgress, "Subcontractor progress", "project_id"), (data.site_material_issue_id, SiteMaterialIssue, "Site material issue", "project_id"),
        (data.equipment_usage_id, EquipmentUsage, "Equipment usage", "project_id"), (data.labor_entry_id, ConstructionLaborEntry, "Labor entry", "project_id"),
        (data.purchase_order_id, PurchaseOrder, "Purchase order", None), (data.item_id, Item, "Item", None), (data.equipment_id, Equipment, "Equipment", None),
        (data.cost_code_id, ConstructionCostCode, "Cost code", None)
    ]
    for ident, model, label, project_field in checks:
        if ident is None: continue
        row=db.query(model).filter_by(id=ident, company_id=company_id).first()
        if not row: raise HTTPException(422, f"{label} does not belong to the current company")
        if project_field and getattr(row, project_field, None) != project_id: raise HTTPException(422, f"{label} does not belong to the selected project")

class DocumentIn(BaseModel):
    project_id:int; document_no:str=Field(min_length=1,max_length=80); title:str=Field(min_length=1,max_length=255)
    document_type:str; contract_id:int|None=None; site_id:int|None=None; wbs_id:int|None=None; boq_line_id:int|None=None; cost_code_id:int|None=None
    item_id:int|None=None; equipment_id:int|None=None; purchase_order_id:int|None=None; measurement_id:int|None=None; progress_certificate_id:int|None=None
    subcontractor_progress_id:int|None=None; site_material_issue_id:int|None=None; equipment_usage_id:int|None=None; labor_entry_id:int|None=None
    discipline:str|None=None; priority:str="normal"; external_reference:str|None=None; issue_date:date|None=None; due_date:date|None=None; confidentiality:str="internal"; description:str|None=None
class StatusIn(BaseModel): status:str
class RevisionIn(BaseModel): revision_code:str|None=None; change_description:str|None=None
class TransmittalIn(BaseModel): project_id:int; transmittal_no:str; recipient:str; recipient_role:str|None=None; subject:str; purpose:str="for_review"; issue_date:date; response_due_date:date|None=None; notes:str|None=None; document_ids:list[int]=Field(min_length=1,max_length=500)
class ApprovalIn(BaseModel): decision:str; comments:str|None=None
class DistributionIn(BaseModel): recipient:str; recipient_role:str|None=None; distribution_method:str="system"; notes:str|None=None

@router.post("/documents", status_code=201)
def create_document(data:DocumentIn, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission("documents:create"))):
    company_id=ctx["company_id"]
    if data.document_type not in DOC_TYPES: raise HTTPException(422,"Unsupported document type")
    if db.query(ProjectDocument).filter_by(company_id=company_id, document_no=data.document_no).first(): raise HTTPException(409,"Document number already exists")
    if not db.query(__import__('app.enterprise_models',fromlist=['Project']).Project).filter_by(id=data.project_id,company_id=company_id).first(): raise HTTPException(404,"Project not found")
    _validate_links(db, company_id, data.project_id, data)
    payload=data.model_dump()
    payload["document_no"] = clean_text(payload.get("document_no"), max_length=80, required=True)
    payload["title"] = clean_text(payload.get("title"), max_length=255, required=True)
    payload["description"] = clean_text(payload.get("description"), max_length=2000)
    row=ProjectDocument(company_id=company_id,created_by_id=user.id,**payload)
    db.add(row); db.commit(); db.refresh(row)
    return {"id":row.id,"document_no":row.document_no,"status":row.status}

@router.get("/documents")
def list_documents(project_id:int|None=None, document_type:str|None=None, status:str|None=None, site_id:int|None=None, q:str|None=None, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission("documents:view"))):
    company_id=ctx["company_id"]; query=db.query(ProjectDocument).filter_by(company_id=company_id)
    if project_id: query=query.filter_by(project_id=project_id)
    if document_type: query=query.filter_by(document_type=document_type)
    if status: query=query.filter_by(status=status)
    if site_id: query=query.filter_by(site_id=site_id)
    if q: query=query.filter((ProjectDocument.title.ilike(f"%{q}%")) | (ProjectDocument.document_no.ilike(f"%{q}%")))
    rows=query.order_by(ProjectDocument.id.desc()).limit(500).all()
    return [{"id":d.id,"project_id":d.project_id,"document_no":d.document_no,"title":d.title,"document_type":d.document_type,"status":d.status,"current_revision_no":d.current_revision_no,"site_id":d.site_id,"wbs_id":d.wbs_id,"boq_line_id":d.boq_line_id,"item_id":d.item_id,"purchase_order_id":d.purchase_order_id,"issue_date":d.issue_date.isoformat() if d.issue_date else None,"due_date":d.due_date.isoformat() if d.due_date else None} for d in rows]

@router.get("/documents/{document_id}")
def get_document(document_id:int, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission("documents:view"))):
    d=_doc(db,ctx["company_id"],document_id); revs=db.query(ProjectDocumentRevision).filter_by(document_id=d.id,company_id=d.company_id).order_by(ProjectDocumentRevision.revision_no.desc()).all()
    approvals=db.query(DocumentApproval).filter_by(document_id=d.id,company_id=d.company_id).order_by(DocumentApproval.id.desc()).all()
    return {"document":{c.name:getattr(d,c.name) for c in d.__table__.columns},"revisions":[{c.name:getattr(r,c.name) for c in r.__table__.columns if c.name not in {"stored_path"}} for r in revs],"approvals":[{c.name:getattr(a,c.name) for c in a.__table__.columns} for a in approvals]}

@router.post("/documents/{document_id}/revisions", status_code=201)
async def upload_revision(document_id:int, revision_code:str|None=Form(None), change_description:str|None=Form(None), file:UploadFile=File(...), ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission("documents:create"))):
    d=_doc(db,ctx["company_id"],document_id); ext=_ext(file.filename or "")
    if ext not in ALLOWED_EXT: raise HTTPException(415,f"File extension not allowed: {ext}")
    previous=db.query(ProjectDocumentRevision).filter_by(document_id=d.id,company_id=d.company_id).order_by(ProjectDocumentRevision.revision_no.desc()).first()
    revision_no=(previous.revision_no+1) if previous else 1
    revision_code=revision_code or f"R{revision_no}"
    if db.query(ProjectDocumentRevision).filter_by(document_id=d.id,revision_code=revision_code).first(): raise HTTPException(409,"Revision code already exists")
    max_bytes=int(os.getenv("ERP_DOCUMENT_MAX_BYTES","52428800"))
    content_length = file.headers.get("content-length") if getattr(file, "headers", None) else None
    if content_length and int(content_length) > max_bytes: raise HTTPException(413,"File exceeds configured maximum size")
    data=await file.read(max_bytes + 1)
    if len(data)>max_bytes: raise HTTPException(413,"File exceeds configured maximum size")
    detected=detect_file_type(data, file.filename or "")
    if detected is None: raise HTTPException(415,"File signature does not match the allowed file type")
    ext=detected.lstrip(".")
    sha=hashlib.sha256(data).hexdigest(); safe=safe_filename(file.filename or f"{d.document_no}.{ext}")
    target_dir=STORAGE_ROOT / str(d.company_id) / str(d.project_id) / str(d.id)
    target_dir.mkdir(parents=True,exist_ok=True); stored=target_dir / f"{revision_no:04d}_{uuid.uuid4().hex}_{safe}"
    stored.write_bytes(data)
    if previous: previous.is_current=False
    r=ProjectDocumentRevision(company_id=d.company_id,document_id=d.id,revision_no=revision_no,revision_code=revision_code,file_name=safe,stored_path=str(stored),mime_type=file.content_type or "application/octet-stream",file_size=len(data),sha256=sha,change_description=change_description,status="draft",uploaded_by_id=user.id,supersedes_revision_id=previous.id if previous else None,is_current=True)
    db.add(r); d.current_revision_no=revision_no; d.status="submitted"; db.commit(); db.refresh(r)
    return {"id":r.id,"document_id":d.id,"revision_no":r.revision_no,"revision_code":r.revision_code,"sha256":r.sha256,"size":r.file_size}

@router.get("/documents/{document_id}/revisions/{revision_id}/download")
def download_revision(document_id:int,revision_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("documents:view"))):
    r=_revision(db,ctx["company_id"],document_id,revision_id)
    p=Path(r.stored_path).resolve()
    if not p.exists() or not p.is_file() or STORAGE_ROOT not in p.parents: raise HTTPException(404,"Stored file not found")
    return FileResponse(str(p),media_type=r.mime_type,filename=r.file_name,headers={"X-Document-SHA256":r.sha256})

@router.post("/documents/{document_id}/status")
def set_status(document_id:int,data:StatusIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("documents:edit"))):
    if data.status not in STATUSES: raise HTTPException(422,"Invalid document status")
    d=_doc(db,ctx["company_id"],document_id); d.status=data.status; db.commit(); return {"id":d.id,"status":d.status}

@router.post("/documents/{document_id}/revisions/{revision_id}/approve")
def approve(document_id:int,revision_id:int,data:ApprovalIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("documents:approve"))):
    if data.decision not in {"approved","approved_with_comments","rejected","for_review"}: raise HTTPException(422,"Invalid approval decision")
    d=_doc(db,ctx["company_id"],document_id); r=_revision(db,ctx["company_id"],document_id,revision_id)
    a=DocumentApproval(company_id=d.company_id,document_id=d.id,revision_id=r.id,approver_id=user.id,decision=data.decision,comments=data.comments); db.add(a)
    r.status=data.decision; d.status={"approved":"approved","approved_with_comments":"approved_with_comments","rejected":"rejected","for_review":"under_review"}[data.decision]
    db.commit(); return {"approval_id":a.id,"document_status":d.status,"revision_status":r.status}

@router.post("/transmittals",status_code=201)
def create_transmittal(data:TransmittalIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("documents:create"))):
    company_id=ctx["company_id"]
    if db.query(DocumentTransmittal).filter_by(company_id=company_id,transmittal_no=data.transmittal_no).first(): raise HTTPException(409,"Transmittal number already exists")
    docs=[_doc(db,company_id,i) for i in data.document_ids]
    if any(d.project_id!=data.project_id for d in docs): raise HTTPException(422,"All transmittal documents must belong to the same project")
    t=DocumentTransmittal(company_id=company_id,created_by_id=user.id,**data.model_dump(exclude={"document_ids"})); db.add(t); db.flush()
    for d in docs:
        r=db.query(ProjectDocumentRevision).filter_by(document_id=d.id,company_id=company_id,is_current=True).first()
        if not r: raise HTTPException(422,f"Document {d.document_no} has no current revision")
        db.add(DocumentTransmittalLine(company_id=company_id,transmittal_id=t.id,document_id=d.id,revision_id=r.id,action="review"))
    db.commit(); db.refresh(t); return {"id":t.id,"transmittal_no":t.transmittal_no,"document_count":len(docs)}


@router.get("/transmittals/{transmittal_id}")
def get_transmittal(transmittal_id:int, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission("documents:view"))):
    t=db.query(DocumentTransmittal).filter_by(id=transmittal_id,company_id=ctx["company_id"]).first()
    if not t: raise HTTPException(404,"Transmittal not found")
    lines=db.query(DocumentTransmittalLine).filter_by(transmittal_id=t.id,company_id=t.company_id).all()
    items=[]
    for line in lines:
        d=_doc(db,t.company_id,line.document_id); r=_revision(db,t.company_id,d.id,line.revision_id)
        items.append({"document_no":d.document_no,"title":d.title,"document_type":d.document_type,"revision":r.revision_code,"action":line.action,"remarks":line.remarks})
    return {"transmittal":{c.name:getattr(t,c.name) for c in t.__table__.columns},"lines":items}

@router.post("/transmittals/{transmittal_id}/acknowledge-receipt")
def acknowledge_transmittal_receipt(transmittal_id:int, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission("documents:edit"))):
    t=db.query(DocumentTransmittal).filter_by(id=transmittal_id,company_id=ctx["company_id"]).first()
    if not t: raise HTTPException(404,"Transmittal not found")
    if not t.received_at: t.received_at=utcnow()
    t.receipt_acknowledged_at=utcnow(); t.receipt_acknowledged_by_id=user.id
    if t.status=="issued": t.status="received"
    db.commit()
    return {"id":t.id,"status":t.status,"received_at":t.received_at.isoformat(),"acknowledged_at":t.receipt_acknowledged_at.isoformat()}

@router.get("/projects/{project_id}/transmittals/overdue")
def overdue_transmittals(project_id:int, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission("documents:view"))):
    today=date.today()
    rows=db.query(DocumentTransmittal).filter(DocumentTransmittal.company_id==ctx["company_id"],DocumentTransmittal.project_id==project_id,DocumentTransmittal.response_due_date.isnot(None),DocumentTransmittal.response_due_date<today,~DocumentTransmittal.status.in_(["responded","closed","rejected"])) .order_by(DocumentTransmittal.response_due_date).all()
    return [{"id":t.id,"transmittal_no":t.transmittal_no,"recipient":t.recipient,"subject":t.subject,"issue_date":t.issue_date.isoformat(),"response_due_date":t.response_due_date.isoformat(),"days_overdue":(today-t.response_due_date).days,"status":t.status} for t in rows]

@router.get("/transmittals/{transmittal_id}/print", response_class=HTMLResponse)
def print_transmittal(transmittal_id:int, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission("documents:view"))):
    data=get_transmittal(transmittal_id,ctx,db,user); t=data["transmittal"]
    rows=''.join(f"<tr><td>{i+1}</td><td>{x['document_no']}</td><td>{x['title']}</td><td>{x['document_type']}</td><td>{x['revision']}</td><td>{x['action']}</td></tr>" for i,x in enumerate(data["lines"]))
    return f"""<!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'><title>Document Transmittal</title><style>body{{font-family:Arial;margin:24px;color:#111}}.head,table{{width:100%;border-collapse:collapse}}td,th{{border:1px solid #111;padding:8px}}.title{{text-align:center;font-size:22px;font-weight:bold}}@media print{{button{{display:none}}body{{margin:0}}}}</style></head><body><button onclick='print()'>طباعة</button><table class='head'><tr><td>رقم الإرسال<br><b>{t['transmittal_no']}</b></td><td class='title'>خطاب إرسال مستندات<br>DOCUMENT TRANSMITTAL</td><td>تاريخ الإصدار<br><b>{t['issue_date']}</b></td></tr></table><table><tr><td>إلى: {t['recipient']}</td><td>الغرض: {t['purpose']}</td><td>الموضوع: {t['subject']}</td></tr><tr><td colspan='3'>موعد الرد: {t.get('response_due_date') or '-'}</td></tr></table><h3>المستندات المرفقة</h3><table><tr><th>#</th><th>رقم المستند</th><th>العنوان</th><th>النوع</th><th>الإصدار</th><th>الإجراء</th></tr>{rows}</table><br><table><tr><td>مُرسل بواسطة / Sender<br><br>....................</td><td>تأكيد الاستلام / Receipt Acknowledgement<br><br>....................</td></tr></table></body></html>"""

@router.get("/transmittals")
def list_transmittals(project_id:int|None=None,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("documents:view"))):
    q=db.query(DocumentTransmittal).filter_by(company_id=ctx["company_id"])
    if project_id:q=q.filter_by(project_id=project_id)
    return [{c.name:getattr(t,c.name) for c in t.__table__.columns} for t in q.order_by(DocumentTransmittal.id.desc()).limit(500).all()]

@router.post("/documents/{document_id}/distribute")
def distribute(document_id:int,data:DistributionIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("documents:create"))):
    d=_doc(db,ctx["company_id"],document_id); r=db.query(ProjectDocumentRevision).filter_by(document_id=d.id,company_id=d.company_id,is_current=True).first()
    if not r: raise HTTPException(422,"Document has no current revision")
    row=DocumentDistribution(company_id=d.company_id,document_id=d.id,revision_id=r.id,**data.model_dump()); db.add(row); db.commit(); db.refresh(row); return {"id":row.id,"distributed_at":row.distributed_at.isoformat()}

@router.post("/transmittals/{transmittal_id}/response")
def transmittal_response(transmittal_id:int, status:str=Query(...), response_date:date|None=Query(None), ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission("documents:edit"))):
    if status not in {"responded","closed","rejected","under_review","received"}: raise HTTPException(422,"Invalid transmittal response status")
    t=db.query(DocumentTransmittal).filter_by(id=transmittal_id,company_id=ctx["company_id"]).first()
    if not t: raise HTTPException(404,"Transmittal not found")
    t.status=status; t.response_date=response_date or date.today(); db.commit(); return {"id":t.id,"status":t.status,"response_date":t.response_date.isoformat()}

@router.post("/documents/{document_id}/acknowledge")
def acknowledge_distribution(document_id:int, distribution_id:int, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission("documents:edit"))):
    _doc(db,ctx["company_id"],document_id)
    row=db.query(DocumentDistribution).filter_by(id=distribution_id,company_id=ctx["company_id"],document_id=document_id).first()
    if not row: raise HTTPException(404,"Distribution record not found")
    row.acknowledged_at=utcnow(); db.commit(); return {"id":row.id,"acknowledged_at":row.acknowledged_at.isoformat()}

@router.get("/projects/{project_id}/dashboard")
def project_dashboard(project_id:int, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission("documents:view"))):
    rows=db.query(ProjectDocument).filter_by(company_id=ctx["company_id"],project_id=project_id).all()
    today=date.today(); overdue=[d for d in rows if d.due_date and d.due_date<today and d.status not in {"closed","approved","void"}]
    return {"project_id":project_id,"total":len(rows),"open":sum(d.status not in {"closed","void"} for d in rows),"approved":sum(d.status in {"approved","approved_with_comments"} for d in rows),"overdue":len(overdue),"pending_review":sum(d.status in {"submitted","under_review"} for d in rows),"by_type":{t:sum(1 for d in rows if d.document_type==t) for t in sorted({d.document_type for d in rows})}}

@router.get("/projects/{project_id}/register")
def project_register(project_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("documents:view"))):
    rows=db.query(ProjectDocument).filter_by(company_id=ctx["company_id"],project_id=project_id).order_by(ProjectDocument.document_type,ProjectDocument.document_no).all()
    return {"project_id":project_id,"total":len(rows),"by_type":{t:sum(1 for d in rows if d.document_type==t) for t in sorted({d.document_type for d in rows})},"documents":[{"id":d.id,"document_no":d.document_no,"title":d.title,"type":d.document_type,"status":d.status,"revision":d.current_revision_no,"due_date":d.due_date.isoformat() if d.due_date else None} for d in rows]}


class ReviewAssignmentIn(BaseModel):
    revision_id:int; reviewer_id:int; reviewer_role:str|None=None; due_date:date|None=None
class ReviewCommentIn(BaseModel):
    revision_id:int; comment_text:str=Field(min_length=1,max_length=4000)
class ReviewDecisionIn(BaseModel):
    status:str; comments:str|None=None

@router.post("/documents/{document_id}/review-assignments", status_code=201)
def assign_reviewer(document_id:int, data:ReviewAssignmentIn, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission("documents:edit"))):
    d=_doc(db,ctx["company_id"],document_id); r=_revision(db,ctx["company_id"],document_id,data.revision_id)
    existing=db.query(DocumentReviewAssignment).filter_by(revision_id=r.id,reviewer_id=data.reviewer_id).first()
    if existing: raise HTTPException(409,"Reviewer already assigned")
    row=DocumentReviewAssignment(company_id=d.company_id,document_id=d.id,revision_id=r.id,reviewer_id=data.reviewer_id,reviewer_role=data.reviewer_role,due_date=data.due_date,assigned_by_id=user.id)
    d.status="under_review"; db.add(row); db.commit(); db.refresh(row)
    return {"id":row.id,"status":row.status,"revision_id":r.id}

@router.post("/documents/{document_id}/review-comments", status_code=201)
def add_review_comment(document_id:int, data:ReviewCommentIn, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission("documents:edit"))):
    d=_doc(db,ctx["company_id"],document_id); r=_revision(db,ctx["company_id"],document_id,data.revision_id)
    row=DocumentReviewComment(company_id=d.company_id,document_id=d.id,revision_id=r.id,author_id=user.id,comment_text=clean_text(data.comment_text,max_length=4000,required=True))
    db.add(row); db.commit(); return {"id":row.id,"status":"open"}

@router.post("/review-assignments/{assignment_id}/decision")
def reviewer_decision(assignment_id:int, data:ReviewDecisionIn, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission("documents:edit"))):
    allowed={"approved","approved_with_comments","revise_and_resubmit","rejected"}
    if data.status not in allowed: raise HTTPException(422,"Invalid review decision")
    row=db.query(DocumentReviewAssignment).filter_by(id=assignment_id,company_id=ctx["company_id"]).first()
    if not row: raise HTTPException(404,"Review assignment not found")
    if row.reviewer_id != user.id: raise HTTPException(403,"Only the assigned reviewer may submit this decision")
    row.status=data.status; row.comments=clean_text(data.comments,max_length=4000); row.reviewed_at=utcnow()
    d=_doc(db,ctx["company_id"],row.document_id)
    d.status="submitted" if data.status=="revise_and_resubmit" else data.status
    db.commit(); return {"assignment_id":row.id,"status":row.status,"document_status":d.status}

@router.get("/documents/{document_id}/review-workflow")
def review_workflow(document_id:int, ctx=Depends(get_tenant_context), db:Session=Depends(get_db), user:User=Depends(require_permission("documents:view"))):
    d=_doc(db,ctx["company_id"],document_id)
    assignments=db.query(DocumentReviewAssignment).filter_by(document_id=d.id,company_id=d.company_id).order_by(DocumentReviewAssignment.created_at.desc()).all()
    comments=db.query(DocumentReviewComment).filter_by(document_id=d.id,company_id=d.company_id).order_by(DocumentReviewComment.created_at.desc()).all()
    return {"document_id":d.id,"status":d.status,"assignments":[{"id":x.id,"revision_id":x.revision_id,"reviewer_id":x.reviewer_id,"role":x.reviewer_role,"due_date":x.due_date.isoformat() if x.due_date else None,"status":x.status,"comments":x.comments} for x in assignments],"comments":[{"id":x.id,"revision_id":x.revision_id,"author_id":x.author_id,"comment":x.comment_text,"status":x.status} for x in comments]}
