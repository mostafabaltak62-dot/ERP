"""Server-rendered Site Operations workspace.

Keeps field/site execution separate from inventory while integrating both through
existing domain services. Every query is scoped to the tenant and selected project.
"""
from datetime import date, timedelta, datetime
from decimal import Decimal
from fastapi import APIRouter, Depends, Request, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import func
from sqlalchemy.orm import Session

from ..database import get_db
from ..governance import get_tenant_context, require_permission, scope_allows
from ..models import User, Item
from ..auth import require_module
from ..enterprise_models import Project, Employee, Equipment, ProjectCost
from ..construction_models import ConstructionSite, EquipmentUsage, ConstructionLaborEntry, SiteMaterialIssue, BOQLine, ConstructionCostCode, ConstructionCostBudgetLine
from ..hr_models import DailyWorker, DailyLaborEntry, DailyLaborSettlement
from ..field_ops_models import SiteMaterialRequisition, SiteMaterialRequisitionLine, EquipmentLog
from ..construction_services import create_site, record_equipment_usage, record_labor
from ..field_ops_services import create_material_requisition, issue_material_requisition_from_warehouse, fulfill_material_requisition, receive_material_at_site, consume_site_material, adjust_site_material, FieldOpsError, BudgetExceeded
from ..warehouse_models import Warehouse
from ..models import StockMovement, MovementTypeEnum
from ..site_material_flow_models import SiteMaterialReceipt, SiteMaterialConsumption, SiteMaterialAdjustment
from ..site_operations_center_models import SiteLocationNode, DailySiteReport, SiteDiaryEntry, SiteIssue, SiteOperationsPlan, SiteProgressEntry

router = APIRouter(prefix="/site-operations", tags=["Site Operations UI"])
templates = Jinja2Templates(directory="templates")


def _visible_projects(db, company_id, user_id, branch_id=None):
    q = db.query(Project).filter(Project.company_id == company_id)
    if branch_id is not None:
        q = q.filter((Project.branch_id == branch_id) | (Project.branch_id.is_(None)))
    return [p for p in q.order_by(Project.id.desc()).all()
            if scope_allows(db, user_id, company_id=company_id, branch_id=p.branch_id, project_id=p.id)]


def _project(db, company_id, user_id, project_id):
    p = db.query(Project).filter_by(id=project_id, company_id=company_id).first()
    if not p or not scope_allows(db, user_id, company_id=company_id, branch_id=p.branch_id, project_id=p.id):
        raise HTTPException(404, "Project not found or access denied")
    return p


def _page_context(request, user, projects, project, **extra):
    ctx = {"request": request, "user": user, "projects": projects, "project": project,
           "section": "site_operations"}
    ctx.update(extra)
    return ctx


@router.get("", response_class=HTMLResponse)
def dashboard(request: Request, project_id: int | None = None, db: Session = Depends(get_db),
              ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:view"))):
    company_id, branch_id = ctx["company_id"], ctx["branch_id"]
    projects = _visible_projects(db, company_id, user.id, branch_id)
    project = next((p for p in projects if p.id == project_id), None) if project_id else (projects[0] if projects else None)
    if not project:
        return templates.TemplateResponse(request, "site_operations.html", _page_context(request, user, projects, None,
            metrics={}, sites=[], material_reqs=[], labor=[], equipment=[], material_issues=[]))

    today = date.today()
    daily_report = db.query(DailySiteReport).filter_by(company_id=company_id, project_id=project.id, report_date=today).first()
    open_issues = db.query(SiteIssue).filter(SiteIssue.company_id==company_id, SiteIssue.project_id==project.id, SiteIssue.status.in_(["open","in_progress"])).count()
    overdue_issues = db.query(SiteIssue).filter(SiteIssue.company_id==company_id, SiteIssue.project_id==project.id, SiteIssue.status.in_(["open","in_progress"]), SiteIssue.due_date.isnot(None), SiteIssue.due_date < today).count()
    today_plan = db.query(SiteOperationsPlan).filter_by(company_id=company_id, project_id=project.id, plan_date=today).order_by(SiteOperationsPlan.id.desc()).all()
    recent_diary = db.query(SiteDiaryEntry).filter_by(company_id=company_id, project_id=project.id).order_by(SiteDiaryEntry.event_date.desc(), SiteDiaryEntry.id.desc()).limit(8).all()
    locations = db.query(SiteLocationNode).filter_by(company_id=company_id, project_id=project.id).order_by(SiteLocationNode.id).all()
    progress_rows = db.query(SiteProgressEntry).filter_by(company_id=company_id, project_id=project.id).order_by(SiteProgressEntry.progress_date.desc(), SiteProgressEntry.id.desc()).limit(8).all()
    start = date.today()
    cost = db.query(func.coalesce(func.sum(ProjectCost.amount), 0)).filter(ProjectCost.company_id == company_id, ProjectCost.project_id == project.id).scalar() or 0
    material = db.query(func.coalesce(func.sum(SiteMaterialIssue.total_cost), 0)).filter(SiteMaterialIssue.company_id == company_id, SiteMaterialIssue.project_id == project.id, SiteMaterialIssue.status == "posted").scalar() or 0
    equipment = db.query(func.coalesce(func.sum(EquipmentUsage.total_cost), 0)).filter(EquipmentUsage.company_id == company_id, EquipmentUsage.project_id == project.id).scalar() or 0
    labor = db.query(func.coalesce(func.sum(ConstructionLaborEntry.total_cost), 0)).filter(ConstructionLaborEntry.company_id == company_id, ConstructionLaborEntry.project_id == project.id).scalar() or 0
    req_count = db.query(func.count(SiteMaterialRequisition.id)).filter(SiteMaterialRequisition.company_id == company_id, SiteMaterialRequisition.project_id == project.id).scalar() or 0
    pending_req = db.query(func.count(SiteMaterialRequisition.id)).filter(SiteMaterialRequisition.company_id == company_id, SiteMaterialRequisition.project_id == project.id, SiteMaterialRequisition.status.in_(["draft", "submitted"])).scalar() or 0
    sites = db.query(ConstructionSite).filter_by(company_id=company_id, project_id=project.id).order_by(ConstructionSite.id).all()
    material_reqs = db.query(SiteMaterialRequisition).filter_by(company_id=company_id, project_id=project.id).order_by(SiteMaterialRequisition.id.desc()).limit(8).all()
    labor_rows = db.query(ConstructionLaborEntry).filter_by(company_id=company_id, project_id=project.id).order_by(ConstructionLaborEntry.id.desc()).limit(8).all()
    equipment_rows = db.query(EquipmentUsage).filter_by(company_id=company_id, project_id=project.id).order_by(EquipmentUsage.id.desc()).limit(8).all()
    material_rows = db.query(SiteMaterialIssue).filter_by(company_id=company_id, project_id=project.id).order_by(SiteMaterialIssue.id.desc()).limit(8).all()
    return templates.TemplateResponse(request, "site_operations.html", _page_context(request, user, projects, project,
        metrics={"cost": Decimal(str(cost)), "material": Decimal(str(material)), "equipment": Decimal(str(equipment)), "labor": Decimal(str(labor)), "req_count": req_count, "pending_req": pending_req, "open_issues": open_issues, "overdue_issues": overdue_issues, "daily_report": bool(daily_report)},
        sites=sites, material_reqs=material_reqs, labor=labor_rows, equipment=equipment_rows, material_issues=material_rows, locations=locations, today_plan=today_plan, recent_diary=recent_diary, progress_rows=progress_rows))


@router.get("/daily-labor", response_class=HTMLResponse)
def daily_labor_page(request: Request, project_id: int, worker_id: int | None = None,
                     start_date: date | None = None, end_date: date | None = None,
                     status: str | None = None, db: Session = Depends(get_db),
                     ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:view"))):
    company_id = ctx["company_id"]
    p = _project(db, company_id, user.id, project_id)
    workers = db.query(DailyWorker).filter_by(company_id=company_id, status="active").order_by(DailyWorker.name).all()
    all_workers = db.query(DailyWorker).filter_by(company_id=company_id).order_by(DailyWorker.name).all()
    sites = db.query(ConstructionSite).filter_by(company_id=company_id, project_id=p.id).order_by(ConstructionSite.name).all()
    q = db.query(DailyLaborEntry).filter_by(company_id=company_id, project_id=p.id)
    if worker_id:
        q = q.filter(DailyLaborEntry.worker_id == worker_id)
    if start_date:
        q = q.filter(DailyLaborEntry.work_date >= start_date)
    if end_date:
        q = q.filter(DailyLaborEntry.work_date <= end_date)
    if status:
        q = q.filter(DailyLaborEntry.status == status)
    rows = q.order_by(DailyLaborEntry.work_date.desc(), DailyLaborEntry.id.desc()).limit(250).all()
    worker_map = {w.id: w for w in all_workers}
    site_map = {x.id: x for x in sites}
    metrics = {
        "workers": len({r.worker_id for r in rows}),
        "regular_hours": sum((Decimal(str(r.regular_hours or 0)) for r in rows), Decimal("0")),
        "overtime_hours": sum((Decimal(str(r.overtime_hours or 0)) for r in rows), Decimal("0")),
        "gross": sum((Decimal(str(r.regular_amount or 0)) + Decimal(str(r.overtime_amount or 0)) + Decimal(str(r.other_amount or 0)) for r in rows), Decimal("0")),
        "deductions": sum((Decimal(str(r.deduction_amount or 0)) for r in rows), Decimal("0")),
        "net": sum((Decimal(str(r.net_amount or 0)) for r in rows), Decimal("0")),
        "draft": sum(1 for r in rows if r.status == "draft"),
        "approved": sum(1 for r in rows if r.status == "approved"),
    }
    settlements = db.query(DailyLaborSettlement).filter_by(company_id=company_id, project_id=p.id).order_by(DailyLaborSettlement.period_start.desc()).limit(12).all()
    filters = {"worker_id": worker_id, "start_date": start_date.isoformat() if start_date else "", "end_date": end_date.isoformat() if end_date else "", "status": status or ""}
    return templates.TemplateResponse(request, "site_operations_daily_labor.html", _page_context(
        request, user, [p], p, workers=workers, all_workers=all_workers, sites=sites, rows=rows,
        worker_map=worker_map, site_map=site_map, metrics=metrics, settlements=settlements, filters=filters))


@router.post("/daily-labor")
def create_daily_labor_form(request: Request, project_id: int, worker_id: int, work_date: date,
                            regular_hours: Decimal = Decimal("8"), overtime_hours: Decimal = Decimal("0"),
                            other_amount: Decimal = Decimal("0"), deduction_amount: Decimal = Decimal("0"),
                            notes: str | None = None, site_id: int | None = None,
                            db: Session = Depends(get_db), ctx=Depends(get_tenant_context),
                            user: User = Depends(require_permission("construction:manage"))):
    p = _project(db, ctx["company_id"], user.id, project_id)
    worker = db.query(DailyWorker).filter_by(id=worker_id, company_id=ctx["company_id"], status="active").first()
    if not worker:
        raise HTTPException(404, "Daily worker not found")
    if any(x < 0 for x in (regular_hours, overtime_hours, other_amount, deduction_amount)):
        raise HTTPException(422, "Hours and amounts cannot be negative")
    if site_id and not db.query(ConstructionSite).filter_by(id=site_id, company_id=ctx["company_id"], project_id=p.id).first():
        raise HTTPException(422, "Site does not belong to project")
    existing = db.query(DailyLaborEntry).filter_by(company_id=ctx["company_id"], worker_id=worker.id, project_id=p.id, work_date=work_date).first()
    if existing:
        raise HTTPException(409, "A daily labor entry already exists for this worker and date")
    regular_amount = Decimal(str(worker.daily_rate)) if regular_hours > 0 else Decimal("0")
    overtime_amount = Decimal(str(worker.overtime_rate or 0)) * overtime_hours
    net = regular_amount + overtime_amount + other_amount - deduction_amount
    row = DailyLaborEntry(company_id=ctx["company_id"], worker_id=worker.id, project_id=p.id, site_id=site_id,
        work_date=work_date, regular_hours=regular_hours, overtime_hours=overtime_hours,
        daily_rate=worker.daily_rate, overtime_rate=worker.overtime_rate, regular_amount=regular_amount,
        overtime_amount=overtime_amount, other_amount=other_amount, deduction_amount=deduction_amount,
        net_amount=net, notes=notes, status="draft")
    db.add(row); db.commit()
    return RedirectResponse(f"/site-operations/daily-labor?project_id={p.id}", status_code=303)


@router.post("/daily-labor/{entry_id}/approve")
def approve_daily_labor_form(entry_id: int, project_id: int, db: Session = Depends(get_db),
                             ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:manage"))):
    p = _project(db, ctx["company_id"], user.id, project_id)
    row = db.query(DailyLaborEntry).filter_by(id=entry_id, company_id=ctx["company_id"], project_id=p.id).first()
    if not row:
        raise HTTPException(404, "Daily labor entry not found")
    if row.status == "approved":
        return RedirectResponse(f"/site-operations/daily-labor?project_id={p.id}", status_code=303)
    if row.project_cost_id:
        row.status = "approved"
    else:
        pc = ProjectCost(company_id=ctx["company_id"], project_id=p.id, cost_type="labor", source_type="daily_labor",
            source_id=row.id, amount=row.net_amount, cost_date=datetime.combine(row.work_date, datetime.min.time()),
            description=f"Daily labor #{row.id}")
        db.add(pc); db.flush(); row.project_cost_id = pc.id; row.status = "approved"
    row.approved_by_id = user.id
    row.approved_at = datetime.utcnow()
    db.commit()
    return RedirectResponse(f"/site-operations/daily-labor?project_id={p.id}", status_code=303)


@router.post("/daily-labor/settlement")
def create_daily_labor_settlement_form(project_id: int, period_start: date, period_end: date,
                                       db: Session = Depends(get_db), ctx=Depends(get_tenant_context),
                                       user: User = Depends(require_permission("construction:manage"))):
    if period_end < period_start:
        raise HTTPException(422, "Period end must be on or after period start")
    p = _project(db, ctx["company_id"], user.id, project_id)
    rows = db.query(DailyLaborEntry).filter(DailyLaborEntry.company_id == ctx["company_id"],
        DailyLaborEntry.project_id == p.id, DailyLaborEntry.status == "approved",
        DailyLaborEntry.work_date >= period_start, DailyLaborEntry.work_date <= period_end).all()
    gross = sum((Decimal(str(r.regular_amount or 0)) + Decimal(str(r.overtime_amount or 0)) + Decimal(str(r.other_amount or 0)) for r in rows), Decimal("0"))
    deductions = sum((Decimal(str(r.deduction_amount or 0)) for r in rows), Decimal("0"))
    st = DailyLaborSettlement(company_id=ctx["company_id"], project_id=p.id, period_start=period_start,
        period_end=period_end, gross_amount=gross, deductions=deductions, net_amount=gross-deductions, status="draft")
    db.add(st); db.commit()
    return RedirectResponse(f"/site-operations/daily-labor?project_id={p.id}", status_code=303)


@router.get("/equipment", response_class=HTMLResponse)
def equipment_page(request: Request, project_id: int, equipment_id: int | None = None, site_id: int | None = None, date_from: date | None = None, date_to: date | None = None, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:view"))):
    p = _project(db, ctx["company_id"], user.id, project_id)
    equipment = db.query(Equipment).filter_by(company_id=ctx["company_id"], is_active=True).order_by(Equipment.code).all()
    sites = db.query(ConstructionSite).filter_by(company_id=ctx["company_id"], project_id=p.id).order_by(ConstructionSite.name).all()
    q = db.query(EquipmentUsage).filter_by(company_id=ctx["company_id"], project_id=p.id)
    if equipment_id: q = q.filter(EquipmentUsage.equipment_id == equipment_id)
    if site_id: q = q.filter(EquipmentUsage.site_id == site_id)
    if date_from: q = q.filter(EquipmentUsage.usage_date >= date_from)
    if date_to: q = q.filter(EquipmentUsage.usage_date <= date_to)
    rows = q.order_by(EquipmentUsage.usage_date.desc(), EquipmentUsage.id.desc()).limit(200).all()
    eq_map = {e.id: e for e in equipment}
    site_map = {s.id: s for s in sites}
    total_hours = sum((Decimal(str(r.hours or 0)) for r in rows), Decimal("0"))
    total_cost = sum((Decimal(str(r.total_cost or 0)) for r in rows), Decimal("0"))
    active_equipment = len({r.equipment_id for r in rows})
    avg_hourly_cost = (total_cost / total_hours) if total_hours else Decimal("0")
    metrics = {"records": len(rows), "active_equipment": active_equipment, "hours": total_hours, "cost": total_cost, "avg_rate": avg_hourly_cost}
    return templates.TemplateResponse(request, "site_operations_equipment.html", _page_context(request, user, [p], p, equipment=equipment, sites=sites, rows=rows, eq_map=eq_map, site_map=site_map, metrics=metrics, filters={"equipment_id": equipment_id, "site_id": site_id, "date_from": date_from, "date_to": date_to}))


@router.post("/equipment")
def create_equipment_form(project_id: int, equipment_id: int, usage_date: date, start_reading: Decimal, end_reading: Decimal, rate_per_hour: Decimal | None = None, site_id: int | None = None, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:manage"))):
    p = _project(db, ctx["company_id"], user.id, project_id)
    if site_id and not db.query(ConstructionSite).filter_by(id=site_id, company_id=ctx["company_id"], project_id=p.id).first():
        raise HTTPException(422, "Site does not belong to project")
    try:
        record_equipment_usage(db, ctx["company_id"], p.id, equipment_id, usage_date, start_reading, end_reading, rate_per_hour, site_id)
        db.commit()
    except ValueError as exc:
        db.rollback(); raise HTTPException(409, str(exc))
    return RedirectResponse(f"/site-operations/equipment?project_id={p.id}", status_code=303)


@router.get("/material-requisitions", response_class=HTMLResponse)
def material_requisitions_page(request: Request, project_id: int, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:view"))):
    p = _project(db, ctx["company_id"], user.id, project_id)
    items = db.query(Item).filter_by(company_id=ctx["company_id"]).order_by(Item.code).all()
    sites = db.query(ConstructionSite).filter_by(company_id=ctx["company_id"], project_id=p.id).order_by(ConstructionSite.name).all()
    reqs = db.query(SiteMaterialRequisition).filter_by(company_id=ctx["company_id"], project_id=p.id).order_by(SiteMaterialRequisition.id.desc()).limit(100).all()
    warehouses = db.query(Warehouse).filter(Warehouse.company_id == ctx["company_id"], Warehouse.is_active == True,
        ((Warehouse.project_id == p.id) | (Warehouse.project_id.is_(None)))).order_by(Warehouse.code).all()

    item_map = {i.id: i for i in items}
    site_map = {x.id: x for x in sites}
    warehouse_map = {w.id: w for w in warehouses}
    req_lines = db.query(SiteMaterialRequisitionLine).filter(
        SiteMaterialRequisitionLine.company_id == ctx["company_id"],
        SiteMaterialRequisitionLine.requisition_id.in_([r.id for r in reqs] or [-1])
    ).order_by(SiteMaterialRequisitionLine.requisition_id, SiteMaterialRequisitionLine.id).all()
    lines_by_req = {}
    for line in req_lines:
        lines_by_req.setdefault(line.requisition_id, []).append(line)

    stock = {}
    for item in items:
        q = db.query(StockMovement.warehouse_id, func.coalesce(func.sum(StockMovement.quantity), 0)).filter(
            StockMovement.company_id == ctx["company_id"], StockMovement.item_id == item.id,
            StockMovement.warehouse_id.in_([w.id for w in warehouses] or [-1])
        ).group_by(StockMovement.warehouse_id).all()
        inbound = db.query(StockMovement.warehouse_id, func.coalesce(func.sum(StockMovement.quantity), 0)).filter(
            StockMovement.company_id == ctx["company_id"], StockMovement.item_id == item.id,
            StockMovement.warehouse_id.in_([w.id for w in warehouses] or [-1]),
            StockMovement.movement_type.in_([MovementTypeEnum.in_, MovementTypeEnum.adjustment_in])
        ).group_by(StockMovement.warehouse_id).all()
        outbound = db.query(StockMovement.warehouse_id, func.coalesce(func.sum(StockMovement.quantity), 0)).filter(
            StockMovement.company_id == ctx["company_id"], StockMovement.item_id == item.id,
            StockMovement.warehouse_id.in_([w.id for w in warehouses] or [-1]),
            StockMovement.movement_type.in_([MovementTypeEnum.out, MovementTypeEnum.adjustment_out])
        ).group_by(StockMovement.warehouse_id).all()
        im={wid: Decimal(str(v or 0)) for wid,v in inbound}; om={wid: Decimal(str(v or 0)) for wid,v in outbound}
        stock[item.id] = {wid: im.get(wid, Decimal('0')) - om.get(wid, Decimal('0')) for wid in set(im)|set(om)}

    metrics = {
        "total": len(reqs),
        "draft": sum(1 for r in reqs if r.status == "draft"),
        "approved": sum(1 for r in reqs if r.status in {"approved", "partially_fulfilled"}),
        "fulfilled": sum(1 for r in reqs if r.status == "fulfilled"),
        "purchase_requested": sum(1 for r in reqs if r.status == "purchase_requested"),
    }
    return templates.TemplateResponse(request, "site_operations_materials.html", _page_context(
        request, user, [p], p, items=items, sites=sites, reqs=reqs, warehouses=warehouses,
        item_map=item_map, site_map=site_map, warehouse_map=warehouse_map, lines_by_req=lines_by_req,
        stock=stock, metrics=metrics))


@router.post("/material-requisitions")
def create_material_requisition_form(project_id: int, requisition_no: str, item_id: int, requested_qty: Decimal, estimated_unit_cost: Decimal = Decimal("0"), site_id: int | None = None, required_date: date | None = None, purpose: str | None = None, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:manage"))):
    p = _project(db, ctx["company_id"], user.id, project_id)
    if site_id and not db.query(ConstructionSite).filter_by(id=site_id, company_id=ctx["company_id"], project_id=p.id).first():
        raise HTTPException(422, "Site does not belong to project")
    try:
        create_material_requisition(db, ctx["company_id"], p.id, requisition_no.strip(), [{"item_id": item_id, "requested_qty": requested_qty, "estimated_unit_cost": estimated_unit_cost}], user.id, site_id, required_date, purpose)
        db.commit()
    except (FieldOpsError, BudgetExceeded) as exc:
        db.rollback(); raise HTTPException(409, str(exc))
    return RedirectResponse(f"/site-operations/material-requisitions?project_id={p.id}", status_code=303)


@router.post("/sites")
def create_site_form(project_id: int, code: str, name: str, location: str | None = None, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:manage"))):
    p = _project(db, ctx["company_id"], user.id, project_id)
    try:
        create_site(db, ctx["company_id"], p.id, code.strip(), name.strip(), location)
        db.commit()
    except ValueError as exc:
        db.rollback(); raise HTTPException(409, str(exc))
    return RedirectResponse(f"/site-operations?project_id={p.id}", status_code=303)


@router.post("/warehouses")
def create_project_warehouse(project_id: int, code: str, name: str, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:manage"))):
    p = _project(db, ctx["company_id"], user.id, project_id)
    code, name = code.strip(), name.strip()
    if not code or not name:
        raise HTTPException(422, "Warehouse code and name are required")
    if db.query(Warehouse).filter_by(company_id=ctx["company_id"], code=code).first():
        raise HTTPException(409, "Warehouse code already exists")
    db.add(Warehouse(company_id=ctx["company_id"], branch_id=p.branch_id, project_id=p.id, code=code, name=name, warehouse_type="project"))
    db.commit()
    return RedirectResponse(f"/site-operations/material-requisitions?project_id={p.id}", status_code=303)


@router.post("/material-requisitions/{requisition_id}/approve")
def approve_material_requisition_form(requisition_id: int, project_id: int, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:manage"))):
    p = _project(db, ctx["company_id"], user.id, project_id)
    from ..field_ops_services import approve_material_requisition
    try:
        approve_material_requisition(db, ctx["company_id"], requisition_id, user.id)
        db.commit()
    except FieldOpsError as exc:
        db.rollback(); raise HTTPException(409, str(exc))
    return RedirectResponse(f"/site-operations/material-requisitions?project_id={p.id}", status_code=303)


@router.post("/material-requisitions/{requisition_id}/issue")
def issue_material_requisition_form(requisition_id: int, project_id: int, warehouse_id: int, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:manage"))):
    p = _project(db, ctx["company_id"], user.id, project_id)
    req = db.query(SiteMaterialRequisition).filter_by(id=requisition_id, company_id=ctx["company_id"], project_id=p.id).first()
    if not req:
        raise HTTPException(404, "Material requisition not found")
    try:
        issue_material_requisition_from_warehouse(db, ctx["company_id"], requisition_id, warehouse_id, user.id)
        db.commit()
    except FieldOpsError as exc:
        db.rollback(); raise HTTPException(409, str(exc))
    return RedirectResponse(f"/site-operations/material-requisitions?project_id={p.id}", status_code=303)



@router.post("/material-requisitions/{requisition_id}/purchase-request")
def material_requisition_purchase_request(requisition_id: int, project_id: int, reference: str, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:manage"))):
    p = _project(db, ctx["company_id"], user.id, project_id)
    req = db.query(SiteMaterialRequisition).filter_by(id=requisition_id, company_id=ctx["company_id"], project_id=p.id).first()
    if not req:
        raise HTTPException(404, "Material requisition not found")
    try:
        fulfill_material_requisition(db, ctx["company_id"], requisition_id, "purchase_request", reference.strip() or req.requisition_no)
        db.commit()
    except FieldOpsError as exc:
        db.rollback(); raise HTTPException(409, str(exc))
    return RedirectResponse(f"/site-operations/material-requisitions?project_id={p.id}", status_code=303)


@router.get("/cost-control", response_class=HTMLResponse)
def material_cost_control_page(request: Request, project_id: int, date_from: date | None = None, date_to: date | None = None, status: str | None = None, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:view"))):
    p = _project(db, ctx["company_id"], user.id, project_id)
    projects = _visible_projects(db, ctx["company_id"], user.id, ctx.get("branch_id"))
    lines = db.query(BOQLine).filter_by(company_id=ctx["company_id"], project_id=p.id).order_by(BOQLine.item_code, BOQLine.id).all()
    rows=[]
    def apply_dates(q, model):
        if date_from and hasattr(model, 'created_at'): q=q.filter(model.created_at >= date_from)
        if date_to and hasattr(model, 'created_at'): q=q.filter(model.created_at < date_to + timedelta(days=1))
        return q
    for line in lines:
        issued_q=db.query(func.coalesce(func.sum(SiteMaterialIssue.quantity),0)).filter(SiteMaterialIssue.company_id==ctx["company_id"], SiteMaterialIssue.project_id==p.id, SiteMaterialIssue.boq_line_id==line.id, SiteMaterialIssue.status=="posted")
        issued=apply_dates(issued_q, SiteMaterialIssue).scalar() or 0
        consumed_q=db.query(func.coalesce(func.sum(SiteMaterialConsumption.quantity),0)).filter(SiteMaterialConsumption.company_id==ctx["company_id"], SiteMaterialConsumption.project_id==p.id, SiteMaterialConsumption.boq_line_id==line.id, SiteMaterialConsumption.status=="posted")
        consumed=apply_dates(consumed_q, SiteMaterialConsumption).scalar() or 0
        linked_items=[x[0] for x in db.query(SiteMaterialRequisitionLine.item_id).filter(SiteMaterialRequisitionLine.company_id==ctx["company_id"], SiteMaterialRequisitionLine.boq_line_id==line.id).distinct().all()]
        waste_q=db.query(func.coalesce(func.sum(SiteMaterialAdjustment.quantity),0)).filter(SiteMaterialAdjustment.company_id==ctx["company_id"], SiteMaterialAdjustment.project_id==p.id, SiteMaterialAdjustment.item_id.in_(linked_items or [-1]), SiteMaterialAdjustment.adjustment_type=="waste", SiteMaterialAdjustment.status=="posted")
        returned_q=db.query(func.coalesce(func.sum(SiteMaterialAdjustment.quantity),0)).filter(SiteMaterialAdjustment.company_id==ctx["company_id"], SiteMaterialAdjustment.project_id==p.id, SiteMaterialAdjustment.item_id.in_(linked_items or [-1]), SiteMaterialAdjustment.adjustment_type=="return", SiteMaterialAdjustment.status=="posted")
        waste=apply_dates(waste_q, SiteMaterialAdjustment).scalar() or 0; returned=apply_dates(returned_q, SiteMaterialAdjustment).scalar() or 0
        budget_cost=db.query(func.coalesce(func.sum(ConstructionCostBudgetLine.budget_amount),0)).filter(ConstructionCostBudgetLine.company_id==ctx["company_id"], ConstructionCostBudgetLine.project_id==p.id, ConstructionCostBudgetLine.boq_line_id==line.id, ConstructionCostBudgetLine.status=="active").scalar() or 0
        planned=Decimal(str(line.contract_qty or 0)); issued_d=Decimal(str(issued)); consumed_d=Decimal(str(consumed)); waste_d=Decimal(str(waste)); returned_d=Decimal(str(returned))
        planned_cost=Decimal(str(budget_cost)) if Decimal(str(budget_cost))>0 else planned*Decimal(str(line.contract_rate or 0))
        cost_q=db.query(SiteMaterialConsumption.total_cost).filter(SiteMaterialConsumption.company_id==ctx["company_id"], SiteMaterialConsumption.project_id==p.id, SiteMaterialConsumption.boq_line_id==line.id, SiteMaterialConsumption.status=="posted")
        actual_cost=sum((Decimal(str(x[0] or 0)) for x in apply_dates(cost_q, SiteMaterialConsumption).all()), Decimal("0"))
        if linked_items:
            waste_cost_q=db.query(SiteMaterialAdjustment.total_cost).filter(SiteMaterialAdjustment.company_id==ctx["company_id"], SiteMaterialAdjustment.project_id==p.id, SiteMaterialAdjustment.item_id.in_(linked_items), SiteMaterialAdjustment.adjustment_type=="waste", SiteMaterialAdjustment.status=="posted")
            actual_cost+=sum((Decimal(str(x[0] or 0)) for x in apply_dates(waste_cost_q, SiteMaterialAdjustment).all()), Decimal("0"))
        qty_variance=consumed_d+waste_d-planned; cost_variance=actual_cost-planned_cost
        waste_pct=(waste_d/(consumed_d+waste_d)*Decimal("100")) if (consumed_d+waste_d) else Decimal("0")
        utilization=(actual_cost/planned_cost*Decimal("100")) if planned_cost else Decimal("0")
        if planned_cost and actual_cost>planned_cost: health='over_budget'; health_label='تجاوز الميزانية'
        elif utilization>=Decimal('85'): health='watch'; health_label='يحتاج متابعة'
        elif waste_pct>=Decimal('5'): health='waste'; health_label='هالك مرتفع'
        else: health='on_track'; health_label='ضمن الحدود'
        if status and health != status: continue
        rows.append({"line":line,"cost_code":(db.query(ConstructionCostCode.code).filter_by(id=line.cost_code_id, company_id=ctx["company_id"]).scalar() if line.cost_code_id else None),"planned":planned,"issued":issued_d,"consumed":consumed_d,"waste":waste_d,"returned":returned_d,"site_balance":issued_d-consumed_d-waste_d-returned_d,"qty_variance":qty_variance,"planned_cost":planned_cost,"actual_cost":actual_cost,"cost_variance":cost_variance,"waste_pct":waste_pct.quantize(Decimal("0.01")),"utilization":utilization.quantize(Decimal('0.01')),"health":health,"health_label":health_label})
    totals={k:sum((r[k] for r in rows), Decimal("0")) for k in ("planned","issued","consumed","waste","returned","planned_cost","actual_cost","cost_variance")}
    totals['remaining_budget']=totals['planned_cost']-totals['actual_cost']
    totals['utilization']=((totals['actual_cost']/totals['planned_cost']*Decimal('100')) if totals['planned_cost'] else Decimal('0')).quantize(Decimal('0.01'))
    totals['waste_pct']=((totals['waste']/(totals['consumed']+totals['waste'])*Decimal('100')) if (totals['consumed']+totals['waste']) else Decimal('0')).quantize(Decimal('0.01'))
    alerts=[r for r in rows if r['health']!='on_track']
    return templates.TemplateResponse(request,"site_operations_cost_control.html",_page_context(request,user,projects,p,rows=rows,totals=totals,alerts=alerts,date_from=date_from,date_to=date_to,status=status))


@router.get("/project-cost-control", response_class=HTMLResponse)
def project_cost_control_page(request: Request, project_id: int, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:view"))):
    p = _project(db, ctx["company_id"], user.id, project_id)
    projects = _visible_projects(db, ctx["company_id"], user.id, ctx.get("branch_id"))
    from ..construction_services import project_cost_control_dashboard
    summary = project_cost_control_dashboard(db, ctx["company_id"], p.id)
    actual = summary["actual"]
    summary["category_pct"] = {k: ((v / actual * Decimal("100")).quantize(Decimal("0.01")) if actual else Decimal("0.00")) for k,v in summary["categories"].items()}
    return templates.TemplateResponse(request, "project_cost_control.html", _page_context(request, user, projects, p, summary=summary))

@router.get("/material-flow", response_class=HTMLResponse)
def material_flow_page(request: Request, project_id: int, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:view"))):
    p = _project(db, ctx["company_id"], user.id, project_id)
    company_id = ctx["company_id"]
    sites = db.query(ConstructionSite).filter_by(company_id=company_id, project_id=p.id).order_by(ConstructionSite.name).all()
    issues = db.query(SiteMaterialIssue).filter_by(company_id=company_id, project_id=p.id, status="posted").order_by(SiteMaterialIssue.id.desc()).limit(100).all()
    receipts = db.query(SiteMaterialReceipt).filter_by(company_id=company_id, project_id=p.id, status="posted").order_by(SiteMaterialReceipt.id.desc()).limit(100).all()
    consumption = db.query(SiteMaterialConsumption).filter_by(company_id=company_id, project_id=p.id, status="posted").order_by(SiteMaterialConsumption.id.desc()).limit(100).all()
    adjustments = db.query(SiteMaterialAdjustment).filter_by(company_id=company_id, project_id=p.id, status="posted").order_by(SiteMaterialAdjustment.id.desc()).limit(100).all()
    warehouses = db.query(Warehouse).filter(Warehouse.company_id == company_id, Warehouse.is_active == True, ((Warehouse.project_id == p.id) | (Warehouse.project_id.is_(None)))).order_by(Warehouse.code).all()
    items = db.query(Item).filter_by(company_id=company_id, is_active=True).order_by(Item.code).all()
    boq_lines = db.query(BOQLine).filter_by(company_id=company_id, project_id=p.id).order_by(BOQLine.item_code, BOQLine.id).all()
    cost_codes = db.query(ConstructionCostCode).filter_by(company_id=company_id, is_active=True).order_by(ConstructionCostCode.code).all()
    item_map = {x.id: x for x in items}; site_map = {x.id: x for x in sites}
    issue_received = {x.id: Decimal("0") for x in issues}
    for r in receipts:
        if r.issue_id in issue_received: issue_received[r.issue_id] += Decimal(str(r.quantity or 0))
    for issue in issues:
        issue.received_qty = issue_received.get(issue.id, Decimal("0")); issue.remaining_receipt_qty = max(Decimal("0"), Decimal(str(issue.quantity or 0)) - issue.received_qty)
        issue.item_display = item_map.get(issue.item_id); issue.site_display = site_map.get(issue.site_id)
    for row in [*receipts, *consumption, *adjustments]:
        row.item_display = item_map.get(row.item_id); row.site_display = site_map.get(row.site_id)
    issued_qty = sum((Decimal(str(x.quantity or 0)) for x in issues), Decimal("0")); received_qty = sum((Decimal(str(x.quantity or 0)) for x in receipts), Decimal("0"))
    consumed_qty = sum((Decimal(str(x.quantity or 0)) for x in consumption), Decimal("0")); waste_qty = sum((Decimal(str(x.quantity or 0)) for x in adjustments if x.adjustment_type == "waste"), Decimal("0")); returned_qty = sum((Decimal(str(x.quantity or 0)) for x in adjustments if x.adjustment_type == "return"), Decimal("0"))
    metrics = {"issued_qty": issued_qty, "received_qty": received_qty, "pending_receipt_qty": max(Decimal("0"), issued_qty-received_qty), "consumed_qty": consumed_qty, "waste_qty": waste_qty, "returned_qty": returned_qty, "site_balance_qty": received_qty-consumed_qty-waste_qty-returned_qty, "consumption_cost": sum((Decimal(str(x.total_cost or 0)) for x in consumption), Decimal("0")), "waste_cost": sum((Decimal(str(x.total_cost or 0)) for x in adjustments if x.adjustment_type == "waste"), Decimal("0"))}
    metrics["waste_pct"] = ((waste_qty/received_qty*Decimal("100")) if received_qty else Decimal("0")).quantize(Decimal("0.01"))
    return templates.TemplateResponse(request, "site_operations_material_flow.html", _page_context(request, user, [p], p, sites=sites, issues=issues, receipts=receipts, consumption=consumption, adjustments=adjustments, warehouses=warehouses, items=items, boq_lines=boq_lines, cost_codes=cost_codes, metrics=metrics, item_map=item_map, site_map=site_map))

@router.post("/material-flow/receipt")
def material_receipt_form(project_id: int, issue_id: int, quantity: Decimal, receipt_date: date | None = None, reference: str | None = None, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:manage"))):
    p = _project(db, ctx["company_id"], user.id, project_id)
    issue = db.query(SiteMaterialIssue).filter_by(id=issue_id, company_id=ctx["company_id"], project_id=p.id).first()
    if not issue: raise HTTPException(404, "Material issue not found")
    try: receive_material_at_site(db, ctx["company_id"], issue_id, quantity, user.id, receipt_date, reference); db.commit()
    except FieldOpsError as exc: db.rollback(); raise HTTPException(409, str(exc))
    return RedirectResponse(f"/site-operations/material-flow?project_id={p.id}", status_code=303)

@router.post("/material-flow/consume")
def material_consume_form(project_id: int, site_id: int, item_id: int, quantity: Decimal, boq_line_id: int | None = None, cost_code_id: int | None = None, consumption_date: date | None = None, reference: str | None = None, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:manage"))):
    p = _project(db, ctx["company_id"], user.id, project_id)
    try:
        if not db.query(ConstructionSite).filter_by(id=site_id, company_id=ctx["company_id"], project_id=p.id).first():
            raise FieldOpsError("Site does not belong to the selected project")
        if not db.query(Item).filter_by(id=item_id, company_id=ctx["company_id"], is_active=True).first():
            raise FieldOpsError("Invalid or inactive material item")
        boq = None
        if boq_line_id:
            boq = db.query(BOQLine).filter_by(id=boq_line_id, company_id=ctx["company_id"], project_id=p.id).first()
            if not boq: raise FieldOpsError("BOQ line does not belong to the selected project")
            if boq.cost_code_id and cost_code_id and boq.cost_code_id != cost_code_id:
                raise FieldOpsError("Selected cost code does not match the BOQ line")
            if cost_code_id is None: cost_code_id = boq.cost_code_id
            prior = db.query(func.coalesce(func.sum(SiteMaterialConsumption.quantity), 0)).filter(
                SiteMaterialConsumption.company_id==ctx["company_id"], SiteMaterialConsumption.project_id==p.id,
                SiteMaterialConsumption.boq_line_id==boq.id, SiteMaterialConsumption.status=="posted").scalar() or 0
            if Decimal(str(prior)) + Decimal(str(quantity)) > Decimal(str(boq.contract_qty or 0)):
                raise FieldOpsError(f"BOQ quantity limit exceeded: remaining {Decimal(str(boq.contract_qty or 0)) - Decimal(str(prior))}")
        if cost_code_id and not db.query(ConstructionCostCode).filter_by(id=cost_code_id, company_id=ctx["company_id"], is_active=True).first():
            raise FieldOpsError("Invalid cost code")
        consume_site_material(db, ctx["company_id"], p.id, site_id, item_id, quantity, user.id, consumption_date, cost_code_id=cost_code_id, boq_line_id=boq_line_id, reference=reference)
        db.commit()
    except FieldOpsError as exc: db.rollback(); raise HTTPException(409, str(exc))
    return RedirectResponse(f"/site-operations/material-flow?project_id={p.id}", status_code=303)

@router.post("/material-flow/adjustment")
def material_adjustment_form(project_id: int, site_id: int, item_id: int, adjustment_type: str, quantity: Decimal, reason: str, warehouse_id: int | None = None, adjustment_date: date | None = None, reference: str | None = None, db: Session = Depends(get_db), ctx=Depends(get_tenant_context), user: User = Depends(require_permission("construction:manage"))):
    p = _project(db, ctx["company_id"], user.id, project_id)
    if not reason.strip(): raise HTTPException(422, "Reason is required")
    if not db.query(ConstructionSite).filter_by(id=site_id, company_id=ctx["company_id"], project_id=p.id).first(): raise HTTPException(422, "Site does not belong to the selected project")
    if not db.query(Item).filter_by(id=item_id, company_id=ctx["company_id"], is_active=True).first(): raise HTTPException(422, "Invalid or inactive material item")
    try: adjust_site_material(db, ctx["company_id"], p.id, site_id, item_id, adjustment_type, quantity, user.id, reason, warehouse_id, adjustment_date, reference); db.commit()
    except FieldOpsError as exc: db.rollback(); raise HTTPException(409, str(exc))
    return RedirectResponse(f"/site-operations/material-flow?project_id={p.id}", status_code=303)


@router.get("/center", response_class=HTMLResponse)
def operations_center(request: Request, project_id: int, db: Session=Depends(get_db), ctx=Depends(get_tenant_context), user: User=Depends(require_permission("construction:view"))):
    p=_project(db,ctx["company_id"],user.id,project_id)
    today=date.today()
    reports=db.query(DailySiteReport).filter_by(company_id=ctx["company_id"],project_id=p.id).order_by(DailySiteReport.report_date.desc()).limit(30).all()
    issues=db.query(SiteIssue).filter_by(company_id=ctx["company_id"],project_id=p.id).order_by(SiteIssue.id.desc()).limit(50).all()
    plans=db.query(SiteOperationsPlan).filter_by(company_id=ctx["company_id"],project_id=p.id).order_by(SiteOperationsPlan.plan_date.desc()).limit(30).all()
    diary=db.query(SiteDiaryEntry).filter_by(company_id=ctx["company_id"],project_id=p.id).order_by(SiteDiaryEntry.event_date.desc(),SiteDiaryEntry.id.desc()).limit(50).all()
    locations=db.query(SiteLocationNode).filter_by(company_id=ctx["company_id"],project_id=p.id).all()
    progress=db.query(SiteProgressEntry).filter_by(company_id=ctx["company_id"],project_id=p.id).order_by(SiteProgressEntry.progress_date.desc()).limit(50).all()
    return templates.TemplateResponse(request,"site_operations_center.html",_page_context(request,user,[p],p,reports=reports,issues=issues,plans=plans,diary=diary,locations=locations,progress=progress,today=today))

@router.post("/daily-report")
def save_daily_report(project_id:int, report_date:date, weather:str|None=None, work_summary:str|None=None, constraints:str|None=None, tomorrow_plan:str|None=None, notes:str|None=None, db:Session=Depends(get_db),ctx=Depends(get_tenant_context),user:User=Depends(require_permission("construction:manage"))):
    p=_project(db,ctx["company_id"],user.id,project_id)
    row=db.query(DailySiteReport).filter_by(company_id=ctx["company_id"],project_id=p.id,report_date=report_date).first()
    if not row: row=DailySiteReport(company_id=ctx["company_id"],project_id=p.id,report_date=report_date,prepared_by_id=user.id); db.add(row)
    row.weather=weather; row.work_summary=work_summary; row.constraints=constraints; row.tomorrow_plan=tomorrow_plan; row.notes=notes
    db.commit(); return RedirectResponse(f"/site-operations/center?project_id={p.id}",303)

@router.post("/issues")
def create_issue(project_id:int,title:str,description:str|None=None,severity:str="medium",due_date:date|None=None,db:Session=Depends(get_db),ctx=Depends(get_tenant_context),user:User=Depends(require_permission("construction:manage"))):
    p=_project(db,ctx["company_id"],user.id,project_id); n=db.query(func.count(SiteIssue.id)).filter_by(company_id=ctx["company_id"],project_id=p.id).scalar() or 0
    row=SiteIssue(company_id=ctx["company_id"],project_id=p.id,issue_no=f"ISS-{p.id}-{n+1:04d}",title=title,description=description,severity=severity,due_date=due_date,created_by_id=user.id); db.add(row); db.commit(); return RedirectResponse(f"/site-operations/center?project_id={p.id}",303)

@router.post("/issues/{issue_id}/status")
def update_issue_status(issue_id:int,project_id:int,status:str,db:Session=Depends(get_db),ctx=Depends(get_tenant_context),user:User=Depends(require_permission("construction:manage"))):
    p=_project(db,ctx["company_id"],user.id,project_id); row=db.query(SiteIssue).filter_by(id=issue_id,company_id=ctx["company_id"],project_id=p.id).first()
    if not row: raise HTTPException(404,"Issue not found")
    if status not in {"open","in_progress","resolved","closed"}: raise HTTPException(422,"Invalid status")
    row.status=status; row.resolved_at=datetime.utcnow() if status in {"resolved","closed"} else None; db.commit(); return RedirectResponse(f"/site-operations/center?project_id={p.id}",303)

@router.post("/plan")
def create_plan(project_id:int,plan_date:date,title:str,description:str|None=None,db:Session=Depends(get_db),ctx=Depends(get_tenant_context),user:User=Depends(require_permission("construction:manage"))):
    p=_project(db,ctx["company_id"],user.id,project_id); db.add(SiteOperationsPlan(company_id=ctx["company_id"],project_id=p.id,plan_date=plan_date,title=title,description=description,created_by_id=user.id)); db.commit(); return RedirectResponse(f"/site-operations/center?project_id={p.id}",303)

@router.post("/diary")
def create_diary(project_id:int,event_date:date,title:str,event_type:str="general",details:str|None=None,db:Session=Depends(get_db),ctx=Depends(get_tenant_context),user:User=Depends(require_permission("construction:manage"))):
    p=_project(db,ctx["company_id"],user.id,project_id); db.add(SiteDiaryEntry(company_id=ctx["company_id"],project_id=p.id,event_date=event_date,title=title,event_type=event_type,details=details,created_by_id=user.id)); db.commit(); return RedirectResponse(f"/site-operations/center?project_id={p.id}",303)
