"""Field operations APIs. Business rules live in field_ops_services."""
from datetime import date, datetime
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from ..database import get_db
from ..governance import require_permission
from ..models import User
from ..field_ops_services import FieldOpsError, BudgetExceeded, create_equipment_log, add_equipment_cost, allocate_existing_fuel_transaction, allocate_existing_maintenance_record, post_equipment_log, approve_variation_amendment, create_material_requisition, approve_material_requisition, fulfill_material_requisition, submit_offline_batch, process_offline_batch, resolve_offline_conflict, create_webhook_subscription, enqueue_webhook_event, webhook_signature, create_license, evaluate_license_alerts, dispatch_webhook_delivery

router = APIRouter(prefix='/api/v1/field-operations', tags=['Field Operations'])

class EquipmentLogIn(BaseModel):
    company_id: int; project_id: int; equipment_id: int; work_date: date; start_reading: Decimal=Field(ge=0); end_reading: Decimal=Field(ge=0); site_id:int|None=None; wbs_id:int|None=None; cost_code_id:int|None=None; notes:str|None=None
class ExistingCostAllocationIn(BaseModel):
    company_id:int; project_id:int; site_id:int|None=None; equipment_log_id:int|None=None
class EquipmentCostIn(BaseModel):
    company_id:int; equipment_id:int; project_id:int; source_type:str; amount:Decimal=Field(ge=0); entry_date:date; site_id:int|None=None; equipment_log_id:int|None=None; quantity:Decimal|None=None; unit_cost:Decimal|None=None; source_id:int|None=None; description:str|None=None
class VariationApproveIn(BaseModel):
    company_id:int; amendment_no:str; approved_amount:Decimal|None=None; time_extension_days:int=Field(default=0,ge=0); document_id:int|None=None
class MaterialLineIn(BaseModel):
    item_id:int; requested_qty:Decimal=Field(gt=0); boq_line_id:int|None=None; wbs_id:int|None=None; cost_code_id:int|None=None; estimated_unit_cost:Decimal=Field(default=0,ge=0); budget_qty:Decimal|None=None; budget_amount:Decimal|None=None; notes:str|None=None
class MaterialReqIn(BaseModel):
    company_id:int; project_id:int; requisition_no:str; site_id:int|None=None; required_date:date|None=None; purpose:str|None=None; lines:list[MaterialLineIn]=Field(min_length=1,max_length=500)
class FulfillIn(BaseModel):
    fulfillment_type:str; reference:str
class SyncOperationIn(BaseModel):
    operation_id:str; entity_type:str; entity_id:int|None=None; operation:str; payload:dict={}; client_version:int=Field(default=1,ge=1)
class SyncBatchIn(BaseModel):
    company_id:int; device_id:str; batch_id:str; client_created_at:datetime|None=None; operations:list[SyncOperationIn]=Field(min_length=1,max_length=1000)
class WebhookIn(BaseModel):
    company_id:int; name:str; endpoint_url:str; secret:str; event_type:str
class WebhookEventIn(BaseModel):
    company_id:int; event_type:str; payload:dict
class LicenseIn(BaseModel):
    company_id:int; license_type:str; license_number:str; expiry_date:date; reminder_days:int=Field(default=30,ge=0); project_id:int|None=None; site_id:int|None=None; equipment_id:int|None=None; issue_date:date|None=None; document_id:int|None=None


def _handle(fn, *args, **kwargs):
    try: return fn(*args, **kwargs)
    except BudgetExceeded as exc: raise HTTPException(409, str(exc))
    except FieldOpsError as exc: raise HTTPException(409, str(exc))

@router.post('/equipment/logs', status_code=201)
def equipment_log(d:EquipmentLogIn, db:Session=Depends(get_db), user:User=Depends(require_permission('construction:manage'))):
    row=_handle(create_equipment_log, db, d.company_id, **d.model_dump(exclude={'company_id'}), user_id=user.id); db.commit(); return {'id':row.id,'hours':str(row.hours),'estimated_cost':str(row.estimated_cost),'actual_cost':str(row.actual_cost),'variance':str(row.variance_amount)}

@router.post('/equipment/costs', status_code=201)
def equipment_cost(d:EquipmentCostIn, db:Session=Depends(get_db), user:User=Depends(require_permission('construction:manage'))):
    row=_handle(add_equipment_cost, db, **d.model_dump()); db.commit(); return {'id':row.id,'amount':str(row.amount)}

@router.post('/equipment/fuel-transactions/{transaction_id}/allocate', status_code=201)
def fuel_allocate(transaction_id:int, d:ExistingCostAllocationIn, db:Session=Depends(get_db), user:User=Depends(require_permission('construction:manage'))):
    row=_handle(allocate_existing_fuel_transaction, db, d.company_id, transaction_id, d.project_id, d.site_id, d.equipment_log_id); db.commit(); return {'id':row.id,'amount':str(row.amount),'project_cost_id':row.project_cost_id}

@router.post('/equipment/maintenance-records/{maintenance_id}/allocate', status_code=201)
def maintenance_allocate(maintenance_id:int, d:ExistingCostAllocationIn, db:Session=Depends(get_db), user:User=Depends(require_permission('construction:manage'))):
    row=_handle(allocate_existing_maintenance_record, db, d.company_id, maintenance_id, d.project_id, d.site_id, d.equipment_log_id); db.commit(); return {'id':row.id,'amount':str(row.amount),'project_cost_id':row.project_cost_id}

@router.post('/equipment/logs/{log_id}/post')
def equipment_post(log_id:int, company_id:int, db:Session=Depends(get_db), user:User=Depends(require_permission('construction:approve'))):
    row=_handle(post_equipment_log, db, company_id, log_id); db.commit(); return {'id':row.id,'status':row.status,'project_cost_id':row.project_cost_id}

@router.post('/variations/{variation_id}/approve')
def variation_approve(variation_id:int, d:VariationApproveIn, db:Session=Depends(get_db), user:User=Depends(require_permission('construction:approve'))):
    row=_handle(approve_variation_amendment, db, d.company_id, variation_id, d.amendment_no, user.id, d.approved_amount, d.time_extension_days, d.document_id); db.commit(); return {'id':row.id,'status':row.status,'approved_amount':str(row.approved_financial_amount),'budget_applied_at':row.budget_applied_at}

@router.post('/material-requisitions', status_code=201)
def material_req(d:MaterialReqIn, db:Session=Depends(get_db), user:User=Depends(require_permission('construction:manage'))):
    row=_handle(create_material_requisition, db, d.company_id, d.project_id, d.requisition_no, [x.model_dump() for x in d.lines], user.id, d.site_id, d.required_date, d.purpose); db.commit(); return {'id':row.id,'requisition_no':row.requisition_no,'status':row.status}

@router.post('/material-requisitions/{requisition_id}/approve')
def material_req_approve(requisition_id:int, company_id:int, db:Session=Depends(get_db), user:User=Depends(require_permission('construction:approve'))):
    row=_handle(approve_material_requisition, db, company_id, requisition_id, user.id); db.commit(); return {'id':row.id,'status':row.status}

@router.post('/material-requisitions/{requisition_id}/fulfill')
def material_req_fulfill(requisition_id:int, company_id:int, d:FulfillIn, db:Session=Depends(get_db), user:User=Depends(require_permission('construction:manage'))):
    row=_handle(fulfill_material_requisition, db, company_id, requisition_id, d.fulfillment_type, d.reference); db.commit(); return {'id':row.id,'status':row.status,'fulfillment_type':row.fulfillment_type}

@router.post('/offline/batches', status_code=201)
def offline_batch(d:SyncBatchIn, db:Session=Depends(get_db), user:User=Depends(require_permission('construction:manage'))):
    row=_handle(submit_offline_batch, db, d.company_id, d.device_id, d.batch_id, user.id, [x.model_dump() for x in d.operations], d.client_created_at); db.commit(); return {'id':row.id,'status':row.status}

@router.post('/offline/batches/{batch_id}/process')
def offline_process(batch_id:int, company_id:int, db:Session=Depends(get_db), user:User=Depends(require_permission('construction:manage'))):
    row, conflicts=_handle(process_offline_batch, db, company_id, batch_id); db.commit(); return {'id':row.id,'status':row.status,'conflicts':len(conflicts)}

@router.post('/offline/conflicts/{conflict_id}/resolve')
def offline_conflict_resolve(conflict_id:int, company_id:int, resolution:str, db:Session=Depends(get_db), user:User=Depends(require_permission('construction:manage'))):
    row=_handle(resolve_offline_conflict, db, company_id, conflict_id, resolution, user.id); db.commit(); return {'id':row.id,'resolution':row.resolution}

@router.post('/webhooks/subscriptions', status_code=201)
def webhook_sub(d:WebhookIn, db:Session=Depends(get_db), user:User=Depends(require_permission('admin:permissions'))):
    row=_handle(create_webhook_subscription, db, **d.model_dump()); db.commit(); return {'id':row.id,'event_type':row.event_type}

@router.post('/licenses', status_code=201)
def license_create(d:LicenseIn, db:Session=Depends(get_db), user:User=Depends(require_permission('construction:manage'))):
    row=_handle(create_license, db, **d.model_dump()); db.commit(); return {'id':row.id,'license_number':row.license_number,'expiry_date':row.expiry_date}

@router.post('/licenses/evaluate')
def license_evaluate(company_id:int, as_of_date:date, db:Session=Depends(get_db), user:User=Depends(require_permission('reports:view'))):
    queued=_handle(evaluate_license_alerts, db, company_id, as_of_date); db.commit(); return {'queued':len(queued),'alerts':queued}

@router.post('/webhooks/deliveries/{delivery_id}/dispatch')
def webhook_dispatch(delivery_id:int, company_id:int, db:Session=Depends(get_db), user:User=Depends(require_permission('admin:permissions'))):
    row=_handle(dispatch_webhook_delivery, db, company_id, delivery_id); db.commit(); return {'id':row.id,'status':row.status,'attempts':row.attempts,'last_error':row.last_error}

@router.post('/webhooks/events', status_code=201)
def webhook_event(d:WebhookEventIn, db:Session=Depends(get_db), user:User=Depends(require_permission('construction:manage'))):
    event_id,count=_handle(enqueue_webhook_event, db, d.company_id, d.event_type, d.payload); db.commit(); return {'event_id':event_id,'queued':count}
