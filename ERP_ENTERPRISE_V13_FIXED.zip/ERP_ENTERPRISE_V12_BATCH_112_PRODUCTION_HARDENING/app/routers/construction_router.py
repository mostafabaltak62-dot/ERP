from datetime import date
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from ..database import get_db
from ..auth import User
from ..governance import get_tenant_context, require_permission
from ..construction_services import *

router=APIRouter(prefix='/api/v1/construction',tags=['construction'])

class CostCodeIn(BaseModel): code:str=Field(min_length=1,max_length=60); name:str=Field(min_length=1,max_length=180); category:str; parent_id:int|None=None
class WBSIn(BaseModel): project_id:int=Field(gt=0); code:str; name:str; budget_amount:Decimal=Field(default=Decimal('0'),ge=0); parent_id:int|None=None
class BOQLineIn(BaseModel): item_code:str; description:str; unit:str; contract_qty:Decimal=Field(ge=0); contract_rate:Decimal=Field(ge=0); wbs_id:int|None=None; cost_code_id:int|None=None; boq_item_id:int|None=None
class BOQIn(BaseModel): project_id:int; revision_no:int=Field(ge=1); effective_date:date; reason:str=''; lines:list[BOQLineIn]=Field(min_length=1,max_length=5000)
class MeasurementLineIn(BaseModel): boq_line_id:int; current_qty:Decimal=Field(ge=0); cumulative_qty:Decimal|None=Field(default=None,ge=0)
class MeasurementIn(BaseModel): project_id:int; measurement_no:str; measurement_date:date; notes:str=''; lines:list[MeasurementLineIn]=Field(min_length=1,max_length=2000)
class VariationIn(BaseModel): project_id:int; variation_no:str; description:str; amount:Decimal; contract_id:int|None=None
class CertificateLineIn(BaseModel): boq_line_id:int; current_qty:Decimal=Field(ge=0); cumulative_qty:Decimal=Field(ge=0)
class CertificateIn(BaseModel): project_id:int; contract_id:int|None=None; certificate_number:str; certificate_date:date; retention_rate:Decimal=Field(default=0,ge=0,le=100); advance_recovery:Decimal=Field(default=0,ge=0); lines:list[CertificateLineIn]=Field(min_length=1,max_length=2000)
class AdvanceIn(BaseModel): project_id:int; contract_id:int; direction:str; amount:Decimal=Field(gt=0); advance_date:date; reference:str|None=None
class SubcontractorProgressIn(BaseModel): project_id:int; contract_id:int; certificate_no:str; certificate_date:date; gross_amount:Decimal=Field(gt=0); retention_amount:Decimal=Field(default=0,ge=0); advance_recovery:Decimal=Field(default=0,ge=0); deductions:Decimal=Field(default=0,ge=0)

@router.post('/cost-codes',status_code=201)
def cost_code(data:CostCodeIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r=create_cost_code(db,ctx['company_id'],**data.model_dump()); db.commit(); return {'id':r.id,'code':r.code,'category':r.category}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/wbs',status_code=201)
def wbs(data:WBSIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r=create_wbs(db,ctx['company_id'],**data.model_dump()); db.commit(); return {'id':r.id,'code':r.code,'level':r.level}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/boq/revisions',status_code=201)
def boq(data:BOQIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r,total=create_boq_revision(db,ctx['company_id'],data.project_id,data.revision_no,data.effective_date,data.reason,user.id,[x.model_dump() for x in data.lines]); db.commit(); return {'id':r.id,'revision_no':r.revision_no,'value':str(total)}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/measurements',status_code=201)
def measurement(data:MeasurementIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  lines=[x.model_dump() for x in data.lines]
  for x in lines:
   if x['cumulative_qty'] is None: x['cumulative_qty']=x['current_qty']
  r,total=record_measurement(db,ctx['company_id'],data.project_id,data.measurement_no,data.measurement_date,user.id,lines,data.notes); db.commit(); return {'id':r.id,'measurement_no':r.measurement_no,'amount':str(total)}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/measurements/{measurement_id}/approve')
def approve_measurement_route(measurement_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:approve'))):
 try: r=approve_measurement(db,ctx['company_id'],measurement_id); db.commit(); return {'id':r.id,'status':r.status}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/variations',status_code=201)
def variation(data:VariationIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try: r=add_variation(db,ctx['company_id'],**data.model_dump()); db.commit(); return {'id':r.id,'variation_no':r.variation_no,'status':r.status}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/variations/{variation_id}/approve')
def approve_variation_route(variation_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:approve'))):
 try: r=approve_variation(db,ctx['company_id'],variation_id,user.id); db.commit(); return {'id':r.id,'status':r.status}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/progress-certificates',status_code=201)
def certificate(data:CertificateIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r=create_progress_certificate(db,ctx['company_id'],data.project_id,data.certificate_number,data.certificate_date,user.id,[x.model_dump() for x in data.lines],data.retention_rate,data.advance_recovery,contract_id=data.contract_id); db.commit(); return {'id':r.id,'gross_amount':str(r.gross_amount),'retention_amount':str(r.retention_amount),'advance_recovery':str(r.advance_recovery),'net_amount':str(r.net_amount)}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/progress-certificates/{certificate_id}/approve')
def approve_certificate_route(certificate_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:approve'))):
 try: r=approve_certificate(db,ctx['company_id'],certificate_id,user.id); db.commit(); return {'id':r.id,'status':r.status}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/advances',status_code=201)
def advance(data:AdvanceIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try: r=create_advance(db,ctx['company_id'],**data.model_dump(),user_id=user.id); db.commit(); return {'id':r.id,'amount':str(r.amount),'status':r.status}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/advances/{advance_id}/recover')
def recover_advance_route(advance_id:int,amount:Decimal,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try: r=recover_advance(db,ctx['company_id'],advance_id,amount); db.commit(); return {'id':r.id,'recovered_amount':str(r.recovered_amount),'status':r.status}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/subcontractor-progress',status_code=201)
def subcontractor_progress(data:SubcontractorProgressIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try: r=create_subcontractor_progress(db,ctx['company_id'],**data.model_dump(),user_id=user.id); db.commit(); return {'id':r.id,'net_amount':str(r.net_amount),'status':r.status}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/subcontractor-progress/{progress_id}/approve')
def approve_subcontractor_progress_route(progress_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:approve'))):
 try: r=approve_subcontractor_progress(db,ctx['company_id'],progress_id,user.id); db.commit(); return {'id':r.id,'status':r.status,'journal_entry_id':r.journal_entry_id}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))


class CostBudgetIn(BaseModel):
    project_id:int
    description:str
    budget_amount:Decimal=Field(ge=0)
    cost_code_id:int|None=None
    wbs_id:int|None=None
    boq_line_id:int|None=None
    budget_date:date|None=None

class CommitmentIn(BaseModel):
    project_id:int
    description:str
    committed_amount:Decimal=Field(ge=0)
    commitment_date:date
    contract_id:int|None=None
    cost_code_id:int|None=None
    wbs_id:int|None=None
    subcontractor_boq_line_id:int|None=None
    source_type:str='manual'
    source_id:int|None=None

class SubMeasurementLineIn(BaseModel):
    subcontractor_boq_line_id:int
    current_qty:Decimal=Field(ge=0)
    cumulative_qty:Decimal|None=Field(default=None,ge=0)

class SubMeasurementIn(BaseModel):
    project_id:int
    contract_id:int
    measurement_no:str
    measurement_date:date
    notes:str=''
    lines:list[SubMeasurementLineIn]=Field(min_length=1,max_length=2000)

class SubProgressFromMeasurementIn(BaseModel):
    project_id:int
    contract_id:int
    certificate_no:str
    certificate_date:date
    measurement_id:int
    retention_amount:Decimal=Field(default=0,ge=0)
    advance_recovery:Decimal=Field(default=0,ge=0)
    deductions:Decimal=Field(default=0,ge=0)

class ForecastIn(BaseModel):
    project_id:int
    description:str
    etc_amount:Decimal=Field(ge=0)
    forecast_date:date
    cost_code_id:int|None=None
    wbs_id:int|None=None

class SiteIn(BaseModel): project_id:int; code:str; name:str; location:str|None=None; manager_id:int|None=None
class MaterialIssueIn(BaseModel): project_id:int; site_id:int; item_id:int; quantity:Decimal=Field(gt=0); unit_cost:Decimal=Field(ge=0); issue_date:date; reference:str|None=None
class EquipmentUsageIn(BaseModel): project_id:int; equipment_id:int; site_id:int|None=None; usage_date:date; start_reading:Decimal=Field(ge=0); end_reading:Decimal=Field(ge=0); rate_per_hour:Decimal=Field(ge=0)
class LaborIn(BaseModel): project_id:int; employee_id:int; site_id:int|None=None; work_date:date; regular_hours:Decimal=Field(ge=0); overtime_hours:Decimal=Field(ge=0); regular_rate:Decimal=Field(ge=0); overtime_rate:Decimal=Field(ge=0)
class SubBOQIn(BaseModel): project_id:int; contract_id:int; item_code:str; description:str; unit:str; contract_qty:Decimal=Field(ge=0); contract_rate:Decimal=Field(ge=0); cost_code_id:int|None=None

@router.post('/sites',status_code=201)
def site(data:SiteIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try: r=create_site(db,ctx['company_id'],**data.model_dump()); db.commit(); return {'id':r.id,'code':r.code}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/site-material-issues',status_code=201)
def material_issue(data:MaterialIssueIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try: r=issue_site_material(db,ctx['company_id'],**data.model_dump()); db.commit(); return {'id':r.id,'total_cost':str(r.total_cost)}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/equipment-usage',status_code=201)
def equipment_usage(data:EquipmentUsageIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try: r=record_equipment_usage(db,ctx['company_id'],**data.model_dump()); db.commit(); return {'id':r.id,'hours':str(r.hours),'total_cost':str(r.total_cost)}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/labor',status_code=201)
def labor(data:LaborIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try: r=record_labor(db,ctx['company_id'],**data.model_dump()); db.commit(); return {'id':r.id,'total_cost':str(r.total_cost)}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/subcontractor-boq',status_code=201)
def subcontractor_boq(data:SubBOQIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try: r=create_subcontractor_boq_line(db,ctx['company_id'],**data.model_dump()); db.commit(); return {'id':r.id,'amount':str(q(r.contract_qty*r.contract_rate))}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.get('/projects/{project_id}/cash-flow')
def cash_flow(project_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('reports:view'))):
 try: return {k:str(v) if isinstance(v,Decimal) else v for k,v in construction_cash_flow(db,ctx['company_id'],project_id).items()}
 except ValueError as e: raise HTTPException(404,str(e))

@router.get('/projects/{project_id}/control')
def control(project_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('reports:view'))):
 try: return {k:str(v) if isinstance(v,Decimal) else v for k,v in project_control(db,ctx['company_id'],project_id).items()}
 except ValueError as e: raise HTTPException(404,str(e))


@router.post('/cost-control/budgets',status_code=201)
def cost_budget(data:CostBudgetIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r=create_cost_budget_line(db,ctx['company_id'],**data.model_dump()); db.commit(); return {'id':r.id,'budget_amount':str(r.budget_amount)}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/cost-control/commitments',status_code=201)
def commitment(data:CommitmentIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r=create_commitment(db,ctx['company_id'],**data.model_dump()); db.commit(); return {'id':r.id,'committed_amount':str(r.committed_amount)}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/subcontractor-measurements',status_code=201)
def subcontractor_measurement(data:SubMeasurementIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r,total=create_subcontractor_measurement(db,ctx['company_id'],data.project_id,data.contract_id,data.measurement_no,data.measurement_date,user.id,[x.model_dump() for x in data.lines],data.notes); db.commit(); return {'id':r.id,'amount':str(total),'status':r.status}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/subcontractor-measurements/{measurement_id}/approve')
def approve_subcontractor_measurement_route(measurement_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:approve'))):
 try: r=approve_subcontractor_measurement(db,ctx['company_id'],measurement_id); db.commit(); return {'id':r.id,'status':r.status}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/subcontractor-progress/from-measurement',status_code=201)
def subcontractor_progress_from_measurement(data:SubProgressFromMeasurementIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r=create_subcontractor_progress_from_measurement(db,ctx['company_id'],data.project_id,data.contract_id,data.certificate_no,data.certificate_date,data.measurement_id,data.retention_amount,data.advance_recovery,data.deductions,user.id)
  db.commit(); return {'id':r.id,'gross_amount':str(r.gross_amount),'net_amount':str(r.net_amount),'measurement_id':r.measurement_id}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/cost-control/forecasts',status_code=201)
def forecast(data:ForecastIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r=create_cost_forecast(db,ctx['company_id'],data.project_id,data.description,data.etc_amount,data.forecast_date,data.cost_code_id,data.wbs_id,user.id); db.commit(); return {'id':r.id,'etc_amount':str(r.etc_amount)}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.get('/projects/{project_id}/cost-control')
def cost_control(project_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('reports:view'))):
 try: return {k:str(v) if isinstance(v,Decimal) else v for k,v in construction_cost_control(db,ctx['company_id'],project_id).items()}
 except ValueError as e: raise HTTPException(404,str(e))

@router.get('/projects/{project_id}/cost-control/summary')
def cost_control_summary(project_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('reports:view'))):
 try:
  return {k:({kk:str(vv) for kk,vv in val.items()} if isinstance(val,dict) else str(val) if isinstance(val,Decimal) else val) for k,val in project_cost_control_dashboard(db,ctx['company_id'],project_id).items()}
 except ValueError as e: raise HTTPException(404,str(e))

@router.get('/projects/{project_id}/profitability')
def profitability(project_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('reports:view'))):
 try: return {k:str(v) if isinstance(v,Decimal) else v for k,v in project_profitability(db,ctx['company_id'],project_id).items()}
 except ValueError as e: raise HTTPException(404,str(e))

@router.get('/projects/{project_id}/cash-flow-v63')
def cash_flow_v63(project_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('reports:view'))):
 try: return {k:str(v) if isinstance(v,Decimal) else v for k,v in construction_cash_flow_63(db,ctx['company_id'],project_id).items()}
 except ValueError as e: raise HTTPException(404,str(e))

@router.get('/projects/{project_id}/subcontractors/{contract_id}/control')
def subcontractor_control_route(project_id:int,contract_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('reports:view'))):
 try: return {k:str(v) if isinstance(v,Decimal) else v for k,v in subcontractor_control(db,ctx['company_id'],project_id,contract_id).items()}
 except ValueError as e: raise HTTPException(404,str(e))

# Phase 6.4 APIs
class ActivityIn(BaseModel):
 project_id:int; code:str; name:str; planned_start:date; planned_finish:date; budget_amount:Decimal=Field(ge=0); wbs_id:int|None=None; boq_line_id:int|None=None
class BaselineLineIn(BaseModel): activity_id:int; planned_start:date; planned_finish:date; budget_amount:Decimal|None=Field(default=None,ge=0)
class BaselineIn(BaseModel): project_id:int; baseline_no:int=Field(ge=1); baseline_date:date; lines:list[BaselineLineIn]=Field(min_length=1,max_length=5000)
class ProgressPeriodIn(BaseModel): project_id:int; status_date:date; baseline_id:int|None=None
class ActivityProgressIn(BaseModel): project_id:int; period_id:int; activity_id:int; earned_percent:Decimal=Field(ge=0,le=100); earned_value:Decimal|None=Field(default=None,ge=0); notes:str|None=None
class TimePhasedBudgetIn(BaseModel): project_id:int; period_date:date; planned_value:Decimal=Field(ge=0); baseline_id:int|None=None; activity_id:int|None=None

@router.post('/planning/activities',status_code=201)
def create_planning_activity(data:ActivityIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r=create_activity(db,ctx['company_id'],**data.model_dump()); db.commit(); return {'id':r.id,'code':r.code}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/planning/baselines',status_code=201)
def create_planning_baseline(data:BaselineIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r=create_schedule_baseline(db,ctx['company_id'],data.project_id,data.baseline_no,data.baseline_date,[x.model_dump() for x in data.lines]); db.commit(); return {'id':r.id,'baseline_no':r.baseline_no,'status':r.status}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/planning/progress-periods',status_code=201)
def create_planning_period(data:ProgressPeriodIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r=create_progress_period(db,ctx['company_id'],**data.model_dump()); db.commit(); return {'id':r.id,'status_date':r.status_date}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/planning/progress',status_code=201)
def planning_progress(data:ActivityProgressIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r=set_activity_progress(db,ctx['company_id'],**data.model_dump()); db.commit(); return {'id':r.id,'earned_value':str(r.earned_value)}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/planning/time-phased-budget',status_code=201)
def time_phased_budget(data:TimePhasedBudgetIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r=create_time_phased_budget(db,ctx['company_id'],**data.model_dump()); db.commit(); return {'id':r.id,'planned_value':str(r.planned_value)}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.get('/projects/{project_id}/evm')
def evm(project_id:int,status_date:date,baseline_id:int|None=None,forecast_method:str='cpi',ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('reports:view'))):
 try: return {k:(v.isoformat() if isinstance(v,date) else str(v) if isinstance(v,Decimal) else v) for k,v in construction_evm(db,ctx['company_id'],project_id,status_date,baseline_id,forecast_method).items()}
 except ValueError as e: raise HTTPException(404,str(e))

@router.post('/projects/{project_id}/evm/snapshot',status_code=201)
def evm_snapshot(project_id:int,status_date:date,baseline_id:int|None=None,forecast_method:str='cpi',ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r,x=save_evm_snapshot(db,ctx['company_id'],project_id,status_date,baseline_id,forecast_method); db.commit(); return {'id':r.id,**{k:str(v) if isinstance(v,Decimal) else v for k,v in x.items()}}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))


class EVMCostAllocationIn(BaseModel):
 project_id:int; project_cost_id:int; allocated_amount:Decimal=Field(gt=0); wbs_id:int|None=None; boq_line_id:int|None=None; cost_code_id:int|None=None

@router.post('/planning/evm-cost-allocations',status_code=201)
def evm_cost_allocation(data:EVMCostAllocationIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r=create_evm_cost_allocation(db,ctx['company_id'],**data.model_dump()); db.commit(); return {'id':r.id,'allocated_amount':str(r.allocated_amount)}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.get('/projects/{project_id}/performance-dashboard')
def performance_dashboard(project_id:int,status_date:date,baseline_id:int|None=None,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('reports:view'))):
 try:
  x=construction_performance_dashboard(db,ctx['company_id'],project_id,status_date,baseline_id)
  def conv(v):
   if isinstance(v,Decimal): return str(v)
   if isinstance(v,date): return v.isoformat()
   if isinstance(v,list): return [conv(i) for i in v]
   if isinstance(v,dict): return {k:conv(val) for k,val in v.items()}
   return v
  return conv(x)
 except ValueError as e: raise HTTPException(404,str(e))

class PerformanceAlertEvaluateIn(BaseModel):
 project_id:int=Field(gt=0); status_date:date; baseline_id:int|None=None; forecast_method:str='cpi'
 cpi_warn:Decimal=Field(default=Decimal('0.95'),ge=0); cpi_critical:Decimal=Field(default=Decimal('0.90'),ge=0)
 spi_warn:Decimal=Field(default=Decimal('0.95'),ge=0); spi_critical:Decimal=Field(default=Decimal('0.90'),ge=0)
 vac_warn_pct:Decimal=Field(default=Decimal('-0.05')); vac_critical_pct:Decimal=Field(default=Decimal('-0.10'))
 tcpi_warn:Decimal=Field(default=Decimal('1.05'),ge=0)
class PerformanceAlertResolveIn(BaseModel): corrective_action:str=Field(min_length=3,max_length=4000)

@router.post('/projects/{project_id}/performance-alerts/evaluate')
def evaluate_alerts(project_id:int,data:PerformanceAlertEvaluateIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  if data.project_id != project_id: raise ValueError('Project mismatch')
  d=data.model_dump(); thresholds={k:d[k] for k in ('cpi_warn','cpi_critical','spi_warn','spi_critical','vac_warn_pct','vac_critical_pct','tcpi_warn')}
  x=evaluate_performance_alerts(db,ctx['company_id'],project_id,data.status_date,data.baseline_id,thresholds,data.forecast_method); db.commit()
  return {'status_date':data.status_date.isoformat(),'alerts':[{'id':r.id,'type':r.alert_type,'metric':r.metric,'severity':r.severity,'threshold':str(r.threshold),'actual_value':str(r.actual_value),'status':r.status,'message':r.message} for r in x['alerts']]}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.get('/projects/{project_id}/performance-alerts')
def list_alerts(project_id:int,status_date:date|None=None,status:str|None=None,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('reports:view'))):
 q=db.query(ConstructionPerformanceAlert).filter_by(company_id=ctx['company_id'],project_id=project_id)
 if status_date: q=q.filter(ConstructionPerformanceAlert.status_date==status_date)
 if status: q=q.filter(ConstructionPerformanceAlert.status==status)
 rows=q.order_by(ConstructionPerformanceAlert.status_date.desc(),ConstructionPerformanceAlert.severity.desc(),ConstructionPerformanceAlert.id.desc()).limit(500).all()
 return [{'id':r.id,'status_date':r.status_date.isoformat(),'alert_type':r.alert_type,'metric':r.metric,'severity':r.severity,'threshold':str(r.threshold),'actual_value':str(r.actual_value),'status':r.status,'message':r.message,'corrective_action':r.corrective_action} for r in rows]

@router.post('/performance-alerts/{alert_id}/acknowledge')
def acknowledge_alert(alert_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r=acknowledge_performance_alert(db,ctx['company_id'],alert_id,user.id); db.commit(); return {'id':r.id,'status':r.status,'acknowledged_at':r.acknowledged_at}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/performance-alerts/{alert_id}/resolve')
def resolve_alert(alert_id:int,data:PerformanceAlertResolveIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission('construction:manage'))):
 try:
  r=resolve_performance_alert(db,ctx['company_id'],alert_id,user.id,data.corrective_action); db.commit(); return {'id':r.id,'status':r.status,'resolved_at':r.resolved_at}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))


# Phase 6.4.3 — Recovery planning APIs
class RecoveryPlanIn(BaseModel):
 project_id:int=Field(gt=0); plan_no:str=Field(min_length=1,max_length=60); title:str=Field(min_length=3,max_length=255); target_date:date; owner_id:int|None=None; alert_id:int|None=None; target_cpi:Decimal|None=Field(default=None,ge=0); target_spi:Decimal|None=Field(default=None,ge=0); target_eac:Decimal|None=Field(default=None,ge=0); notes:str|None=None
class RecoveryActionIn(BaseModel):
 plan_id:int=Field(gt=0); action_no:str=Field(min_length=1,max_length=60); description:str=Field(min_length=3,max_length=4000); due_date:date; owner_id:int|None=None
class RecoveryActionUpdateIn(BaseModel):
 status:str|None=None; completion_percent:Decimal|None=Field(default=None,ge=0,le=100); evidence:str|None=None

@router.post('/recovery-plans',status_code=201)
def recovery_plan(data:RecoveryPlanIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user=Depends(require_permission('construction:manage'))):
 try:
  r=create_recovery_plan(db,ctx['company_id'],**data.model_dump()); db.commit(); return {'id':r.id,'plan_no':r.plan_no,'status':r.status}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/recovery-actions',status_code=201)
def recovery_action(data:RecoveryActionIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user=Depends(require_permission('construction:manage'))):
 try:
  r=add_recovery_action(db,ctx['company_id'],**data.model_dump()); db.commit(); return {'id':r.id,'action_no':r.action_no,'status':r.status}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/recovery-actions/{action_id}')
def recovery_action_update(action_id:int,data:RecoveryActionUpdateIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user=Depends(require_permission('construction:manage'))):
 try:
  r=update_recovery_action(db,ctx['company_id'],action_id,**data.model_dump()); db.commit(); return {'id':r.id,'status':r.status,'completion_percent':str(r.completion_percent)}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/recovery-plans/{plan_id}/approve')
def recovery_plan_approve(plan_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user=Depends(require_permission('construction:approve'))):
 try:
  r=approve_recovery_plan(db,ctx['company_id'],plan_id,user.id); db.commit(); return {'id':r.id,'status':r.status}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post('/recovery-plans/{plan_id}/close')
def recovery_plan_close(plan_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user=Depends(require_permission('construction:approve'))):
 try:
  r=close_recovery_plan(db,ctx['company_id'],plan_id,user.id); db.commit(); return {'id':r.id,'status':r.status}
 except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.get('/projects/{project_id}/recovery-plans')
def recovery_plans(project_id:int,status:str|None=None,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user=Depends(require_permission('reports:view'))):
 q=db.query(ConstructionRecoveryPlan).filter_by(company_id=ctx['company_id'],project_id=project_id)
 if status: q=q.filter(ConstructionRecoveryPlan.status==status)
 rows=q.order_by(ConstructionRecoveryPlan.target_date.asc(),ConstructionRecoveryPlan.id.desc()).all()
 return [{'id':r.id,'plan_no':r.plan_no,'title':r.title,'alert_id':r.alert_id,'target_date':r.target_date.isoformat(),'target_cpi':str(r.target_cpi) if r.target_cpi is not None else None,'target_spi':str(r.target_spi) if r.target_spi is not None else None,'target_eac':str(r.target_eac) if r.target_eac is not None else None,'status':r.status,'notes':r.notes,'actions':[{'id':a.id,'action_no':a.action_no,'description':a.description,'due_date':a.due_date.isoformat(),'status':a.status,'completion_percent':str(a.completion_percent),'evidence':a.evidence} for a in db.query(ConstructionRecoveryAction).filter_by(plan_id=r.id,company_id=ctx['company_id']).order_by(ConstructionRecoveryAction.due_date.asc()).all()]} for r in rows]

# Patch 56 — authoritative cost-control linkage APIs
class CostControlLinkageIn(BaseModel):
    project_id:int=Field(gt=0)
    status_date:date

class CostForecastAutoIn(CostControlLinkageIn):
    method:str='remaining_budget'

@router.post('/cost-control/budget-revisions/{revision_id}/approve')
def approve_budget_revision_linkage(revision_id:int,ctx=Depends(get_tenant_context),db=Depends(get_db),user=Depends(require_permission('construction:approve'))):
    try:
        r=approve_cost_budget_revision(db,ctx['company_id'],revision_id,user.id); db.commit()
        return {'id':r.id,'revision_no':r.revision_no,'status':r.status,'authoritative_budget':str(authoritative_budget_total(db,ctx['company_id'],r.project_id))}
    except ValueError as e:
        db.rollback(); raise HTTPException(409,str(e))

@router.post('/cost-control/reconcile')
def cost_reconcile(data:CostControlLinkageIn,ctx=Depends(get_tenant_context),db=Depends(get_db),user=Depends(require_permission('construction:manage'))):
    try:
        r=reconcile_project_costs(db,ctx['company_id'],data.project_id,data.status_date); db.commit()
        return {k:(str(v) if isinstance(v,Decimal) else v) for k,v in r.__dict__.items() if not k.startswith('_')}
    except ValueError as e:
        db.rollback(); raise HTTPException(409,str(e))

@router.post('/cost-control/forecast/auto')
def cost_forecast_auto(data:CostForecastAutoIn,ctx=Depends(get_tenant_context),db=Depends(get_db),user=Depends(require_permission('construction:manage'))):
    try:
        v=generate_cost_forecast(db,ctx['company_id'],data.project_id,data.status_date,user.id,data.method); db.commit()
        return {'id':v.id,'version_no':v.version_no,'status':v.status,'method':v.method,'etc':str(v.total_etc),'eac':str(v.total_eac)}
    except ValueError as e:
        db.rollback(); raise HTTPException(409,str(e))

@router.post('/cost-control/alerts/refresh')
def cost_alerts_refresh(data:CostControlLinkageIn,ctx=Depends(get_tenant_context),db=Depends(get_db),user=Depends(require_permission('construction:manage'))):
    try:
        rows=refresh_cost_alerts(db,ctx['company_id'],data.project_id,data.status_date); db.commit()
        return [{'id':r.id,'type':r.alert_type,'severity':r.severity,'metric':r.metric,'value':str(r.actual_value) if r.actual_value is not None else None,'status':r.status} for r in rows]
    except ValueError as e:
        db.rollback(); raise HTTPException(409,str(e))

@router.post('/cost-control/cash-flow')
def cost_cash_flow(data:CostControlLinkageIn,ctx=Depends(get_tenant_context),db=Depends(get_db),user=Depends(require_permission('reports:view'))):
    try:
        r=build_cost_cash_flow_snapshot(db,ctx['company_id'],data.project_id,data.status_date); db.commit()
        return {k:(str(v) if isinstance(v,Decimal) else v) for k,v in r.__dict__.items() if not k.startswith('_')}
    except ValueError as e:
        db.rollback(); raise HTTPException(409,str(e))

@router.post('/cost-control/profitability/refresh')
def cost_profitability_refresh(data:CostControlLinkageIn,ctx=Depends(get_tenant_context),db=Depends(get_db),user=Depends(require_permission('construction:manage'))):
    try:
        r=refresh_project_profitability_forecast(db,ctx['company_id'],data.project_id,data.status_date); db.commit()
        return {k:(str(v) if isinstance(v,Decimal) else v) for k,v in r.__dict__.items() if not k.startswith('_')}
    except ValueError as e:
        db.rollback(); raise HTTPException(409,str(e))
