# -*- coding: utf-8 -*-
"""Tenant-aware HR workspace pages."""
from fastapi import APIRouter, Depends, Request, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import func, or_
from datetime import date, timedelta
from ..database import get_db
from ..models import User
from ..enterprise_models import Employee, Department, Project, AttendanceRecord, LeaveRequest, PayrollLine, PayrollRun
from ..hr_models import EmployeeProfile, EmployeeProjectAssignment, LeaveBalance, DailyWorker, DailyLaborEntry, HRDocument, PerformanceReview, TrainingRecord, PayrollComponent, EmployeeTimelineEvent
from ..auth import require_module
from ..governance import get_request_context

router=APIRouter(prefix="/hr", tags=["HR Workspace UI"])
templates=Jinja2Templates(directory="templates")

def _cid(user):
    cid=get_request_context().get("company_id") or getattr(user,"company_id",None)
    if cid is None: raise HTTPException(403,"لم يتم تحديد الشركة الحالية")
    return cid

@router.get("",response_class=HTMLResponse)
def hr_home(request:Request, db:Session=Depends(get_db), user:User=Depends(require_module("hr"))):
    cid=_cid(user)
    employees=db.query(Employee).filter(Employee.company_id==cid).order_by(Employee.id.desc()).limit(100).all()
    profiles={p.employee_id:p for p in db.query(EmployeeProfile).filter(EmployeeProfile.company_id==cid).all()}
    departments={d.id:d for d in db.query(Department).filter(Department.company_id==cid).all()}
    active=sum(1 for e in employees if e.is_active)
    assignments=db.query(EmployeeProjectAssignment).filter(EmployeeProjectAssignment.company_id==cid).count()
    leave_open=db.query(LeaveBalance).filter(LeaveBalance.company_id==cid).count()
    daily_workers=db.query(DailyWorker).filter(DailyWorker.company_id==cid).count()
    today=date.today()
    pending_leaves=db.query(LeaveRequest).filter(LeaveRequest.company_id==cid,LeaveRequest.status=='pending').count()
    present_today=db.query(AttendanceRecord).filter(AttendanceRecord.company_id==cid,AttendanceRecord.work_date==today).count()
    absent_today=db.query(AttendanceRecord).filter(AttendanceRecord.company_id==cid,AttendanceRecord.work_date==today,AttendanceRecord.status=='absent').count()
    expiring_to=today+timedelta(days=30)
    expiring_docs=db.query(HRDocument).filter(HRDocument.company_id==cid,HRDocument.expiry_date.is_not(None),HRDocument.expiry_date>=today,HRDocument.expiry_date<=expiring_to).count()
    expired_docs=db.query(HRDocument).filter(HRDocument.company_id==cid,HRDocument.expiry_date.is_not(None),HRDocument.expiry_date<today).count()
    latest_payroll=db.query(PayrollRun).filter(PayrollRun.company_id==cid).order_by(PayrollRun.end_date.desc()).first()
    departments_count=len(departments)
    return templates.TemplateResponse(request,"hr_workspace.html",{
        "user":user,"employees":employees,"profiles":profiles,"departments":departments,
        "summary":{"employees":len(employees),"active":active,"assignments":assignments,"leave_balances":leave_open,"daily_workers":daily_workers,
                   "pending_leaves":pending_leaves,"present_today":present_today,"absent_today":absent_today,"expiring_docs":expiring_docs,
                   "expired_docs":expired_docs,"departments":departments_count,"latest_payroll":latest_payroll}
    })

@router.get("/employees/{employee_id}",response_class=HTMLResponse)
def employee_detail(employee_id:int,request:Request,db:Session=Depends(get_db),user:User=Depends(require_module("hr"))):
    cid=_cid(user)
    employee=db.query(Employee).filter(Employee.id==employee_id,Employee.company_id==cid).first()
    if not employee: raise HTTPException(404,"الموظف غير موجود")
    profile=db.query(EmployeeProfile).filter(EmployeeProfile.employee_id==employee.id,EmployeeProfile.company_id==cid).first()
    assignments=db.query(EmployeeProjectAssignment,Project).outerjoin(Project,Project.id==EmployeeProjectAssignment.project_id).filter(EmployeeProjectAssignment.company_id==cid,EmployeeProjectAssignment.employee_id==employee.id).order_by(EmployeeProjectAssignment.start_date.desc()).all()
    balances=db.query(LeaveBalance).filter(LeaveBalance.company_id==cid,LeaveBalance.employee_id==employee.id).order_by(LeaveBalance.year.desc()).all()
    attendance=db.query(AttendanceRecord).filter(AttendanceRecord.company_id==cid,AttendanceRecord.employee_id==employee.id).order_by(AttendanceRecord.work_date.desc()).limit(12).all()
    leaves=db.query(LeaveRequest).filter(LeaveRequest.company_id==cid,LeaveRequest.employee_id==employee.id).order_by(LeaveRequest.start_date.desc()).limit(12).all()
    documents=db.query(HRDocument).filter(HRDocument.company_id==cid,HRDocument.employee_id==employee.id).order_by(HRDocument.expiry_date.asc()).all()
    reviews=db.query(PerformanceReview).filter(PerformanceReview.company_id==cid,PerformanceReview.employee_id==employee.id).order_by(PerformanceReview.review_date.desc()).all()
    training=db.query(TrainingRecord).filter(TrainingRecord.company_id==cid,TrainingRecord.employee_id==employee.id).order_by(TrainingRecord.start_date.desc()).all()
    components=db.query(PayrollComponent).filter(PayrollComponent.company_id==cid,PayrollComponent.employee_id==employee.id).all()
    payroll=db.query(PayrollLine,PayrollRun).join(PayrollRun,PayrollRun.id==PayrollLine.payroll_run_id).filter(PayrollLine.company_id==cid,PayrollLine.employee_id==employee.id).order_by(PayrollRun.end_date.desc()).limit(12).all()
    timeline=db.query(EmployeeTimelineEvent).filter(EmployeeTimelineEvent.company_id==cid,EmployeeTimelineEvent.employee_id==employee.id).order_by(EmployeeTimelineEvent.event_date.desc(),EmployeeTimelineEvent.id.desc()).limit(30).all()
    return templates.TemplateResponse(request,"employee_detail.html",{"user":user,"employee":employee,"profile":profile,"assignments":assignments,"balances":balances,"attendance":attendance,"leaves":leaves,"documents":documents,"reviews":reviews,"training":training,"components":components,"payroll":payroll,"timeline":timeline})
