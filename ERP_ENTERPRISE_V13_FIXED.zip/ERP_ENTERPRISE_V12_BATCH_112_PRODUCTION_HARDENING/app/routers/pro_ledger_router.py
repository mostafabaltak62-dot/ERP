# -*- coding: utf-8 -*-
"""Advanced Finance workspace.

All advanced-finance masters and postings are explicitly tenant/branch scoped.
A NULL branch means company-wide configuration; a selected branch may see only
its own rows plus company-wide rows. Mutating operations always write the active
company/branch context and pass it explicitly to the accounting engine.
"""
from ..time_utils import utcnow
import csv, datetime, io
from decimal import Decimal, InvalidOperation
from fastapi import APIRouter, Depends, Request, Form, HTTPException, Query
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import func, or_

from ..database import get_db
from ..models import (User, Account, AccountTypeEnum, JournalEntry, JournalLine,
                      CostCenter, JournalLineCostCenter, TaxRate, AccrualEntry,
                      FixedAsset, FixedAssetDisposal, WithholdingTaxRate,
                      WithholdingTaxTransaction, TaxTransaction, AuditLog,
                      ModulePermission)
from ..enterprise_models import Branch, UserCompanyAccess
from ..accounting import next_number, create_entry
from ..auth import require_module
from ..governance import get_request_context, resolve_tenant
from ..governance_models import AssetDepreciationRun

router = APIRouter(prefix="/pro-finance", tags=["pro-finance"])
templates = Jinja2Templates(directory="templates")
D = Decimal

def money(v):
    return Decimal(str(v or 0)).quantize(Decimal("0.01"))

def _dt(value):
    if not value: return None
    try: return datetime.datetime.fromisoformat(value)
    except (ValueError, TypeError): raise HTTPException(400, "التاريخ غير صحيح")

def _scope(db, user, branch_id=None):
    ctx = get_request_context(); cid = ctx.get("company_id")
    if cid is None: raise HTTPException(403, "لم يتم تحديد الشركة الحالية")
    requested = branch_id if branch_id is not None else ctx.get("branch_id")
    bid = resolve_tenant(db, user, cid, int(requested))[1] if requested is not None else None
    return cid, bid

def _branches(db, user, cid):
    q = (db.query(Branch).join(UserCompanyAccess, UserCompanyAccess.branch_id == Branch.id)
         .filter(UserCompanyAccess.user_id == user.id, UserCompanyAccess.company_id == cid,
                 Branch.company_id == cid, Branch.is_active.is_(True)))
    if db.query(UserCompanyAccess).filter(UserCompanyAccess.user_id == user.id,
        UserCompanyAccess.company_id == cid, UserCompanyAccess.branch_id.is_(None)).first():
        q = db.query(Branch).filter(Branch.company_id == cid, Branch.is_active.is_(True))
    return q.order_by(Branch.name).all()

def _edit(db, user):
    if user.role.value == "admin": return True
    p = db.query(ModulePermission).filter_by(user_id=user.id, module_key="accounting").first()
    return bool(p and p.can_edit)

def _ctx(request, user, db, section, rows=None, branch_id=None, **extra):
    cid, bid = _scope(db, user, branch_id)
    return {"user": user, "section": section, "rows": rows or [], "can_edit": _edit(db,user),
            "branches": _branches(db,user,cid), "branch_id": bid, **extra}

def _branch_filter(q, model, bid):
    if bid is not None: q = q.filter(or_(model.branch_id == bid, model.branch_id.is_(None)))
    return q

def _company_branch_filter(q, model, cid, bid):
    q = q.filter(model.company_id == cid)
    return _branch_filter(q, model, bid)

def _account(db, cid, bid, code):
    code = (code or "").strip()
    q = db.query(Account).filter(Account.company_id == cid, Account.code == code, Account.is_active.is_(True))
    if bid is not None: q = q.filter(or_(Account.branch_id == bid, Account.branch_id.is_(None))).order_by(Account.branch_id.desc())
    acc = q.first()
    if not acc: raise HTTPException(400, f"الحساب {code} غير موجود أو غير متاح للفرع الحالي")
    return acc

@router.get("", response_class=HTMLResponse)
def advanced_finance_home(request: Request, db: Session = Depends(get_db), user: User = Depends(require_module("accounting"))):
    cid, bid = _scope(db,user)
    counts = {
        "cost_centers": _company_branch_filter(db.query(CostCenter), CostCenter, cid,bid).filter(CostCenter.is_active.is_(True)).count(),
        "taxes": _company_branch_filter(db.query(TaxRate), TaxRate, cid,bid).filter(TaxRate.is_active.is_(True)).count(),
        "accruals": _company_branch_filter(db.query(AccrualEntry), AccrualEntry, cid,bid).filter(AccrualEntry.is_active.is_(True)).count(),
        "assets": _company_branch_filter(db.query(FixedAsset), FixedAsset, cid,bid).filter(FixedAsset.is_active.is_(True)).count(),
        "withholding": _company_branch_filter(db.query(WithholdingTaxRate), WithholdingTaxRate, cid,bid).filter(WithholdingTaxRate.is_active.is_(True)).count(),
    }
    return templates.TemplateResponse(request,"pro_finance.html",_ctx(request,user,db,"home",counts=counts))

@router.get("/cost-centers", response_class=HTMLResponse)
def cost_centers(request:Request, branch_id:int|None=None, db:Session=Depends(get_db), user:User=Depends(require_module("accounting"))):
    cid,bid=_scope(db,user,branch_id)
    q=_company_branch_filter(db.query(CostCenter),CostCenter,cid,bid).order_by(CostCenter.code).limit(500)
    return templates.TemplateResponse(request,"pro_finance.html",_ctx(request,user,db,"cost_centers",q.all()))

@router.post("/cost-centers/new")
def create_cost_center(db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True)), code:str=Form(...), name:str=Form(...), branch_id:int|None=Form(None)):
    cid,bid=_scope(db,user,branch_id); code=code.strip(); name=name.strip()
    if not code or not name: raise HTTPException(400,"بيانات مركز التكلفة مطلوبة")
    q=db.query(CostCenter).filter(CostCenter.company_id==cid,CostCenter.code==code,CostCenter.branch_id==bid)
    if q.first(): raise HTTPException(409,"كود مركز التكلفة مستخدم داخل هذا النطاق")
    db.add(CostCenter(company_id=cid,branch_id=bid,code=code,name=name)); db.add(AuditLog(user_id=user.id,action="create",entity_type="cost_center",description=code)); db.commit()
    return RedirectResponse(f"/pro-finance/cost-centers{('?branch_id='+str(bid)) if bid else ''}",303)

@router.get("/taxes", response_class=HTMLResponse)
def taxes(request:Request, branch_id:int|None=None, db:Session=Depends(get_db), user:User=Depends(require_module("accounting"))):
    cid,bid=_scope(db,user,branch_id); q=_company_branch_filter(db.query(TaxRate),TaxRate,cid,bid).order_by(TaxRate.code).limit(500)
    return templates.TemplateResponse(request,"pro_finance.html",_ctx(request,user,db,"taxes",q.all()))

def _validate_tax_master(db, cid, bid, code, name, rate, tax_account_code, tax_direction):
    code=(code or "").strip(); name=(name or "").strip(); account=(tax_account_code or "").strip(); rate=money(rate)
    if not code or len(code)>30 or not name or len(name)>100: raise HTTPException(400,"بيانات الضريبة غير صحيحة")
    if rate<0 or rate>100: raise HTTPException(400,"نسبة الضريبة يجب أن تكون بين 0 و100")
    if tax_direction not in ("input","output"): raise HTTPException(400,"نوع الضريبة غير صحيح")
    _account(db,cid,bid,account)
    return code,name,rate,account,tax_direction

@router.post("/taxes/new")
def create_tax(db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True)), code:str=Form(...), name:str=Form(...), rate:Decimal=Form(...), tax_account_code:str=Form("2200"), tax_direction:str=Form("output"), branch_id:int|None=Form(None)):
    cid,bid=_scope(db,user,branch_id); code,name,rate,account,tax_direction=_validate_tax_master(db,cid,bid,code,name,rate,tax_account_code,tax_direction)
    if db.query(TaxRate).filter(TaxRate.company_id==cid,TaxRate.branch_id==bid,TaxRate.code==code).first(): raise HTTPException(409,"كود الضريبة مستخدم داخل هذا النطاق")
    db.add(TaxRate(company_id=cid,branch_id=bid,code=code,name=name,rate=rate,tax_account_code=account,tax_direction=tax_direction)); db.add(AuditLog(user_id=user.id,action="create",entity_type="tax_rate",description=f"إنشاء معدل ضريبة {code}")); db.commit()
    return RedirectResponse(f"/pro-finance/taxes{('?branch_id='+str(bid)) if bid else ''}",303)

@router.post("/taxes/{tax_id}/update")
def update_tax(tax_id:int, db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True)), code:str=Form(...), name:str=Form(...), rate:Decimal=Form(...), tax_account_code:str=Form(...), tax_direction:str=Form(...), branch_id:int|None=Form(None)):
    cid,bid=_scope(db,user,branch_id)
    tax=_company_branch_filter(db.query(TaxRate),TaxRate,cid,bid).filter(TaxRate.id==tax_id).first()
    if not tax: raise HTTPException(404,"معدل الضريبة غير موجود")
    code,name,rate,account,tax_direction=_validate_tax_master(db,cid,bid,code,name,rate,tax_account_code,tax_direction)
    duplicate=db.query(TaxRate).filter(TaxRate.company_id==cid,TaxRate.branch_id==tax.branch_id,TaxRate.code==code,TaxRate.id!=tax.id).first()
    if duplicate: raise HTTPException(409,"كود الضريبة مستخدم داخل هذا النطاق")
    used=db.query(TaxTransaction).filter(TaxTransaction.company_id==cid,TaxTransaction.tax_rate_id==tax.id).first()
    if used and (code!=tax.code or account!=tax.tax_account_code or tax_direction!=tax.tax_direction):
        raise HTTPException(409,"لا يمكن تغيير الكود أو حساب الضريبة أو اتجاهها بعد استخدامها؛ أنشئ معدلًا جديدًا للحفاظ على التاريخ المحاسبي")
    tax.code,tax.name,tax.rate,tax.tax_account_code,tax.tax_direction=code,name,rate,account,tax_direction
    db.add(AuditLog(user_id=user.id,action="update",entity_type="tax_rate",entity_id=tax.id,description=f"تعديل معدل ضريبة {code}")); db.commit()
    return RedirectResponse(f"/pro-finance/taxes{('?branch_id='+str(bid)) if bid else ''}",303)

@router.post("/taxes/{tax_id}/toggle")
def toggle_tax(tax_id:int, db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True)), branch_id:int|None=Form(None)):
    cid,bid=_scope(db,user,branch_id); tax=_company_branch_filter(db.query(TaxRate),TaxRate,cid,bid).filter(TaxRate.id==tax_id).first()
    if not tax: raise HTTPException(404,"معدل الضريبة غير موجود")
    tax.is_active=not tax.is_active
    db.add(AuditLog(user_id=user.id,action="activate" if tax.is_active else "deactivate",entity_type="tax_rate",entity_id=tax.id,description=f"تغيير حالة معدل الضريبة {tax.code}")); db.commit()
    return RedirectResponse(f"/pro-finance/taxes{('?branch_id='+str(bid)) if bid else ''}",303)

@router.get("/accruals", response_class=HTMLResponse)
def accruals(request:Request, branch_id:int|None=None, db:Session=Depends(get_db), user:User=Depends(require_module("accounting"))):
    cid,bid=_scope(db,user,branch_id); q=_company_branch_filter(db.query(AccrualEntry),AccrualEntry,cid,bid).order_by(AccrualEntry.start_date.desc()).limit(500)
    return templates.TemplateResponse(request,"pro_finance.html",_ctx(request,user,db,"accruals",q.all()))

@router.post("/accruals/new")
def create_accrual(db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True)), name:str=Form(...), start_date:str=Form(...), end_date:str=Form(...), total_amount:Decimal=Form(...), expense_account_code:str=Form(...), balance_account_code:str=Form("2210"), branch_id:int|None=Form(None)):
    cid,bid=_scope(db,user,branch_id); s,e=_dt(start_date),_dt(end_date); total=money(total_amount)
    if e is None or s is None or e<=s or total<=0: raise HTTPException(400,"بيانات الاستحقاق غير صحيحة")
    _account(db,cid,bid,expense_account_code); _account(db,cid,bid,balance_account_code)
    a=AccrualEntry(company_id=cid,branch_id=bid,name=name.strip(),start_date=s,end_date=e,total_amount=total,expense_account_code=expense_account_code.strip(),balance_account_code=balance_account_code.strip(),created_by_id=user.id)
    db.add(a); db.flush(); db.add(AuditLog(user_id=user.id,action="create",entity_type="accrual",entity_id=a.id,description=a.name)); db.commit()
    return RedirectResponse(f"/pro-finance/accruals{('?branch_id='+str(bid)) if bid else ''}",303)

@router.post("/accruals/{accrual_id}/recognize")
def recognize_accrual(accrual_id:int, db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True)), amount:Decimal=Form(...), entry_date:str=Form(""), branch_id:int|None=Form(None)):
    cid,bid=_scope(db,user,branch_id); q=_company_branch_filter(db.query(AccrualEntry),AccrualEntry,cid,bid); a=q.filter(AccrualEntry.id==accrual_id).with_for_update().first()
    if not a: raise HTTPException(404,"الاستحقاق غير موجود")
    amount=money(amount); remaining=money(a.total_amount-a.recognized_amount)
    if amount<=0 or amount>remaining: raise HTTPException(400,f"المبلغ المتاح للاعتراف {remaining}")
    dt=_dt(entry_date) or utcnow(); _account(db,cid,bid,a.expense_account_code); _account(db,cid,bid,a.balance_account_code)
    entry=create_entry(db,f"إثبات استحقاق: {a.name}",user.id,[(a.expense_account_code,amount,0),(a.balance_account_code,0,amount)],"accrual",a.id,dt,company_id=cid,branch_id=bid)
    a.recognized_amount=money(a.recognized_amount+amount); a.is_active=a.recognized_amount<a.total_amount
    db.add(AuditLog(user_id=user.id,action="recognize",entity_type="accrual",entity_id=a.id,description=a.name)); db.commit()
    return RedirectResponse(f"/pro-finance/accruals{('?branch_id='+str(bid)) if bid else ''}",303)

@router.get("/assets", response_class=HTMLResponse)
def assets(request:Request, branch_id:int|None=None, db:Session=Depends(get_db), user:User=Depends(require_module("accounting"))):
    cid,bid=_scope(db,user,branch_id); q=_company_branch_filter(db.query(FixedAsset),FixedAsset,cid,bid).order_by(FixedAsset.acquisition_date.desc()).limit(500)
    return templates.TemplateResponse(request,"pro_finance.html",_ctx(request,user,db,"assets",q.all()))

@router.post("/assets/new")
def create_asset(db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True)), asset_code:str=Form(...), name:str=Form(...), acquisition_date:str=Form(...), acquisition_cost:Decimal=Form(...), useful_life_months:int=Form(...), payment_account_code:str=Form("1100"), branch_id:int|None=Form(None)):
    cid,bid=_scope(db,user,branch_id); dt=_dt(acquisition_date) or utcnow(); cost=money(acquisition_cost); code=asset_code.strip()
    if not code or not name.strip() or cost<=0 or useful_life_months<=0: raise HTTPException(400,"بيانات الأصل غير صحيحة")
    if db.query(FixedAsset).filter(FixedAsset.company_id==cid,FixedAsset.branch_id==bid,FixedAsset.asset_code==code).first(): raise HTTPException(409,"كود الأصل مستخدم داخل هذا النطاق")
    for c in ("1500","1510","5400",payment_account_code): _account(db,cid,bid,c)
    asset=FixedAsset(company_id=cid,branch_id=bid,asset_code=code,name=name.strip(),acquisition_date=dt,acquisition_cost=cost,useful_life_months=useful_life_months,created_by_id=user.id)
    db.add(asset); db.flush(); create_entry(db,f"إثبات أصل ثابت {asset.asset_code}",user.id,[("1500",cost,0),(payment_account_code,0,cost)],"fixed_asset",asset.id,dt,company_id=cid,branch_id=bid)
    db.add(AuditLog(user_id=user.id,action="create",entity_type="fixed_asset",entity_id=asset.id,description=asset.asset_code)); db.commit()
    return RedirectResponse(f"/pro-finance/assets{('?branch_id='+str(bid)) if bid else ''}",303)

@router.post("/assets/{asset_id}/depreciate")
def depreciate(asset_id:int, db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True)), entry_date:str=Form(""), branch_id:int|None=Form(None)):
    cid,bid=_scope(db,user,branch_id); asset=_company_branch_filter(db.query(FixedAsset),FixedAsset,cid,bid).filter(FixedAsset.id==asset_id,FixedAsset.is_active.is_(True)).with_for_update().first()
    if not asset: raise HTTPException(404,"الأصل غير موجود أو غير نشط")
    dt=_dt(entry_date) or utcnow(); period_label=dt.strftime("%Y-%m")
    if db.query(AssetDepreciationRun).filter(AssetDepreciationRun.company_id==cid,AssetDepreciationRun.asset_id==asset.id,AssetDepreciationRun.period_label==period_label).first(): raise HTTPException(409,f"تم ترحيل إهلاك الفترة {period_label} لهذا الأصل بالفعل")
    monthly=money((asset.acquisition_cost-asset.residual_value)/asset.useful_life_months); remaining=money(asset.acquisition_cost-asset.residual_value-asset.accumulated_depreciation); amount=min(monthly,remaining)
    if amount<=0: asset.is_active=False; db.commit(); return RedirectResponse(f"/pro-finance/assets{('?branch_id='+str(bid)) if bid else ''}",303)
    _account(db,cid,bid,asset.depreciation_expense_account_code); _account(db,cid,bid,asset.accumulated_depreciation_account_code)
    run=AssetDepreciationRun(company_id=cid,branch_id=bid,asset_id=asset.id,period_label=period_label,amount=amount); db.add(run); db.flush()
    entry=create_entry(db,f"إهلاك أصل ثابت {asset.asset_code} - {period_label}",user.id,[(asset.depreciation_expense_account_code,amount,0),(asset.accumulated_depreciation_account_code,0,amount)],"depreciation",run.id,dt,company_id=cid,branch_id=bid); run.journal_entry_id=entry.id
    asset.accumulated_depreciation=money(asset.accumulated_depreciation+amount); asset.is_active=asset.accumulated_depreciation < asset.acquisition_cost-asset.residual_value
    db.add(AuditLog(user_id=user.id,action="depreciate",entity_type="fixed_asset",entity_id=asset.id,description=f"إهلاك {amount}")); db.commit()
    return RedirectResponse(f"/pro-finance/assets{('?branch_id='+str(bid)) if bid else ''}",303)

@router.post("/assets/{asset_id}/dispose")
def dispose_asset(asset_id:int, db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True)), proceeds:Decimal=Form(0), disposal_date:str=Form(""), proceeds_account_code:str=Form("1100"), branch_id:int|None=Form(None)):
    cid,bid=_scope(db,user,branch_id); asset=_company_branch_filter(db.query(FixedAsset),FixedAsset,cid,bid).filter(FixedAsset.id==asset_id,FixedAsset.is_active.is_(True)).with_for_update().first()
    if not asset: raise HTTPException(404,"الأصل غير موجود أو تم التصرف فيه")
    if db.query(FixedAssetDisposal).filter(FixedAssetDisposal.company_id==cid,FixedAssetDisposal.asset_id==asset.id).first(): raise HTTPException(409,"تم تسجيل التصرف في الأصل بالفعل")
    dt=_dt(disposal_date) or utcnow(); proceeds=money(proceeds)
    if proceeds<0: raise HTTPException(400,"حصيلة البيع لا يمكن أن تكون سالبة")
    _account(db,cid,bid,proceeds_account_code); _account(db,cid,bid,asset.asset_account_code); _account(db,cid,bid,asset.accumulated_depreciation_account_code)
    net_book=money(asset.acquisition_cost-asset.accumulated_depreciation); gain_loss=money(proceeds-net_book); lines=[]
    if proceeds>0: lines.append((proceeds_account_code,proceeds,0))
    if asset.accumulated_depreciation>0: lines.append((asset.accumulated_depreciation_account_code,asset.accumulated_depreciation,0))
    lines.append((asset.asset_account_code,0,asset.acquisition_cost))
    if gain_loss>0: _account(db,cid,bid,"4300"); lines.append(("4300",0,gain_loss))
    elif gain_loss<0: _account(db,cid,bid,"5300"); lines.append(("5300",abs(gain_loss),0))
    entry=create_entry(db,f"التصرف في أصل {asset.asset_code}",user.id,lines,"fixed_asset_disposal",asset.id,dt,company_id=cid,branch_id=bid)
    db.add(FixedAssetDisposal(company_id=cid,branch_id=bid,asset_id=asset.id,disposal_date=dt,proceeds=proceeds,net_book_value=net_book,gain_loss=gain_loss,journal_entry_id=entry.id,created_by_id=user.id)); asset.is_active=False
    db.add(AuditLog(user_id=user.id,action="dispose",entity_type="fixed_asset",entity_id=asset.id,description=f"التصرف في {asset.asset_code}")); db.commit()
    return RedirectResponse(f"/pro-finance/assets{('?branch_id='+str(bid)) if bid else ''}",303)

@router.get("/withholding", response_class=HTMLResponse)
def withholding(request:Request, branch_id:int|None=None, db:Session=Depends(get_db), user:User=Depends(require_module("accounting"))):
    cid,bid=_scope(db,user,branch_id); q=_company_branch_filter(db.query(WithholdingTaxRate),WithholdingTaxRate,cid,bid).order_by(WithholdingTaxRate.code).limit(500)
    return templates.TemplateResponse(request,"pro_finance.html",_ctx(request,user,db,"withholding",q.all()))

@router.post("/withholding/new")
def create_withholding(db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True)), code:str=Form(...), name:str=Form(...), rate:Decimal=Form(...), tax_account_code:str=Form("2230"), branch_id:int|None=Form(None)):
    cid,bid=_scope(db,user,branch_id); code=code.strip(); rate=money(rate)
    if not code or not name.strip() or rate<0 or rate>100: raise HTTPException(400,"بيانات الخصم غير صحيحة")
    _account(db,cid,bid,tax_account_code)
    if db.query(WithholdingTaxRate).filter(WithholdingTaxRate.company_id==cid,WithholdingTaxRate.branch_id==bid,WithholdingTaxRate.code==code).first(): raise HTTPException(409,"كود الخصم مستخدم داخل هذا النطاق")
    db.add(WithholdingTaxRate(company_id=cid,branch_id=bid,code=code,name=name.strip(),rate=rate,tax_account_code=tax_account_code.strip())); db.commit()
    return RedirectResponse(f"/pro-finance/withholding{('?branch_id='+str(bid)) if bid else ''}",303)

def _tax_period(start_date,end_date):
    s=_dt(start_date).date() if start_date else datetime.date.today().replace(month=1,day=1); e=_dt(end_date).date() if end_date else datetime.date.today()
    if e<s: raise HTTPException(400,"نطاق التاريخ غير صحيح")
    return s,e

def _tax_report_data(db,cid,bid,s,e):
    start=datetime.datetime.combine(s,datetime.time.min); end=datetime.datetime.combine(e+datetime.timedelta(days=1),datetime.time.min)
    q=(db.query(TaxTransaction).join(TaxRate,TaxRate.id==TaxTransaction.tax_rate_id).join(JournalEntry,JournalEntry.id==TaxTransaction.journal_entry_id,isouter=True)
       .filter(TaxTransaction.company_id==cid,TaxRate.company_id==cid,or_(TaxTransaction.branch_id==bid if bid is not None else TaxTransaction.branch_id.is_(None), TaxTransaction.branch_id.is_(None)) if bid is not None else True,
               or_((TaxTransaction.journal_entry_id.is_(None)) & (TaxTransaction.created_at>=start) & (TaxTransaction.created_at<end), (JournalEntry.status=="posted") & (JournalEntry.entry_date>=start) & (JournalEntry.entry_date<end))))
    rows=q.order_by(TaxTransaction.created_at.desc(),TaxTransaction.id.desc()).limit(5000).all(); output=money(sum((r.tax_amount for r in rows if r.tax_direction=="output"),D("0"))); input_tax=money(sum((r.tax_amount for r in rows if r.tax_direction=="input"),D("0")))
    summary={}
    for r in rows:
        key=(r.tax_rate_id,r.tax_direction); item=summary.setdefault(key,{"tax_rate":r.tax_rate,"rate_applied":D(str(r.rate_applied or (r.tax_rate.rate if r.tax_rate else 0))),"tax_code":r.tax_code_snapshot or (r.tax_rate.code if r.tax_rate else ""),"tax_name":r.tax_name_snapshot or (r.tax_rate.name if r.tax_rate else ""),"direction":r.tax_direction,"taxable":D("0"),"tax":D("0"),"count":0}); item["taxable"]+=D(str(r.taxable_amount or 0)); item["tax"]+=D(str(r.tax_amount or 0)); item["count"]+=1
    return rows,sorted(summary.values(),key=lambda x:((x["direction"] or ""),(x["tax_rate"].code if x["tax_rate"] else ""))),output,input_tax

@router.get("/tax-report", response_class=HTMLResponse)
def tax_report(request:Request,start_date:str="",end_date:str="",branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid,bid=_scope(db,user,branch_id); s,e=_tax_period(start_date,end_date); rows,summary,output,input_tax=_tax_report_data(db,cid,bid,s,e)
    return templates.TemplateResponse(request,"tax_report.html",{"user":user,"rows":rows,"summary":summary,"output":output,"input_tax":input_tax,"net":money(output-input_tax),"start_date":s.isoformat(),"end_date":e.isoformat(),"branches":_branches(db,user,cid),"branch_id":bid})

@router.get("/tax-report/export/csv")
def tax_report_csv(start_date:str="",end_date:str="",branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid,bid=_scope(db,user,branch_id); s,e=_tax_period(start_date,end_date); rows,_,_,_=_tax_report_data(db,cid,bid,s,e); out=io.StringIO(); w=csv.writer(out); w.writerow(["Source","Source ID","Tax Rate","Direction","Taxable Amount","Tax Amount","Journal Entry"])
    for r in rows: w.writerow([r.source_type,r.source_id,getattr(r.tax_rate,"code",""),r.tax_direction,money(r.taxable_amount),money(r.tax_amount),getattr(r,"journal_entry_id","")])
    return Response("\ufeff"+out.getvalue(),media_type="text/csv; charset=utf-8",headers={"Content-Disposition":"attachment; filename=tax_report.csv","X-Content-Type-Options":"nosniff"})

@router.get("/cost-center-report", response_class=HTMLResponse)
def cost_center_report(request:Request,start_date:str="",end_date:str="",branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid,bid=_scope(db,user,branch_id); s=_dt(start_date) if start_date else None; e=_dt(end_date) if end_date else None
    if s and e and e<s: raise HTTPException(400,"نطاق التاريخ غير صحيح")
    centers=_company_branch_filter(db.query(CostCenter),CostCenter,cid,bid).filter(CostCenter.is_active.is_(True)).order_by(CostCenter.code).limit(500).all(); rows=[]
    for c in centers:
        q=(db.query(func.coalesce(func.sum(JournalLineCostCenter.amount),0)).join(JournalLine).join(JournalEntry)
           .filter(JournalLineCostCenter.company_id==cid,JournalLineCostCenter.cost_center_id==c.id,JournalLine.company_id==cid,JournalEntry.company_id==cid,JournalEntry.status=="posted"))
        if bid is not None: q=q.filter(JournalEntry.branch_id==bid)
        if s: q=q.filter(JournalEntry.entry_date>=s)
        if e: q=q.filter(JournalEntry.entry_date<=e)
        rows.append({"center":c,"amount":money(q.scalar() or 0)})
    return templates.TemplateResponse(request,"pro_finance.html",_ctx(request,user,db,"cost_report",rows,start_date=start_date,end_date=end_date))
