from ..time_utils import utcnow
from datetime import datetime, date
from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends, Request, Query, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.auth import get_current_user
from app.models import User, Customer, Supplier
from app.governance import require_permission, get_request_context, resolve_tenant
from app.deep_transactions import receive_purchase_order, create_sales_return, create_purchase_return, ar_aging, ap_aging, reconcile_ar_ap, reconcile_inventory_valuation

router = APIRouter(prefix="/api/v1/deep-transactions", tags=["deep-transactions"])

class QtyLine(BaseModel):
    line_id: int
    quantity: str = Field(gt="0")

class ReturnLine(BaseModel):
    invoice_line_id: int
    quantity: str = Field(gt="0")
    unit_cost: str | None = None

class ReceiveRequest(BaseModel):
    quantities: list[QtyLine] = []

class ReturnRequest(BaseModel):
    lines: list[ReturnLine]
    tax_rate: str | None = None

@router.post("/purchase-orders/{po_id}/receive", dependencies=[Depends(require_permission("purchases:post"))])
def receive(po_id: int, payload: ReceiveRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    ctx=get_request_context()
    quantities={str(x.line_id): x.quantity for x in payload.quantities}
    receipt=receive_purchase_order(db, ctx["company_id"], po_id, user.id, quantities or None)
    db.commit()
    return {"id": receipt.id, "status": "received", "po_id": po_id}

@router.post("/sales-invoices/{invoice_id}/return", dependencies=[Depends(require_permission("sales:reverse"))])
def sales_return(invoice_id: int, payload: ReturnRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    ctx=get_request_context()
    ret=create_sales_return(db, ctx["company_id"], user.id, invoice_id,
                            [{"invoice_line_id": x.invoice_line_id, "quantity": x.quantity, "unit_cost": x.unit_cost} for x in payload.lines], payload.tax_rate)
    db.commit()
    return {"id": ret.id, "return_number": ret.return_number, "total": str(ret.total_amount)}

@router.post("/purchase-invoices/{invoice_id}/return", dependencies=[Depends(require_permission("purchases:reverse"))])
def purchase_return(invoice_id: int, payload: ReturnRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    ctx=get_request_context()
    ret=create_purchase_return(db, ctx["company_id"], user.id, invoice_id,
                               [{"invoice_line_id": x.invoice_line_id, "quantity": x.quantity} for x in payload.lines], payload.tax_rate)
    db.commit()
    return {"id": ret.id, "return_number": ret.return_number, "total": str(ret.total_amount)}

@router.get("/ar-aging", dependencies=[Depends(require_permission("reports:view"))])
def get_ar_aging(as_of_date: str | None = None, branch_id: int | None = None, customer_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    ctx=get_request_context(); cid=ctx["company_id"]; bid=ctx.get("branch_id")
    if branch_id is not None:
        _, bid = resolve_tenant(db, user, cid, int(branch_id))
    try:
        d=date.fromisoformat(as_of_date) if as_of_date else date.today()
    except ValueError:
        raise HTTPException(422,"صيغة التاريخ غير صحيحة؛ استخدم YYYY-MM-DD")
    if customer_id is not None and not db.query(Customer).filter(Customer.id==customer_id, Customer.company_id==cid).first():
        raise HTTPException(404,"العميل غير موجود ضمن الشركة الحالية")
    return {"as_of": d.isoformat(), "branch_id": bid, "customer_id": customer_id, "rows": ar_aging(db, cid, d, bid, customer_id)}

@router.get("/ap-aging", dependencies=[Depends(require_permission("reports:view"))])
def get_ap_aging(as_of_date: str | None = None, branch_id: int | None = None, supplier_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    ctx=get_request_context(); cid=ctx["company_id"]; bid=ctx.get("branch_id")
    if branch_id is not None:
        _, bid = resolve_tenant(db, user, cid, int(branch_id))
    try:
        d=date.fromisoformat(as_of_date) if as_of_date else date.today()
    except ValueError:
        raise HTTPException(422,"صيغة التاريخ غير صحيحة؛ استخدم YYYY-MM-DD")
    if supplier_id is not None and not db.query(Supplier).filter(Supplier.id==supplier_id,Supplier.company_id==cid).first():
        raise HTTPException(404,"المورد غير موجود ضمن الشركة الحالية")
    return {"as_of": d.isoformat(), "branch_id": bid, "supplier_id": supplier_id, "rows": ap_aging(db, cid, d, bid, supplier_id)}

@router.post("/reconcile", dependencies=[Depends(require_permission("journal:post"))])
def reconcile(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    ctx=get_request_context(); rows=reconcile_ar_ap(db, ctx["company_id"], user_id=user.id); db.commit()
    return [{"type": x.subledger_type, "subledger": str(x.subledger_total), "gl": str(x.gl_total), "difference": str(x.difference), "status": x.status} for x in rows]


@router.get("/inventory-reconciliation", dependencies=[Depends(require_permission("reports:view"))])
def inventory_reconciliation(db: Session = Depends(get_db)):
    ctx=get_request_context()
    return {"as_of": utcnow().isoformat(), "rows": reconcile_inventory_valuation(db, ctx["company_id"])}
