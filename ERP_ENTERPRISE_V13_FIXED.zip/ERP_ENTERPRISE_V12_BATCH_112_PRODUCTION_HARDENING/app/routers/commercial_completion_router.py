# -*- coding: utf-8 -*-
"""Enterprise completion workspace: approvals, procurement sourcing, credit and controls."""
from datetime import datetime
from decimal import Decimal, InvalidOperation
from fastapi import APIRouter, Depends, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import func, or_
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

from ..database import get_db
from ..models import User, Customer, Supplier, Item, PurchaseOrder, SaleInvoice, PurchaseInvoice, StockMovement, MovementTypeEnum, Account, JournalLine, JournalEntry
from ..enterprise_models import Project, ProjectCost
from ..governance_models import ApprovalRule, ApprovalRuleStep, ApprovalRequest, ApprovalAction, GovernanceAuditLog
from ..commercial_completion_models import CustomerCreditPolicy, SupplierCreditPolicy, InventoryPolicy, BudgetControlPolicy, ProcurementRequest, ProcurementRequestLine, RFQ, RFQSupplier, RFQQuote, RFQQuoteLine
from ..construction_models import ConstructionCostBudgetLine, ConstructionCommitment, ConstructionAuthoritativeBudgetLine, SubcontractorBOQLine
from ..governance import get_request_context, _has_permission
from ..auth import require_module
from ..accounting import D, money, next_number
from ..workflows import request_approval, act_on_approval

router = APIRouter(prefix="/enterprise-control", tags=["Enterprise Commercial Control"])
templates = Jinja2Templates(directory="templates")


def cid():
    x = get_request_context().get("company_id")
    if x is None: raise HTTPException(403, "لم يتم تحديد الشركة الحالية")
    return int(x)

def bid(): return get_request_context().get("branch_id")

def can(db, user, permission):
    return user.role.value == "admin" or _has_permission(db, user.id, permission, cid(), bid())

def require_admin_or(db, user, permission):
    if not can(db,user,permission): raise HTTPException(403, f"Missing permission: {permission}")


def customer_outstanding(db, company_id, customer_id, branch_id=None):
    from ..transaction_services import _allocated
    total = Decimal("0")
    q = db.query(SaleInvoice).filter(SaleInvoice.company_id==company_id, SaleInvoice.customer_id==customer_id)
    if branch_id is not None:
        q = q.filter(or_(SaleInvoice.branch_id==branch_id, SaleInvoice.branch_id.is_(None)))
    for inv in q.all():
        total += max(Decimal("0"), D(inv.total_amount) - D(_allocated(db,"sale",inv.id,company_id)))
    return money(total)


def project_actual_cost(db, company_id, project_id):
    return money(db.query(func.coalesce(func.sum(__import__('app.enterprise_models',fromlist=['ProjectCost']).ProjectCost.amount),0)).filter(__import__('app.enterprise_models',fromlist=['ProjectCost']).ProjectCost.company_id==company_id, __import__('app.enterprise_models',fromlist=['ProjectCost']).ProjectCost.project_id==project_id).scalar() or 0)

@router.get("", response_class=HTMLResponse)
def control_center(request: Request, db: Session=Depends(get_db), user: User=Depends(require_module("accounting"))):
    company_id=cid()
    branch_id=bid()
    def branch_scope(query, model):
        if branch_id is not None and hasattr(model, "branch_id"):
            return query.filter(or_(model.branch_id==branch_id, model.branch_id.is_(None)))
        return query
    pending_q=db.query(ApprovalRequest).filter(ApprovalRequest.company_id==company_id,ApprovalRequest.status=="pending")
    pending=branch_scope(pending_q, ApprovalRequest).order_by(ApprovalRequest.requested_at.desc()).limit(100).all()
    prs_q=db.query(ProcurementRequest).filter(ProcurementRequest.company_id==company_id)
    prs=branch_scope(prs_q, ProcurementRequest).order_by(ProcurementRequest.id.desc()).limit(50).all()
    overlimits=[]
    customers_q=db.query(Customer).filter(Customer.company_id==company_id,Customer.is_active.is_(True))
    customers_q=branch_scope(customers_q, Customer)
    policies=db.query(CustomerCreditPolicy).filter(CustomerCreditPolicy.company_id==company_id,CustomerCreditPolicy.is_active.is_(True)).all()
    policies_by_customer={p.customer_id:p for p in policies}
    for c in customers_q.limit(500).all():
        pol=policies_by_customer.get(c.id)
        if pol and D(pol.credit_limit)>0:
            out=customer_outstanding(db,company_id,c.id,branch_id); pct=(out/D(pol.credit_limit)*100) if D(pol.credit_limit) else 0
            if pct>=D(pol.warning_percent): overlimits.append({"customer":c,"outstanding":out,"limit":D(pol.credit_limit),"pct":pct})
    project_count = branch_scope(db.query(Project).filter(Project.company_id == company_id), Project).count()
    customer_count = customers_q.count()
    supplier_count = branch_scope(db.query(Supplier).filter(Supplier.company_id == company_id, Supplier.is_active.is_(True)), Supplier).count()
    item_count = branch_scope(db.query(Item).filter(Item.company_id == company_id, Item.is_active.is_(True)), Item).count()
    open_prs = branch_scope(db.query(ProcurementRequest).filter(ProcurementRequest.company_id == company_id), ProcurementRequest).filter(ProcurementRequest.status.notin_(["closed", "cancelled"])).count()
    budget_alerts = 0
    for project in branch_scope(db.query(Project).filter(Project.company_id==company_id), Project).all():
        pol = db.query(BudgetControlPolicy).filter_by(company_id=company_id, project_id=project.id, is_active=True).first()
        snap = _project_budget_snapshot(db, company_id, project, pol)
        if snap["status_class"] in ("warning", "danger"): budget_alerts += 1
    return templates.TemplateResponse(request,"enterprise_control_center.html",{
        "user": user, "pending": pending, "prs": prs, "overlimits": overlimits,
        "project_count": project_count, "customer_count": customer_count,
        "supplier_count": supplier_count, "item_count": item_count, "open_prs": open_prs, "budget_alerts": budget_alerts, "branch_id": branch_id,
        "section": "accounting"
    })

@router.get("/approvals", response_class=HTMLResponse)
def approvals(request: Request, db: Session=Depends(get_db), user: User=Depends(require_module("accounting"))):
    rows_q=db.query(ApprovalRequest).filter(ApprovalRequest.company_id==cid())
    branch_id=bid()
    if branch_id is not None: rows_q=rows_q.filter(or_(ApprovalRequest.branch_id==branch_id, ApprovalRequest.branch_id.is_(None)))
    rows=rows_q.order_by(ApprovalRequest.requested_at.desc()).limit(300).all()
    return templates.TemplateResponse(request,"approval_center.html",{"user":user,"rows":rows,"section":"accounting"})

@router.post("/approvals/{request_id}/{decision}")
def approval_action(request_id:int, decision:str, reason:str=Form(""), db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True))):
    req=db.query(ApprovalRequest).filter(ApprovalRequest.id==request_id,ApprovalRequest.company_id==cid()).first()
    if not req: raise HTTPException(404,"طلب الاعتماد غير موجود")
    try:
        result=act_on_approval(db,request_id,user.id,decision,reason or None,company_id=cid())
        # Synchronize the governed decision back to the source document.
        if req.document_type=="purchase_order":
            doc=db.query(PurchaseOrder).filter(PurchaseOrder.id==req.document_id,PurchaseOrder.company_id==cid()).first()
            if doc:
                # PurchaseOrder has approval_status as its authoritative workflow field.
                # Do not assign a non-existent dynamic `status` attribute.
                doc.approval_status=result.status
        db.commit()
    except PermissionError as e: db.rollback(); raise HTTPException(403,str(e))
    except ValueError as e: db.rollback(); raise HTTPException(409,str(e))
    return RedirectResponse("/enterprise-control/approvals",303)

@router.post("/approvals/rules")
def create_rule(document_type:str=Form(...), name:str=Form(...), min_amount:str=Form(""), max_amount:str=Form(""), permission:str=Form(...), db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True))):
    require_admin_or(db,user,"core:workflow")
    try: mn=Decimal(min_amount) if min_amount else None; mx=Decimal(max_amount) if max_amount else None
    except InvalidOperation: raise HTTPException(400,"قيمة الحد غير صحيحة")
    rule=ApprovalRule(company_id=cid(),document_type=document_type.strip(),name=name.strip(),min_amount=mn,max_amount=mx,priority=100,is_active=True)
    db.add(rule); db.flush(); db.add(ApprovalRuleStep(rule_id=rule.id,sequence=1,required_permission=permission.strip(),min_amount=mn,max_amount=mx)); db.commit()
    return RedirectResponse("/enterprise-control/approvals",303)

@router.post("/seed-rules")
def seed_rules(db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True))):
    require_admin_or(db,user,"core:workflow")
    company_id=cid(); specs=[("purchase_order","اعتماد أوامر الشراء","purchases:approve"),("sales_order","اعتماد أوامر البيع","sales:approve"),("inventory_transfer","اعتماد التحويل المخزني","inventory:approve")]
    for typ,name,perm in specs:
        if not db.query(ApprovalRule).filter_by(company_id=company_id,document_type=typ,is_active=True).first():
            r=ApprovalRule(company_id=company_id,document_type=typ,name=name,priority=100,is_active=True); db.add(r); db.flush(); db.add(ApprovalRuleStep(rule_id=r.id,sequence=1,required_permission=perm))
    db.commit(); return RedirectResponse("/enterprise-control/approvals",303)

@router.get("/credit", response_class=HTMLResponse)
def credit(request:Request, db:Session=Depends(get_db), user:User=Depends(require_module("sales"))):
    company_id=cid(); branch_id=bid(); rows=[]
    customers_q=db.query(Customer).filter(Customer.company_id==company_id,Customer.is_active.is_(True))
    if branch_id is not None and hasattr(Customer, "branch_id"): customers_q=customers_q.filter(or_(Customer.branch_id==branch_id, Customer.branch_id.is_(None)))
    policies={p.customer_id:p for p in db.query(CustomerCreditPolicy).filter_by(company_id=company_id,is_active=True).all()}
    for c in customers_q.order_by(Customer.name).all():
        p=policies.get(c.id); out=customer_outstanding(db,company_id,c.id,branch_id)
        rows.append({"customer":c,"policy":p,"outstanding":out,"available":(D(p.credit_limit)-out if p else None)})
    return templates.TemplateResponse(request,"credit_control.html",{"user":user,"rows":rows,"section":"sales"})

@router.post("/credit/customer/{customer_id}")
def save_credit(customer_id:int, credit_limit:str=Form("0"), terms_days:int=Form(0), block_on_overlimit:bool=Form(False), warning_percent:str=Form("80"), db:Session=Depends(get_db), user:User=Depends(require_module("sales",need_edit=True))):
    company_id=cid(); branch_id=bid(); c=db.query(Customer).filter(Customer.id==customer_id,Customer.company_id==company_id).first()
    if not c: raise HTTPException(404,"العميل غير موجود")
    if branch_id is not None and getattr(c,"branch_id",None) not in (None, branch_id): raise HTTPException(403,"العميل خارج نطاق الفرع الحالي")
    p=db.query(CustomerCreditPolicy).filter_by(company_id=company_id,customer_id=customer_id).first()
    if not p: p=CustomerCreditPolicy(company_id=company_id,customer_id=customer_id); db.add(p)
    p.credit_limit=money(credit_limit); p.payment_terms_days=max(0,terms_days); p.block_on_overlimit=block_on_overlimit; p.warning_percent=money(warning_percent); p.is_active=True; db.commit()
    return RedirectResponse("/enterprise-control/credit",303)

@router.get("/procurement", response_class=HTMLResponse)
def procurement(request:Request, db:Session=Depends(get_db), user:User=Depends(require_module("purchases"))):
    company_id=cid(); branch_id=bid()
    requests_q=db.query(ProcurementRequest).filter_by(company_id=company_id)
    suppliers_q=db.query(Supplier).filter_by(company_id=company_id,is_active=True)
    items_q=db.query(Item).filter_by(company_id=company_id,is_active=True)
    if branch_id is not None:
        requests_q=requests_q.filter(or_(ProcurementRequest.branch_id==branch_id, ProcurementRequest.branch_id.is_(None)))
        if hasattr(Supplier, "branch_id"): suppliers_q=suppliers_q.filter(or_(Supplier.branch_id==branch_id, Supplier.branch_id.is_(None)))
        if hasattr(Item, "branch_id"): items_q=items_q.filter(or_(Item.branch_id==branch_id, Item.branch_id.is_(None)))
    requests=requests_q.order_by(ProcurementRequest.id.desc()).limit(200).all(); suppliers=suppliers_q.all(); items=items_q.all()
    return templates.TemplateResponse(request,"procurement_workspace.html",{"user":user,"requests":requests,"suppliers":suppliers,"items":items,"section":"purchases"})

@router.post("/procurement/request")
async def create_procurement_request(request:Request, db:Session=Depends(get_db), user:User=Depends(require_module("purchases",need_edit=True))):
    form=await request.form(); company_id=cid(); branch_id=bid()
    item_ids=form.getlist("item_id[]"); qtys=form.getlist("quantity[]")
    priority=(form.get("priority") or "normal").strip().lower()
    if priority not in {"normal", "high", "urgent"}:
        raise HTTPException(422,"أولوية الطلب غير صالحة")
    justification=(form.get("justification") or "").strip()
    if len(justification)>2000:
        raise HTTPException(422,"مبرر الطلب يتجاوز الحد المسموح")
    try:
        project_id=int(form.get("project_id")) if form.get("project_id") else None
    except (TypeError,ValueError):
        raise HTTPException(422,"المشروع غير صالح")
    if project_id:
        project=db.query(Project).filter(Project.id==project_id,Project.company_id==company_id).first()
        if not project: raise HTTPException(422,"المشروع غير صالح للشركة الحالية")
        if branch_id is not None and project.branch_id is not None and project.branch_id != branch_id:
            raise HTTPException(422,"المشروع لا يتبع الفرع الحالي")
    rows=[]; seen=set()
    if len(item_ids)!=len(qtys): raise HTTPException(422,"بيانات بنود طلب الشراء غير متطابقة")
    if len(item_ids)>500: raise HTTPException(422,"الطلب يتجاوز 500 بند")
    for iid,qty in zip(item_ids,qtys):
        if not iid and not qty: continue
        try: item_id=int(iid); amount=D(qty)
        except (TypeError,ValueError,InvalidOperation): raise HTTPException(422,"الصنف أو الكمية غير صالحة")
        if item_id in seen: raise HTTPException(422,"لا يمكن تكرار الصنف داخل طلب الشراء")
        if amount<=0 or amount>Decimal("1000000000000"): raise HTTPException(422,"الكمية يجب أن تكون موجبة وضمن الحد المسموح")
        seen.add(item_id); rows.append((item_id,amount))
    if not rows: raise HTTPException(400,"أضف صنفًا واحدًا على الأقل")
    valid={x[0] for x in db.query(Item.id).filter(Item.company_id==company_id,Item.id.in_(seen),Item.is_active.is_(True)).all()}
    if valid!=seen: raise HTTPException(422,"يوجد صنف غير صالح للشركة الحالية")
    pr=ProcurementRequest(company_id=company_id,branch_id=branch_id,project_id=project_id,request_number=next_number(db,"procurement_request","PR"),requested_by_id=user.id,priority=priority,justification=justification or None,status="submitted")
    db.add(pr); db.flush()
    for iid,qty in rows: db.add(ProcurementRequestLine(company_id=company_id,request_id=pr.id,item_id=iid,quantity=qty))
    db.add(GovernanceAuditLog(user_id=user.id,company_id=company_id,branch_id=branch_id,action="create",entity_type="procurement_request",entity_id=str(pr.id),reason=f"إنشاء طلب شراء {pr.request_number}"))
    try:
        db.commit()
    except IntegrityError:
        db.rollback(); raise HTTPException(409,"تعذر حفظ طلب الشراء بسبب تعارض في البيانات")
    return RedirectResponse("/enterprise-control/procurement",303)

@router.post("/procurement/{request_id}/rfq")
async def create_rfq(request_id:int, request:Request, db:Session=Depends(get_db), user:User=Depends(require_module("purchases",need_edit=True))):
    company_id=cid(); branch_id=bid()
    pr=db.query(ProcurementRequest).filter_by(id=request_id,company_id=company_id).with_for_update().first()
    if not pr: raise HTTPException(404,"طلب الشراء غير موجود")
    if pr.status not in {"submitted", "rfq"}: raise HTTPException(409,"حالة طلب الشراء لا تسمح بإنشاء RFQ")
    if not pr.lines: raise HTTPException(409,"طلب الشراء لا يحتوي على بنود")
    if branch_id is not None and pr.branch_id is not None and pr.branch_id != branch_id:
        raise HTTPException(403,"طلب الشراء خارج نطاق الفرع الحالي")
    form=await request.form(); raw_supplier_ids=form.getlist("supplier_id[]")
    try: supplier_ids=sorted(set(int(x) for x in raw_supplier_ids if x))
    except (TypeError,ValueError): raise HTTPException(422,"معرّف المورد غير صالح")
    if not supplier_ids: raise HTTPException(400,"اختر موردًا واحدًا على الأقل")
    suppliers=db.query(Supplier).filter(Supplier.id.in_(supplier_ids),Supplier.company_id==company_id,Supplier.is_active.is_(True)).all()
    if len(suppliers)!=len(supplier_ids): raise HTTPException(422,"يوجد مورد غير صالح للشركة الحالية")
    existing=db.query(RFQ).filter(RFQ.company_id==company_id,RFQ.request_id==pr.id,RFQ.status.in_(["draft","issued","open"])).first()
    if existing: raise HTTPException(409,"يوجد RFQ نشط بالفعل لطلب الشراء")
    notes=(form.get("notes") or "").strip()
    if len(notes)>2000: raise HTTPException(422,"ملاحظات RFQ تتجاوز الحد المسموح")
    rfq=RFQ(company_id=company_id,branch_id=branch_id,request_id=pr.id,rfq_number=next_number(db,"rfq","RFQ"),status="issued",created_by_id=user.id,notes=notes or None); db.add(rfq); db.flush()
    for sid in supplier_ids: db.add(RFQSupplier(company_id=company_id,rfq_id=rfq.id,supplier_id=sid))
    pr.status="rfq"
    db.add(GovernanceAuditLog(user_id=user.id,company_id=company_id,branch_id=branch_id,action="create",entity_type="rfq",entity_id=str(rfq.id),reason=f"إنشاء RFQ {rfq.rfq_number} لطلب {pr.request_number}"))
    db.commit(); return RedirectResponse("/enterprise-control/procurement",303)

@router.get("/inventory-policy", response_class=HTMLResponse)
def inventory_policy(request:Request, db:Session=Depends(get_db), user:User=Depends(require_module("inventory"))):
    from ..warehouse_models import Warehouse
    company_id = cid()
    whs=db.query(Warehouse).filter_by(company_id=company_id,is_active=True).order_by(Warehouse.name).all()
    policies=db.query(InventoryPolicy).filter_by(company_id=company_id).all()
    return templates.TemplateResponse(request,"inventory_policy.html",{
        "user":user,"warehouses":whs,
        "policies":{p.warehouse_id:p for p in policies if p.warehouse_id is not None},
        "default_policy":next((p for p in policies if p.warehouse_id is None), None),
        "section":"inventory"})

@router.post("/inventory-policy")
def save_inventory_policy(warehouse_id:str=Form(""), costing_method:str=Form("weighted_average"), allow_negative_stock:bool=Form(False), reorder_point:str=Form("0"), reorder_quantity:str=Form("0"), db:Session=Depends(get_db), user:User=Depends(require_module("inventory",need_edit=True))):
    company_id=cid()
    if not warehouse_id:
        raise HTTPException(400,"اختر مخزنًا قبل حفظ السياسة")
    try:
        wid=int(warehouse_id); point=D(reorder_point); quantity=D(reorder_quantity)
    except Exception:
        raise HTTPException(400,"قيم إعادة الطلب غير صالحة")
    if point < 0 or quantity < 0:
        raise HTTPException(400,"لا يمكن أن تكون قيم إعادة الطلب سالبة")
    from ..warehouse_models import Warehouse
    warehouse=db.query(Warehouse).filter_by(id=wid,company_id=company_id,is_active=True).first()
    if not warehouse:
        raise HTTPException(404,"المخزن غير موجود ضمن الشركة الحالية")
    if costing_method not in {"fifo","weighted_average","standard"}:
        raise HTTPException(400,"طريقة تقييم المخزون غير مدعومة")
    # A warehouse policy controls operational stock behavior. Valuation becomes
    # authoritative for an item only when an item-level policy exists; the
    # company default (warehouse_id=NULL) seeds new item policies.
    p=db.query(InventoryPolicy).filter_by(company_id=company_id,warehouse_id=wid).first()
    if not p:
        p=InventoryPolicy(company_id=company_id,warehouse_id=wid); db.add(p)
    p.costing_method=costing_method
    p.allow_negative_stock=allow_negative_stock
    p.reorder_point=point
    p.reorder_quantity=quantity
    db.commit()
    return RedirectResponse("/enterprise-control/inventory-policy",303)

@router.post("/inventory-policy/default")
def save_inventory_default_policy(costing_method:str=Form("weighted_average"), allow_negative_stock:bool=Form(False),
                                  db:Session=Depends(get_db), user:User=Depends(require_module("inventory",need_edit=True))):
    company_id = cid()
    if costing_method not in {"fifo", "weighted_average", "standard"}:
        raise HTTPException(400, "طريقة تقييم المخزون غير مدعومة")
    p = db.query(InventoryPolicy).filter(InventoryPolicy.company_id==company_id, InventoryPolicy.warehouse_id.is_(None)).first()
    if not p:
        p = InventoryPolicy(company_id=company_id, warehouse_id=None); db.add(p)
    p.costing_method = costing_method
    p.allow_negative_stock = bool(allow_negative_stock)
    db.commit()
    return RedirectResponse("/enterprise-control/inventory-policy",303)

def _budget_status(usage_percent, warning_percent, tolerance_percent):
    usage=D(usage_percent); warning=D(warning_percent); tolerance=D(tolerance_percent)
    if usage > D("100") + tolerance:
        return "danger", "تجاوز حرج"
    if usage > D("100"):
        return "danger", "تجاوز"
    if usage >= warning:
        return "warning", "تحذير"
    return "success", "طبيعي"

def _project_budget_snapshot(db, company_id, project, policy):
    # The control center must consume the same authoritative budget used by
    # cost reconciliation/forecasting; falling back only when no materialized
    # authoritative rows exist avoids losing approved revisions or treating a
    # legitimate zero budget as if no authoritative budget existed.
    auth_q = db.query(func.coalesce(func.sum(ConstructionAuthoritativeBudgetLine.approved_budget), 0)).filter(
        ConstructionAuthoritativeBudgetLine.company_id == company_id,
        ConstructionAuthoritativeBudgetLine.project_id == project.id
    )
    auth_count = db.query(ConstructionAuthoritativeBudgetLine.id).filter(
        ConstructionAuthoritativeBudgetLine.company_id == company_id,
        ConstructionAuthoritativeBudgetLine.project_id == project.id
    ).count()
    if auth_count:
        budget = D(auth_q.scalar() or 0)
    else:
        explicit_budget = D(db.query(func.coalesce(func.sum(ConstructionCostBudgetLine.budget_amount), 0)).filter(
            ConstructionCostBudgetLine.company_id == company_id,
            ConstructionCostBudgetLine.project_id == project.id,
            ConstructionCostBudgetLine.status == "active"
        ).scalar() or 0)
        budget = explicit_budget if explicit_budget > 0 else D(project.budget or 0)
    actual = D(db.query(func.coalesce(func.sum(ProjectCost.amount), 0)).filter(
        ProjectCost.company_id == company_id, ProjectCost.project_id == project.id
    ).scalar() or 0)
    committed = D(db.query(func.coalesce(func.sum(ConstructionCommitment.committed_amount - ConstructionCommitment.released_amount), 0)).filter(
        ConstructionCommitment.company_id == company_id,
        ConstructionCommitment.project_id == project.id,
        ConstructionCommitment.status.in_(["open", "approved", "active"])
    ).scalar() or 0)
    exposure = actual + committed
    usage = (exposure / budget * D("100")) if budget > 0 else D("0")
    warning = D(policy.warning_percent if policy else 80)
    tolerance = D(policy.tolerance_percent if policy else 0)
    status_class, status_label = _budget_status(usage, warning, tolerance)
    return {
        "project": project, "budget": budget, "actual": actual, "committed": committed,
        "exposure": exposure, "remaining": budget - exposure, "usage": usage,
        "warning": warning, "tolerance": tolerance,
        "block_over_budget": bool(policy.block_over_budget) if policy else True,
        "status_class": status_class, "status_label": status_label
    }

@router.get("/budget-control", response_class=HTMLResponse)
def budget_control(request:Request, db:Session=Depends(get_db), user:User=Depends(require_module("accounting"))):
    company_id=cid()
    pq=db.query(Project).filter_by(company_id=company_id)
    branch_id=bid()
    if branch_id is not None:
        pq=pq.filter((Project.branch_id==branch_id)|(Project.branch_id.is_(None)))
    projects=pq.order_by(Project.name).all()
    policies={p.project_id:p for p in db.query(BudgetControlPolicy).filter_by(company_id=company_id,is_active=True).all()}
    rows=[_project_budget_snapshot(db, company_id, project, policies.get(project.id)) for project in projects]
    total_budget=sum((r["budget"] for r in rows), D("0")); total_actual=sum((r["actual"] for r in rows), D("0")); total_committed=sum((r["committed"] for r in rows), D("0"))
    total_exposure=total_actual+total_committed; total_remaining=total_budget-total_exposure
    summary={"project_count":len(rows),"budget":total_budget,"actual":total_actual,"committed":total_committed,"exposure":total_exposure,"remaining":total_remaining,"usage":(total_exposure/total_budget*D("100") if total_budget>0 else D("0")),"alerts":sum(1 for r in rows if r["status_class"] in ("warning","danger"))}
    return templates.TemplateResponse(request,"budget_control.html",{"user":user,"rows":rows,"summary":summary,"section":"accounting"})

@router.post("/budget-control")
def save_budget_control(project_id:str=Form(""), tolerance_percent:str=Form("0"), block_over_budget:bool=Form(False), warning_percent:str=Form("80"), db:Session=Depends(get_db), user:User=Depends(require_module("accounting",need_edit=True))):
    require_admin_or(db,user,"core:manage"); company_id=cid()
    try:
        pid=int(project_id)
        warning=D(warning_percent); tolerance=D(tolerance_percent)
    except (ValueError, InvalidOperation):
        raise HTTPException(400,"قيم سياسة رقابة الموازنة غير صحيحة")
    if warning < 0 or warning > 100 or tolerance < 0 or tolerance > 100:
        raise HTTPException(400,"النسب يجب أن تكون بين 0 و100")
    project=db.query(Project).filter_by(id=pid,company_id=company_id).first()
    if not project: raise HTTPException(404,"المشروع غير موجود ضمن الشركة الحالية")
    p=db.query(BudgetControlPolicy).filter_by(company_id=company_id,project_id=pid).first()
    if not p: p=BudgetControlPolicy(company_id=company_id,project_id=pid); db.add(p)
    p.tolerance_percent=tolerance; p.block_over_budget=block_over_budget; p.warning_percent=warning; p.is_active=True
    db.commit(); return RedirectResponse("/enterprise-control/budget-control",303)

@router.get("/api/customer/{customer_id}/credit")
def credit_api(customer_id:int, db:Session=Depends(get_db), user:User=Depends(require_module("sales"))):
    company_id=cid(); c=db.query(Customer).filter_by(id=customer_id,company_id=company_id).first()
    if not c: raise HTTPException(404,"Customer not found")
    p=db.query(CustomerCreditPolicy).filter_by(company_id=company_id,customer_id=customer_id,is_active=True).first(); out=customer_outstanding(db,company_id,customer_id)
    return {"customer_id":customer_id,"credit_limit":str(p.credit_limit if p else 0),"outstanding":str(out),"available":str(max(Decimal(0),D(p.credit_limit)-out) if p else 0),"blocked":bool(p and p.block_on_overlimit and out>=D(p.credit_limit))}
