from ..time_utils import utcnow
"""Enterprise Plus APIs: HR completeness, project workforce, quality, maintenance, field service and controlled signatures."""
from datetime import date, datetime
from decimal import Decimal
import hashlib, json
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import User
from ..auth import require_module
from ..governance import get_request_context
from ..enterprise_models import Employee, Project, ProjectCost
from ..construction_models import ConstructionSite
from ..enterprise_plus_models import (WorkSchedule,WorkScheduleDay,OvertimeRule,EmployeeContract,AttendanceEvent,OnboardingCase,OnboardingTask,RecruitmentJob,RecruitmentCandidate,EmployeeLifecycleCase,ExpenseClaim,ProjectTimesheet,ProjectTask,QualityInspection,QualityDefect,MaintenancePlan,MaintenanceWorkOrder,FieldServiceVisit,DocumentTemplate,SignatureRequest,SignatureSigner)

router=APIRouter(prefix='/api/v1/enterprise-plus',tags=['Enterprise Plus'])

def _current_company_id() -> int:
    company_id = get_request_context().get("company_id")
    if company_id is None:
        raise HTTPException(400, "A valid company context is required")
    return int(company_id)

def _get(cls, db, company_id, ident):
    row=db.query(cls).filter_by(id=ident,company_id=company_id).first()
    if not row: raise HTTPException(404,f'{cls.__tablename__} record not found')
    return row

class ScheduleIn(BaseModel):
    code:str; name:str; daily_hours:Decimal=Field(default=8,gt=0); weekly_hours:Decimal=Field(default=48,gt=0); timezone:str='Africa/Cairo'
class ScheduleDayIn(BaseModel):
    schedule_id:int; weekday:int=Field(ge=0,le=6); start_time:str; end_time:str; break_hours:Decimal=Field(default=0,ge=0); is_working:bool=True
class OvertimeRuleIn(BaseModel):
    code:str; name:str; weekday_multiplier:Decimal=Field(default=Decimal('1.25'),ge=0); weekend_multiplier:Decimal=Field(default=Decimal('1.5'),ge=0); holiday_multiplier:Decimal=Field(default=Decimal('2'),ge=0); max_daily_hours:Decimal=Field(default=4,ge=0); approval_required:bool=True
class ContractIn(BaseModel):
    employee_id:int; contract_no:str; contract_type:str='full_time'; start_date:date; end_date:date|None=None; salary:Decimal=Field(default=0,ge=0); schedule_id:int|None=None; overtime_rule_id:int|None=None; terms:str|None=None
class AttendanceEventIn(BaseModel):
    employee_id:int; event_at:datetime; event_type:str; method:str='manual'; device_id:str|None=None; ip_address:str|None=None; latitude:Decimal|None=None; longitude:Decimal|None=None; project_id:int|None=None; site_id:int|None=None; notes:str|None=None
class LifecycleIn(BaseModel):
    employee_id:int; case_type:str; effective_date:date|None=None; reason:str|None=None; owner_user_id:int|None=None
class ExpenseIn(BaseModel):
    employee_id:int; project_id:int|None=None; expense_date:date; category:str; description:str|None=None; amount:Decimal=Field(gt=0); currency_code:str='EGP'; receipt_document_id:int|None=None
class TimesheetIn(BaseModel):
    employee_id:int; project_id:int; site_id:int|None=None; wbs_id:int|None=None; cost_code_id:int|None=None; work_date:date; hours:Decimal=Field(ge=0); description:str|None=None
class TaskIn(BaseModel):
    project_id:int; code:str; title:str; parent_id:int|None=None; wbs_id:int|None=None; planned_start:date|None=None; planned_end:date|None=None; assigned_user_id:int|None=None; estimated_hours:Decimal=Field(default=0,ge=0)
class InspectionIn(BaseModel):
    project_id:int; site_id:int|None=None; boq_line_id:int|None=None; inspection_no:str; inspection_type:str; inspection_date:date; inspector_id:int|None=None; result:str='pending'; comments:str|None=None; document_id:int|None=None
class DefectIn(BaseModel):
    inspection_id:int; defect_no:str; severity:str='minor'; description:str; corrective_action:str|None=None; responsible_user_id:int|None=None; due_date:date|None=None
class MaintenancePlanIn(BaseModel):
    equipment_id:int; code:str; interval_days:int|None=None; interval_hours:Decimal|None=None; last_service_date:date|None=None; next_due_date:date|None=None
class WorkOrderIn(BaseModel):
    equipment_id:int; plan_id:int|None=None; project_id:int|None=None; work_order_no:str; work_type:str='preventive'; scheduled_date:date|None=None; estimated_cost:Decimal=Field(default=0,ge=0); notes:str|None=None
class FieldVisitIn(BaseModel):
    project_id:int; site_id:int|None=None; assigned_user_id:int|None=None; visit_no:str; scheduled_at:datetime|None=None; summary:str|None=None
class TemplateIn(BaseModel):
    code:str; name:str; document_type:str; body:str=''
class SignatureIn(BaseModel):
    project_id:int|None=None; document_id:int; title:str; signer_name:str; signer_email:str|None=None; signer_user_id:int|None=None; expires_at:datetime|None=None

@router.post('/hr/schedules',status_code=201)
def create_schedule(d:ScheduleIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=WorkSchedule(company_id=company_id,**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'code':row.code}
@router.post('/hr/schedules/days',status_code=201)
def add_schedule_day(d:ScheduleDayIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    if not db.query(WorkSchedule).filter_by(id=d.schedule_id, company_id=company_id).first(): raise HTTPException(404,'Schedule not found')
    row=WorkScheduleDay(**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id}
@router.post('/hr/overtime-rules',status_code=201)
def create_ot(d:OvertimeRuleIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=OvertimeRule(company_id=company_id,**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'code':row.code}
@router.post('/hr/contracts',status_code=201)
def create_contract(d:ContractIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    if not db.query(Employee).filter_by(id=d.employee_id,company_id=company_id).first(): raise HTTPException(404,'Employee not found')
    if d.end_date and d.end_date<d.start_date: raise HTTPException(422,'Contract end date before start date')
    row=EmployeeContract(company_id=company_id,**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'contract_no':row.contract_no}
@router.post('/hr/attendance-events',status_code=201)
def attendance_event(d:AttendanceEventIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    if not db.query(Employee).filter_by(id=d.employee_id,company_id=company_id).first(): raise HTTPException(404,'Employee not found')
    row=AttendanceEvent(company_id=company_id,**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'event_at':row.event_at.isoformat()}
@router.post('/hr/lifecycle',status_code=201)
def lifecycle(d:LifecycleIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    if d.case_type not in {'onboarding','offboarding','transfer','promotion','termination'}: raise HTTPException(422,'Invalid lifecycle type')
    row=EmployeeLifecycleCase(company_id=company_id,**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'status':row.status}

@router.post('/expenses',status_code=201)
def expense(d:ExpenseIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    if not db.query(Employee).filter_by(id=d.employee_id,company_id=company_id).first(): raise HTTPException(404,'Employee not found')
    row=ExpenseClaim(company_id=company_id,**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'status':row.status,'amount':str(row.amount)}
@router.post('/expenses/{expense_id}/approve')
def approve_expense(expense_id:int,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=_get(ExpenseClaim,db,company_id,expense_id)
    if row.status not in {'draft','submitted'}: raise HTTPException(409,'Expense is not approvable')
    row.status='approved'; row.approved_by_id=user.id; row.approved_at=utcnow()
    if row.project_id:
        pc=ProjectCost(company_id=company_id,project_id=row.project_id,cost_type='employee_expense',source_type='expense_claim',source_id=row.id,amount=row.amount,cost_date=datetime.combine(row.expense_date,datetime.min.time()),description=row.description or row.category); db.add(pc); db.flush(); row.posted_project_cost_id=pc.id
    db.commit(); return {'id':row.id,'status':row.status,'project_cost_id':row.posted_project_cost_id}

@router.post('/timesheets',status_code=201)
def timesheet(d:TimesheetIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    if not db.query(Employee).filter_by(id=d.employee_id,company_id=company_id).first(): raise HTTPException(404,'Employee not found')
    if not db.query(Project).filter_by(id=d.project_id,company_id=company_id).first(): raise HTTPException(404,'Project not found')
    row=ProjectTimesheet(company_id=company_id,**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'status':row.status}
@router.post('/timesheets/{timesheet_id}/approve')
def approve_timesheet(timesheet_id:int,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=_get(ProjectTimesheet,db,company_id,timesheet_id)
    if row.status=='approved': return {'id':row.id,'status':'approved','project_cost_id':row.project_cost_id}
    
    emp=db.query(Employee).filter_by(id=row.employee_id,company_id=company_id).first()
    hourly=(Decimal(str(emp.base_salary or 0))/Decimal('30')/Decimal('8')) if emp else Decimal('0')
    amount=(hourly*Decimal(str(row.hours))).quantize(Decimal('0.000001'))
    pc=ProjectCost(company_id=company_id,project_id=row.project_id,cost_type='labor_timesheet',source_type='timesheet',source_id=row.id,amount=amount,cost_date=datetime.combine(row.work_date,datetime.min.time()),description=row.description or f'Timesheet {row.id}')
    db.add(pc); db.flush(); row.project_cost_id=pc.id; row.status='approved'; row.approved_by_id=user.id; row.approved_at=utcnow(); db.commit(); return {'id':row.id,'status':row.status,'project_cost_id':row.project_cost_id}

@router.post('/projects/tasks',status_code=201)
def create_task(d:TaskIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    if not db.query(Project).filter_by(id=d.project_id,company_id=company_id).first(): raise HTTPException(404,'Project not found')
    row=ProjectTask(company_id=company_id,**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'code':row.code}
@router.post('/projects/tasks/{task_id}/progress')
def task_progress(task_id:int,company_id:int=Depends(_current_company_id),progress:Decimal=Query(...),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=_get(ProjectTask,db,company_id,task_id)
    if progress<0 or progress>100: raise HTTPException(422,'Progress must be 0..100')
    row.progress=progress; row.status='done' if progress==100 else ('in_progress' if progress>0 else 'todo'); db.commit(); return {'id':row.id,'progress':str(row.progress),'status':row.status}

@router.post('/quality/inspections',status_code=201)
def create_inspection(d:InspectionIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=QualityInspection(company_id=company_id,**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'inspection_no':row.inspection_no,'result':row.result}
@router.post('/quality/inspections/{inspection_id}/defects',status_code=201)
def create_defect(d:DefectIn,inspection_id:int,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    if not db.query(QualityInspection).filter_by(id=inspection_id, company_id=company_id).first(): raise HTTPException(404,'Inspection not found')
    if d.inspection_id!=inspection_id: raise HTTPException(422,'Inspection mismatch')
    row=QualityDefect(company_id=company_id,**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'status':row.status}

@router.post('/maintenance/plans',status_code=201)
def maintenance_plan(d:MaintenancePlanIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=MaintenancePlan(company_id=company_id,**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'code':row.code}
@router.post('/maintenance/work-orders',status_code=201)
def maintenance_wo(d:WorkOrderIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=MaintenanceWorkOrder(company_id=company_id,**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'work_order_no':row.work_order_no}

@router.post('/field-service/visits',status_code=201)
def field_visit(d:FieldVisitIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=FieldServiceVisit(company_id=company_id,**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'visit_no':row.visit_no}
@router.post('/field-service/visits/{visit_id}/check-in')
def visit_checkin(visit_id:int,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=_get(FieldServiceVisit,db,company_id,visit_id); row.check_in=utcnow(); row.status='in_progress'; db.commit(); return {'id':row.id,'status':row.status}
@router.post('/field-service/visits/{visit_id}/check-out')
def visit_checkout(visit_id:int,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=_get(FieldServiceVisit,db,company_id,visit_id)
    if not row.check_in: raise HTTPException(409,'Visit has not been checked in')
    row.check_out=utcnow(); row.status='completed'; db.commit(); return {'id':row.id,'status':row.status}

@router.post('/documents/templates',status_code=201)
def create_template(d:TemplateIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=DocumentTemplate(company_id=company_id,**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'version':row.version}
@router.post('/documents/signature-requests',status_code=201)
def signature_request(d:SignatureIn,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=SignatureRequest(company_id=company_id,project_id=d.project_id,document_id=d.document_id,title=d.title,requested_by_id=user.id,expires_at=d.expires_at); db.add(row); db.flush()
    signer=SignatureSigner(request_id=row.id,signer_order=1,user_id=d.signer_user_id,signer_name=d.signer_name,signer_email=d.signer_email); db.add(signer); db.commit(); db.refresh(row); return {'id':row.id,'status':row.status,'signer_id':signer.id}
@router.post('/documents/signature-requests/{request_id}/sign')
def sign_request(request_id:int,company_id:int=Depends(_current_company_id),signer_id:int=Query(...),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    req=_get(SignatureRequest,db,company_id,request_id); signer=db.query(SignatureSigner).filter_by(id=signer_id,request_id=req.id).first()
    if not signer: raise HTTPException(404,'Signer not found')
    if signer.status!='pending': raise HTTPException(409,'Signer is not pending')
    previous=db.query(SignatureSigner).filter(SignatureSigner.request_id==req.id,SignatureSigner.signer_order<signer.signer_order).order_by(SignatureSigner.signer_order.desc()).first()
    if previous and previous.status!='signed': raise HTTPException(409,'Previous signer must sign first')
    payload=f'{req.id}:{signer.id}:{user.id}:{utcnow().isoformat()}'.encode(); signer.signature_hash=hashlib.sha256(payload).hexdigest(); signer.signed_at=utcnow(); signer.status='signed'
    remaining=db.query(SignatureSigner).filter(SignatureSigner.request_id==req.id,SignatureSigner.status!='signed').count()
    if remaining==0:
        req.status='signed'; req.completed_at=signer.signed_at; req.certificate_hash=hashlib.sha256((req.title+':'+''.join((x.signature_hash or '') for x in db.query(SignatureSigner).filter_by(request_id=req.id).order_by(SignatureSigner.signer_order).all())).encode()).hexdigest()
    db.commit(); return {'id':req.id,'status':req.status,'certificate_hash':req.certificate_hash}

@router.get('/dashboard')
def enterprise_dashboard(company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr'))):
    return {'workforce':{'employees':db.query(Employee).filter_by(company_id=company_id).count(),'attendance_events':db.query(AttendanceEvent).filter_by(company_id=company_id).count(),'contracts':db.query(EmployeeContract).filter_by(company_id=company_id).count()},'operations':{'expenses':db.query(ExpenseClaim).filter_by(company_id=company_id).count(),'timesheets':db.query(ProjectTimesheet).filter_by(company_id=company_id).count(),'tasks':db.query(ProjectTask).filter_by(company_id=company_id).count()},'quality':{'inspections':db.query(QualityInspection).filter_by(company_id=company_id).count(),'open_defects':db.query(QualityDefect).filter_by(company_id=company_id,status='open').count()},'maintenance':{'plans':db.query(MaintenancePlan).filter_by(company_id=company_id).count(),'work_orders':db.query(MaintenanceWorkOrder).filter_by(company_id=company_id).count()},'documents':{'templates':db.query(DocumentTemplate).filter_by(company_id=company_id).count(),'signature_requests':db.query(SignatureRequest).filter_by(company_id=company_id).count()}}

class RecruitmentJobIn(BaseModel):
    code:str; title:str; department_id:int|None=None; project_id:int|None=None; openings:int=Field(default=1,ge=1); description:str|None=None
class CandidateIn(BaseModel):
    job_id:int; name:str; email:str|None=None; phone:str|None=None; stage:str='new'; score:Decimal|None=None; notes:str|None=None
class OnboardingIn(BaseModel):
    employee_id:int; start_date:date|None=None; target_date:date|None=None; owner_user_id:int|None=None; notes:str|None=None
class OnboardingTaskIn(BaseModel):
    case_id:int; title:str; sequence:int=1; required:bool=True; due_date:date|None=None
class QualityCloseIn(BaseModel):
    result:str; comments:str|None=None

@router.post('/recruitment/jobs',status_code=201)
def recruitment_job(d:RecruitmentJobIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=RecruitmentJob(company_id=company_id,**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'code':row.code,'status':row.status}
@router.post('/recruitment/candidates',status_code=201)
def recruitment_candidate(d:CandidateIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    if not db.query(RecruitmentJob).filter_by(id=d.job_id,company_id=company_id).first(): raise HTTPException(404,'Recruitment job not found')
    row=RecruitmentCandidate(company_id=company_id,**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'stage':row.stage}
@router.post('/recruitment/candidates/{candidate_id}/stage')
def candidate_stage(candidate_id:int,company_id:int=Depends(_current_company_id),stage:str=Query(...),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=_get(RecruitmentCandidate,db,company_id,candidate_id); row.stage=stage; db.commit(); return {'id':row.id,'stage':row.stage}

@router.post('/onboarding',status_code=201)
def onboarding(d:OnboardingIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    if not db.query(Employee).filter_by(id=d.employee_id,company_id=company_id).first(): raise HTTPException(404,'Employee not found')
    row=OnboardingCase(company_id=company_id,**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'status':row.status}
@router.post('/onboarding/tasks',status_code=201)
def onboarding_task(d:OnboardingTaskIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    if not db.query(OnboardingCase).filter_by(id=d.case_id, company_id=company_id).first(): raise HTTPException(404,'Onboarding case not found')
    row=OnboardingTask(**d.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'status':row.status}
@router.post('/onboarding/tasks/{task_id}/complete')
def complete_onboarding(task_id:int,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=db.query(OnboardingTask).join(OnboardingCase, OnboardingTask.case_id==OnboardingCase.id).filter(OnboardingTask.id==task_id, OnboardingCase.company_id==company_id).first()
    if not row: raise HTTPException(404,'Onboarding task not found')
    row.status='completed'; row.completed_at=utcnow(); row.completed_by_id=user.id; db.commit(); return {'id':row.id,'status':row.status}

@router.post('/quality/inspections/{inspection_id}/close')
def close_inspection(inspection_id:int,d:QualityCloseIn,company_id:int=Depends(_current_company_id),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=_get(QualityInspection,db,company_id,inspection_id)
    if d.result not in {'passed','failed','conditional','rejected'}: raise HTTPException(422,'Invalid inspection result')
    row.result=d.result; row.comments=d.comments; row.closed_at=utcnow(); db.commit(); return {'id':row.id,'result':row.result,'closed_at':row.closed_at.isoformat()}
@router.post('/quality/defects/{defect_id}/close')
def close_defect(defect_id:int,company_id:int=Depends(_current_company_id),corrective_action:str|None=Query(default=None),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=_get(QualityDefect,db,company_id,defect_id); row.corrective_action=corrective_action or row.corrective_action; row.status='closed'; row.closed_at=utcnow(); db.commit(); return {'id':row.id,'status':row.status}

@router.post('/maintenance/work-orders/{work_order_id}/complete')
def complete_maintenance(work_order_id:int,company_id:int=Depends(_current_company_id),actual_cost:Decimal=Query(default=Decimal('0'),ge=0),db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=_get(MaintenanceWorkOrder,db,company_id,work_order_id)
    if row.status=='completed': return {'id':row.id,'status':row.status,'actual_cost':str(row.actual_cost)}
    row.status='completed'; row.completed_date=date.today(); row.actual_cost=actual_cost
    if row.project_id and actual_cost>0:
        pc=ProjectCost(company_id=company_id,project_id=row.project_id,cost_type='equipment_maintenance',source_type='maintenance_work_order',source_id=row.id,amount=actual_cost,cost_date=utcnow(),description=f'Maintenance {row.work_order_no}'); db.add(pc)
    db.commit(); return {'id':row.id,'status':row.status,'actual_cost':str(row.actual_cost)}

@router.post('/documents/signature-requests/{request_id}/add-signer',status_code=201)
def add_signer(request_id:int,company_id:int=Depends(_current_company_id),signer_name:str=Query(...),signer_email:str|None=None,signer_user_id:int|None=None,signer_order:int=2,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    req=_get(SignatureRequest,db,company_id,request_id)
    if signer_order<1: raise HTTPException(422,'Invalid signer order')
    if db.query(SignatureSigner).filter_by(request_id=req.id,signer_order=signer_order).first(): raise HTTPException(409,'Signer order already exists')
    row=SignatureSigner(request_id=req.id,signer_order=signer_order,user_id=signer_user_id,signer_name=signer_name,signer_email=signer_email); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'order':row.signer_order}
