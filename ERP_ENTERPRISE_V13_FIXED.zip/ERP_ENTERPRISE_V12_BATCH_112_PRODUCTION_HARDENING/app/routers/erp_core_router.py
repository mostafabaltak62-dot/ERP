from datetime import date, datetime
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Header
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import User
from ..enterprise_models import Branch, Department, AnalyticalDimension, DimensionValue, Project, ProjectPhase, Contract, ContractMilestone, Notification
from ..governance import require_permission, get_tenant_context
from ..core_services import tenant_company, tenant_branch, create_project, create_contract, add_dimension_value, global_search, mark_notification_read

router = APIRouter(prefix="/api/v1/core", tags=["ERP Core"])

class BranchIn(BaseModel):
    code: str = Field(min_length=2, max_length=30); name: str = Field(min_length=2, max_length=150)
class DepartmentIn(BaseModel):
    code: str = Field(min_length=2, max_length=30); name: str = Field(min_length=2, max_length=150)
class DimensionIn(BaseModel):
    code: str = Field(min_length=2, max_length=40); name: str = Field(min_length=2, max_length=120)
class DimensionValueIn(BaseModel):
    code: str = Field(min_length=1, max_length=40); name: str = Field(min_length=1, max_length=150)
class ProjectCoreIn(BaseModel):
    code: str = Field(min_length=2, max_length=50); name: str = Field(min_length=2, max_length=200); branch_id: int | None = None; customer_id: int | None = None; budget: Decimal = Field(default=Decimal("0"), ge=0)
class ContractIn(BaseModel):
    contract_number: str = Field(min_length=2, max_length=60); contract_type: str = Field(min_length=2, max_length=30); customer_id: int | None = None; supplier_id: int | None = None; project_id: int | None = None; value: Decimal = Field(default=Decimal("0"), ge=0); start_date: date | None = None; end_date: date | None = None; retention_rate: Decimal = Field(default=Decimal("0"), ge=0, le=100); advance_amount: Decimal = Field(default=Decimal("0"), ge=0)

@router.get("/context")
def context(ctx=Depends(get_tenant_context), user: User = Depends(require_permission("reports:view"))):
    return {"company_id": ctx["company_id"], "branch_id": ctx["branch_id"], "user_id": user.id}

@router.post("/branches", status_code=201)
def create_branch(data: BranchIn, ctx=Depends(get_tenant_context), db: Session=Depends(get_db), user: User=Depends(require_permission("core:manage"))):
    company_id = ctx["company_id"]
    if db.query(Branch).filter_by(company_id=company_id, code=data.code).first(): raise HTTPException(409, "Branch code already exists")
    row=Branch(company_id=company_id, code=data.code, name=data.name); db.add(row); db.commit(); db.refresh(row); return {"id":row.id,"code":row.code,"name":row.name}

@router.post("/departments", status_code=201)
def create_department(data: DepartmentIn, ctx=Depends(get_tenant_context), db: Session=Depends(get_db), user: User=Depends(require_permission("core:manage"))):
    company_id=ctx["company_id"]
    if db.query(Department).filter_by(company_id=company_id, code=data.code).first(): raise HTTPException(409,"Department code already exists")
    row=Department(company_id=company_id, code=data.code, name=data.name); db.add(row); db.commit(); db.refresh(row); return {"id":row.id,"code":row.code,"name":row.name}

@router.post("/dimensions", status_code=201)
def create_dimension(data: DimensionIn, ctx=Depends(get_tenant_context), db: Session=Depends(get_db), user: User=Depends(require_permission("core:manage"))):
    company_id=ctx["company_id"]
    if db.query(AnalyticalDimension).filter_by(company_id=company_id, code=data.code).first(): raise HTTPException(409,"Dimension code already exists")
    row=AnalyticalDimension(company_id=company_id, code=data.code, name=data.name); db.add(row); db.commit(); db.refresh(row); return {"id":row.id,"code":row.code,"name":row.name}

@router.post("/dimensions/{dimension_id}/values", status_code=201)
def create_dimension_value(dimension_id:int,data:DimensionValueIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("core:manage"))):
    try: row=add_dimension_value(db,ctx["company_id"],dimension_id,data.code,data.name); db.commit(); db.refresh(row); return {"id":row.id,"code":row.code,"name":row.name}
    except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.post("/projects", status_code=201)
def create_core_project(data:ProjectCoreIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("core:manage"))):
    try: row=create_project(db,ctx["company_id"],data.branch_id,data.code,data.name,data.customer_id,data.budget); db.commit(); db.refresh(row); return {"id":row.id,"code":row.code,"name":row.name,"budget":str(row.budget)}
    except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.get("/projects")
def list_projects(ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("reports:view"))):
    return [{"id":p.id,"code":p.code,"name":p.name,"budget":str(p.budget),"status":p.status} for p in db.query(Project).filter(Project.company_id==ctx["company_id"]).order_by(Project.id.desc()).all()]

@router.post("/contracts", status_code=201)
def create_core_contract(data:ContractIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("core:manage"))):
    try: row=create_contract(db,ctx["company_id"],**data.model_dump()); db.commit(); db.refresh(row); return {"id":row.id,"contract_number":row.contract_number,"value":str(row.value),"status":row.status}
    except ValueError as e: db.rollback(); raise HTTPException(409,str(e))

@router.get("/contracts")
def list_contracts(ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("reports:view"))):
    return [{"id":c.id,"contract_number":c.contract_number,"type":c.contract_type,"value":str(c.value),"status":c.status,"project_id":c.project_id} for c in db.query(Contract).filter(Contract.company_id==ctx["company_id"]).order_by(Contract.id.desc()).all()]

@router.get("/search")
def search(q:str,limit:int=25,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("reports:view"))):
    if limit<1 or limit>100: raise HTTPException(422,"limit must be between 1 and 100")
    return global_search(db,ctx["company_id"],q,limit)

@router.post("/notifications/{notification_id}/read")
def read_notification(notification_id:int,db:Session=Depends(get_db),user:User=Depends(require_permission("reports:view"))):
    try: row=mark_notification_read(db,user.id,notification_id); db.commit(); return {"id":row.id,"read":row.is_read}
    except ValueError as e: db.rollback(); raise HTTPException(404,str(e))

# -------------------- Documents / Notifications / Workflow --------------------
from pydantic import ConfigDict
from ..enterprise_models import WorkflowDefinition, WorkflowStep, WorkflowInstance
from ..core_services import create_document_attachment, list_document_attachments, create_notification
from ..enterprise_services import create_workflow_definition, decide_workflow_hardened

class AttachmentIn(BaseModel):
    entity_type: str = Field(min_length=2, max_length=80)
    entity_id: int = Field(gt=0)
    file_name: str = Field(min_length=1, max_length=255)
    storage_key: str = Field(min_length=1, max_length=500)
    content_type: str | None = Field(default=None, max_length=120)
    file_size: int | None = Field(default=None, ge=0)
    expires_at: datetime | None = None
class WorkflowStepIn(BaseModel):
    sequence: int = Field(ge=1)
    name: str = Field(min_length=1, max_length=120)
    required_permission: str = Field(min_length=2, max_length=150)
    min_amount: Decimal | None = Field(default=None, ge=0)
    max_amount: Decimal | None = Field(default=None, ge=0)
class WorkflowIn(BaseModel):
    document_type: str = Field(min_length=2, max_length=80)
    name: str = Field(min_length=2, max_length=150)
    steps: list[WorkflowStepIn] = Field(min_length=1, max_length=20)
class NotificationIn(BaseModel):
    user_id: int = Field(gt=0)
    notification_type: str = Field(min_length=2, max_length=80)
    title: str = Field(min_length=1, max_length=200)
    message: str = Field(min_length=1, max_length=4000)
    entity_type: str | None = None
    entity_id: int | None = Field(default=None, gt=0)
    branch_id: int | None = Field(default=None, gt=0)

@router.post("/documents/attachments", status_code=201)
def upload_attachment(data: AttachmentIn, ctx=Depends(get_tenant_context), db: Session=Depends(get_db), user: User=Depends(require_permission("core:documents"))):
    try:
        row=create_document_attachment(db,ctx["company_id"],user.id,**data.model_dump()); db.commit(); db.refresh(row)
        return {"id":row.id,"version":row.version,"file_name":row.file_name,"storage_key":row.storage_key}
    except ValueError as e:
        db.rollback(); raise HTTPException(422,str(e))
    except Exception:
        db.rollback(); raise HTTPException(409,"Attachment storage key already exists")

@router.get("/documents/attachments")
def get_attachments(entity_type:str,entity_id:int,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("core:documents"))):
    rows=list_document_attachments(db,ctx["company_id"],entity_type,entity_id)
    return [{"id":r.id,"version":r.version,"file_name":r.file_name,"storage_key":r.storage_key,"expires_at":r.expires_at.isoformat() if r.expires_at else None} for r in rows]

@router.post("/workflows", status_code=201)
def create_workflow(data:WorkflowIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("core:workflow"))):
    try:
        row=create_workflow_definition(db,ctx["company_id"],data.document_type,data.name,[s.model_dump() for s in data.steps]); db.commit(); db.refresh(row)
        return {"id":row.id,"document_type":row.document_type,"name":row.name}
    except ValueError as e:
        db.rollback(); raise HTTPException(409,str(e))

@router.get("/workflows")
def list_workflows(ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("core:workflow"))):
    rows=db.query(WorkflowDefinition).filter(WorkflowDefinition.company_id==ctx["company_id"]).order_by(WorkflowDefinition.id.desc()).all()
    return [{"id":r.id,"document_type":r.document_type,"name":r.name,"active":r.is_active} for r in rows]

@router.post("/notifications", status_code=201)
def send_notification(data:NotificationIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("core:notifications"))):
    try:
        row=create_notification(db,ctx["company_id"],**data.model_dump()); db.commit(); db.refresh(row)
        return {"id":row.id,"user_id":row.user_id,"title":row.title}
    except ValueError as e:
        db.rollback(); raise HTTPException(422,str(e))

class WorkflowDecisionIn(BaseModel):
    approved: bool
    reason: str = Field(default="", max_length=2000)

@router.post("/workflows/instances/{instance_id}/decision")
def workflow_decision(instance_id:int,data:WorkflowDecisionIn,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("core:workflow"))):
    from ..governance import _has_permission
    try:
        row=decide_workflow_hardened(db,instance_id,user.id,data.approved,data.reason,
            has_permission=lambda code: _has_permission(db,user.id,code,ctx["company_id"],ctx["branch_id"]))
        db.commit(); return {"id":row.id,"status":row.status,"current_step":row.current_step}
    except ValueError as e:
        db.rollback(); raise HTTPException(403 if "permission" in str(e).lower() else 409,str(e))
