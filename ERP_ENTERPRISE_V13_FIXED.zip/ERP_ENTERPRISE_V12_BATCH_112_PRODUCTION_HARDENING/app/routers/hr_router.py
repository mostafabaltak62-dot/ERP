from ..time_utils import utcnow
from datetime import date, datetime
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from sqlalchemy import func
from ..database import get_db
from ..models import User
from ..auth import require_module
from ..enterprise_models import Employee, Department, Project, ProjectCost, PayrollRun, PayrollLine
from ..construction_models import ConstructionSite
from ..hr_models import EmployeeProfile, EmployeeProjectAssignment, LeaveBalance, PayrollAllocation, UserScope, RoleScope, RoleApprovalLimit, HRDocument, DailyWorker, DailyLaborEntry, DailyLaborSettlement
from ..governance_models import Role, Permission, RolePermission, UserRole

router=APIRouter(prefix='/api/v1/hr', tags=['Enterprise HR & Access'])

def _require(user, module='hr', edit=False): return user

def _employee(db, company_id, employee_id):
    e=db.query(Employee).filter(Employee.id==employee_id, Employee.company_id==company_id).first()
    if not e: raise HTTPException(404,'Employee not found')
    return e

class EmployeeIn(BaseModel):
    company_id:int; employee_code:str; name:str; department_id:int|None=None; position:str|None=None; hire_date:date|None=None; base_salary:Decimal=Field(default=Decimal('0'),ge=0)
    branch_id:int|None=None; user_id:int|None=None; manager_employee_id:int|None=None; job_title:str|None=None; job_grade:str|None=None; employment_type:str='full_time'; employment_status:str='active'; termination_date:date|None=None; phone:str|None=None; email:str|None=None; address:str|None=None; overtime_rate:Decimal=Field(default=Decimal('0'),ge=0)
class AssignmentIn(BaseModel):
    company_id:int; employee_id:int; project_id:int; site_id:int|None=None; wbs_id:int|None=None; cost_code_id:int|None=None; allocation_percent:Decimal=Field(default=Decimal('100'),gt=0,le=100); start_date:date; end_date:date|None=None; is_primary:bool=False
class LeaveBalanceIn(BaseModel):
    company_id:int; employee_id:int; year:int; leave_type:str; entitled_days:Decimal=Field(default=0,ge=0); carried_days:Decimal=Field(default=0,ge=0)
class UserScopeIn(BaseModel):
    user_id:int; company_id:int|None=None; branch_id:int|None=None; project_id:int|None=None; site_id:int|None=None; can_view:bool=True; can_edit:bool=False; can_approve:bool=False
class ApprovalLimitIn(BaseModel):
    role_id:int; company_id:int; document_type:str; max_amount:Decimal=Field(ge=0); currency_code:str='EGP'
class RoleIn(BaseModel): code:str; name:str; is_system:bool=False
class PermissionIn(BaseModel): code:str; description:str|None=None
class RolePermissionIn(BaseModel): role_id:int; permission_id:int
class UserRoleIn(BaseModel): user_id:int; role_id:int; company_id:int|None=None; branch_id:int|None=None
class HRDocumentIn(BaseModel): company_id:int; employee_id:int; document_type:str; document_number:str|None=None; issue_date:date|None=None; expiry_date:date|None=None; status:str='active'; notes:str|None=None

@router.post('/employees',status_code=201)
def create_employee(data:EmployeeIn,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    e=Employee(company_id=data.company_id,employee_code=data.employee_code,name=data.name,department_id=data.department_id,position=data.position,hire_date=data.hire_date,base_salary=data.base_salary,is_active=data.employment_status=='active'); db.add(e); db.flush()
    p=EmployeeProfile(company_id=data.company_id,employee_id=e.id,branch_id=data.branch_id,user_id=data.user_id,manager_employee_id=data.manager_employee_id,job_title=data.job_title or data.position,job_grade=data.job_grade,employment_type=data.employment_type,employment_status=data.employment_status,termination_date=data.termination_date,phone=data.phone,email=data.email,address=data.address,basic_salary=data.base_salary,overtime_rate=data.overtime_rate); db.add(p); db.commit(); db.refresh(e); return {'id':e.id,'employee_code':e.employee_code}

@router.get('/employees')
def list_employees(company_id:int,db:Session=Depends(get_db),user:User=Depends(require_module('hr'))):
    rows=db.query(Employee,EmployeeProfile).outerjoin(EmployeeProfile,EmployeeProfile.employee_id==Employee.id).filter(Employee.company_id==company_id).order_by(Employee.id).all()
    return [{'id':e.id,'code':e.employee_code,'name':e.name,'department_id':e.department_id,'position':e.position,'branch_id':p.branch_id if p else None,'user_id':p.user_id if p else None,'status':p.employment_status if p else ('active' if e.is_active else 'inactive'),'salary':str(p.basic_salary if p else e.base_salary)} for e,p in rows]

@router.get('/employees/{employee_id}')
def get_employee(employee_id:int,company_id:int,db:Session=Depends(get_db),user:User=Depends(require_module('hr'))):
    e=_employee(db,company_id,employee_id); p=db.query(EmployeeProfile).filter_by(employee_id=e.id).first(); assignments=db.query(EmployeeProjectAssignment).filter_by(employee_id=e.id,company_id=company_id).all()
    return {'employee':{'id':e.id,'code':e.employee_code,'name':e.name,'department_id':e.department_id,'position':e.position,'salary':str(e.base_salary)},'profile':None if not p else {'branch_id':p.branch_id,'user_id':p.user_id,'manager_employee_id':p.manager_employee_id,'job_title':p.job_title,'job_grade':p.job_grade,'employment_type':p.employment_type,'employment_status':p.employment_status,'hire_date':e.hire_date.isoformat() if e.hire_date else None},'assignments':[{'project_id':a.project_id,'site_id':a.site_id,'wbs_id':a.wbs_id,'cost_code_id':a.cost_code_id,'allocation_percent':str(a.allocation_percent),'start_date':a.start_date.isoformat(),'end_date':a.end_date.isoformat() if a.end_date else None} for a in assignments]}

@router.post('/project-assignments',status_code=201)
def assign_employee(data:AssignmentIn,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    _employee(db,data.company_id,data.employee_id)
    if not db.query(Project).filter_by(id=data.project_id,company_id=data.company_id).first(): raise HTTPException(404,'Project not found')
    if data.site_id and not db.query(ConstructionSite).filter_by(id=data.site_id,project_id=data.project_id,company_id=data.company_id).first(): raise HTTPException(422,'Site does not belong to project')
    row=EmployeeProjectAssignment(**data.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id}

@router.get('/project-assignments')
def list_assignments(company_id:int,project_id:int|None=None,employee_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module('hr'))):
    q=db.query(EmployeeProjectAssignment).filter_by(company_id=company_id)
    if project_id:q=q.filter_by(project_id=project_id)
    if employee_id:q=q.filter_by(employee_id=employee_id)
    return [{'id':a.id,'employee_id':a.employee_id,'project_id':a.project_id,'site_id':a.site_id,'wbs_id':a.wbs_id,'cost_code_id':a.cost_code_id,'allocation_percent':str(a.allocation_percent),'start_date':a.start_date.isoformat(),'end_date':a.end_date.isoformat() if a.end_date else None} for a in q.all()]

@router.post('/leave-balances',status_code=201)
def set_leave_balance(data:LeaveBalanceIn,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    _employee(db,data.company_id,data.employee_id); row=db.query(LeaveBalance).filter_by(employee_id=data.employee_id,year=data.year,leave_type=data.leave_type).first()
    if not row: row=LeaveBalance(company_id=data.company_id,employee_id=data.employee_id,year=data.year,leave_type=data.leave_type); db.add(row)
    row.entitled_days=data.entitled_days; row.carried_days=data.carried_days; db.commit(); return {'id':row.id,'available':str(row.entitled_days+row.carried_days-row.used_days)}

@router.get('/leave-balances')
def leave_balances(company_id:int,employee_id:int|None=None,year:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module('hr'))):
    q=db.query(LeaveBalance).filter_by(company_id=company_id)
    if employee_id:q=q.filter_by(employee_id=employee_id)
    if year:q=q.filter_by(year=year)
    return [{'id':x.id,'employee_id':x.employee_id,'year':x.year,'leave_type':x.leave_type,'entitled':str(x.entitled_days),'used':str(x.used_days),'carried':str(x.carried_days),'available':str(x.entitled_days+x.carried_days-x.used_days)} for x in q.all()]

@router.post('/payroll/{payroll_run_id}/allocate',status_code=201)
def allocate_payroll(payroll_run_id:int,company_id:int,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    """Allocate payroll to projects using the employee's active project assignments.

    Explicit PayrollLine.project_id remains authoritative when supplied; when it is
    absent, active EmployeeProjectAssignment rows drive project/site/WBS/cost-code
    allocation. Every allocation creates exactly one authoritative ProjectCost row.
    """
    run=db.query(PayrollRun).filter_by(id=payroll_run_id,company_id=company_id).first()
    if not run: raise HTTPException(404,'Payroll run not found')
    lines=db.query(PayrollLine).filter_by(payroll_run_id=run.id,company_id=company_id).all(); created=[]
    for line in lines:
        if db.query(PayrollAllocation).filter_by(payroll_line_id=line.id).count():
            continue
        amount=Decimal(str(line.gross or 0))
        if amount < 0: raise HTTPException(422,'Payroll gross cannot be negative')
        assignments=db.query(EmployeeProjectAssignment).filter(
            EmployeeProjectAssignment.company_id==company_id,
            EmployeeProjectAssignment.employee_id==line.employee_id,
            EmployeeProjectAssignment.start_date<=run.end_date,
            (EmployeeProjectAssignment.end_date.is_(None) | (EmployeeProjectAssignment.end_date>=run.start_date))
        ).order_by(EmployeeProjectAssignment.is_primary.desc(),EmployeeProjectAssignment.id.asc()).all()
        if line.project_id:
            assignments=[a for a in assignments if a.project_id==line.project_id]
        if not assignments and line.project_id:
            assignments=[]
        total_pct=sum((Decimal(str(a.allocation_percent)) for a in assignments),Decimal('0'))
        if total_pct>Decimal('100'):
            raise HTTPException(422,f'Employee {line.employee_id} project allocation exceeds 100%')
        targets=[]
        if assignments:
            for a in assignments:
                targets.append((a, amount*Decimal(str(a.allocation_percent))/Decimal('100')))
            allocated=sum((x[1] for x in targets),Decimal('0'))
            if allocated < amount and line.project_id:
                primary=next((a for a in assignments if a.is_primary),assignments[0])
                targets.append((primary,amount-allocated))
        elif line.project_id:
            # Backward-compatible explicit project assignment when HR project mapping
            # has not yet been configured.
            targets=[(None,amount)]
        else:
            continue
        for a,allocated_amount in targets:
            if allocated_amount<=0: continue
            project_id=line.project_id if line.project_id else a.project_id
            row=PayrollAllocation(company_id=company_id,payroll_line_id=line.id,project_id=project_id,
                site_id=(a.site_id if a else None),wbs_id=(a.wbs_id if a else None),
                cost_code_id=(a.cost_code_id if a else None),amount=allocated_amount,
                allocation_percent=(Decimal('100') if a is None else (Decimal(str(allocated_amount))*Decimal('100')/amount)),
                allocation_method=('explicit_project' if a is None else 'employee_project_assignment'))
            db.add(row); db.flush()
            pc=ProjectCost(company_id=company_id,project_id=project_id,cost_type='labor_payroll',
                source_type='payroll_allocation',source_id=row.id,amount=allocated_amount,
                cost_date=datetime.combine(run.end_date,datetime.min.time()),
                description=f'Payroll {run.period_label} - employee {line.employee_id} allocation {row.id}')
            db.add(pc)
            created.append({'payroll_line_id':line.id,'allocation_id':row.id,'project_id':project_id,'site_id':row.site_id,'wbs_id':row.wbs_id,'cost_code_id':row.cost_code_id,'amount':str(allocated_amount)})
    db.commit(); return {'payroll_run_id':run.id,'allocated':created}

@router.post('/payroll/{payroll_run_id}/post-to-accounting',status_code=201)
def post_payroll_to_accounting(payroll_run_id:int,company_id:int,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    """Post the payroll run to the GL once, then keep the journal id on PayrollRun."""
    from ..accounting import create_entry, ensure_default_accounts
    run=db.query(PayrollRun).filter_by(id=payroll_run_id,company_id=company_id).first()
    if not run: raise HTTPException(404,'Payroll run not found')
    if run.journal_entry_id:
        return {'payroll_run_id':run.id,'journal_entry_id':run.journal_entry_id,'status':'already_posted'}
    if run.status not in {'approved','posted','paid'}:
        raise HTTPException(409,'Payroll run must be approved before accounting posting')
    lines=db.query(PayrollLine).filter_by(payroll_run_id=run.id,company_id=company_id).all()
    gross=sum((Decimal(str(x.gross or 0)) for x in lines),Decimal('0'))
    if gross<=0: raise HTTPException(422,'Payroll gross must be greater than zero')
    ensure_default_accounts(db,company_id=company_id)
    je=create_entry(db,description=f'Payroll {run.period_label}',user_id=user.id,
        lines=[('5200',gross,'0'),('2210','0',gross)],source_type='payroll_run',source_id=run.id,
        entry_date=datetime.combine(run.end_date,datetime.min.time()),company_id=company_id)
    run.journal_entry_id=je.id
    run.status='posted'
    db.commit()
    return {'payroll_run_id':run.id,'journal_entry_id':je.id,'status':run.status,'gross':str(gross)}

@router.get('/payroll/{payroll_run_id}/integration-summary')
def payroll_integration_summary(payroll_run_id:int,company_id:int,db:Session=Depends(get_db),user:User=Depends(require_module('hr'))):
    run=db.query(PayrollRun).filter_by(id=payroll_run_id,company_id=company_id).first()
    if not run: raise HTTPException(404,'Payroll run not found')
    allocations=(db.query(PayrollAllocation, PayrollLine.employee_id)
                 .join(PayrollLine, PayrollLine.id==PayrollAllocation.payroll_line_id)
                 .filter(PayrollLine.payroll_run_id==run.id, PayrollAllocation.company_id==company_id)
                 .all())
    by_project={}
    allocation_rows=[]
    for allocation, employee_id in allocations:
        key=str(allocation.project_id) if allocation.project_id is not None else 'unallocated'
        by_project[key]=by_project.get(key,Decimal('0'))+Decimal(str(allocation.amount))
        allocation_rows.append({'id':allocation.id,'employee_id':employee_id,'project_id':allocation.project_id,
                                'site_id':allocation.site_id,'wbs_id':allocation.wbs_id,
                                'cost_code_id':allocation.cost_code_id,'amount':str(allocation.amount),
                                'method':allocation.allocation_method})
    return {'payroll_run_id':run.id,'status':run.status,'journal_entry_id':run.journal_entry_id,
            'total_gross':str(run.total_gross or 0),'allocations':allocation_rows,
            'project_totals':{k:str(v) for k,v in by_project.items()}}

@router.post('/users/scopes',status_code=201)
def add_user_scope(data:UserScopeIn,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=UserScope(**data.model_dump()); db.add(row)
    try: db.commit()
    except Exception: db.rollback(); raise HTTPException(409,'Scope already exists')
    db.refresh(row); return {'id':row.id}

@router.get('/users/{user_id}/scopes')
def get_user_scopes(user_id:int,db:Session=Depends(get_db),user:User=Depends(require_module('hr'))):
    return [{'id':s.id,'company_id':s.company_id,'branch_id':s.branch_id,'project_id':s.project_id,'site_id':s.site_id,'can_view':s.can_view,'can_edit':s.can_edit,'can_approve':s.can_approve} for s in db.query(UserScope).filter_by(user_id=user_id).all()]

@router.post('/roles',status_code=201)
def create_role(data:RoleIn,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=Role(**data.model_dump()); db.add(row)
    try:db.commit()
    except Exception:db.rollback();raise HTTPException(409,'Role code already exists')
    db.refresh(row);return {'id':row.id,'code':row.code}

@router.post('/permissions',status_code=201)
def create_permission(data:PermissionIn,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=Permission(**data.model_dump());db.add(row)
    try:db.commit()
    except Exception:db.rollback();raise HTTPException(409,'Permission already exists')
    db.refresh(row);return {'id':row.id,'code':row.code}

@router.post('/roles/permissions',status_code=201)
def grant_role_permission(data:RolePermissionIn,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=RolePermission(**data.model_dump());db.add(row)
    try:db.commit()
    except Exception:db.rollback();raise HTTPException(409,'Role permission already exists')
    db.refresh(row);return {'id':row.id}

@router.post('/users/roles',status_code=201)
def assign_role(data:UserRoleIn,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=UserRole(**data.model_dump());db.add(row)
    try:db.commit()
    except Exception:db.rollback();raise HTTPException(409,'User role assignment already exists')
    db.refresh(row);return {'id':row.id}

@router.post('/roles/approval-limits',status_code=201)
def set_approval_limit(data:ApprovalLimitIn,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=db.query(RoleApprovalLimit).filter_by(role_id=data.role_id,company_id=data.company_id,document_type=data.document_type).first()
    if not row: row=RoleApprovalLimit(**data.model_dump());db.add(row)
    else:
        row.max_amount=data.max_amount;row.currency_code=data.currency_code
    db.commit();db.refresh(row);return {'id':row.id,'max_amount':str(row.max_amount)}

@router.get('/access/effective')
def effective_access(user_id:int,company_id:int|None=None,project_id:int|None=None,site_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module('hr'))):
    roles=db.query(UserRole).filter(UserRole.user_id==user_id,UserRole.is_active==True).all(); out=[]
    for ur in roles:
        r=db.query(Role).filter_by(id=ur.role_id,is_active=True).first()
        if not r:continue
        perms=db.query(Permission.code).join(RolePermission,RolePermission.permission_id==Permission.id).filter(RolePermission.role_id==r.id,Permission.is_active == True).all()
        limits=db.query(RoleApprovalLimit).filter_by(role_id=r.id,company_id=company_id).all() if company_id else []
        out.append({'role':r.code,'permissions':[x[0] for x in perms],'approval_limits':[{'document_type':x.document_type,'max_amount':str(x.max_amount),'currency':x.currency_code} for x in limits]})
    scopes=db.query(UserScope).filter_by(user_id=user_id).all()
    return {'roles':out,'scopes':[{'company_id':s.company_id,'branch_id':s.branch_id,'project_id':s.project_id,'site_id':s.site_id,'view':s.can_view,'edit':s.can_edit,'approve':s.can_approve} for s in scopes]}

@router.post('/documents',status_code=201)
def add_hr_document(data:HRDocumentIn,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    _employee(db,data.company_id,data.employee_id); row=HRDocument(**data.model_dump());db.add(row);db.commit();db.refresh(row);return {'id':row.id}

@router.get('/documents')
def list_hr_documents(company_id:int,employee_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module('hr'))):
    q=db.query(HRDocument).filter_by(company_id=company_id)
    if employee_id:q=q.filter_by(employee_id=employee_id)
    return [{'id':d.id,'employee_id':d.employee_id,'type':d.document_type,'number':d.document_number,'expiry_date':d.expiry_date.isoformat() if d.expiry_date else None,'status':d.status} for d in q.all()]

from ..enterprise_models import AttendanceRecord, LeaveRequest
from ..hr_models import PerformanceReview, TrainingRecord, PayrollComponent
class DailyWorkerIn(BaseModel):
    company_id:int; worker_code:str; name:str; national_id:str|None=None; phone:str|None=None; trade:str|None=None; worker_type:str="daily"; daily_rate:Decimal=Field(default=Decimal("0"),ge=0); overtime_rate:Decimal=Field(default=Decimal("0"),ge=0); normal_hours:Decimal=Field(default=Decimal("8"),gt=0)
class DailyLaborIn(BaseModel):
    company_id:int; worker_id:int; project_id:int; site_id:int|None=None; wbs_id:int|None=None; cost_code_id:int|None=None; boq_line_id:int|None=None; work_date:date; check_in:datetime|None=None; check_out:datetime|None=None; regular_hours:Decimal|None=None; overtime_hours:Decimal=Field(default=Decimal("0"),ge=0); other_amount:Decimal=Field(default=Decimal("0"),ge=0); deduction_amount:Decimal=Field(default=Decimal("0"),ge=0); notes:str|None=None
class DailyLaborSettlementIn(BaseModel):
    company_id:int; project_id:int|None=None; period_start:date; period_end:date

class AttendanceIn(BaseModel):
    company_id:int; employee_id:int; work_date:date; check_in:datetime|None=None; check_out:datetime|None=None; overtime_hours:Decimal=Field(default=0,ge=0); status:str='present'
class LeaveRequestIn(BaseModel):
    company_id:int; employee_id:int; start_date:date; end_date:date; leave_type:str; status:str='pending'
class ReviewIn(BaseModel):
    company_id:int; employee_id:int; review_date:date; period_label:str; rating:Decimal=Field(ge=0,le=100); goals:str|None=None; comments:str|None=None
class TrainingIn(BaseModel):
    company_id:int; employee_id:int; training_name:str; provider:str|None=None; start_date:date|None=None; end_date:date|None=None; cost:Decimal=Field(default=0,ge=0); status:str='planned'; certificate_expiry:date|None=None; notes:str|None=None
class ComponentIn(BaseModel):
    company_id:int; employee_id:int; component_type:str; code:str; name:str; amount:Decimal=Field(ge=0); is_recurring:bool=True; effective_from:date|None=None; effective_to:date|None=None

@router.post('/attendance',status_code=201)
def upsert_attendance(data:AttendanceIn,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    _employee(db,data.company_id,data.employee_id); row=db.query(AttendanceRecord).filter_by(employee_id=data.employee_id,work_date=data.work_date).first()
    if not row: row=AttendanceRecord(company_id=data.company_id,employee_id=data.employee_id,work_date=data.work_date); db.add(row)
    row.check_in=data.check_in; row.check_out=data.check_out; row.overtime_hours=data.overtime_hours; row.status=data.status; db.commit();db.refresh(row);return {'id':row.id,'status':row.status}

@router.get('/attendance')
def attendance(company_id:int,employee_id:int|None=None,start_date:date|None=None,end_date:date|None=None,db:Session=Depends(get_db),user:User=Depends(require_module('hr'))):
    q=db.query(AttendanceRecord).filter_by(company_id=company_id)
    if employee_id:q=q.filter_by(employee_id=employee_id)
    if start_date:q=q.filter(AttendanceRecord.work_date>=start_date)
    if end_date:q=q.filter(AttendanceRecord.work_date<=end_date)
    return [{'id':r.id,'employee_id':r.employee_id,'work_date':r.work_date.isoformat(),'check_in':r.check_in.isoformat() if r.check_in else None,'check_out':r.check_out.isoformat() if r.check_out else None,'overtime_hours':str(r.overtime_hours),'status':r.status} for r in q.order_by(AttendanceRecord.work_date).all()]

@router.post('/leave-requests',status_code=201)
def request_leave(data:LeaveRequestIn,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    _employee(db,data.company_id,data.employee_id)
    if data.end_date < data.start_date: raise HTTPException(422,'end_date must be on or after start_date')
    row=LeaveRequest(**data.model_dump());db.add(row);db.commit();db.refresh(row);return {'id':row.id,'status':row.status}

@router.post('/leave-requests/{request_id}/approve')
def approve_leave(request_id:int,company_id:int,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=db.query(LeaveRequest).filter_by(id=request_id,company_id=company_id).first()
    if not row:raise HTTPException(404,'Leave request not found')
    row.status='approved';db.commit();return {'id':row.id,'status':row.status}

@router.get('/leave-requests')
def leave_requests(company_id:int,employee_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module('hr'))):
    q=db.query(LeaveRequest).filter_by(company_id=company_id)
    if employee_id:q=q.filter_by(employee_id=employee_id)
    return [{'id':r.id,'employee_id':r.employee_id,'start_date':r.start_date.isoformat(),'end_date':r.end_date.isoformat(),'leave_type':r.leave_type,'status':r.status} for r in q.all()]

@router.post('/performance-reviews',status_code=201)
def create_review(data:ReviewIn,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    _employee(db,data.company_id,data.employee_id);row=PerformanceReview(**data.model_dump(),reviewer_id=user.id);db.add(row);db.commit();db.refresh(row);return {'id':row.id}

@router.get('/performance-reviews')
def reviews(company_id:int,employee_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module('hr'))):
    q=db.query(PerformanceReview).filter_by(company_id=company_id)
    if employee_id:q=q.filter_by(employee_id=employee_id)
    return [{'id':r.id,'employee_id':r.employee_id,'period':r.period_label,'rating':str(r.rating),'status':r.status} for r in q.all()]

@router.post('/training',status_code=201)
def add_training(data:TrainingIn,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    _employee(db,data.company_id,data.employee_id);row=TrainingRecord(**data.model_dump());db.add(row);db.commit();db.refresh(row);return {'id':row.id}

@router.get('/training')
def training(company_id:int,employee_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module('hr'))):
    q=db.query(TrainingRecord).filter_by(company_id=company_id)
    if employee_id:q=q.filter_by(employee_id=employee_id)
    return [{'id':r.id,'employee_id':r.employee_id,'training_name':r.training_name,'provider':r.provider,'status':r.status,'cost':str(r.cost)} for r in q.all()]

@router.post('/payroll-components',status_code=201)
def add_component(data:ComponentIn,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    _employee(db,data.company_id,data.employee_id);row=PayrollComponent(**data.model_dump());db.add(row);db.commit();db.refresh(row);return {'id':row.id}

@router.get('/payroll-components')
def components(company_id:int,employee_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module('hr'))):
    q=db.query(PayrollComponent).filter_by(company_id=company_id)
    if employee_id:q=q.filter_by(employee_id=employee_id)
    return [{'id':r.id,'employee_id':r.employee_id,'type':r.component_type,'code':r.code,'name':r.name,'amount':str(r.amount),'recurring':r.is_recurring} for r in q.all()]


@router.post('/daily-workers', status_code=201)
def create_daily_worker(data:DailyWorkerIn, db:Session=Depends(get_db), user:User=Depends(require_module('hr',True))):
    row=DailyWorker(**data.model_dump()); db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'worker_code':row.worker_code}

@router.get('/daily-workers')
def list_daily_workers(company_id:int,status:str|None=None,db:Session=Depends(get_db),user:User=Depends(require_module('hr'))):
    q=db.query(DailyWorker).filter_by(company_id=company_id)
    if status: q=q.filter_by(status=status)
    return [{'id':r.id,'worker_code':r.worker_code,'name':r.name,'trade':r.trade,'daily_rate':str(r.daily_rate),'overtime_rate':str(r.overtime_rate),'normal_hours':str(r.normal_hours),'status':r.status} for r in q.order_by(DailyWorker.id).all()]

@router.post('/daily-labor', status_code=201)
def create_daily_labor(data:DailyLaborIn, db:Session=Depends(get_db), user:User=Depends(require_module('hr',True))):
    worker=db.query(DailyWorker).filter_by(id=data.worker_id,company_id=data.company_id).first()
    if not worker: raise HTTPException(404,'Daily worker not found')
    project=db.query(Project).filter_by(id=data.project_id,company_id=data.company_id).first()
    if not project: raise HTTPException(404,'Project not found')
    if data.site_id and not db.query(ConstructionSite).filter_by(id=data.site_id,project_id=data.project_id,company_id=data.company_id).first(): raise HTTPException(422,'Site does not belong to project')
    if data.check_in and data.check_out and data.check_out < data.check_in: raise HTTPException(422,'check_out must be after check_in')
    regular=data.regular_hours
    if regular is None and data.check_in and data.check_out:
        regular=Decimal(str((data.check_out-data.check_in).total_seconds()/3600))
        regular=max(Decimal('0'), min(regular, Decimal(str(worker.normal_hours))))
    if regular is None: regular=Decimal(str(worker.normal_hours))
    overtime=Decimal(str(data.overtime_hours))
    if data.check_in and data.check_out and data.overtime_hours==0:
        total=Decimal(str((data.check_out-data.check_in).total_seconds()/3600)); overtime=max(Decimal('0'), total-Decimal(str(worker.normal_hours)))
    daily_rate=Decimal(str(worker.daily_rate)); ot_rate=Decimal(str(worker.overtime_rate or 0))
    regular_amount=daily_rate if regular>0 else Decimal('0')
    overtime_amount=overtime*ot_rate
    net=regular_amount+overtime_amount+data.other_amount-data.deduction_amount
    row=DailyLaborEntry(company_id=data.company_id,worker_id=data.worker_id,project_id=data.project_id,site_id=data.site_id,wbs_id=data.wbs_id,cost_code_id=data.cost_code_id,boq_line_id=data.boq_line_id,work_date=data.work_date,check_in=data.check_in,check_out=data.check_out,regular_hours=regular,overtime_hours=overtime,daily_rate=daily_rate,overtime_rate=ot_rate,regular_amount=regular_amount,overtime_amount=overtime_amount,other_amount=data.other_amount,deduction_amount=data.deduction_amount,net_amount=net,notes=data.notes)
    db.add(row); db.commit(); db.refresh(row); return {'id':row.id,'regular_amount':str(regular_amount),'overtime_amount':str(overtime_amount),'net_amount':str(net),'status':row.status}

@router.get('/daily-labor')
def list_daily_labor(company_id:int,project_id:int|None=None,worker_id:int|None=None,start_date:date|None=None,end_date:date|None=None,status:str|None=None,db:Session=Depends(get_db),user:User=Depends(require_module('hr'))):
    q=db.query(DailyLaborEntry).filter_by(company_id=company_id)
    if project_id:q=q.filter_by(project_id=project_id)
    if worker_id:q=q.filter_by(worker_id=worker_id)
    if start_date:q=q.filter(DailyLaborEntry.work_date>=start_date)
    if end_date:q=q.filter(DailyLaborEntry.work_date<=end_date)
    if status:q=q.filter_by(status=status)
    return [{'id':r.id,'worker_id':r.worker_id,'project_id':r.project_id,'site_id':r.site_id,'wbs_id':r.wbs_id,'cost_code_id':r.cost_code_id,'work_date':r.work_date.isoformat(),'regular_hours':str(r.regular_hours),'overtime_hours':str(r.overtime_hours),'regular_amount':str(r.regular_amount),'overtime_amount':str(r.overtime_amount),'other_amount':str(r.other_amount),'deduction_amount':str(r.deduction_amount),'net_amount':str(r.net_amount),'status':r.status,'project_cost_id':r.project_cost_id} for r in q.order_by(DailyLaborEntry.work_date,DailyLaborEntry.id).all()]

@router.post('/daily-labor/{entry_id}/approve')
def approve_daily_labor(entry_id:int,company_id:int,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    row=db.query(DailyLaborEntry).filter_by(id=entry_id,company_id=company_id).first()
    if not row: raise HTTPException(404,'Daily labor entry not found')
    if row.status=='approved': return {'id':row.id,'status':row.status,'project_cost_id':row.project_cost_id}
    if row.status=='posted': raise HTTPException(409,'Daily labor entry already posted')
    from ..enterprise_models import ProjectCost
    pc=ProjectCost(company_id=company_id,project_id=row.project_id,cost_type='labor',source_type='daily_labor',source_id=row.id,amount=row.net_amount,cost_date=datetime.combine(row.work_date,datetime.min.time()),description=f'Daily labor {row.id}')
    db.add(pc); db.flush(); row.project_cost_id=pc.id; row.status='approved'; row.approved_by_id=user.id; row.approved_at=utcnow(); db.commit(); return {'id':row.id,'status':row.status,'project_cost_id':pc.id,'amount':str(row.net_amount)}

@router.post('/daily-labor/settlements', status_code=201)
def create_daily_labor_settlement(data:DailyLaborSettlementIn,db:Session=Depends(get_db),user:User=Depends(require_module('hr',True))):
    if data.period_end < data.period_start: raise HTTPException(422,'period_end must be on or after period_start')
    q=db.query(DailyLaborEntry).filter(DailyLaborEntry.company_id==data.company_id,DailyLaborEntry.work_date>=data.period_start,DailyLaborEntry.work_date<=data.period_end,DailyLaborEntry.status=='approved')
    if data.project_id:q=q.filter(DailyLaborEntry.project_id==data.project_id)
    rows=q.all(); gross=sum((Decimal(str(r.regular_amount))+Decimal(str(r.overtime_amount))+Decimal(str(r.other_amount)) for r in rows),Decimal('0')); deductions=sum((Decimal(str(r.deduction_amount)) for r in rows),Decimal('0')); net=gross-deductions
    st=DailyLaborSettlement(company_id=data.company_id,project_id=data.project_id,period_start=data.period_start,period_end=data.period_end,gross_amount=gross,deductions=deductions,net_amount=net)
    db.add(st); db.commit(); db.refresh(st); return {'id':st.id,'workers_count':len(rows),'gross_amount':str(gross),'deductions':str(deductions),'net_amount':str(net),'status':st.status}

@router.get('/daily-labor/settlements')
def list_daily_labor_settlements(company_id:int,project_id:int|None=None,start_date:date|None=None,end_date:date|None=None,db:Session=Depends(get_db),user:User=Depends(require_module('hr'))):
    q=db.query(DailyLaborSettlement).filter_by(company_id=company_id)
    if project_id:q=q.filter_by(project_id=project_id)
    if start_date:q=q.filter(DailyLaborSettlement.period_end>=start_date)
    if end_date:q=q.filter(DailyLaborSettlement.period_start<=end_date)
    return [{'id':r.id,'project_id':r.project_id,'period_start':r.period_start.isoformat(),'period_end':r.period_end.isoformat(),'gross_amount':str(r.gross_amount),'deductions':str(r.deductions),'net_amount':str(r.net_amount),'status':r.status} for r in q.order_by(DailyLaborSettlement.period_start.desc()).all()]
