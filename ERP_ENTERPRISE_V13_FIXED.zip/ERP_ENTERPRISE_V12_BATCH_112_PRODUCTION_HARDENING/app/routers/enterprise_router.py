from ..time_utils import utcnow
# -*- coding: utf-8 -*-
import datetime
from decimal import Decimal, ROUND_HALF_UP
from fastapi import APIRouter, Depends, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import func

from ..database import get_db
from ..models import (User, Account, AccountTypeEnum, JournalEntry, JournalLine,
                      AccountingPeriod, JournalReversal, TaxRate, TaxTransaction,
                      PeriodClosingEntry, ModulePermission, SaleInvoice)
from ..accounting import create_entry, account, next_number, close_accounting_period, create_reversing_entry
from ..auth import require_module
from ..governance import require_permission, get_request_context

router = APIRouter(prefix="/enterprise")
templates = Jinja2Templates(directory="templates")


def can_edit(db, user):
    if user.role.value == "admin":
        return True
    p = db.query(ModulePermission).filter_by(user_id=user.id, module_key="accounting").first()
    return bool(p and p.can_edit)


def parse_date(value, fallback=None):
    if not value:
        return fallback
    try:
        return datetime.datetime.fromisoformat(value)
    except ValueError:
        raise HTTPException(400, "التاريخ غير صحيح")


def period_for(db, dt):
    return db.query(AccountingPeriod).filter(
        AccountingPeriod.start_date <= dt,
        AccountingPeriod.end_date >= dt,
    ).first()


def cash_account_codes(db):
    # حسابات نقدية/بنوك افتراضية: 11xx، ويمكن إضافة أي حساب لاحقًا بإعادة تعريفه.
    return [a.code for a in db.query(Account).filter(Account.is_active == True, Account.code.like("11%"))]


@router.get("/cash-flow", response_class=HTMLResponse)
def cash_flow(request: Request, start_date: str = "", end_date: str = "", db: Session = Depends(get_db), user: User = Depends(require_module("accounting"))):
    # Single source of truth: the authoritative accounting report owns cash-flow
    # classification, branch isolation, reconciliation and exports.
    target = "/accounting/reports/cash-flow"
    params=[]
    if start_date: params.append(f"start_date={start_date}")
    if end_date: params.append(f"end_date={end_date}")
    if params: target += "?" + "&".join(params)
    return RedirectResponse(target, status_code=307)

@router.get("/reversals", response_class=HTMLResponse)
def reversals(request: Request, db: Session = Depends(get_db), user: User = Depends(require_module("accounting")), _permission: User = Depends(require_permission("journal:view"))):
    ctx = get_request_context()
    cid, bid = ctx.get("company_id"), ctx.get("branch_id")
    q = db.query(JournalReversal).filter(JournalReversal.company_id == cid)
    if bid is not None:
        q = q.filter(JournalReversal.reversal_entry.has(JournalEntry.branch_id == bid))
    rows = q.order_by(JournalReversal.id.desc()).limit(100).all()
    eq = db.query(JournalEntry).filter(JournalEntry.status == "posted", JournalEntry.company_id == cid)
    if bid is not None:
        eq = eq.filter((JournalEntry.branch_id == bid) | (JournalEntry.branch_id.is_(None)))
    reversed_ids = db.query(JournalReversal.original_entry_id).filter(JournalReversal.company_id == cid)
    entries = (eq.filter(~JournalEntry.id.in_(reversed_ids))
                 .filter(JournalEntry.source_type.in_(["manual", "other", "accrual", "recurring_journal"]) | JournalEntry.source_type.is_(None))
                 .order_by(JournalEntry.id.desc()).limit(100).all())
    return templates.TemplateResponse(request, "reversals.html", {"user": user, "rows": rows, "entries": entries, "can_edit": True})


@router.post("/journal/{entry_id}/reverse")
def reverse_journal(entry_id: int, reason: str = Form(...), reversal_date: str = Form(""),
                    db: Session = Depends(get_db), user: User = Depends(require_permission("journal:reverse"))):
    dt = parse_date(reversal_date, utcnow())
    try:
        rev = create_reversing_entry(db, entry_id, user.id, reason, dt)
        db.commit()
    except Exception:
        db.rollback()
        raise
    return RedirectResponse(f"/accounting/journal/{rev.id}", status_code=303)


@router.post("/period/{period_id}/close")
def close_period(period_id: int, db: Session = Depends(get_db),
                 user: User = Depends(require_module("accounting", need_edit=True))):
    close_accounting_period(db, period_id, user.id)
    db.commit()
    return RedirectResponse("/finance", status_code=303)


@router.post("/period/{period_id}/reopen")
def reopen_period(period_id: int, db: Session = Depends(get_db), user: User = Depends(require_module("accounting", need_edit=True))):
    if user.role.value != "admin":
        raise HTTPException(403, "إعادة فتح الفترة متاحة للمدير العام فقط")
    period = db.query(AccountingPeriod).filter(AccountingPeriod.id == period_id).first()
    if not period: raise HTTPException(404, "الفترة غير موجودة")
    if not period.is_closed: raise HTTPException(400, "الفترة مفتوحة بالفعل")
    close_record = db.query(PeriodClosingEntry).filter(PeriodClosingEntry.period_id == period.id).first()
    if close_record:
        raise HTTPException(400, "لا يمكن إعادة فتح الفترة قبل معالجة قيد الإقفال/عكسه")
    period.is_closed = False
    period.closed_at = None
    period.closed_by_id = None
    db.commit()
    return RedirectResponse("/finance", status_code=303)


@router.get("/taxes", response_class=HTMLResponse)
def tax_transactions(request: Request, db: Session = Depends(get_db), user: User = Depends(require_module("accounting"))):
    from ..governance import get_request_context
    cid=get_request_context().get("company_id")
    if cid is None: raise HTTPException(403,"لم يتم تحديد الشركة الحالية")
    rows = (db.query(TaxTransaction).filter(TaxTransaction.company_id==cid).order_by(TaxTransaction.id.desc()).limit(100).all())
    rates = db.query(TaxRate).filter(TaxRate.company_id==cid, TaxRate.is_active == True).order_by(TaxRate.code).all()
    invoices = db.query(SaleInvoice).filter(SaleInvoice.company_id==cid).order_by(SaleInvoice.id.desc()).limit(100).all()
    return templates.TemplateResponse(request, "tax_transactions.html", {"user": user, "rows": rows, "rates": rates, "invoices": invoices, "can_edit": can_edit(db,user)})


@router.post("/tax/sales/{invoice_id}")
def apply_sales_tax(invoice_id: int, tax_rate_id: int = Form(...), db: Session = Depends(get_db), user: User = Depends(require_module("accounting", need_edit=True))):
    from ..governance import get_request_context
    ctx=get_request_context(); cid=ctx.get("company_id"); bid=ctx.get("branch_id")
    if cid is None: raise HTTPException(403,"لم يتم تحديد الشركة الحالية")
    invoice = db.query(SaleInvoice).filter(SaleInvoice.id == invoice_id, SaleInvoice.company_id == cid).first()
    if not invoice: raise HTTPException(404, "الفاتورة غير موجودة")
    if bid is not None and getattr(invoice,"branch_id",None) not in (None,bid): raise HTTPException(404,"الفاتورة غير متاحة للنطاق الحالي")
    if db.query(TaxTransaction).filter(TaxTransaction.company_id==cid,TaxTransaction.source_type=="sale_invoice", TaxTransaction.source_id==invoice.id).first():
        raise HTTPException(400, "تم احتساب الضريبة على الفاتورة بالفعل")
    rate = db.query(TaxRate).filter(TaxRate.id == tax_rate_id, TaxRate.company_id==cid, TaxRate.is_active == True).first()
    if bid is not None and rate and rate.branch_id not in (None,bid): raise HTTPException(404,"معدل الضريبة غير متاح للفرع الحالي")
    if not rate: raise HTTPException(400, "معدل الضريبة غير صالح")
    gross = Decimal(str(invoice.total))
    if gross <= 0: raise HTTPException(400, "قيمة الفاتورة غير صالحة")
    if Decimal(str(invoice.tax_amount or 0)) > 0:
        raise HTTPException(409, "الفاتورة تحتوي بالفعل على ضريبة؛ لا يمكن إعادة احتسابها من شاشة الإدارة القديمة")
    tax = (gross * Decimal(str(rate.rate)) / (Decimal("100") + Decimal(str(rate.rate)))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    net = (gross - tax).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    # الفاتورة الحالية تسجل إجماليًا كإيراد؛ نعيد تصنيف جزء الضريبة من الإيراد إلى الالتزام الضريبي.
    entry = create_entry(db, f"إثبات ضريبة الفاتورة {invoice.invoice_number}", user.id,
                         [("4100", tax, 0), (rate.tax_account_code, 0, tax)],
                         "sales_tax", invoice.id, invoice.invoice_date)
    db.add(TaxTransaction(company_id=cid, branch_id=getattr(invoice,"branch_id",None), tax_rate_id=rate.id, source_type="sale_invoice", source_id=invoice.id,
                          taxable_amount=net, tax_amount=tax, tax_direction="output", rate_applied=rate.rate,
                          tax_code_snapshot=rate.code, tax_name_snapshot=rate.name, tax_account_code_snapshot=rate.tax_account_code,
                          journal_entry_id=entry.id, created_by_id=user.id))
    db.commit()
    return RedirectResponse("/enterprise/taxes", status_code=303)
