# -*- coding: utf-8 -*-
"""Commercial/warehouse UI layer for the V10 ERP.

Adds the missing web workflows visible in the legacy screenshots while reusing
V10's authoritative transaction services for accounting and stock integrity.
"""
from datetime import datetime, time
import csv
from io import StringIO
from decimal import Decimal

from fastapi import APIRouter, Depends, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import func, and_, or_
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import (
    User, Item, ItemTypeEnum, StockMovement, MovementTypeEnum,
    SaleInvoice, PurchaseInvoice, FinanceVoucher, Account, Customer, Supplier, JournalEntry, JournalLine,
)
from ..enterprise_models import SalesReturn, SalesReturnLine, PurchaseReturn, PurchaseReturnLine, Branch, Project
from ..warehouse_models import Warehouse
from ..deep_transactions import create_sales_return, create_purchase_return, validate_three_way_match
from ..accounting import D, money, next_number
from ..auth import require_module
from ..governance import get_request_context
from ..inventory_transactions import create_movement

router = APIRouter(tags=["commercial-workspace"])
templates = Jinja2Templates(directory="templates")

# Canonical inventory direction sets used by the ledger and its aggregates.
IN_TYPES = (MovementTypeEnum.in_, MovementTypeEnum.adjustment_in)
OUT_TYPES = (MovementTypeEnum.out, MovementTypeEnum.adjustment_out)


def company_id():
    cid = get_request_context().get("company_id")
    if cid is None:
        raise HTTPException(403, "لم يتم تحديد الشركة الحالية")
    return int(cid)


def _date_start(value: str):
    return datetime.combine(datetime.fromisoformat(value).date(), time.min) if value else None


def _date_end(value: str):
    return datetime.combine(datetime.fromisoformat(value).date(), time.max) if value else None


# -------------------------------------------------------------------------
# مرتجعات المبيعات
# -------------------------------------------------------------------------
@router.get("/sales/returns", response_class=HTMLResponse)
def sales_returns(
    request: Request, q: str = "", status: str = "", date_from: str = "", date_to: str = "",
    db: Session = Depends(get_db), user: User = Depends(require_module("sales"))
):
    """Sales return control center with tenant-scoped search and KPI summary."""
    cid = company_id()
    query = db.query(SalesReturn).filter(SalesReturn.company_id == cid)
    if q:
        like = f"%{q.strip()}%"
        invoice_ids = [x[0] for x in db.query(SaleInvoice.id).filter(
            SaleInvoice.company_id == cid,
            SaleInvoice.invoice_number.ilike(like)
        ).all()]
        customer_ids = [x[0] for x in db.query(Customer.id).filter(
            Customer.company_id == cid,
            (Customer.code.ilike(like) | Customer.name.ilike(like))
        ).all()]
        filters = [SalesReturn.return_number.ilike(like)]
        if invoice_ids:
            filters.append(SalesReturn.sale_invoice_id.in_(invoice_ids))
        if customer_ids:
            filters.append(SalesReturn.customer_id.in_(customer_ids))
        from sqlalchemy import or_
        query = query.filter(or_(*filters))
    if status:
        query = query.filter(SalesReturn.status == status)
    start_dt = _date_start(date_from)
    end_dt = _date_end(date_to)
    if start_dt:
        query = query.filter(SalesReturn.return_date >= start_dt)
    if end_dt:
        query = query.filter(SalesReturn.return_date <= end_dt)

    rows = query.order_by(SalesReturn.return_date.desc(), SalesReturn.id.desc()).limit(200).all()
    invoice_map = {i.id: i for i in db.query(SaleInvoice).filter(SaleInvoice.company_id == cid).all()}
    customer_map = {c.id: c for c in db.query(Customer).filter(Customer.company_id == cid).all()}
    for r in rows:
        r.invoice_display = getattr(invoice_map.get(r.sale_invoice_id), 'invoice_number', f"INV-{r.sale_invoice_id}")
        c = customer_map.get(r.customer_id)
        r.customer_display = getattr(c, 'name', f"عميل #{r.customer_id}")

    all_returns = db.query(SalesReturn).filter(SalesReturn.company_id == cid)
    total_count = all_returns.count()
    total_amount = all_returns.with_entities(func.coalesce(func.sum(SalesReturn.total_amount), 0)).scalar() or 0
    posted_count = all_returns.filter(SalesReturn.status == 'posted').count()
    customer_count = all_returns.with_entities(func.count(func.distinct(SalesReturn.customer_id))).scalar() or 0
    eligible_invoices = db.query(SaleInvoice).filter(
        SaleInvoice.company_id == cid, SaleInvoice.status == 'posted'
    ).order_by(SaleInvoice.invoice_date.desc()).limit(8).all()

    return templates.TemplateResponse(request, "sales_returns.html", {
        "user": user, "rows": rows, "q": q, "status": status,
        "date_from": date_from, "date_to": date_to, "section": "sales",
        "total_count": total_count, "total_amount": total_amount,
        "posted_count": posted_count, "customer_count": customer_count,
        "eligible_invoices": eligible_invoices,
    })


@router.get("/sales/returns/{return_id}", response_class=HTMLResponse)
def sales_return_detail(return_id: int, request: Request, db: Session = Depends(get_db),
                        user: User = Depends(require_module("sales"))):
    cid = company_id()
    ret = db.query(SalesReturn).filter(SalesReturn.id == return_id, SalesReturn.company_id == cid).first()
    if not ret:
        raise HTTPException(404, "مرتجع المبيعات غير موجود")
    invoice = db.query(SaleInvoice).filter(SaleInvoice.id == ret.sale_invoice_id, SaleInvoice.company_id == cid).first()
    customer = db.query(Customer).filter(Customer.id == ret.customer_id, Customer.company_id == cid).first()
    lines = db.query(SalesReturnLine).filter(SalesReturnLine.return_id == ret.id, SalesReturnLine.company_id == cid).all()
    item_ids = [l.item_id for l in lines]
    items = {i.id: i for i in db.query(Item).filter(Item.id.in_(item_ids)).all()} if item_ids else {}
    return templates.TemplateResponse(request, "sales_return_detail.html", {
        "user": user, "ret": ret, "invoice": invoice, "customer": customer,
        "lines": lines, "items": items, "section": "sales"
    })

@router.get("/sales/{invoice_id}/return", response_class=HTMLResponse)
def sales_return_form(invoice_id: int, request: Request, db: Session = Depends(get_db),
                      user: User = Depends(require_module("sales", need_edit=True))):
    cid = company_id()
    invoice = db.query(SaleInvoice).filter(SaleInvoice.id == invoice_id, SaleInvoice.company_id == cid).first()
    if not invoice:
        raise HTTPException(404, "فاتورة البيع غير موجودة")
    returned = {
        r.invoice_line_id: D(r.qty)
        for r in db.query(
            SalesReturnLine.invoice_line_id,
            func.coalesce(func.sum(SalesReturnLine.quantity), 0).label("qty")
        ).filter(SalesReturnLine.company_id == cid).group_by(SalesReturnLine.invoice_line_id).all()
    }
    lines = []
    for line in invoice.lines:
        remaining = max(D(line.quantity) - returned.get(line.id, D(0)), D(0))
        lines.append({"line": line, "remaining": remaining})
    return templates.TemplateResponse(request, "return_form.html", {
        "user": user, "invoice": invoice, "lines": lines,
        "return_type": "sales", "action": f"/sales/{invoice_id}/return", "section": "sales"
    })


@router.post("/sales/{invoice_id}/return")
async def create_sales_return_web(invoice_id: int, request: Request, db: Session = Depends(get_db),
                                  user: User = Depends(require_module("sales", need_edit=True))):
    cid = company_id()
    form = await request.form()
    line_ids = form.getlist("invoice_line_id[]")
    quantities = form.getlist("quantity[]")
    costs = form.getlist("unit_cost[]")
    lines = []
    for lid, qty, cost in zip(line_ids, quantities, costs):
        if not lid or not qty or D(qty) <= 0:
            continue
        lines.append({"invoice_line_id": int(lid), "quantity": qty, "unit_cost": cost or None})
    if not lines:
        raise HTTPException(400, "حدد كمية مرتجع واحدة على الأقل")
    tax_rate = form.get("tax_rate") or None
    ret = create_sales_return(db, cid, user.id, invoice_id, lines, tax_rate)
    db.commit()
    return RedirectResponse(f"/sales/returns?q={ret.return_number}", status_code=303)


# -------------------------------------------------------------------------
# مرتجعات المشتريات — مركز تحكم كامل
# -------------------------------------------------------------------------
@router.get("/purchases/returns", response_class=HTMLResponse)
def purchase_returns(
    request: Request, q: str = "", status: str = "", supplier_id: int | None = None,
    date_from: str = "", date_to: str = "", db: Session = Depends(get_db),
    user: User = Depends(require_module("purchases"))
):
    cid = company_id()
    query = db.query(PurchaseReturn).filter(PurchaseReturn.company_id == cid)
    if q:
        like = f"%{q.strip()}%"
        supplier_ids = [x[0] for x in db.query(Supplier.id).filter(
            Supplier.company_id == cid,
            (Supplier.code.ilike(like) | Supplier.name.ilike(like))
        ).all()]
        invoice_ids = [x[0] for x in db.query(PurchaseInvoice.id).filter(
            PurchaseInvoice.company_id == cid,
            PurchaseInvoice.invoice_number.ilike(like)
        ).all()]
        from sqlalchemy import or_
        filters = [PurchaseReturn.return_number.ilike(like)]
        if supplier_ids: filters.append(PurchaseReturn.supplier_id.in_(supplier_ids))
        if invoice_ids: filters.append(PurchaseReturn.purchase_invoice_id.in_(invoice_ids))
        query = query.filter(or_(*filters))
    if status:
        query = query.filter(PurchaseReturn.status == status)
    if supplier_id:
        query = query.filter(PurchaseReturn.supplier_id == supplier_id)
    start_dt = _date_start(date_from); end_dt = _date_end(date_to)
    if start_dt: query = query.filter(PurchaseReturn.return_date >= start_dt)
    if end_dt: query = query.filter(PurchaseReturn.return_date <= end_dt)

    rows = query.order_by(PurchaseReturn.return_date.desc(), PurchaseReturn.id.desc()).limit(200).all()
    invoice_map = {i.id: i for i in db.query(PurchaseInvoice).filter(PurchaseInvoice.company_id == cid).all()}
    supplier_map = {x.id: x for x in db.query(Supplier).filter(Supplier.company_id == cid).all()}
    for r in rows:
        r.invoice_display = getattr(invoice_map.get(r.purchase_invoice_id), "invoice_number", f"PINV-{r.purchase_invoice_id}")
        r.supplier_display = getattr(supplier_map.get(r.supplier_id), "name", f"مورد #{r.supplier_id}")

    all_returns = db.query(PurchaseReturn).filter(PurchaseReturn.company_id == cid)
    total_count = all_returns.count()
    total_amount = all_returns.with_entities(func.coalesce(func.sum(PurchaseReturn.total_amount), 0)).scalar() or 0
    posted_count = all_returns.filter(PurchaseReturn.status == "posted").count()
    supplier_count = all_returns.with_entities(func.count(func.distinct(PurchaseReturn.supplier_id))).scalar() or 0
    eligible_invoices = db.query(PurchaseInvoice).filter(
        PurchaseInvoice.company_id == cid, PurchaseInvoice.status == "posted"
    ).order_by(PurchaseInvoice.invoice_date.desc()).limit(12).all()
    suppliers = db.query(Supplier).filter(Supplier.company_id == cid).order_by(Supplier.name).all()

    return templates.TemplateResponse(request, "purchase_returns.html", {
        "user": user, "rows": rows, "q": q, "status": status, "supplier_id": supplier_id,
        "date_from": date_from, "date_to": date_to, "section": "purchases",
        "total_count": total_count, "total_amount": total_amount,
        "posted_count": posted_count, "supplier_count": supplier_count,
        "eligible_invoices": eligible_invoices, "suppliers": suppliers,
    })


@router.get("/purchases/returns/{return_id}", response_class=HTMLResponse)
def purchase_return_detail(return_id: int, request: Request, db: Session = Depends(get_db),
                           user: User = Depends(require_module("purchases"))):
    cid = company_id()
    ret = db.query(PurchaseReturn).filter(PurchaseReturn.id == return_id, PurchaseReturn.company_id == cid).first()
    if not ret: raise HTTPException(404, "مرتجع المشتريات غير موجود")
    invoice = db.query(PurchaseInvoice).filter(PurchaseInvoice.id == ret.purchase_invoice_id, PurchaseInvoice.company_id == cid).first()
    supplier = db.query(Supplier).filter(Supplier.id == ret.supplier_id, Supplier.company_id == cid).first()
    lines = db.query(PurchaseReturnLine).filter(PurchaseReturnLine.return_id == ret.id, PurchaseReturnLine.company_id == cid).all()
    item_ids = [x.item_id for x in lines]
    items = {x.id: x for x in db.query(Item).filter(Item.id.in_(item_ids)).all()} if item_ids else {}
    warehouse = db.query(Warehouse).filter(Warehouse.id == ret.warehouse_id, Warehouse.company_id == cid).first() if ret.warehouse_id else None
    return templates.TemplateResponse(request, "purchase_return_detail.html", {
        "user": user, "ret": ret, "invoice": invoice, "supplier": supplier,
        "lines": lines, "items": items, "warehouse": warehouse, "section": "purchases"
    })


@router.get("/purchases/invoices", response_class=HTMLResponse)
def purchase_invoices(request: Request, q: str = "", db: Session = Depends(get_db),
                      user: User = Depends(require_module("purchases"))):
    cid = company_id()
    query = db.query(PurchaseInvoice).filter(PurchaseInvoice.company_id == cid)
    if q: query = query.filter(PurchaseInvoice.invoice_number.ilike(f"%{q}%"))
    rows = query.order_by(PurchaseInvoice.id.desc()).limit(200).all()
    return templates.TemplateResponse(request, "purchase_invoices.html", {"user": user, "rows": rows, "q": q, "section": "purchases"})


@router.get("/purchases/{invoice_id}/return", response_class=HTMLResponse)
def purchase_return_form(invoice_id: int, request: Request, db: Session = Depends(get_db),
                         user: User = Depends(require_module("purchases", need_edit=True))):
    cid = company_id()
    invoice = db.query(PurchaseInvoice).filter(PurchaseInvoice.id == invoice_id, PurchaseInvoice.company_id == cid).first()
    if not invoice: raise HTTPException(404, "فاتورة الشراء غير موجودة")
    if invoice.status != "posted": raise HTTPException(409, "لا يمكن إنشاء مرتجع من فاتورة غير مرحّلة")
    returned = {r.invoice_line_id: D(r.qty) for r in db.query(
        PurchaseReturnLine.invoice_line_id, func.coalesce(func.sum(PurchaseReturnLine.quantity), 0).label("qty")
    ).join(PurchaseReturn, PurchaseReturn.id == PurchaseReturnLine.return_id).filter(
        PurchaseReturnLine.company_id == cid, PurchaseReturn.status != "cancelled"
    ).group_by(PurchaseReturnLine.invoice_line_id).all()}
    lines = [{"line": line, "remaining": max(D(line.quantity) - returned.get(line.id, D(0)), D(0))} for line in invoice.lines]
    warehouses = db.query(Warehouse).filter(Warehouse.company_id == cid).order_by(Warehouse.name).all()
    return templates.TemplateResponse(request, "return_form.html", {
        "user": user, "invoice": invoice, "lines": lines, "warehouses": warehouses,
        "return_type": "purchase", "action": f"/purchases/{invoice_id}/return", "section": "purchases"
    })


@router.post("/purchases/{invoice_id}/return")
async def create_purchase_return_web(invoice_id: int, request: Request, db: Session = Depends(get_db),
                                     user: User = Depends(require_module("purchases", need_edit=True))):
    cid = company_id(); form = await request.form(); lines = []
    line_ids = form.getlist("invoice_line_id[]"); quantities = form.getlist("quantity[]")
    reasons = form.getlist("line_reason[]"); conditions = form.getlist("condition[]"); notes = form.getlist("line_notes[]")
    for idx, (lid, qty) in enumerate(zip(line_ids, quantities)):
        if lid and qty and D(qty) > 0:
            lines.append({"invoice_line_id": int(lid), "quantity": qty,
                          "return_reason": reasons[idx] if idx < len(reasons) else None,
                          "condition": conditions[idx] if idx < len(conditions) else None,
                          "notes": notes[idx] if idx < len(notes) else None})
    if not lines: raise HTTPException(400, "حدد كمية مرتجع واحدة على الأقل")
    warehouse_id = int(form.get("warehouse_id")) if form.get("warehouse_id") else None
    ret = create_purchase_return(db, cid, user.id, invoice_id, lines, form.get("tax_rate") or None,
                                 warehouse_id=warehouse_id, reason=form.get("reason") or None,
                                 notes=form.get("notes") or None)
    db.commit()
    return RedirectResponse(f"/purchases/returns/{ret.id}", status_code=303)



@router.post("/purchases/invoices/{invoice_id}/three-way-match")
def three_way_match(invoice_id:int, db:Session=Depends(get_db), user:User=Depends(require_module("purchases", need_edit=True))):
    result=validate_three_way_match(db, company_id(), invoice_id)
    db.commit()
    return RedirectResponse(f"/purchases/invoices?q={invoice_id}", status_code=303)

# -------------------------------------------------------------------------
# إدارة المخازن + دفتر حركة الصنف
# -------------------------------------------------------------------------
WAREHOUSE_TYPES = {"main", "branch", "project", "site"}

def _warehouse_scope_query(db: Session, cid: int):
    q = db.query(Warehouse).filter(Warehouse.company_id == cid)
    ctx_branch = get_request_context().get("branch_id")
    if ctx_branch is not None:
        q = q.filter(Warehouse.branch_id == int(ctx_branch))
    return q

def _validate_warehouse_scope(db: Session, cid: int, branch_id, project_id):
    ctx_branch = get_request_context().get("branch_id")
    if branch_id is not None:
        branch = db.query(Branch).filter(Branch.id == int(branch_id), Branch.company_id == cid, Branch.is_active.is_(True)).first()
        if not branch:
            raise HTTPException(400, "الفرع غير موجود في الشركة الحالية أو غير نشط")
        if ctx_branch is not None and int(branch_id) != int(ctx_branch):
            raise HTTPException(403, "لا يمكن ربط المخزن بفرع خارج نطاق الفرع الحالي")
    if project_id is not None:
        project = db.query(Project).filter(Project.id == int(project_id), Project.company_id == cid).first()
        if not project:
            raise HTTPException(400, "المشروع غير موجود في الشركة الحالية")
        if branch_id is not None and project.branch_id is not None and int(project.branch_id) != int(branch_id):
            raise HTTPException(400, "فرع المشروع لا يتطابق مع فرع المخزن")

@router.get("/inventory/warehouses", response_class=HTMLResponse)
def warehouses(request: Request, db: Session = Depends(get_db),
               user: User = Depends(require_module("inventory"))):
    cid = company_id()
    rows = _warehouse_scope_query(db, cid).order_by(Warehouse.is_active.desc(), Warehouse.code).all()
    ctx_branch = get_request_context().get("branch_id")
    branches = db.query(Branch).filter(Branch.company_id == cid, Branch.is_active.is_(True)).order_by(Branch.code).all()
    projects = db.query(Project).filter(Project.company_id == cid).order_by(Project.code).all()
    return templates.TemplateResponse(request, "warehouses.html", {"user": user, "rows": rows, "branches": branches, "projects": projects, "context_branch_id": ctx_branch, "section": "inventory"})

@router.post("/inventory/warehouses")
def create_warehouse(db: Session = Depends(get_db), user: User = Depends(require_module("inventory", need_edit=True)),
                     code: str = Form(...), name: str = Form(...), warehouse_type: str = Form("branch"),
                     branch_id: int | None = Form(None), project_id: int | None = Form(None)):
    cid = company_id()
    code = code.strip(); name = name.strip(); warehouse_type = (warehouse_type or "branch").strip().lower()
    if not code or not name:
        raise HTTPException(400, "الكود والاسم مطلوبان")
    if warehouse_type not in WAREHOUSE_TYPES:
        raise HTTPException(400, "نوع المخزن غير صالح")
    if warehouse_type in {"project", "site"} and project_id is None:
        raise HTTPException(400, "مخازن المشاريع والمواقع يجب ربطها بمشروع")
    if warehouse_type in {"main", "branch"} and project_id is not None:
        raise HTTPException(400, "المخزن الرئيسي أو مخزن الفرع لا يرتبط بمشروع")
    if db.query(Warehouse).filter(Warehouse.company_id == cid, Warehouse.code == code).first():
        raise HTTPException(409, "كود المخزن مستخدم بالفعل")
    _validate_warehouse_scope(db, cid, branch_id if branch_id is not None else get_request_context().get("branch_id"), project_id)
    bid = branch_id if branch_id is not None else get_request_context().get("branch_id")
    db.add(Warehouse(company_id=cid, branch_id=bid, project_id=project_id, code=code, name=name, warehouse_type=warehouse_type))
    db.commit()
    return RedirectResponse("/inventory/warehouses", status_code=303)

@router.get("/inventory/warehouses/{warehouse_id}/edit", response_class=HTMLResponse)
def edit_warehouse_form(warehouse_id: int, request: Request, db: Session = Depends(get_db),
                        user: User = Depends(require_module("inventory", need_edit=True))):
    cid = company_id()
    warehouse = _warehouse_scope_query(db, cid).filter(Warehouse.id == warehouse_id).first()
    if not warehouse:
        raise HTTPException(404, "المخزن غير موجود في نطاق الشركة/الفرع الحالي")
    branches = db.query(Branch).filter(Branch.company_id == cid, Branch.is_active.is_(True)).order_by(Branch.code).all()
    projects = db.query(Project).filter(Project.company_id == cid).order_by(Project.code).all()
    return templates.TemplateResponse(request, "warehouse_form.html", {"user": user, "warehouse": warehouse, "branches": branches, "projects": projects, "section": "inventory"})

@router.post("/inventory/warehouses/{warehouse_id}/edit")
def edit_warehouse(warehouse_id: int, db: Session = Depends(get_db), user: User = Depends(require_module("inventory", need_edit=True)),
                   code: str = Form(...), name: str = Form(...), warehouse_type: str = Form(...),
                   branch_id: int | None = Form(None), project_id: int | None = Form(None), is_active: str | None = Form(None)):
    cid = company_id(); code = code.strip(); name = name.strip(); warehouse_type = (warehouse_type or "").strip().lower()
    warehouse = _warehouse_scope_query(db, cid).filter(Warehouse.id == warehouse_id).first()
    if not warehouse: raise HTTPException(404, "المخزن غير موجود في نطاق الشركة/الفرع الحالي")
    if not code or not name: raise HTTPException(400, "الكود والاسم مطلوبان")
    if warehouse_type not in WAREHOUSE_TYPES: raise HTTPException(400, "نوع المخزن غير صالح")
    if warehouse_type in {"project", "site"} and project_id is None: raise HTTPException(400, "مخازن المشاريع والمواقع يجب ربطها بمشروع")
    if warehouse_type in {"main", "branch"} and project_id is not None: raise HTTPException(400, "المخزن الرئيسي أو مخزن الفرع لا يرتبط بمشروع")
    duplicate = db.query(Warehouse).filter(Warehouse.company_id == cid, Warehouse.code == code, Warehouse.id != warehouse_id).first()
    if duplicate: raise HTTPException(409, "كود المخزن مستخدم بالفعل")
    _validate_warehouse_scope(db, cid, branch_id, project_id)
    warehouse.code, warehouse.name, warehouse.warehouse_type = code, name, warehouse_type
    warehouse.branch_id, warehouse.project_id = branch_id, project_id
    warehouse.is_active = bool(is_active)
    db.commit(); return RedirectResponse("/inventory/warehouses", status_code=303)

@router.post("/inventory/warehouses/{warehouse_id}/deactivate")
def deactivate_warehouse(warehouse_id: int, db: Session = Depends(get_db), user: User = Depends(require_module("inventory", need_edit=True))):
    cid = company_id(); warehouse = _warehouse_scope_query(db, cid).filter(Warehouse.id == warehouse_id).first()
    if not warehouse: raise HTTPException(404, "المخزن غير موجود في نطاق الشركة/الفرع الحالي")
    if warehouse.is_active:
        inbound = db.query(func.coalesce(func.sum(StockMovement.quantity), 0)).filter(
            StockMovement.company_id == cid, StockMovement.warehouse_id == warehouse_id,
            StockMovement.movement_type.in_((MovementTypeEnum.in_, MovementTypeEnum.adjustment_in))
        ).scalar() or 0
        outbound = db.query(func.coalesce(func.sum(StockMovement.quantity), 0)).filter(
            StockMovement.company_id == cid, StockMovement.warehouse_id == warehouse_id,
            StockMovement.movement_type.in_((MovementTypeEnum.out, MovementTypeEnum.adjustment_out))
        ).scalar() or 0
        balance = D(inbound) - D(outbound)
        if balance != 0:
            raise HTTPException(409, f"لا يمكن إيقاف المخزن لأن رصيده الحالي {balance:g} وليس صفرًا")
    warehouse.is_active = False; db.commit(); return RedirectResponse("/inventory/warehouses", status_code=303)


def warehouse_stock(db: Session, cid: int, warehouse_id: int, item_id: int) -> Decimal:
    ins = db.query(func.coalesce(func.sum(StockMovement.quantity), 0)).filter(
        StockMovement.company_id == cid, StockMovement.warehouse_id == warehouse_id,
        StockMovement.item_id == item_id,
        StockMovement.movement_type.in_((MovementTypeEnum.in_, MovementTypeEnum.adjustment_in))).scalar() or 0
    outs = db.query(func.coalesce(func.sum(StockMovement.quantity), 0)).filter(
        StockMovement.company_id == cid, StockMovement.warehouse_id == warehouse_id,
        StockMovement.item_id == item_id,
        StockMovement.movement_type.in_((MovementTypeEnum.out, MovementTypeEnum.adjustment_out))).scalar() or 0
    return D(ins) - D(outs)


@router.get("/inventory/stock-ledger", response_class=HTMLResponse)
def stock_ledger(request: Request, item_id: int | None = None, warehouse_id: int | None = None,
                movement_type: str = "", start_date: str = "", end_date: str = "",
                page: int = 1, page_size: int = 100,
                db: Session = Depends(get_db), user: User = Depends(require_module("inventory"))):
    """Authoritative, tenant-scoped stock movement ledger.

    The report deliberately derives opening/running balances from immutable movement
    rows instead of trusting cached stock figures. This makes the ledger auditable
    and correct for arbitrary date ranges and warehouse/item filters.
    """
    cid = company_id()
    page = max(1, min(page, 100000))
    page_size = max(25, min(page_size, 500))

    def parse_date(value: str, label: str, end=False):
        if not value:
            return None
        try:
            d = datetime.fromisoformat(value).date()
        except (TypeError, ValueError):
            raise HTTPException(400, f"تاريخ {label} غير صحيح")
        return datetime.combine(d, time.max if end else time.min)

    s, e = parse_date(start_date, "البداية"), parse_date(end_date, "النهاية", end=True)
    if s and e and s > e:
        raise HTTPException(400, "تاريخ البداية لا يمكن أن يكون بعد تاريخ النهاية")

    item = None
    if item_id is not None:
        item = db.query(Item).filter(Item.id == item_id, Item.company_id == cid).first()
        if not item:
            raise HTTPException(404, "الصنف غير موجود في الشركة الحالية")
        if item.item_type != ItemTypeEnum.product:
            raise HTTPException(400, "دفتر حركة المخزون متاح للأصناف المخزنية فقط")

    warehouse = None
    if warehouse_id is not None:
        warehouse = db.query(Warehouse).filter(Warehouse.id == warehouse_id, Warehouse.company_id == cid).first()
        if not warehouse:
            raise HTTPException(404, "المخزن غير موجود في الشركة الحالية")

    try:
        mtype = MovementTypeEnum(movement_type) if movement_type else None
    except ValueError:
        raise HTTPException(400, "نوع الحركة غير صحيح")

    base = db.query(StockMovement).filter(StockMovement.company_id == cid)
    if item_id is not None:
        base = base.filter(StockMovement.item_id == item_id)
    if warehouse_id is not None:
        base = base.filter(StockMovement.warehouse_id == warehouse_id)
    if mtype:
        base = base.filter(StockMovement.movement_type == mtype)

    # Opening balance must ignore the movement-type filter: otherwise a filtered
    # ledger (e.g. inbound only) would report a mathematically wrong balance.
    balance_base = db.query(StockMovement).filter(StockMovement.company_id == cid)
    if item_id is not None:
        balance_base = balance_base.filter(StockMovement.item_id == item_id)
    if warehouse_id is not None:
        balance_base = balance_base.filter(StockMovement.warehouse_id == warehouse_id)

    def signed(qty, movement):
        return D(qty) if movement in IN_TYPES else -D(qty)

    if s:
        base = base.filter(StockMovement.created_at >= s)
    if e:
        base = base.filter(StockMovement.created_at <= e)

    total_count = base.count()
    total_in = base.filter(StockMovement.movement_type.in_(IN_TYPES)).with_entities(
        func.coalesce(func.sum(StockMovement.quantity), 0)).scalar() or 0
    total_out = base.filter(StockMovement.movement_type.in_(OUT_TYPES)).with_entities(
        func.coalesce(func.sum(StockMovement.quantity), 0)).scalar() or 0
    total_cost_in = base.filter(StockMovement.movement_type.in_(IN_TYPES)).with_entities(
        func.coalesce(func.sum(StockMovement.total_cost), 0)).scalar() or 0
    total_cost_out = base.filter(StockMovement.movement_type.in_(OUT_TYPES)).with_entities(
        func.coalesce(func.sum(StockMovement.total_cost), 0)).scalar() or 0

    rows = base.order_by(StockMovement.created_at.asc(), StockMovement.id.asc()).offset((page - 1) * page_size).limit(page_size).all()

    # Seed the running balance immediately before the first displayed row. This
    # keeps page 2+ mathematically continuous without loading every prior row.
    opening = {}
    if rows:
        first = rows[0]
        prior = balance_base
        if s:
            prior = prior.filter(StockMovement.created_at >= s)
        if first.created_at is not None:
            from sqlalchemy import or_, and_
            prior = prior.filter(or_(StockMovement.created_at < first.created_at,
                                     and_(StockMovement.created_at == first.created_at, StockMovement.id < first.id)))
        for mv in prior.all():
            key = (mv.item_id, mv.warehouse_id)
            opening[key] = opening.get(key, D(0)) + signed(mv.quantity, mv.movement_type)

    item_ids = {r.item_id for r in rows}
    warehouse_ids = {r.warehouse_id for r in rows if r.warehouse_id is not None}
    item_map = {x.id: x for x in db.query(Item).filter(Item.company_id == cid, Item.id.in_(item_ids)).all()} if item_ids else {}
    wh_map = {x.id: x for x in db.query(Warehouse).filter(Warehouse.company_id == cid, Warehouse.id.in_(warehouse_ids)).all()} if warehouse_ids else {}

    running = dict(opening)
    enriched = []
    for r in rows:
        key = (r.item_id, r.warehouse_id)
        running[key] = running.get(key, D(0)) + signed(r.quantity, r.movement_type)
        enriched.append({"movement": r, "item": item_map.get(r.item_id), "warehouse": wh_map.get(r.warehouse_id),
                         "balance": running[key]})

    total_pages = max(1, (total_count + page_size - 1) // page_size)
    return templates.TemplateResponse(request, "stock_ledger.html", {
        "user": user, "rows": enriched, "items": db.query(Item).filter(Item.company_id == cid, Item.is_active == True).order_by(Item.name).all(),
        "warehouses": db.query(Warehouse).filter(Warehouse.company_id == cid, Warehouse.is_active == True).order_by(Warehouse.name).all(),
        "item_id": item_id, "warehouse_id": warehouse_id, "movement_type": movement_type,
        "start_date": start_date, "end_date": end_date, "page": page, "page_size": page_size,
        "total_count": total_count, "total_pages": total_pages,
        "total_in": D(total_in), "total_out": D(total_out), "net_qty": D(total_in) - D(total_out),
        "total_cost_in": D(total_cost_in), "total_cost_out": D(total_cost_out),
        "movement_types": list(MovementTypeEnum), "section": "inventory",
    })


@router.get("/inventory/stock-ledger/export")
def export_stock_ledger(item_id: int | None = None, warehouse_id: int | None = None,
                       movement_type: str = "", start_date: str = "", end_date: str = "",
                       db: Session = Depends(get_db), user: User = Depends(require_module("inventory"))):
    """CSV export uses exactly the same tenant/filter rules as the visible ledger."""
    cid = company_id()
    try:
        s = _date_start(start_date) if start_date else None
        e = _date_end(end_date) if end_date else None
    except (TypeError, ValueError):
        raise HTTPException(400, "نطاق التاريخ غير صحيح")
    if s and e and s > e:
        raise HTTPException(400, "تاريخ البداية لا يمكن أن يكون بعد تاريخ النهاية")
    if item_id is not None and not db.query(Item.id).filter(Item.id == item_id, Item.company_id == cid).first():
        raise HTTPException(404, "الصنف غير موجود في الشركة الحالية")
    if warehouse_id is not None and not db.query(Warehouse.id).filter(Warehouse.id == warehouse_id, Warehouse.company_id == cid).first():
        raise HTTPException(404, "المخزن غير موجود في الشركة الحالية")
    try:
        mtype = MovementTypeEnum(movement_type) if movement_type else None
    except ValueError:
        raise HTTPException(400, "نوع الحركة غير صحيح")
    q = db.query(StockMovement).filter(StockMovement.company_id == cid)
    if item_id is not None: q = q.filter(StockMovement.item_id == item_id)
    if warehouse_id is not None: q = q.filter(StockMovement.warehouse_id == warehouse_id)
    if mtype: q = q.filter(StockMovement.movement_type == mtype)
    if s: q = q.filter(StockMovement.created_at >= s)
    if e: q = q.filter(StockMovement.created_at <= e)
    rows = q.order_by(StockMovement.created_at.asc(), StockMovement.id.asc()).all()
    items = {x.id: x for x in db.query(Item).filter(Item.company_id == cid).all()}
    warehouses = {x.id: x for x in db.query(Warehouse).filter(Warehouse.company_id == cid).all()}
    out = StringIO(); w = csv.writer(out)
    w.writerow(["التاريخ", "الصنف", "المخزن", "نوع الحركة", "الكمية", "تكلفة الوحدة", "الإجمالي", "البيان"])
    for r in rows:
        w.writerow([r.created_at.strftime("%Y-%m-%d %H:%M:%S"), getattr(items.get(r.item_id), "name", r.item_id),
                    getattr(warehouses.get(r.warehouse_id), "name", "غير محدد"), r.movement_type.value,
                    r.quantity, r.unit_cost, r.total_cost, r.note or ""])
    out.seek(0)
    return StreamingResponse(iter(["\ufeff" + out.getvalue()]), media_type="text/csv; charset=utf-8",
                             headers={"Content-Disposition": "attachment; filename=stock_ledger.csv"})


@router.post("/inventory/transfer")
async def transfer_stock(request: Request, db: Session = Depends(get_db),
                        user: User = Depends(require_module("inventory", need_edit=True))):
    cid = company_id(); form = await request.form()
    item_id = int(form.get("item_id")); source_id = int(form.get("source_warehouse_id")); dest_id = int(form.get("destination_warehouse_id")); qty = D(form.get("quantity"))
    if source_id == dest_id or qty <= 0: raise HTTPException(400, "بيانات التحويل غير صحيحة")
    item = db.query(Item).filter(Item.id == item_id, Item.company_id == cid, Item.item_type == ItemTypeEnum.product).first()
    source = db.query(Warehouse).filter(Warehouse.id == source_id, Warehouse.company_id == cid, Warehouse.is_active == True).first()
    dest = db.query(Warehouse).filter(Warehouse.id == dest_id, Warehouse.company_id == cid, Warehouse.is_active == True).first()
    if not item or not source or not dest: raise HTTPException(404, "الصنف أو المخزن غير موجود")
    ref = next_number(db, "warehouse_transfer", "TRF")
    transfer_id = ref
    cost = money(item.standard_cost or item.purchase_price or 0)
    create_movement(db, company_id=cid, item_id=item_id, warehouse_id=source_id, movement_type=MovementTypeEnum.out,
                    quantity=qty, unit_cost=cost, user_id=user.id, transfer_id=transfer_id,
                    note=f"تحويل مخزني {ref} إلى {dest.code}")
    create_movement(db, company_id=cid, item_id=item_id, warehouse_id=dest_id, movement_type=MovementTypeEnum.in_,
                    quantity=qty, unit_cost=cost, user_id=user.id, transfer_id=transfer_id,
                    note=f"تحويل مخزني {ref} من {source.code}")
    db.commit()
    return RedirectResponse(f"/inventory/stock-ledger?item_id={item_id}", status_code=303)


# -------------------------------------------------------------------------
# تقرير الخزينة المحسن - نفس فكرة شاشة الصور
# -------------------------------------------------------------------------
@router.get("/finance/treasury-report.csv")
def treasury_report_csv(start_date: str = "", end_date: str = "", account_code: str = "",
                       db: Session = Depends(get_db), user: User = Depends(require_module("accounting"))):
    """CSV export uses the same authoritative posted-journal dataset and tenant scope."""
    # Keep export behavior identical to the screen by delegating to a small local
    # query rather than trusting FinanceVoucher rows.
    cid = company_id()
    try:
        s, e = _date_start(start_date), _date_end(end_date)
    except (TypeError, ValueError):
        raise HTTPException(422, "نطاق التاريخ غير صحيح")
    if s and e and s > e:
        raise HTTPException(422, "تاريخ البداية يجب ألا يتجاوز تاريخ النهاية")
    accounts = db.query(Account).filter(Account.company_id==cid, Account.is_active.is_(True), Account.statement_section=="cash_and_equivalents").order_by(Account.code).all()
    allowed={a.code for a in accounts}
    if account_code and account_code not in allowed: raise HTTPException(404,"حساب الخزينة/البنك غير موجود أو غير متاح")
    ids=[next(a.id for a in accounts if a.code==account_code)] if account_code else [a.id for a in accounts]
    q=(db.query(JournalEntry,JournalLine,Account).join(JournalLine,JournalLine.entry_id==JournalEntry.id).join(Account,Account.id==JournalLine.account_id).filter(JournalEntry.company_id==cid,JournalLine.company_id==cid,Account.company_id==cid,JournalEntry.status=="posted",Account.id.in_(ids)))
    bid=get_request_context().get("branch_id")
    if bid is not None: q=q.filter(JournalEntry.branch_id==int(bid),JournalLine.branch_id==int(bid))
    if s: q=q.filter(JournalEntry.entry_date>=s)
    if e: q=q.filter(JournalEntry.entry_date<=e)
    rows=q.order_by(JournalEntry.entry_date,JournalEntry.id,JournalLine.id).all()
    out=StringIO(); w=csv.writer(out); w.writerow(["Date","Entry","Type","Account","Description","Debit","Credit","Net"])
    for entry,line,acc in rows: w.writerow([entry.entry_date.isoformat(),entry.entry_number,entry.source_type or "journal",acc.code,entry.description,str(money(line.debit)),str(money(line.credit)),str(money(D(line.debit)-D(line.credit)))])
    return StreamingResponse(iter([out.getvalue().encode("utf-8-sig")]),media_type="text/csv",headers={"Content-Disposition":"attachment; filename=treasury-report.csv"})

@router.get("/finance/treasury-report", response_class=HTMLResponse)
def treasury_report(request: Request, start_date: str = "", end_date: str = "", account_code: str = "",
                    db: Session = Depends(get_db), user: User = Depends(require_module("accounting"))):
    """Authoritative treasury movement report.

    Treasury reporting is derived from POSTED journal lines, not the operational
    voucher table. This prevents draft/unposted vouchers from appearing as cash
    and keeps the report reconcilable with the general ledger.
    """
    cid = company_id()
    try:
        s, e = _date_start(start_date), _date_end(end_date)
    except (TypeError, ValueError):
        raise HTTPException(422, "نطاق التاريخ غير صحيح")
    if s and e and s > e:
        raise HTTPException(422, "تاريخ البداية يجب ألا يتجاوز تاريخ النهاية")

    accounts_q = db.query(Account).filter(
        Account.company_id == cid,
        Account.is_active.is_(True),
        Account.statement_section == "cash_and_equivalents",
    )
    accounts = accounts_q.order_by(Account.code).all()
    allowed_codes = {a.code for a in accounts}
    if account_code and account_code not in allowed_codes:
        raise HTTPException(404, "حساب الخزينة/البنك غير موجود أو غير متاح")

    # Resolve the selected account from the tenant-scoped cash account list.
    selected = next((a for a in accounts if a.code == account_code), None)
    account_ids = [selected.id] if selected else [a.id for a in accounts]

    base = (db.query(JournalEntry, JournalLine, Account)
            .join(JournalLine, JournalLine.entry_id == JournalEntry.id)
            .join(Account, Account.id == JournalLine.account_id)
            .filter(
                JournalEntry.company_id == cid,
                JournalLine.company_id == cid,
                Account.company_id == cid,
                JournalEntry.status == "posted",
                Account.id.in_(account_ids),
            ))

    # Branch is intentionally taken from the authoritative accounting entry.
    # If the current request context carries a branch, never mix branches.
    ctx = get_request_context()
    branch_id = ctx.get("branch_id")
    if branch_id is not None:
        base = base.filter(JournalEntry.branch_id == int(branch_id),
                           JournalLine.branch_id == int(branch_id))

    # Opening balance: all posted cash activity before the selected start date.
    opening_balance = Decimal("0")
    if s:
        oq = base.filter(JournalEntry.entry_date < s)
        opening_balance = money(sum(
            (D(line.debit) - D(line.credit) for _, line, _ in oq.all()), D(0)
        ))

    period_q = base
    if s:
        period_q = period_q.filter(JournalEntry.entry_date >= s)
    if e:
        period_q = period_q.filter(JournalEntry.entry_date <= e)

    # Deterministic ordering is essential for a reproducible running balance.
    raw = period_q.order_by(JournalEntry.entry_date.asc(), JournalEntry.id.asc(), JournalLine.id.asc()).all()

    # Map finance-voucher source records once; other accounting sources remain visible.
    voucher_ids = [e.source_id for e, _, _ in raw if e.source_type == "finance_voucher" and e.source_id]
    vouchers = {}
    if voucher_ids:
        vouchers = {v.id: v for v in db.query(FinanceVoucher).filter(
            FinanceVoucher.company_id == cid, FinanceVoucher.id.in_(voucher_ids)
        ).all()}

    running = opening_balance
    rows = []
    receipts = Decimal("0")
    payments = Decimal("0")
    expense_payments = Decimal("0")

    for entry, line, acc in raw:
        debit = money(line.debit)
        credit = money(line.credit)
        net = money(debit - credit)
        running = money(running + net)
        v = vouchers.get(entry.source_id) if entry.source_type == "finance_voucher" else None
        if net > 0:
            receipts += net
            if v and v.voucher_type == "expense":
                # An expense voucher credits cash, so it cannot be a positive cash row;
                # keep classification defensive for non-standard journal sources.
                expense_payments += net
        elif net < 0:
            payments += -net
            if v and v.voucher_type == "expense":
                expense_payments += -net
        rows.append({
            "voucher_date": entry.entry_date,
            "voucher_number": v.voucher_number if v else entry.entry_number,
            "voucher_type": v.voucher_type if v else entry.source_type or "journal",
            "account_code": acc.code,
            "account_name": acc.name,
            "description": entry.description,
            "debit": debit,
            "credit": credit,
            "net": net,
            "amount": money(abs(net)),
            "running_balance": running,
            "branch_id": entry.branch_id,
        })

    receipts = money(receipts)
    payments = money(payments)
    expense_payments = money(expense_payments)
    closing_balance = money(opening_balance + receipts - payments)

    # Independent reconciliation against the authoritative cash-flow engine.
    # This catches report-query drift without using the report rows themselves.
    from ..financial_reporting import cash_flow
    recon = None
    if s and e:
        cf = cash_flow(db, cid, s.date(), e.date(), int(branch_id) if branch_id is not None else None)
        recon = {
            "engine_closing": money(cf.get("closing_cash", 0)),
            "engine_net_change": money(cf.get("net_change", 0)),
            "engine_reconciles": bool(cf.get("reconciles", False)),
        }

    return templates.TemplateResponse(request, "treasury_report.html", {
        "user": user, "rows": rows, "accounts": accounts, "account_code": account_code,
        "start_date": start_date, "end_date": end_date,
        "receipts": receipts, "payments": payments, "expenses": expense_payments,
        "net": money(receipts - payments), "opening_balance": opening_balance,
        "closing_balance": closing_balance, "reconciliation": recon,
        "section": "finance",
    })
