# -*- coding: utf-8 -*-
from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from ..database import get_db
from ..models import User, RoleEnum
from ..enterprise_models import Company, Branch, UserCompanyAccess, Currency
from ..governance import require_permission, get_request_context
from ..governance_models import GovernanceAuditLog

router = APIRouter(tags=["Organization Administration"])
templates = Jinja2Templates(directory="templates")


def _company_for_admin(db: Session, user: User, company_id: int | None) -> Company:
    if company_id is None:
        access = (db.query(UserCompanyAccess)
                  .filter(UserCompanyAccess.user_id == user.id, UserCompanyAccess.can_manage.is_(True))
                  .order_by(UserCompanyAccess.id).first())
        if not access:
            raise HTTPException(403, "No company access assigned")
        company_id = access.company_id
    company = db.get(Company, company_id)
    if not company:
        raise HTTPException(404, "Company not found")
    if user.role != RoleEnum.admin:
        access = db.query(UserCompanyAccess).filter(
            UserCompanyAccess.user_id == user.id,
            UserCompanyAccess.company_id == company.id,
            UserCompanyAccess.can_manage.is_(True),
        ).first()
        if not access:
            raise HTTPException(403, "Company administration access required")
    return company


def _redirect(company_id: int):
    return RedirectResponse(f"/admin/organization?company_id={company_id}", status_code=303)

def _audit(db: Session, user: User, action: str, entity_type: str, entity_id, before=None, after=None, company_id=None, reason=None):
    ctx = get_request_context()
    before = before or {}
    after = after or {}
    changes = {}
    for key in set(before) | set(after):
        if before.get(key) != after.get(key):
            changes[key] = {"before": before.get(key), "after": after.get(key)}
    db.add(GovernanceAuditLog(
        user_id=user.id, company_id=company_id, branch_id=None,
        request_id=ctx.get("request_id"), ip_address=ctx.get("ip_address"),
        action=action, entity_type=entity_type, entity_id=str(entity_id) if entity_id is not None else None,
        before_json=before, after_json=after, changes_json=changes, reason=reason))


def _active_currency(db: Session, currency_id):
    if currency_id is None:
        return None
    return db.query(Currency).filter(Currency.id == currency_id, Currency.is_active.is_(True)).first()


@router.get("/admin/organization", response_class=HTMLResponse)
def organization_admin(
    request: Request,
    company_id: int | None = None,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("admin:tenants")),
):
    company = _company_for_admin(db, user, company_id)
    companies = db.query(Company).order_by(Company.id).all() if user.role == RoleEnum.admin else (
        db.query(Company).join(UserCompanyAccess, UserCompanyAccess.company_id == Company.id)
        .filter(UserCompanyAccess.user_id == user.id, UserCompanyAccess.can_manage.is_(True)).order_by(Company.id).all()
    )
    branches = db.query(Branch).filter(Branch.company_id == company.id).order_by(Branch.code).all()
    users = db.query(User).order_by(User.full_name, User.id).all()
    accesses = db.query(UserCompanyAccess).filter(UserCompanyAccess.company_id == company.id).all()
    access_map = {(a.user_id, a.branch_id): a for a in accesses}
    branch_counts = {b.id: sum(1 for a in accesses if a.branch_id == b.id) for b in branches}
    company_admins = [a.user_id for a in accesses if a.branch_id is None and a.can_manage]
    return templates.TemplateResponse(request, "admin_organization.html", {
        "user": user, "company": company, "companies": companies, "branches": branches,
        "users": users, "access_map": access_map, "branch_counts": branch_counts,
        "company_admins": set(company_admins), "currencies": db.query(Currency).filter(Currency.is_active.is_(True)).order_by(Currency.code).all(),
        "section": "users",
    })


@router.post("/admin/organization/company/create")
def create_company(
    code: str = Form(...), name: str = Form(...), legal_name: str = Form(""), tax_number: str = Form(""),
    base_currency_id: int | None = Form(None), db: Session = Depends(get_db),
    user: User = Depends(require_permission("admin:tenants")),
):
    code, name = code.strip().upper(), name.strip()
    if not code or not name:
        raise HTTPException(422, "Company code and name are required")
    if db.query(Company).filter(Company.code == code).first():
        raise HTTPException(409, "Company code already exists")
    if base_currency_id is not None and not _active_currency(db, base_currency_id):
        raise HTTPException(422, "Base currency must be active")
    tax_number = tax_number.strip() or None
    row = Company(code=code, name=name, legal_name=legal_name.strip() or None, tax_number=tax_number, base_currency_id=base_currency_id)
    db.add(row)
    try:
        db.flush()
        main = Branch(company_id=row.id, code="MAIN", name="Main Branch", is_active=True)
        db.add(main)
        db.flush()
        # System administrators automatically receive company-wide + MAIN branch scope.
        admins = db.query(User).filter(User.role == RoleEnum.admin, User.is_active.is_(True)).all()
        for admin in admins:
            db.add(UserCompanyAccess(user_id=admin.id, company_id=row.id, branch_id=None, can_manage=True))
            db.add(UserCompanyAccess(user_id=admin.id, company_id=row.id, branch_id=main.id, can_manage=True))
        _audit(db, user, "create", "Company", row.id, after={"code": row.code, "name": row.name, "tax_number": row.tax_number, "base_currency_id": row.base_currency_id}, company_id=row.id)
        db.commit()
    except IntegrityError:
        db.rollback(); raise HTTPException(409, "Company code or tax number already exists")
    return _redirect(row.id)


@router.post("/admin/organization/company/{company_id}/update")
def update_company(
    company_id: int, name: str = Form(...), legal_name: str = Form(""), tax_number: str = Form(""),
    base_currency_id: int | None = Form(None), db: Session = Depends(get_db),
    user: User = Depends(require_permission("admin:tenants")),
):
    company = _company_for_admin(db, user, company_id)
    if not name.strip(): raise HTTPException(422, "Company name is required")
    if base_currency_id is not None and not _active_currency(db, base_currency_id):
        raise HTTPException(422, "Base currency must be active")
    before = {"name": company.name, "legal_name": company.legal_name, "tax_number": company.tax_number, "base_currency_id": company.base_currency_id}
    company.name = name.strip(); company.legal_name = legal_name.strip() or None; company.tax_number = tax_number.strip() or None; company.base_currency_id = base_currency_id
    try:
        _audit(db, user, "update", "Company", company.id, before=before, after={"name": company.name, "legal_name": company.legal_name, "tax_number": company.tax_number, "base_currency_id": company.base_currency_id}, company_id=company.id)
        db.commit()
    except IntegrityError:
        db.rollback(); raise HTTPException(409, "Tax number already exists")
    return _redirect(company.id)


@router.post("/admin/organization/company/{company_id}/toggle")
def toggle_company(company_id: int, db: Session = Depends(get_db), user: User = Depends(require_permission("admin:tenants"))):
    company = _company_for_admin(db, user, company_id)
    if company.is_active and db.query(Company).filter(Company.is_active.is_(True)).count() <= 1:
        raise HTTPException(422, "Cannot deactivate the last active company")
    before = {"is_active": company.is_active}
    company.is_active = not company.is_active
    _audit(db, user, "activate" if company.is_active else "deactivate", "Company", company.id, before=before, after={"is_active": company.is_active}, company_id=company.id)
    db.commit(); return _redirect(company.id)


@router.post("/admin/organization/{company_id}/branch/create")
def create_branch(
    company_id: int, code: str = Form(...), name: str = Form(...), db: Session = Depends(get_db),
    user: User = Depends(require_permission("admin:tenants")),
):
    company = _company_for_admin(db, user, company_id)
    code, name = code.strip().upper(), name.strip()
    if not code or not name: raise HTTPException(422, "Branch code and name are required")
    if db.query(Branch).filter(Branch.company_id == company.id, Branch.code == code).first():
        raise HTTPException(409, "Branch code already exists")
    branch = Branch(company_id=company.id, code=code, name=name, is_active=True); db.add(branch)
    try:
        db.flush()
        # Every active administrator of this company gets automatic management scope.
        admin_ids = {a.user_id for a in db.query(UserCompanyAccess).filter(UserCompanyAccess.company_id == company.id, UserCompanyAccess.branch_id.is_(None), UserCompanyAccess.can_manage.is_(True)).all()}
        for admin_id in admin_ids:
            if not db.query(UserCompanyAccess).filter_by(user_id=admin_id, company_id=company.id, branch_id=branch.id).first():
                db.add(UserCompanyAccess(user_id=admin_id, company_id=company.id, branch_id=branch.id, can_manage=True))
        _audit(db, user, "create", "Branch", branch.id, after={"company_id": company.id, "code": branch.code, "name": branch.name, "is_active": branch.is_active}, company_id=company.id)
        db.commit()
    except IntegrityError:
        db.rollback(); raise HTTPException(409, "Branch code already exists")
    return _redirect(company.id)


@router.post("/admin/organization/{company_id}/branch/{branch_id}/update")
def update_branch(company_id: int, branch_id: int, code: str = Form(...), name: str = Form(...), db: Session = Depends(get_db), user: User = Depends(require_permission("admin:tenants"))):
    company = _company_for_admin(db, user, company_id)
    branch = db.query(Branch).filter(Branch.id == branch_id, Branch.company_id == company.id).first()
    if not branch: raise HTTPException(404, "Branch not found")
    code, name = code.strip().upper(), name.strip()
    if not code or not name: raise HTTPException(422, "Branch code and name are required")
    if db.query(Branch).filter(Branch.company_id == company.id, Branch.code == code, Branch.id != branch.id).first(): raise HTTPException(409, "Branch code already exists")
    before = {"code": branch.code, "name": branch.name}
    branch.code = code; branch.name = name
    _audit(db, user, "update", "Branch", branch.id, before=before, after={"code": branch.code, "name": branch.name}, company_id=company.id)
    db.commit(); return _redirect(company.id)


@router.post("/admin/organization/{company_id}/branch/{branch_id}/toggle")
def toggle_branch(company_id: int, branch_id: int, db: Session = Depends(get_db), user: User = Depends(require_permission("admin:tenants"))):
    company = _company_for_admin(db, user, company_id)
    branch = db.query(Branch).filter(Branch.id == branch_id, Branch.company_id == company.id).first()
    if not branch: raise HTTPException(404, "Branch not found")
    if branch.is_active and db.query(Branch).filter(Branch.company_id == company.id, Branch.is_active.is_(True)).count() <= 1: raise HTTPException(422, "Cannot deactivate the last active branch")
    before = {"is_active": branch.is_active}
    branch.is_active = not branch.is_active
    _audit(db, user, "activate" if branch.is_active else "deactivate", "Branch", branch.id, before=before, after={"is_active": branch.is_active}, company_id=company.id)
    db.commit(); return _redirect(company.id)


@router.post("/admin/organization/{company_id}/access")
def set_branch_access(
    company_id: int, user_id: int = Form(...), branch_id: int = Form(...), can_manage: str = Form("0"),
    enabled: str = Form("1"), db: Session = Depends(get_db), user: User = Depends(require_permission("admin:tenants")),
):
    company = _company_for_admin(db, user, company_id)
    target = db.get(User, user_id); branch = db.query(Branch).filter(Branch.id == branch_id, Branch.company_id == company.id).first()
    if not target or not branch: raise HTTPException(404, "User or branch not found")
    if not target.is_active: raise HTTPException(422, "Inactive users cannot receive branch access")
    if not branch.is_active: raise HTTPException(422, "Inactive branches cannot receive access")
    if target.role == RoleEnum.admin and target.is_active:
        # Admins are intentionally managed through company-wide access and cannot be removed from an active company here.
        enabled = "1"
    row = db.query(UserCompanyAccess).filter_by(user_id=target.id, company_id=company.id, branch_id=branch.id).first()
    if enabled in {"1", "true", "on"}:
        if not row:
            row = UserCompanyAccess(user_id=target.id, company_id=company.id, branch_id=branch.id, can_manage=can_manage in {"1", "true", "on"}); db.add(row)
            db.flush(); action = "grant"
        else:
            before = {"can_manage": row.can_manage}
            row.can_manage = can_manage in {"1", "true", "on"}
            action = "update"
            _audit(db, user, action, "UserCompanyAccess", row.id, before=before, after={"can_manage": row.can_manage}, company_id=company.id)
    elif row:
        rid = row.id
        before = {"user_id": row.user_id, "company_id": row.company_id, "branch_id": row.branch_id, "can_manage": row.can_manage}
        db.delete(row)
        _audit(db, user, "revoke", "UserCompanyAccess", rid, before=before, after={}, company_id=company.id)
    else:
        return _redirect(company.id)
    if enabled in {"1", "true", "on"} and action == "grant":
        _audit(db, user, "grant", "UserCompanyAccess", row.id, after={"user_id": target.id, "company_id": company.id, "branch_id": branch.id, "can_manage": row.can_manage}, company_id=company.id)
    db.commit(); return _redirect(company.id)
