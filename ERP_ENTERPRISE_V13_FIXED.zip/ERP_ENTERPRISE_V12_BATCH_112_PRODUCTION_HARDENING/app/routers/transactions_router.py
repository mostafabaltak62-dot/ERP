from datetime import datetime
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Header
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from sqlalchemy import func

from ..database import get_db
from ..models import User, SalesOrder, SaleInvoice, PurchaseInvoice
from ..auth import get_current_user
from ..governance import get_request_context, _has_permission
from ..transaction_services import (
    create_sales_order, confirm_sales_order, deliver_sales_order, invoice_sales_delivery,
    create_purchase_invoice, create_customer_receipt, create_supplier_payment,
)

router = APIRouter(prefix="/api/v1/transactions", tags=["Enterprise Transactions"])


def _ctx(user: User):
    ctx = get_request_context()
    company_id = ctx.get("company_id")
    branch_id = ctx.get("branch_id")
    if not company_id:
        raise HTTPException(403, "Tenant context is required")
    return company_id, branch_id


def _permission(db, user, code):
    company_id, branch_id = _ctx(user)
    if not _has_permission(db, user.id, code, company_id, branch_id):
        raise HTTPException(403, f"Missing permission: {code}")
    return company_id


class LineIn(BaseModel):
    item_id: int
    quantity: Decimal = Field(gt=0)
    unit_price: Decimal = Field(ge=0)
    po_line_id: int | None = Field(default=None, gt=0)


class SalesOrderIn(BaseModel):
    customer_id: int
    lines: list[LineIn] = Field(min_length=1)
    payment_method: str = "credit"
    warehouse_id: int | None = None
    notes: str | None = None


class DeliveryIn(BaseModel):
    quantities: dict[str, Decimal] | None = None


class SalesInvoiceIn(BaseModel):
    tax_rate_id: int | None = None
    discount: Decimal = Field(default=Decimal("0"), ge=0)


class PurchaseInvoiceIn(BaseModel):
    supplier_id: int
    lines: list[LineIn] = Field(min_length=1)
    po_id: int | None = None
    tax_rate_id: int | None = None
    discount: Decimal = Field(default=Decimal("0"), ge=0)
    payment_method: str = "credit"
    notes: str | None = None


class PaymentIn(BaseModel):
    amount: Decimal = Field(gt=0)
    account_code: str = "1100"
    payment_date: datetime | None = None


@router.post("/sales-orders", status_code=201)
def sales_order(data: SalesOrderIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    company_id = _permission(db, user, "sales:create")
    try:
        order = create_sales_order(db, company_id, user.id, data.customer_id,
                                   [x.model_dump() for x in data.lines], data.payment_method, data.notes)
        if data.warehouse_id is not None:
            from ..warehouse_models import Warehouse
            wh = db.query(Warehouse).filter(Warehouse.id==data.warehouse_id, Warehouse.company_id==company_id, Warehouse.is_active.is_(True)).first()
            if not wh: raise HTTPException(404, "Warehouse not found")
            order.warehouse_id = wh.id
        db.commit(); db.refresh(order)
        return {"id": order.id, "number": order.order_number, "status": order.status, "total": str(order.total)}
    except Exception:
        db.rollback(); raise


@router.post("/sales-orders/{order_id}/confirm")
def confirm_order(order_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    company_id = _permission(db, user, "sales:post")
    try:
        order = confirm_sales_order(db, order_id, company_id)
        db.commit(); return {"id": order.id, "status": order.status}
    except Exception:
        db.rollback(); raise


@router.post("/sales-orders/{order_id}/deliver")
def deliver_order(order_id: int, data: DeliveryIn | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    company_id = _permission(db, user, "inventory:post")
    try:
        delivery = deliver_sales_order(db, order_id, company_id, user.id, (data.quantities if data else None))
        db.commit(); db.refresh(delivery)
        return {"id": delivery.id, "number": delivery.delivery_number, "status": delivery.status}
    except Exception:
        db.rollback(); raise


@router.post("/sales-deliveries/{delivery_id}/invoice", status_code=201)
def invoice_delivery(delivery_id: int, data: SalesInvoiceIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    company_id = _permission(db, user, "sales:post")
    try:
        invoice = invoice_sales_delivery(db, delivery_id, company_id, user.id, data.tax_rate_id, data.discount)
        db.commit(); db.refresh(invoice)
        return {"id": invoice.id, "number": invoice.invoice_number, "subtotal": str(invoice.subtotal), "tax": str(invoice.tax_amount), "total": str(invoice.total_amount)}
    except Exception:
        db.rollback(); raise


@router.post("/purchase-invoices", status_code=201)
def purchase_invoice(data: PurchaseInvoiceIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    company_id = _permission(db, user, "purchases:post")
    try:
        invoice = create_purchase_invoice(db, company_id, user.id, data.supplier_id,
                                          [x.model_dump() for x in data.lines], data.po_id,
                                          data.tax_rate_id, data.discount, data.payment_method, data.notes)
        db.commit(); db.refresh(invoice)
        return {"id": invoice.id, "number": invoice.invoice_number, "subtotal": str(invoice.subtotal), "tax": str(invoice.tax_amount), "total": str(invoice.total_amount)}
    except Exception:
        db.rollback(); raise


@router.post("/sales-invoices/{invoice_id}/payments", status_code=201)
def customer_payment(invoice_id: int, data: PaymentIn, db: Session = Depends(get_db), user: User = Depends(get_current_user), idempotency_key: str | None = Header(default=None, alias="Idempotency-Key")):
    company_id = _permission(db, user, "sales:post")
    try:
        payment = create_customer_receipt(db, company_id, user.id, invoice_id, data.amount, data.account_code, data.payment_date, idempotency_key)
        db.commit(); db.refresh(payment)
        return {"id": payment.id, "number": payment.voucher_number, "amount": str(payment.amount)}
    except Exception:
        db.rollback(); raise


@router.post("/purchase-invoices/{invoice_id}/payments", status_code=201)
def supplier_payment(invoice_id: int, data: PaymentIn, db: Session = Depends(get_db), user: User = Depends(get_current_user), idempotency_key: str | None = Header(default=None, alias="Idempotency-Key")):
    company_id = _permission(db, user, "purchases:post")
    try:
        payment = create_supplier_payment(db, company_id, user.id, invoice_id, data.amount, data.account_code, data.payment_date, idempotency_key)
        db.commit(); db.refresh(payment)
        return {"id": payment.id, "number": payment.voucher_number, "amount": str(payment.amount)}
    except Exception:
        db.rollback(); raise


@router.get("/sales-invoices/{invoice_id}/balance")
def sales_balance(invoice_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    company_id = _permission(db, user, "sales:view")
    invoice = db.query(SaleInvoice).filter(SaleInvoice.id == invoice_id, SaleInvoice.company_id == company_id).first()
    if not invoice: raise HTTPException(404, "Invoice not found")
    from ..transaction_services import _allocated
    allocated = _allocated(db, "sale", invoice.id, company_id)
    return {"invoice_id": invoice.id, "total": str(invoice.total), "allocated": str(allocated), "outstanding": str(max(Decimal("0"), Decimal(str(invoice.total)) - allocated))}


@router.get("/purchase-invoices/{invoice_id}/balance")
def purchase_balance(invoice_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    company_id = _permission(db, user, "purchases:view")
    invoice = db.query(PurchaseInvoice).filter(PurchaseInvoice.id == invoice_id, PurchaseInvoice.company_id == company_id).first()
    if not invoice: raise HTTPException(404, "Invoice not found")
    from ..transaction_services import _allocated
    allocated = _allocated(db, "purchase", invoice.id, company_id)
    outstanding = max(Decimal("0"), Decimal(str(invoice.total_amount)) - allocated)
    return {"invoice_id": invoice.id, "total": str(invoice.total_amount), "allocated": str(allocated), "outstanding": str(outstanding)}
