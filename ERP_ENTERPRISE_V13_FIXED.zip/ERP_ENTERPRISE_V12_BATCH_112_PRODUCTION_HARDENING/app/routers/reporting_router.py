from datetime import date
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import User
from ..governance import get_tenant_context, require_permission
from ..reporting import trial_balance, general_ledger, pnl, balance_sheet, cash_flow, changes_in_equity, validate_financials, dashboard

router=APIRouter(prefix="/api/v1/reports", tags=["Authoritative Financial Reporting"])

def _dates(from_date: date|None, to_date: date|None):
    if (from_date is None) != (to_date is None): raise HTTPException(422,"from_date and to_date must be supplied together")
    return from_date,to_date

@router.get("/trial-balance")
def report_trial_balance(from_date:date|None=None,to_date:date|None=None,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("reports:view"))):
    from_date,to_date=_dates(from_date,to_date)
    return {"report":"trial_balance","company_id":ctx["company_id"],"from_date":from_date.isoformat() if from_date else None,"to_date":to_date.isoformat() if to_date else None,"rows":trial_balance(db,ctx["company_id"],from_date,to_date)}

@router.get("/general-ledger")
def report_gl(from_date:date,to_date:date,account_id:int|None=None,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("reports:view"))):
    try:
        rows=general_ledger(db,ctx["company_id"],from_date,to_date,account_id)
    except ValueError as exc:
        raise HTTPException(422,str(exc))
    return {"report":"general_ledger","company_id":ctx["company_id"],"rows":rows}

@router.get("/profit-and-loss")
def report_pnl(from_date:date,to_date:date,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("reports:view"))):
    try:
        return pnl(db,ctx["company_id"],from_date,to_date)
    except ValueError as exc:
        raise HTTPException(422,str(exc))

@router.get("/balance-sheet")
def report_bs(as_of_date:date,branch_id:int|None=None,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("reports:view"))):
    if branch_id is not None and ctx.get("branch_id") is not None and branch_id != ctx["branch_id"]:
        raise HTTPException(status_code=403, detail="الفرع خارج نطاق المستخدم")
    return balance_sheet(db,ctx["company_id"],as_of_date,branch_id or ctx.get("branch_id"))

@router.get("/cash-flow")
def report_cash_flow(from_date:date,to_date:date,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("reports:view"))):
    try: return cash_flow(db,ctx["company_id"],from_date,to_date)
    except ValueError as exc: raise HTTPException(422,str(exc))

@router.get("/changes-in-equity")
def report_equity(from_date:date,to_date:date,branch_id:int|None=None,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("reports:view"))):
    if branch_id is not None and ctx.get("branch_id") is not None and branch_id != ctx["branch_id"]:
        raise HTTPException(status_code=403, detail="الفرع خارج نطاق المستخدم")
    try: return changes_in_equity(db,ctx["company_id"],from_date,to_date,branch_id or ctx.get("branch_id"))
    except ValueError as exc: raise HTTPException(422,str(exc))

@router.get("/validation")
def report_validation(from_date:date,to_date:date,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("reports:view"))):
    try: return validate_financials(db,ctx["company_id"],from_date,to_date)
    except ValueError as exc: raise HTTPException(422,str(exc))

@router.get("/executive-dashboard")
def executive_dashboard(from_date:date,to_date:date,ctx=Depends(get_tenant_context),db:Session=Depends(get_db),user:User=Depends(require_permission("reports:view"))):
    try:
        return dashboard(db,ctx["company_id"],from_date,to_date)
    except ValueError as exc:
        raise HTTPException(422,str(exc))
