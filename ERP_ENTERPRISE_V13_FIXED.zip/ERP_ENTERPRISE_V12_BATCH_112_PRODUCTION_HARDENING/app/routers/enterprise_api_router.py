from ..time_utils import utcnow
from datetime import datetime
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Header, Request
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from sqlalchemy import func, select
from ..database import get_db
from ..models import User
from ..auth import verify_password, create_access_token, issue_refresh_token, rotate_refresh_token, revoke_refresh_token
from ..auth import get_current_user, require_module
from ..enterprise_models import Company, Branch, Currency, ExchangeRate, Project, ProjectCost, Notification
from ..enterprise_services import fx_rate, record_project_cost
from ..governance import resolve_tenant, set_request_context, require_permission

router = APIRouter(prefix="/api/v1", tags=["Enterprise ERP"])


class MobileLoginIn(BaseModel):
    username: str = Field(min_length=1, max_length=120)
    password: str = Field(min_length=1, max_length=200)
    company_id: int

@router.post("/mobile/auth/login")
def mobile_login(data: MobileLoginIn, request: Request, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == data.username, User.is_active == True).first()
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(401, "بيانات الدخول غير صحيحة")
    company_id, branch_id = resolve_tenant(db, user, data.company_id, request.headers.get("X-Branch-ID"))
    set_request_context(user_id=user.id, company_id=company_id, branch_id=branch_id)
    refresh_token, refresh_expires = issue_refresh_token(db, user)
    return {"access_token": create_access_token(user), "refresh_token": refresh_token, "token_type": "bearer", "expires_in": 3600, "refresh_expires_at": refresh_expires.isoformat(), "user": {"id": user.id, "username": user.username, "full_name": user.full_name, "role": user.role.value}, "tenant": {"company_id": company_id, "branch_id": branch_id}}


class RefreshIn(BaseModel):
    refresh_token: str = Field(min_length=20, max_length=500)


@router.post("/mobile/auth/refresh")
def mobile_refresh(data: RefreshIn, db: Session = Depends(get_db)):
    result = rotate_refresh_token(db, data.refresh_token)
    if not result:
        raise HTTPException(401, "Refresh token is invalid or expired")
    user, refresh_token, refresh_expires = result
    return {"access_token": create_access_token(user), "refresh_token": refresh_token, "token_type": "bearer", "expires_in": 3600, "refresh_expires_at": refresh_expires.isoformat()}

@router.get("/mobile/bootstrap")
def mobile_bootstrap(request: Request, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    company_id, branch_id = resolve_tenant(db, user, request.headers.get("X-Company-ID"), request.headers.get("X-Branch-ID"))
    set_request_context(user_id=user.id, company_id=company_id, branch_id=branch_id)
    rows = db.query(Notification).filter_by(user_id=user.id).order_by(Notification.created_at.desc()).limit(20).all()
    return {"user": {"id": user.id, "username": user.username, "full_name": user.full_name, "role": user.role.value}, "tenant": {"company_id": company_id, "branch_id": branch_id}, "notifications": [{"id": n.id, "type": n.notification_type, "title": n.title, "message": n.message, "read": n.is_read, "created_at": n.created_at.isoformat()} for n in rows]}

class CompanyIn(BaseModel):
    code: str = Field(min_length=2, max_length=30)
    name: str = Field(min_length=2, max_length=200)
    legal_name: str | None = None
    tax_number: str | None = None
    base_currency_id: int | None = None
class CurrencyIn(BaseModel):
    code: str = Field(min_length=3, max_length=3)
    name: str = Field(min_length=2, max_length=80)
    decimal_places: int = Field(default=2, ge=0, le=6)
class FXIn(BaseModel):
    from_currency_id: int
    to_currency_id: int
    rate: Decimal = Field(gt=0)
    effective_at: datetime
    source: str | None = None
class ProjectIn(BaseModel):
    company_id: int
    branch_id: int | None = None
    code: str = Field(min_length=2, max_length=50)
    name: str = Field(min_length=2, max_length=200)
    customer_id: int | None = None
    budget: Decimal = Field(default=Decimal("0"), ge=0)
class CostIn(BaseModel):
    amount: Decimal = Field(gt=0)
    cost_type: str = Field(min_length=2, max_length=50)
    source_type: str | None = None
    source_id: int | None = None
    description: str | None = None

@router.get("/health")
def health(db: Session = Depends(get_db)):
    db.execute(select(func.count()).select_from(Company))
    return {"status":"ok","service":"erp","timestamp":utcnow().isoformat()}

@router.post("/companies", status_code=201)
def create_company(data: CompanyIn, db: Session = Depends(get_db), user: User = Depends(require_permission("admin:tenants"))):
    row=Company(**data.model_dump()); db.add(row)
    try: db.commit()
    except Exception:
        db.rollback(); raise HTTPException(409,"Company code or tax number already exists")
    db.refresh(row); return {"id":row.id,"code":row.code,"name":row.name}

@router.post("/currencies", status_code=201)
def create_currency(data: CurrencyIn, db: Session = Depends(get_db), user: User = Depends(require_module("accounting", need_edit=True))):
    row=Currency(**data.model_dump()); db.add(row)
    try: db.commit()
    except Exception:
        db.rollback(); raise HTTPException(409,"Currency code already exists")
    db.refresh(row); return {"id":row.id,"code":row.code,"name":row.name}

@router.post("/exchange-rates", status_code=201)
def create_fx(data: FXIn, db: Session = Depends(get_db), user: User = Depends(require_module("accounting", need_edit=True))):
    if data.from_currency_id == data.to_currency_id: raise HTTPException(422,"Currencies must differ")
    row=ExchangeRate(**data.model_dump(), created_by_id=user.id); db.add(row); db.commit(); db.refresh(row)
    return {"id":row.id,"rate":str(row.rate)}

@router.get("/exchange-rates/resolve")
def resolve_fx(from_currency_id:int,to_currency_id:int,at:datetime,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    try: rate=fx_rate(db,from_currency_id,to_currency_id,at)
    except ValueError as e: raise HTTPException(404,str(e))
    return {"rate":str(rate)}

@router.post("/projects", status_code=201)
def create_project(data:ProjectIn,db:Session=Depends(get_db),user:User=Depends(require_module("accounting",need_edit=True))):
    row=Project(**data.model_dump()); db.add(row)
    try: db.commit()
    except Exception:
        db.rollback(); raise HTTPException(409,"Project code already exists for this company")
    db.refresh(row); return {"id":row.id,"code":row.code,"name":row.name}

@router.post("/projects/{project_id}/costs", status_code=201)
def add_project_cost(project_id:int,data:CostIn,db:Session=Depends(get_db),user:User=Depends(require_module("accounting",need_edit=True))):
    project=db.query(Project).filter_by(id=project_id).first()
    if not project: raise HTTPException(404,"Project not found")
    row=record_project_cost(db,ctx['company_id'],project_id,data.amount,data.cost_type,data.source_type,data.source_id,data.description); db.commit()
    return {"id":row.id,"project_id":project_id,"amount":str(row.amount)}

@router.get("/projects/{project_id}/profitability")
def project_profitability(project_id:int,db:Session=Depends(get_db),user:User=Depends(require_module("reports"))):
    project=db.query(Project).filter_by(id=project_id).first()
    if not project: raise HTTPException(404,"Project not found")
    cost=db.query(func.coalesce(func.sum(ProjectCost.amount),0)).filter(ProjectCost.project_id==project_id).scalar() or 0
    budget=Decimal(str(project.budget or 0)); actual=Decimal(str(cost)); return {"project_id":project_id,"budget":str(budget),"actual_cost":str(actual),"remaining_budget":str(budget-actual),"cost_variance":str(actual-budget)}


@router.get("/mobile/dashboard")
def mobile_dashboard(request: Request, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    company_id, branch_id = resolve_tenant(db, user, request.headers.get("X-Company-ID"), request.headers.get("X-Branch-ID"))
    set_request_context(user_id=user.id, company_id=company_id, branch_id=branch_id)
    projects = db.query(Project).filter(Project.company_id == company_id).order_by(Project.id.desc()).limit(20).all()
    total_budget = sum((Decimal(str(p.budget or 0)) for p in projects), Decimal("0"))
    project_ids = [p.id for p in projects]
    actual = Decimal("0")
    if project_ids:
        actual = Decimal(str(db.query(func.coalesce(func.sum(ProjectCost.amount), 0)).filter(ProjectCost.company_id == company_id, ProjectCost.project_id.in_(project_ids)).scalar() or 0))
    unread = db.query(Notification).filter(Notification.user_id == user.id, Notification.is_read == False).count()
    return {"company_id": company_id, "branch_id": branch_id, "projects": [{"id": p.id, "code": p.code, "name": p.name, "budget": str(p.budget or 0)} for p in projects], "summary": {"project_count": len(projects), "budget": str(total_budget), "actual_cost": str(actual), "remaining_budget": str(total_budget - actual), "unread_notifications": unread}}

@router.get("/notifications")
def notifications(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    rows=db.query(Notification).filter_by(user_id=user.id).order_by(Notification.created_at.desc()).limit(100).all()
    return [{"id":n.id,"type":n.notification_type,"title":n.title,"message":n.message,"read":n.is_read,"created_at":n.created_at.isoformat()} for n in rows]
