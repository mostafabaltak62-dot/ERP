# -*- coding: utf-8 -*-
import logging
logger = logging.getLogger(__name__)
from fastapi import APIRouter, Depends, Form, HTTPException, Request, status
import os
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import User, RoleEnum, ModulePermission, MODULES
from ..auth import hash_password, validate_password_policy, get_current_user, revoke_user_access_tokens
from ..governance import require_permission, _has_permission
from ..governance_models import Role, UserRole
from ..role_catalog import ROLE_CATALOG, ROLE_BY_CODE
from ..account_security import PasswordResetRequest, create_reset_request, send_otp, verify_otp
from ..time_utils import utcnow

router = APIRouter(tags=['Administrative Security'])
templates = Jinja2Templates(directory='templates')


def _dual_approval_ready(db, row):
    return bool(row.admin_approved_by and row.senior_approved_by and row.verified_at and not row.revoked_at and row.expires_at > utcnow())

@router.get('/admin/accounts', response_class=HTMLResponse)
def admin_accounts(request: Request, db: Session = Depends(get_db), user: User = Depends(require_permission('admin:users'))):
    users = db.query(User).order_by(User.id).all()
    pending = db.query(PasswordResetRequest).filter(PasswordResetRequest.completed_at.is_(None), PasswordResetRequest.revoked_at.is_(None), PasswordResetRequest.expires_at > utcnow()).order_by(PasswordResetRequest.id.desc()).all()
    perms_by_user = {u.id: {p.module_key: p for p in u.permissions} for u in users}
    return templates.TemplateResponse(request, 'admin_accounts.html', {'user': user, 'all_users': users, 'roles': list(RoleEnum), 'pending_resets': pending, 'perms_by_user': perms_by_user, 'modules': MODULES, 'now': utcnow()})

def _require_platform_admin(user):
    if user.role != RoleEnum.admin:
        raise HTTPException(403, 'إدارة دورة حياة الحسابات محصورة بمدير النظام')


def _validate_manager(db, manager_user_id, target_id=None):
    if manager_user_id is None:
        return None
    if target_id is not None and manager_user_id == target_id:
        raise HTTPException(422, 'A user cannot manage themselves')
    manager = db.get(User, manager_user_id)
    if not manager or not manager.is_active:
        raise HTTPException(422, 'المدير المحدد غير موجود أو غير نشط')
    return manager


def _ensure_admin_survival(db, target, new_role=None, new_active=None):
    role = new_role if new_role is not None else target.role
    active = new_active if new_active is not None else target.is_active
    if target.role == RoleEnum.admin and target.is_active and (role != RoleEnum.admin or not active):
        others = (db.query(User).filter(User.role == RoleEnum.admin, User.is_active.is_(True), User.id != target.id).count())
        if others < 1:
            raise HTTPException(422, 'لا يمكن إزالة آخر مدير نظام نشط')


@router.post('/admin/accounts/create')
def admin_create(username: str = Form(...), full_name: str = Form(...), employee_code: str = Form(''), job_title: str = Form(''), department: str = Form(''), manager_user_id: int | None = Form(None), email: str = Form(''), phone: str = Form(''), password: str = Form(...), role: str = Form('employee'), db: Session = Depends(get_db), user: User = Depends(require_permission('admin:users'))):
    _require_platform_admin(user)
    username = username.strip(); full_name = full_name.strip(); employee_code = employee_code.strip(); job_title = job_title.strip(); department = department.strip(); email = email.strip() or None; phone = phone.strip() or None
    if not username or not full_name: raise HTTPException(422, 'اسم المستخدم والاسم الكامل مطلوبان')
    _validate_manager(db, manager_user_id)
    if db.query(User).filter(User.username == username).first(): raise HTTPException(409, 'Username already exists')
    if employee_code.strip() and db.query(User).filter(User.employee_code == employee_code.strip()).first(): raise HTTPException(409, 'Employee code already exists')
    if email and db.query(User).filter(User.email == email).first(): raise HTTPException(409, 'Email already exists')
    if phone and db.query(User).filter(User.phone == phone).first(): raise HTTPException(409, 'Phone already exists')
    try: validate_password_policy(password); role_enum = RoleEnum(role)
    except (ValueError, TypeError): raise HTTPException(422, 'Invalid password or role')
    if role_enum == RoleEnum.admin and user.role != RoleEnum.admin: raise HTTPException(403, 'لا يمكن إنشاء مدير نظام من حساب غير إداري')
    db.add(User(username=username, full_name=full_name, employee_code=employee_code or None, job_title=job_title or None, department=department or None, manager_user_id=manager_user_id, email=email, phone=phone, password_hash=hash_password(password), role=role_enum, is_active=True)); db.commit()
    return RedirectResponse('/admin/accounts', status_code=303)

@router.post('/admin/accounts/{target_id}/update')
def admin_update(target_id: int, full_name: str = Form(...), employee_code: str = Form(''), job_title: str = Form(''), department: str = Form(''), manager_user_id: int | None = Form(None), email: str = Form(''), phone: str = Form(''), role: str = Form(...), password: str = Form(''), db: Session = Depends(get_db), user: User = Depends(require_permission('admin:users'))):
    _require_platform_admin(user)
    target = db.get(User, target_id)
    if not target: raise HTTPException(404, 'User not found')
    try: new_role = RoleEnum(role)
    except ValueError: raise HTTPException(422, 'Invalid role')
    if target.id == user.id: raise HTTPException(422, 'لا يمكن تعديل حساب مدير النظام الحالي من هذه العملية')
    if not full_name.strip(): raise HTTPException(422, 'الاسم الكامل مطلوب')
    if password: validate_password_policy(password); target.password_hash = hash_password(password)
    employee_code = employee_code.strip(); email = email.strip() or None; phone = phone.strip() or None
    if employee_code and db.query(User).filter(User.employee_code == employee_code, User.id != target_id).first(): raise HTTPException(409, 'Employee code already exists')
    if email and db.query(User).filter(User.email == email, User.id != target_id).first(): raise HTTPException(409, 'Email already exists')
    if phone and db.query(User).filter(User.phone == phone, User.id != target_id).first(): raise HTTPException(409, 'Phone already exists')
    _validate_manager(db, manager_user_id, target_id)
    _ensure_admin_survival(db, target, new_role=new_role)
    if new_role == RoleEnum.admin and target.role != RoleEnum.admin and user.role != RoleEnum.admin: raise HTTPException(403, 'ترقية الحساب إلى مدير نظام تتطلب مدير النظام')
    target.full_name = full_name.strip(); target.employee_code = employee_code or None; target.job_title = job_title.strip() or None; target.department = department.strip() or None; target.manager_user_id = manager_user_id; target.email = email; target.phone = phone; target.role = new_role
    db.commit(); revoke_user_access_tokens(target.id); return RedirectResponse('/admin/accounts', status_code=303)

@router.post('/admin/accounts/{target_id}/toggle')
def admin_toggle(target_id: int, db: Session = Depends(get_db), user: User = Depends(require_permission('admin:users'))):
    _require_platform_admin(user)
    target = db.get(User, target_id)
    if not target: raise HTTPException(404, 'User not found')
    if target.id == user.id: raise HTTPException(422, 'You cannot disable your own account')
    if target.is_active: _ensure_admin_survival(db, target, new_active=False)
    target.is_active = not target.is_active; db.commit(); revoke_user_access_tokens(target.id); return RedirectResponse('/admin/accounts', status_code=303)

@router.post('/admin/accounts/{target_id}/delete')
def admin_delete(target_id: int, db: Session = Depends(get_db), user: User = Depends(require_permission('admin:users'))):
    _require_platform_admin(user)
    target = db.get(User, target_id)
    if not target: raise HTTPException(404, 'User not found')
    if target.id == user.id: raise HTTPException(422, 'You cannot delete your own account')
    # Accounts are security/audit principals and must never be hard-deleted.
    # Retain the identity for audit history and revoke all access instead.
    if target.is_active: _ensure_admin_survival(db, target, new_active=False)
    target.is_active = False
    db.commit(); revoke_user_access_tokens(target.id); return RedirectResponse('/admin/accounts', status_code=303)

@router.post('/admin/password-resets/{reset_id}/approve')
def approve_reset(reset_id: int, kind: str = Form(...), db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    row = db.get(PasswordResetRequest, reset_id)
    if not row or row.expires_at <= utcnow() or row.revoked_at or row.completed_at: raise HTTPException(404, 'Reset request not found or expired')
    if kind == 'admin':
        if user.role != RoleEnum.admin or not user.is_active: raise HTTPException(403, 'Administrator approval required')
        if row.admin_approved_by: raise HTTPException(409, 'Already approved')
        row.admin_approved_by = user.id; row.admin_approved_at = utcnow()
    elif kind == 'senior':
        if not user.is_active or not _has_permission(db, user.id, 'admin:password_reset_approve'): raise HTTPException(403, 'Senior management approval required')
        if user.id == row.admin_approved_by: raise HTTPException(403, 'Two-person approval is required')
        if row.senior_approved_by: raise HTTPException(409, 'Already approved')
        row.senior_approved_by = user.id; row.senior_approved_at = utcnow()
    else: raise HTTPException(422, 'Invalid approval type')
    db.commit(); return RedirectResponse('/admin/accounts', status_code=303)

def _role_level(role_code: str) -> int:
    return int(ROLE_BY_CODE.get(role_code, {}).get("level", -1))


def _can_manage_role_scope(db, actor, company_id: int | None, branch_id: int | None) -> bool:
    # Global role assignments can alter access across the whole installation and
    # are therefore reserved for the platform administrator.
    if company_id is None and branch_id is None:
        return actor.role == RoleEnum.admin
    if actor.role == RoleEnum.admin:
        return True
    from ..enterprise_models import UserCompanyAccess
    q = db.query(UserCompanyAccess).filter(
        UserCompanyAccess.user_id == actor.id,
        UserCompanyAccess.company_id == company_id,
        UserCompanyAccess.can_manage.is_(True),
    )
    if branch_id is not None:
        q = q.filter((UserCompanyAccess.branch_id == branch_id) | (UserCompanyAccess.branch_id.is_(None)))
    else:
        # A branch-only manager must not be able to grant company-wide access.
        q = q.filter(UserCompanyAccess.branch_id.is_(None))
    return q.first() is not None


def _assert_role_assignment_allowed(db, actor, spec, company_id, branch_id):
    if not _can_manage_role_scope(db, actor, company_id, branch_id):
        raise HTTPException(403, 'ليس لديك صلاحية إدارة الأدوار في هذا النطاق')
    # Segregation of duties: a non-platform administrator cannot grant a role
    # at or above their own role level.
    if actor.role != RoleEnum.admin:
        # Segregation of duties: use the highest active governed role actually
        # assigned to the actor; legacy User.role values are not trusted as a
        # job hierarchy.
        held = (db.query(Role.code)
                .join(UserRole, UserRole.role_id == Role.id)
                .filter(UserRole.user_id == actor.id, UserRole.is_active.is_(True), Role.is_active.is_(True)).all())
        actor_level = max((_role_level(code) for (code,) in held), default=-1)
        if actor_level < 0 or _role_level(spec["code"]) >= actor_level:
            raise HTTPException(403, 'لا يمكن منح دور مساويًا أو أعلى من دورك')


@router.get('/admin/roles', response_class=HTMLResponse)
def admin_roles(request: Request, db: Session = Depends(get_db), user: User = Depends(require_permission('admin:permissions'))):
    roles = db.query(Role).filter(Role.is_active.is_(True)).order_by(Role.code).all()
    assignments_q = (db.query(UserRole, User, Role)
                   .join(User, User.id == UserRole.user_id)
                   .join(Role, Role.id == UserRole.role_id)
                   .filter(UserRole.is_active.is_(True), Role.is_active.is_(True)))
    if user.role != RoleEnum.admin:
        from ..enterprise_models import UserCompanyAccess
        managed = db.query(UserCompanyAccess.company_id, UserCompanyAccess.branch_id).filter(
            UserCompanyAccess.user_id == user.id, UserCompanyAccess.can_manage.is_(True)).all()
        if managed:
            from sqlalchemy import or_, and_
            predicates = []
            for cid, bid in managed:
                predicates.append(and_(UserRole.company_id == cid, or_(UserRole.branch_id == bid, UserRole.branch_id.is_(None))))
            assignments_q = assignments_q.filter(or_(*predicates))
        else:
            assignments_q = assignments_q.filter(False)
    assignments = assignments_q.order_by(User.full_name, Role.id).all()
    return templates.TemplateResponse(request, 'admin_roles.html', {
        'user': user, 'catalog': ROLE_CATALOG, 'roles': roles,
        'users': db.query(User).filter(User.is_active.is_(True)).order_by(User.full_name).all(),
        'assignments': assignments,
    })

@router.post('/admin/roles/assign')
def admin_assign_role(target_user_id: int = Form(...), role_code: str = Form(...), company_id: int | None = Form(None), branch_id: int | None = Form(None), db: Session = Depends(get_db), user: User = Depends(require_permission('admin:role_assign'))):
    from ..enterprise_models import Company, Branch
    spec = ROLE_BY_CODE.get(role_code)
    target = db.get(User, target_user_id)
    if not spec or not target or not target.is_active:
        raise HTTPException(404, 'المستخدم أو الدور غير موجود')
    if company_id is not None:
        company = db.get(Company, company_id)
        if not company or not company.is_active: raise HTTPException(422, 'الشركة غير صالحة')
    if branch_id is not None:
        branch = db.get(Branch, branch_id)
        if not branch or not branch.is_active or (company_id is not None and branch.company_id != company_id):
            raise HTTPException(422, 'الفرع لا يتبع الشركة المحددة')
        company_id = branch.company_id
    if company_id is None and branch_id is not None:
        raise HTTPException(422, 'الفرع يتطلب شركة')
    _assert_role_assignment_allowed(db, user, spec, company_id, branch_id)
    role = db.query(Role).filter(Role.code == role_code, Role.is_active.is_(True)).first()
    if not role:
        raise HTTPException(409, 'الدور غير مهيأ بعد')
    exists = db.query(UserRole).filter_by(user_id=target.id, role_id=role.id, company_id=company_id, branch_id=branch_id).first()
    if not exists:
        db.add(UserRole(user_id=target.id, role_id=role.id, company_id=company_id, branch_id=branch_id, is_active=True)); db.commit()
    from ..auth import revoke_user_access_tokens
    revoke_user_access_tokens(target.id)
    return RedirectResponse('/admin/roles', status_code=303)

@router.post('/admin/roles/{user_role_id}/revoke')
def admin_revoke_role(user_role_id: int, db: Session = Depends(get_db), user: User = Depends(require_permission('admin:role_assign'))):
    row = db.get(UserRole, user_role_id)
    if not row: raise HTTPException(404, 'Role assignment not found')
    role = db.get(Role, row.role_id)
    if not role or not role.is_active:
        raise HTTPException(409, 'الدور غير نشط')
    if not _can_manage_role_scope(db, user, row.company_id, row.branch_id):
        raise HTTPException(403, 'ليس لديك صلاحية إدارة هذا النطاق')
    if row.user_id == user.id and row.role_id:
        # Prevent an administrator from accidentally removing their own final governed role.
        active_other = db.query(UserRole).filter(UserRole.user_id == user.id, UserRole.is_active.is_(True), UserRole.id != row.id).count()
        if active_other == 0 and user.role == RoleEnum.admin: raise HTTPException(422, 'لا يمكن إزالة آخر دور أمني للحساب الحالي')
    row.is_active = False; db.commit()
    from ..auth import revoke_user_access_tokens
    revoke_user_access_tokens(row.user_id)
    return RedirectResponse('/admin/roles', status_code=303)

@router.get('/forgot-password', response_class=HTMLResponse)
def forgot_password(request: Request, token: str = '', error: str = ''):
    # Reset tokens are stored in a short-lived HttpOnly cookie rather than the
    # URL. This avoids browser history, proxy-log and Referer leakage.
    effective_token = token or request.cookies.get("erp_reset_token", "")
    return templates.TemplateResponse(request, 'forgot_password.html', {'token': effective_token, 'error': error})

@router.post('/forgot-password/request')
def request_reset(request: Request, username: str = Form(...), channel: str = Form(...), db: Session = Depends(get_db)):
    # Deliberately generic response to prevent account enumeration.
    user = db.query(User).filter(User.username == username.strip(), User.is_active.is_(True)).first()
    if user:
        try:
            row, token, otp = create_reset_request(db, user, channel)
            send_otp(row.delivery_channel, row.delivery_target, otp)
            response = RedirectResponse('/forgot-password', status_code=303)
            response.set_cookie('erp_reset_token', token, httponly=True, secure=os.getenv('ERP_ENV', 'development').lower() == 'production', samesite='strict', max_age=900, path='/forgot-password')
            return response
        except Exception:
            # Keep the public response generic to prevent account enumeration,
            # but never silently discard operational failures.
            logger.exception("Password-reset notification delivery failed")
    return RedirectResponse('/forgot-password?error=إذا كانت البيانات صحيحة فسيتم إرسال رمز التحقق إلى وسيلة الاسترداد المسجلة.', status_code=303)

@router.post('/forgot-password/verify')
def verify_reset(request: Request, token: str = Form(""), otp: str = Form(...), db: Session = Depends(get_db)):
    token = token or request.cookies.get("erp_reset_token", "")
    row = db.query(PasswordResetRequest).filter(PasswordResetRequest.request_token_hash == __import__('hashlib').sha256(token.encode()).hexdigest()).with_for_update().first()
    if not row or not verify_otp(row, otp):
        db.commit(); return RedirectResponse('/forgot-password?error=رمز التحقق غير صحيح أو منتهي.', status_code=303)
    db.commit(); return RedirectResponse('/forgot-password?verified=1', status_code=303)

@router.post('/forgot-password/complete')
def complete_reset(request: Request, token: str = Form(""), new_password: str = Form(...), db: Session = Depends(get_db)):
    import hashlib
    token = token or request.cookies.get("erp_reset_token", "")
    row = db.query(PasswordResetRequest).filter(PasswordResetRequest.request_token_hash == hashlib.sha256(token.encode()).hexdigest()).with_for_update().first()
    if not row or not _dual_approval_ready(db, row): raise HTTPException(403, 'Password reset requires OTP verification and both approvals')
    validate_password_policy(new_password)
    target = db.get(User, row.user_id)
    if not target: raise HTTPException(404, 'User not found')
    target.password_hash = hash_password(new_password); row.completed_at = utcnow(); db.commit(); revoke_user_access_tokens(target.id)
    response = RedirectResponse('/login?error=تم تحديث كلمة المرور بنجاح، يمكنك تسجيل الدخول الآن.', status_code=303)
    response.delete_cookie('erp_reset_token', path='/forgot-password')
    return response
