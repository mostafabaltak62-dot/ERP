from decimal import Decimal
from datetime import date as _date, datetime as _datetime
from fastapi import APIRouter, Depends, Request, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import func, and_
from sqlalchemy.orm import Session
from ..database import get_db
from ..auth import User
from ..governance import get_tenant_context, require_permission, scope_allows
from ..enterprise_models import Project, ProjectCost
from ..construction_models import (ConstructionActivity, ConstructionScheduleBaseline, ConstructionProgressPeriod,
    ConstructionActivityProgress, ConstructionActivityBaseline, ConstructionActivityDependency, ConstructionCostBudgetLine, ConstructionCommitment, ConstructionCostForecast, ConstructionEVMSnapshot,
    ConstructionCostCode, WBSNode, ConstructionScheduleDelayEvent, ConstructionScheduleResource, ConstructionTimeImpactAnalysis, ConstructionScheduleUpdatePeriod, ConstructionRecoveryPlan, ConstructionRecoveryScheduleLink, ConstructionEOTClaim, ConstructionScheduleUpdateLine, ConstructionCostControlSnapshot)

router = APIRouter(prefix='/planning-costs', tags=['planning-costs-ui'])
templates = Jinja2Templates(directory='templates')

def visible_projects(db, company_id, user_id, branch_id=None):
    q=db.query(Project).filter(Project.company_id==company_id)
    if branch_id is not None: q=q.filter((Project.branch_id==branch_id)|(Project.branch_id.is_(None)))
    return [p for p in q.order_by(Project.id.desc()).all() if scope_allows(db,user_id,company_id=company_id,branch_id=p.branch_id,project_id=p.id)]

def selected_project(db, company_id, user_id, projects, project_id):
    if project_id is None: return None
    p=next((x for x in projects if x.id==project_id),None)
    if not p: raise HTTPException(403,'Project access denied')
    return p

@router.get('/planning', response_class=HTMLResponse)
def planning_page(request:Request, project_id:int|None=None, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:view'))):
    projects=visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')); p=selected_project(db,ctx['company_id'],user.id,projects,project_id)
    activities=[]; baselines=[]; periods=[]; evm=None
    if p:
        activities=db.query(ConstructionActivity).filter_by(company_id=ctx['company_id'],project_id=p.id).order_by(ConstructionActivity.planned_start,ConstructionActivity.code).all()
        baselines=db.query(ConstructionScheduleBaseline).filter_by(company_id=ctx['company_id'],project_id=p.id).order_by(ConstructionScheduleBaseline.baseline_no.desc()).all()
        periods=db.query(ConstructionProgressPeriod).filter_by(company_id=ctx['company_id'],project_id=p.id).order_by(ConstructionProgressPeriod.status_date.desc()).limit(12).all()
        evm=db.query(ConstructionEVMSnapshot).filter_by(company_id=ctx['company_id'],project_id=p.id).order_by(ConstructionEVMSnapshot.status_date.desc()).first()
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,p.id) if p else {'user':user,'projects':projects,'project':p,'activities':activities,'baselines':baselines,'periods':periods,'evm':evm,'wbs':[],'section':'planning'})

@router.get('/costs', response_class=HTMLResponse)
def costs_page(request:Request, project_id:int|None=None, date_from:_date|None=None, date_to:_date|None=None, category:str|None=None, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:view'))):
    projects=visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')); p=selected_project(db,ctx['company_id'],user.id,projects,project_id)
    if not p:
        return templates.TemplateResponse(request,'costs_dashboard.html',{'user':user,'projects':projects,'project':None,'rows':[],'totals':_zero_cost_totals(),'codes':[],'wbs':[],'section':'costs','filters':{'date_from':date_from,'date_to':date_to,'category':category or ''},'categories':[],'actual_details':[],'alerts':[],'cost_health':None})
    return templates.TemplateResponse(request,'costs_dashboard.html',_costs_context(db,ctx,user,p.id,date_from=date_from,date_to=date_to,category=category))

@router.get('/costs/drilldown', response_class=HTMLResponse)
def costs_drilldown(request:Request, project_id:int, category:str|None=None, date_from:_date|None=None, date_to:_date|None=None, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:view'))):
    context=_costs_context(db,ctx,user,project_id,date_from=date_from,date_to=date_to,category=category)
    return templates.TemplateResponse(request,'costs_drilldown.html',context)


# Phase 8.0 — dedicated planning/cost-control workspaces (server-rendered actions)
from ..construction_services import create_activity as _create_activity, create_schedule_baseline as _create_baseline, create_cost_budget_line as _create_budget, create_commitment as _create_commitment, create_activity_dependency as _create_dependency, calculate_schedule as _calculate_schedule, schedule_baseline_variance as _baseline_variance, create_delay_event as _create_delay, approve_delay_event as _approve_delay, add_schedule_resource as _add_resource, create_time_impact_analysis as _create_tia, approve_time_impact_analysis as _approve_tia, calculate_schedule_health as _schedule_health, create_schedule_update_period as _create_update_period, approve_schedule_update_period as _approve_update_period, lock_schedule_update_period as _lock_update_period, add_resource_period as _add_resource_period, resource_histogram as _resource_histogram, link_recovery_activity as _link_recovery_activity, submit_eot_claim as _submit_eot_claim, approve_eot_claim as _approve_eot_claim, create_schedule_update_line as _create_schedule_update_line, resource_curves as _resource_curves, create_cost_control_snapshot as _create_cost_snapshot, approve_cost_control_snapshot as _approve_cost_snapshot, construction_cost_control_health as _cost_control_health

@router.post('/planning/activities', response_class=HTMLResponse)
def planning_activity_form(request: Request, project_id:int, code:str, name:str, planned_start:_date, planned_finish:_date, budget_amount:Decimal=Decimal('0'), wbs_id:int|None=None, status:str='planned', db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        selected_project(db,ctx['company_id'],user.id,visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')),project_id)
        r=_create_activity(db, ctx['company_id'], project_id, code.strip(), name.strip(), planned_start, planned_finish, budget_amount, wbs_id=wbs_id)
        if status in {'planned','in_progress','completed','on_hold'}: r.status=status
        db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400, str(e))
    return templates.TemplateResponse(request, 'planning_dashboard.html', _planning_context(db, ctx, user, project_id))

@router.post('/planning/wbs', response_class=HTMLResponse)
def planning_wbs_form(request: Request, project_id:int, code:str, name:str, budget_amount:Decimal=Decimal('0'), parent_id:int|None=None, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        selected_project(db,ctx['company_id'],user.id,visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')),project_id)
        if budget_amount < 0: raise ValueError('Budget must be non-negative')
        parent=None
        if parent_id:
            parent=db.query(WBSNode).filter_by(id=parent_id,company_id=ctx['company_id'],project_id=project_id,is_active=True).one_or_none()
            if not parent: raise ValueError('Parent WBS not found')
        exists=db.query(WBSNode).filter_by(company_id=ctx['company_id'],project_id=project_id,code=code.strip()).first()
        if exists: raise ValueError('WBS code already exists in this project')
        row=WBSNode(company_id=ctx['company_id'],project_id=project_id,parent_id=parent_id,code=code.strip(),name=name.strip(),level=(parent.level+1 if parent else 1),budget_amount=budget_amount,is_active=True)
        db.add(row); db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/planning/activities/{activity_id}/status', response_class=HTMLResponse)
def planning_activity_status(request:Request, activity_id:int, project_id:int, status:str, progress_percent:Decimal|None=None, actual_start:_date|None=None, actual_finish:_date|None=None, status_date:_date|None=None, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        selected_project(db,ctx['company_id'],user.id,visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')),project_id)
        if status not in {'planned','in_progress','completed','on_hold'}: raise ValueError('Invalid activity status')
        a=db.query(ConstructionActivity).filter_by(id=activity_id,company_id=ctx['company_id'],project_id=project_id).one_or_none()
        if not a: raise ValueError('Activity not found')
        a.status=status
        if actual_start is not None: a.actual_start=actual_start
        if actual_finish is not None: a.actual_finish=actual_finish
        if a.actual_start and a.actual_finish and a.actual_finish < a.actual_start: raise ValueError('Actual finish cannot precede actual start')
        if status=='completed' and progress_percent is not None and progress_percent != 100: raise ValueError('Completed activity must have 100% progress')
        if status!='completed' and progress_percent is not None and progress_percent == 100: raise ValueError('100% progress requires completed status')
        if progress_percent is not None:
            if progress_percent < 0 or progress_percent > 100: raise ValueError('Progress must be between 0 and 100')
            period=db.query(ConstructionProgressPeriod).filter_by(company_id=ctx['company_id'],project_id=project_id,status_date=(status_date or _date.today())).one_or_none()
            if not period:
                period=ConstructionProgressPeriod(company_id=ctx['company_id'],project_id=project_id,status_date=(status_date or _date.today()),status='open'); db.add(period); db.flush()
            row=db.query(ConstructionActivityProgress).filter_by(company_id=ctx['company_id'],period_id=period.id,activity_id=a.id).one_or_none()
            ev=Decimal(str(a.budget_amount))*progress_percent/Decimal('100')
            if row: row.earned_percent=progress_percent; row.earned_value=ev
            else: db.add(ConstructionActivityProgress(company_id=ctx['company_id'],period_id=period.id,activity_id=a.id,earned_percent=progress_percent,earned_value=ev))
        db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/planning/dependencies', response_class=HTMLResponse)
def planning_dependency_form(request: Request, project_id:int, predecessor_id:int, successor_id:int, dependency_type:str='FS', lag_days:int=0, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        selected_project(db,ctx['company_id'],user.id,visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')),project_id)
        _create_dependency(db,ctx['company_id'],project_id,predecessor_id,successor_id,dependency_type,lag_days)
        db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/planning/delay-events', response_class=HTMLResponse)
def planning_delay_event(request:Request, project_id:int, event_no:str, event_date:_date, cause:str, description:str, claimed_days:int=0, excusable:bool=False, compensable:bool=False, activity_id:int|None=None, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        selected_project(db,ctx['company_id'],user.id,visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')),project_id)
        _create_delay(db,ctx['company_id'],project_id,event_no,event_date,cause,description,claimed_days,excusable,compensable,activity_id,user.id); db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/planning/delay-events/{event_id}/approve', response_class=HTMLResponse)
def planning_delay_approve(request:Request, event_id:int, project_id:int, approved_days:int, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        _approve_delay(db,ctx['company_id'],event_id,approved_days); db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/planning/time-impact', response_class=HTMLResponse)
def planning_time_impact(request:Request, project_id:int, delay_event_id:int, status_date:_date|None=None, notes:str|None=None, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        selected_project(db,ctx['company_id'],user.id,visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')),project_id)
        _create_tia(db,ctx['company_id'],project_id,delay_event_id,status_date=status_date,user_id=user.id,notes=notes); db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/planning/time-impact/{analysis_id}/approve', response_class=HTMLResponse)
def planning_time_impact_approve(request:Request, analysis_id:int, project_id:int, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        selected_project(db,ctx['company_id'],user.id,visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')),project_id)
        row=db.query(ConstructionTimeImpactAnalysis).filter_by(id=analysis_id,company_id=ctx['company_id'],project_id=project_id).one_or_none()
        if not row: raise ValueError('Time impact analysis not found')
        _approve_tia(db,ctx['company_id'],analysis_id,user.id); db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/planning/update-periods', response_class=HTMLResponse)
def planning_update_period(request:Request, project_id:int, status_date:_date, baseline_id:int|None=None, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        selected_project(db,ctx['company_id'],user.id,visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')),project_id)
        _create_update_period(db,ctx['company_id'],project_id,status_date,baseline_id); db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/planning/update-periods/{period_id}/approve', response_class=HTMLResponse)
def planning_update_period_approve(request:Request, period_id:int, project_id:int, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        _lock_candidate=db.query(ConstructionScheduleUpdatePeriod, ConstructionRecoveryPlan, ConstructionRecoveryScheduleLink, ConstructionEOTClaim, ConstructionScheduleUpdateLine).filter_by(id=period_id,company_id=ctx['company_id'],project_id=project_id).one_or_none()
        if not _lock_candidate: raise ValueError('Schedule update period not found')
        _approve_update_period(db,ctx['company_id'],period_id,user.id); db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/planning/update-periods/{period_id}/lock', response_class=HTMLResponse)
def planning_update_period_lock(request:Request, period_id:int, project_id:int, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:approve'))):
    try:
        _lock_update_period(db,ctx['company_id'],period_id,user.id); db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/planning/resource-periods', response_class=HTMLResponse)
def planning_resource_period(request:Request, project_id:int, resource_id:int, period_date:_date, planned_units:Decimal, actual_units:Decimal=Decimal('0'), db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        selected_project(db,ctx['company_id'],user.id,visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')),project_id)
        _add_resource_period(db,ctx['company_id'],project_id,resource_id,period_date,planned_units,actual_units); db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/planning/recovery-links', response_class=HTMLResponse)
def planning_recovery_link(request:Request, project_id:int, recovery_plan_id:int, activity_id:int, target_start:_date|None=None, target_finish:_date|None=None, target_progress:Decimal=Decimal('100'), acceleration_factor:Decimal=Decimal('1'), notes:str|None=None, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        selected_project(db,ctx['company_id'],user.id,visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')),project_id)
        _link_recovery_activity(db,ctx['company_id'],project_id,recovery_plan_id,activity_id,target_start,target_finish,target_progress,acceleration_factor,notes); db.commit()
    except Exception as e: db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/planning/eot-claims/{claim_id}/submit', response_class=HTMLResponse)
def planning_eot_submit(request:Request, claim_id:int, project_id:int, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try: _submit_eot_claim(db,ctx['company_id'],claim_id,user.id); db.commit()
    except Exception as e: db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/planning/eot-claims/{claim_id}/approve', response_class=HTMLResponse)
def planning_eot_approve(request:Request, claim_id:int, project_id:int, approved_days:int, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:approve'))):
    try: _approve_eot_claim(db,ctx['company_id'],claim_id,approved_days,user.id); db.commit()
    except Exception as e: db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/planning/update-lines', response_class=HTMLResponse)
def planning_update_line(request:Request, project_id:int, period_id:int, activity_id:int, actual_start:_date|None=None, actual_finish:_date|None=None, progress_percent:Decimal=Decimal('0'), db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try: _create_schedule_update_line(db,ctx['company_id'],project_id,period_id,activity_id,actual_start,actual_finish,progress_percent); db.commit()
    except Exception as e: db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/planning/resources', response_class=HTMLResponse)
def planning_resource(request:Request, project_id:int, activity_id:int, resource_type:str, resource_name:str, planned_units:Decimal, actual_units:Decimal=Decimal('0'), unit_cost:Decimal=Decimal('0'), db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        _add_resource(db,ctx['company_id'],project_id,activity_id,resource_type,resource_name,planned_units,actual_units,unit_cost); db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/planning/baselines', response_class=HTMLResponse)
def planning_baseline_form(request:Request, project_id:int, baseline_date:_date, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        selected_project(db,ctx['company_id'],user.id,visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')),project_id)
        activities=db.query(ConstructionActivity).filter_by(company_id=ctx['company_id'],project_id=project_id).all()
        if not activities: raise ValueError('Add at least one activity before creating a baseline')
        last=db.query(func.coalesce(func.max(ConstructionScheduleBaseline.baseline_no),0)).filter_by(company_id=ctx['company_id'],project_id=project_id).scalar() or 0
        lines=[{'activity_id':a.id,'planned_start':a.planned_start,'planned_finish':a.planned_finish,'budget_amount':a.budget_amount} for a in activities]
        _create_baseline(db,ctx['company_id'],project_id,int(last)+1,baseline_date,lines)
        db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/planning/baselines/{baseline_id}/approve', response_class=HTMLResponse)
def planning_baseline_approve(request:Request, baseline_id:int, project_id:int, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        selected_project(db,ctx['company_id'],user.id,visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')),project_id)
        b=db.query(ConstructionScheduleBaseline).filter_by(id=baseline_id,company_id=ctx['company_id'],project_id=project_id).one_or_none()
        if not b: raise ValueError('Baseline not found')
        if b.status=='approved': raise ValueError('Baseline is already approved')
        b.status='approved'; b.approved_by_id=user.id; b.approved_at=_datetime.utcnow()
        db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'planning_dashboard.html',_planning_context(db,ctx,user,project_id))

@router.post('/costs/snapshots', response_class=HTMLResponse)
def costs_snapshot_form(request: Request, project_id:int, status_date:_date, method:str='manual_etc', db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        selected_project(db,ctx['company_id'],user.id,visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')),project_id)
        _create_cost_snapshot(db,ctx['company_id'],project_id,status_date,user.id,method); db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'costs_dashboard.html',_costs_context(db,ctx,user,project_id))

@router.post('/costs/snapshots/{snapshot_id}/approve', response_class=HTMLResponse)
def costs_snapshot_approve(request: Request, snapshot_id:int, project_id:int, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        selected_project(db,ctx['company_id'],user.id,visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')),project_id)
        row=db.query(ConstructionCostControlSnapshot).filter_by(id=snapshot_id,company_id=ctx['company_id'],project_id=project_id).first()
        if not row: raise ValueError('Cost-control snapshot not found')
        _approve_cost_snapshot(db,ctx['company_id'],snapshot_id,user.id); db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400,str(e))
    return templates.TemplateResponse(request,'costs_dashboard.html',_costs_context(db,ctx,user,project_id))

@router.post('/costs/budget', response_class=HTMLResponse)
def costs_budget_form(request: Request, project_id:int, description:str, budget_amount:Decimal, budget_date:_date|None=None, cost_code_id:int|None=None, wbs_id:int|None=None, db:Session=Depends(get_db), ctx=Depends(get_tenant_context), user:User=Depends(require_permission('construction:manage'))):
    try:
        _create_budget(db, ctx['company_id'], project_id, description.strip(), budget_amount, cost_code_id=cost_code_id, wbs_id=wbs_id, budget_date=budget_date)
        db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400, str(e))
    return templates.TemplateResponse(request, 'costs_dashboard.html', _costs_context(db, ctx, user, project_id))

# Helpers used by the dedicated HTML POST actions.
def _planning_context(db, ctx, user, project_id):
    projects=visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')); p=selected_project(db,ctx['company_id'],user.id,projects,project_id)
    activities=db.query(ConstructionActivity).filter_by(company_id=ctx['company_id'],project_id=p.id).order_by(ConstructionActivity.planned_start,ConstructionActivity.code).all()
    baselines=db.query(ConstructionScheduleBaseline).filter_by(company_id=ctx['company_id'],project_id=p.id).order_by(ConstructionScheduleBaseline.baseline_no.desc()).all()
    periods=db.query(ConstructionProgressPeriod).filter_by(company_id=ctx['company_id'],project_id=p.id).order_by(ConstructionProgressPeriod.status_date.desc()).limit(12).all()
    evm=db.query(ConstructionEVMSnapshot).filter_by(company_id=ctx['company_id'],project_id=p.id).order_by(ConstructionEVMSnapshot.status_date.desc()).first()
    wbs=db.query(WBSNode).filter_by(company_id=ctx['company_id'],project_id=p.id,is_active=True).order_by(WBSNode.level,WBSNode.code).all()
    progress_map={}
    if periods:
        latest_by_activity={}
        rows=db.query(ConstructionActivityProgress,ConstructionProgressPeriod.status_date).join(ConstructionProgressPeriod,ConstructionActivityProgress.period_id==ConstructionProgressPeriod.id).filter(ConstructionActivityProgress.company_id==ctx['company_id'],ConstructionProgressPeriod.project_id==p.id).order_by(ConstructionProgressPeriod.status_date.desc()).all()
        for r,d in rows:
            latest_by_activity.setdefault(r.activity_id,r)
        progress_map={k:Decimal(str(v.earned_percent or 0)) for k,v in latest_by_activity.items()}
    total_budget=sum((Decimal(str(a.budget_amount or 0)) for a in activities),Decimal('0'))
    weighted_progress=(sum((Decimal(str(a.budget_amount or 0))*progress_map.get(a.id,Decimal('0')) for a in activities),Decimal('0'))/total_budget) if total_budget else (sum(progress_map.values(),Decimal('0'))/Decimal(len(activities)) if activities else Decimal('0'))
    today=_date.today(); delayed=sum(1 for a in activities if a.status!='completed' and a.planned_finish<today); completed=sum(1 for a in activities if a.status=='completed')
    in_progress=sum(1 for a in activities if a.status=='in_progress')
    starts=[a.planned_start for a in activities]; finishes=[a.planned_finish for a in activities]
    schedule_start=min(starts) if starts else today; schedule_finish=max(finishes) if finishes else today
    span=max((schedule_finish-schedule_start).days,1)
    activity_rows=[]
    wbs_map={x.id:x for x in wbs}
    for a in activities:
        offset=max((a.planned_start-schedule_start).days,0); duration=max((a.planned_finish-a.planned_start).days+1,1)
        activity_rows.append({'activity':a,'progress':progress_map.get(a.id,Decimal('0')),'duration_days':duration,'gantt_left':round(offset/span*100,2),'gantt_width':max(round(duration/span*100,2),2),'wbs_name':(wbs_map[a.wbs_id].name if a.wbs_id in wbs_map else '—')})
    schedule_data=_calculate_schedule(db,ctx['company_id'],p.id) if activities else {}
    approved_baseline=next((b for b in baselines if b.status=='approved'), None)
    baseline_variance=_baseline_variance(db,ctx['company_id'],p.id,approved_baseline.id if approved_baseline else None)
    delay_events=db.query(ConstructionScheduleDelayEvent).filter_by(company_id=ctx['company_id'],project_id=p.id).order_by(ConstructionScheduleDelayEvent.event_date.desc()).limit(20).all()
    resources=db.query(ConstructionScheduleResource).filter_by(company_id=ctx['company_id'],project_id=p.id).order_by(ConstructionScheduleResource.activity_id).all()
    resource_planned=sum((D(r.planned_units) for r in resources),Decimal('0')); resource_actual=sum((D(r.actual_units) for r in resources),Decimal('0'))
    dep_rows=db.query(ConstructionActivityDependency).filter_by(company_id=ctx['company_id'],project_id=p.id).all()
    critical_count=sum(1 for x in schedule_data.values() if x['critical'])
    time_impacts=db.query(ConstructionTimeImpactAnalysis).filter_by(company_id=ctx['company_id'],project_id=p.id).order_by(ConstructionTimeImpactAnalysis.created_at.desc()).limit(20).all()
    schedule_health=_schedule_health(db,ctx['company_id'],p.id)
    resource_hist=_resource_histogram(db,ctx['company_id'],p.id)
    resource_curves_data=_resource_curves(db,ctx['company_id'],p.id)
    update_periods=db.query(ConstructionScheduleUpdatePeriod, ConstructionRecoveryPlan, ConstructionRecoveryScheduleLink, ConstructionEOTClaim, ConstructionScheduleUpdateLine).filter_by(company_id=ctx['company_id'],project_id=p.id).order_by(ConstructionScheduleUpdatePeriod.status_date.desc()).limit(12).all()
    metrics={'total':len(activities),'completed':completed,'in_progress':in_progress,'delayed':delayed,'wbs':len(wbs),'baselines':len(baselines),'progress':weighted_progress,'resource_planned':resource_planned,'resource_actual':resource_actual,'approved_delay_days':sum((int(x.approved_days or 0) for x in delay_events),0),'spi':(Decimal(str(evm.spi)) if evm else None),'cpi':(Decimal(str(evm.cpi)) if evm else None),'budget':total_budget,'dependencies':len(dep_rows),'critical':critical_count,'schedule_health_score':schedule_health['score'],'schedule_health_status':schedule_health['status']}
    return {'user':user,'projects':projects,'project':p,'activities':activities,'activity_rows':activity_rows,'schedule_data':schedule_data,'dependencies':dep_rows,'baselines':baselines,'baseline_variance':baseline_variance,'delay_events':delay_events,'resources':resources,'periods':periods,'evm':evm,'wbs':wbs,'metrics':metrics,'time_impacts':time_impacts,'schedule_health':schedule_health,'resource_histogram':resource_hist,'resource_curves':resource_curves_data,'update_periods':update_periods,'today':today,'schedule_start':schedule_start,'schedule_finish':schedule_finish,'section':'planning'}

def _zero_cost_totals():
    return {'budget':Decimal('0'),'committed':Decimal('0'),'actual':Decimal('0'),'etc':Decimal('0'),'eac':Decimal('0'),'variance':Decimal('0'),'remaining_budget':Decimal('0'),'utilization':Decimal('0'),'commitment_ratio':Decimal('0'),'cpi':None}

def _cost_category_label(value):
    labels={'material':'مواد','materials':'مواد','labor':'عمالة','labour':'عمالة','equipment':'معدات','subcontractor':'مقاولو الباطن','subcontractors':'مقاولو الباطن','overhead':'أعمال/مصروفات غير مباشرة','indirect':'أعمال/مصروفات غير مباشرة','other':'أخرى','material_return':'مرتجعات مواد'}
    return labels.get((value or '').lower(), value or 'أخرى')

def _cost_status(t):
    if t['budget'] <= 0: return ('unbudgeted','غير موازن')
    exposure=t['actual']+t['committed']+t['etc']
    if exposure > t['budget']: return ('critical','خطر تجاوز الميزانية')
    if exposure >= t['budget']*Decimal('0.90'): return ('watch','يحتاج متابعة')
    return ('on_track','ضمن الميزانية')

def _costs_context(db, ctx, user, project_id, date_from=None, date_to=None, category=None):
    projects=visible_projects(db,ctx['company_id'],user.id,ctx.get('branch_id')); p=selected_project(db,ctx['company_id'],user.id,projects,project_id)
    if date_from and date_to and date_to < date_from: raise HTTPException(400,'End date cannot be before start date')
    codes=db.query(ConstructionCostCode).filter_by(company_id=ctx['company_id'],is_active=True).order_by(ConstructionCostCode.code).all()
    wbs=db.query(WBSNode).filter_by(company_id=ctx['company_id'],project_id=p.id,is_active=True).order_by(WBSNode.code).all()
    # Budgets and commitments are controlled by cost code. Actuals are intentionally grouped by ProjectCost.cost_type;
    # ProjectCost has no cost_code_id column, so this avoids a runtime SQLAlchemy attribute error.
    budget_q=db.query(ConstructionCostBudgetLine).filter_by(company_id=ctx['company_id'],project_id=p.id,status='active')
    commitment_q=db.query(ConstructionCommitment).filter_by(company_id=ctx['company_id'],project_id=p.id,status='active')
    actual_q=db.query(ProjectCost).filter_by(company_id=ctx['company_id'],project_id=p.id)
    if date_from:
        budget_q=budget_q.filter(ConstructionCostBudgetLine.budget_date>=date_from)
        commitment_q=commitment_q.filter(ConstructionCommitment.commitment_date>=date_from)
        actual_q=actual_q.filter(ProjectCost.cost_date>=date_from)
    if date_to:
        budget_q=budget_q.filter(ConstructionCostBudgetLine.budget_date<=date_to)
        commitment_q=commitment_q.filter(ConstructionCommitment.commitment_date<=date_to)
        actual_q=actual_q.filter(ProjectCost.cost_date<=date_to)
    budgets=budget_q.all(); commitments=commitment_q.all(); actuals=actual_q.order_by(ProjectCost.cost_date.desc()).all()
    forecast_q=db.query(ConstructionCostForecast).filter_by(company_id=ctx['company_id'],project_id=p.id,status='active')
    if date_from: forecast_q=forecast_q.filter(ConstructionCostForecast.forecast_date>=date_from)
    if date_to: forecast_q=forecast_q.filter(ConstructionCostForecast.forecast_date<=date_to)
    latest_forecasts=forecast_q.order_by(ConstructionCostForecast.forecast_date.desc(),ConstructionCostForecast.id.desc()).all()
    # Keep only latest active forecast per cost code/WBS pair.
    forecast_map={}
    for f in latest_forecasts:
        key=(f.cost_code_id,f.wbs_id)
        forecast_map.setdefault(key,Decimal(str(f.etc_amount or 0)))
    code_map={c.id:c for c in codes}
    grouped={}
    for c in codes:
        grouped[f'code:{c.id}']={'key':f'code:{c.id}','code':c.code,'name':c.name,'budget':Decimal('0'),'committed':Decimal('0'),'actual':Decimal('0'),'etc':Decimal('0'),'category':'budget'}
    for b in budgets:
        key=f'code:{b.cost_code_id}' if b.cost_code_id else 'unassigned_budget'
        grouped.setdefault(key,{'key':key,'code':'—','name':'بنود غير مصنفة','budget':Decimal('0'),'committed':Decimal('0'),'actual':Decimal('0'),'etc':Decimal('0'),'category':'other'})['budget']+=Decimal(str(b.budget_amount or 0))
    for cmt in commitments:
        key=f'code:{cmt.cost_code_id}' if cmt.cost_code_id else 'unassigned_budget'
        grouped.setdefault(key,{'key':key,'code':'—','name':'بنود غير مصنفة','budget':Decimal('0'),'committed':Decimal('0'),'actual':Decimal('0'),'etc':Decimal('0'),'category':'other'})['committed']+=Decimal(str(cmt.committed_amount or 0))-Decimal(str(cmt.released_amount or 0))
    # Forecasts map cleanly to cost codes when present.
    for (cost_code_id,_wbs_id),etc in forecast_map.items():
        key=f'code:{cost_code_id}' if cost_code_id else 'unassigned_forecast'
        grouped.setdefault(key,{'key':key,'code':'—','name':'توقعات غير مصنفة','budget':Decimal('0'),'committed':Decimal('0'),'actual':Decimal('0'),'etc':Decimal('0'),'category':'other'})['etc']+=etc
    # Actual cost categories are operational cost types; retain source-level drill-down instead of inventing a false cost-code relationship.
    actual_groups={}
    for a in actuals:
        label=_cost_category_label(a.cost_type); actual_groups.setdefault(label,Decimal('0')); actual_groups[label]+=Decimal(str(a.amount or 0))
    rows=[]
    for r in grouped.values():
        if any(r[k] for k in ('budget','committed','actual','etc')): rows.append(r)
    for label,amount in actual_groups.items():
        rows.append({'key':'actual:'+label,'code':'ACT','name':label,'budget':Decimal('0'),'committed':Decimal('0'),'actual':amount,'etc':Decimal('0'),'category':label})
    if category:
        rows=[r for r in rows if (r['name']==category or r['key']==category or r['category']==category)]
        actuals=[a for a in actuals if _cost_category_label(a.cost_type)==category]
    for r in rows:
        r['eac']=r['actual']+r['etc']; r['variance']=r['budget']-r['eac']; r['utilization']=(r['actual']/r['budget']*100) if r['budget'] else Decimal('0'); r['status'],r['status_label']=_cost_status(r)
    totals=_zero_cost_totals()
    totals.update({'budget':sum((r['budget'] for r in rows),Decimal('0')),'committed':sum((r['committed'] for r in rows),Decimal('0')),'actual':sum((r['actual'] for r in rows),Decimal('0')),'etc':sum((r['etc'] for r in rows),Decimal('0'))})
    totals['eac']=totals['actual']+totals['etc']; totals['variance']=totals['budget']-totals['eac']; totals['remaining_budget']=totals['budget']-totals['actual']-totals['committed']; totals['utilization']=(totals['actual']/totals['budget']*100) if totals['budget'] else Decimal('0'); totals['commitment_ratio']=(totals['committed']/totals['budget']*100) if totals['budget'] else Decimal('0')
    # Latest EVM snapshot provides CPI when available.
    evm=db.query(ConstructionEVMSnapshot).filter_by(company_id=ctx['company_id'],project_id=p.id).order_by(ConstructionEVMSnapshot.status_date.desc()).first()
    totals['cpi']=Decimal(str(evm.cpi)) if evm and evm.cpi is not None else None
    # Patch 56 linkage: expose authoritative budget and synchronized financial-control artifacts.
    linkage_date=date_to or date.today()
    totals['authoritative_budget']=authoritative_budget_total(db,ctx['company_id'],p.id)
    reconciliation=reconcile_project_costs(db,ctx['company_id'],p.id,linkage_date)
    totals['reconciled_actual']=Decimal(str(reconciliation.actual_amount or 0))
    totals['open_commitment']=Decimal(str(reconciliation.open_commitment_amount or 0))
    totals['unreconciled']=Decimal(str(reconciliation.unreconciled_amount or 0))
    latest_forecast_version=db.query(ConstructionCostForecastVersion).filter_by(company_id=ctx['company_id'],project_id=p.id,status='approved').order_by(ConstructionCostForecastVersion.status_date.desc(),ConstructionCostForecastVersion.version_no.desc()).first()
    totals['forecast_version']=latest_forecast_version.version_no if latest_forecast_version else None
    cashflow=db.query(ConstructionCostCashFlowSnapshot).filter_by(company_id=ctx['company_id'],project_id=p.id,status_date=linkage_date).first()
    profitability=db.query(ProjectForecast).filter_by(company_id=ctx['company_id'],project_id=p.id,as_of_date=linkage_date).first()
    status,status_label=_cost_status(totals); totals['status']=status; totals['status_label']=status_label
    cost_health=_cost_control_health(db,ctx['company_id'],p.id)
    alerts=[]
    if totals['budget']<=0 and (totals['actual']>0 or totals['committed']>0): alerts.append(('warning','توجد تكاليف أو التزامات بدون ميزانية معتمدة.'))
    if totals['eac']>totals['budget'] and totals['budget']>0: alerts.append(('danger',f"التوقع عند الإكمال يتجاوز الميزانية بمقدار {abs(totals['variance']):,.2f}."))
    elif totals['budget']>0 and totals['utilization']>=90: alerts.append(('warning','استهلاك التكلفة وصل إلى 90% أو أكثر من الميزانية.'))
    if totals['committed']>totals['budget'] and totals['budget']>0: alerts.append(('danger','الالتزامات المفتوحة تجاوزت الميزانية المعتمدة.'))
    if not alerts and totals['budget']>0: alerts.append(('success','لا توجد مؤشرات تجاوز تكلفة حالية وفق البيانات المسجلة.'))
    actual_details=[{'id':a.id,'date':a.cost_date,'type':_cost_category_label(a.cost_type),'source_type':a.source_type or '—','source_id':a.source_id,'description':a.description or '—','amount':Decimal(str(a.amount or 0))} for a in actuals]
    categories=sorted(actual_groups.keys())
    snapshots=db.query(ConstructionCostControlSnapshot).filter_by(company_id=ctx['company_id'],project_id=p.id).order_by(ConstructionCostControlSnapshot.status_date.desc()).limit(12).all()
    return {'user':user,'projects':projects,'project':p,'rows':rows,'totals':totals,'codes':codes,'wbs':wbs,'section':'costs','filters':{'date_from':date_from,'date_to':date_to,'category':category or ''},'categories':categories,'actual_details':actual_details,'alerts':alerts,'evm':evm,'cost_health':cost_health,'cost_snapshots':snapshots,'reconciliation':reconciliation,'cashflow':cashflow,'profitability_forecast':profitability,'latest_forecast_version':latest_forecast_version}


