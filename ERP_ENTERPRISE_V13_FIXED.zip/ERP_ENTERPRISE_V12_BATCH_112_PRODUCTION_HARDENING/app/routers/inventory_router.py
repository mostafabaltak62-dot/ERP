# -*- coding: utf-8 -*-
from fastapi import APIRouter, Depends, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import func, case
from decimal import Decimal
import csv
from io import StringIO

from ..database import get_db
from ..models import Item, StockMovement, ItemTypeEnum, MovementTypeEnum, User
from ..accounting import create_entry, D, money
from ..auth import require_module
from ..governance import get_request_context
from ..time_utils import utcnow

router = APIRouter(prefix="/inventory")
templates = Jinja2Templates(directory="templates")

IN_TYPES = (MovementTypeEnum.in_, MovementTypeEnum.adjustment_in)
OUT_TYPES = (MovementTypeEnum.out, MovementTypeEnum.adjustment_out)


def _clean_text(value: str, field: str, max_len: int) -> str:
    value = (value or "").strip()
    if not value:
        raise HTTPException(status_code=422, detail=f"{field} مطلوب")
    if len(value) > max_len:
        raise HTTPException(status_code=422, detail=f"{field} أطول من الحد المسموح")
    return value


def _checkbox(value: str | None) -> bool:
    return str(value or "").lower() in {"1", "true", "on", "yes", "checked"}


def _validate_item_numbers(purchase_price, sale_price, standard_cost, min_stock, max_stock, reorder_level, safety_stock, reorder_qty, conversion_factor, tax_rate):
    values = {
        "سعر الشراء": purchase_price, "سعر البيع": sale_price, "التكلفة القياسية": standard_cost,
        "الحد الأدنى": min_stock, "الحد الأقصى": max_stock, "مستوى إعادة الطلب": reorder_level,
        "مخزون الأمان": safety_stock, "كمية إعادة الطلب": reorder_qty,
    }
    for label, value in values.items():
        if value < 0:
            raise HTTPException(status_code=422, detail=f"{label} لا يمكن أن يكون سالبًا")
    if conversion_factor <= 0:
        raise HTTPException(status_code=422, detail="معامل التحويل يجب أن يكون أكبر من صفر")
    if tax_rate < 0 or tax_rate > 100:
        raise HTTPException(status_code=422, detail="نسبة الضريبة يجب أن تكون بين 0 و100")
    if max_stock > 0 and min_stock > max_stock:
        raise HTTPException(status_code=422, detail="الحد الأدنى لا يمكن أن يكون أكبر من الحد الأقصى")
    if max_stock > 0 and reorder_level > max_stock:
        raise HTTPException(status_code=422, detail="مستوى إعادة الطلب لا يمكن أن يتجاوز الحد الأقصى")


def _item_for_update(db: Session, item_id: int, cid: int) -> Item:
    item = db.query(Item).filter(Item.id == item_id, Item.company_id == cid).with_for_update().first()
    if not item:
        raise HTTPException(status_code=404, detail="الصنف مش موجود")
    return item


def company_id() -> int:
    cid = get_request_context().get("company_id")
    if cid is None:
        raise HTTPException(403, "لم يتم تحديد الشركة الحالية")
    return int(cid)


def compute_stock(db: Session, item_id: int, cid: int) -> Decimal:
    total_in = db.query(func.coalesce(func.sum(StockMovement.quantity), 0)).filter(
        StockMovement.company_id == cid,
        StockMovement.item_id == item_id,
        StockMovement.movement_type.in_(IN_TYPES)
    ).scalar()
    total_out = db.query(func.coalesce(func.sum(StockMovement.quantity), 0)).filter(
        StockMovement.company_id == cid,
        StockMovement.item_id == item_id,
        StockMovement.movement_type.in_(OUT_TYPES)
    ).scalar()
    return D(total_in or 0) - D(total_out or 0)


@router.get("", response_class=HTMLResponse)
def item_list(request: Request, q: str = "", status: str = "all", db: Session = Depends(get_db),
              user: User = Depends(require_module("inventory"))):
    cid = company_id()
    query = db.query(Item).filter(Item.company_id == cid)
    q = (q or "").strip()[:100]
    if q:
        like = f"%{q}%"
        query = query.filter((Item.code.ilike(like)) | (Item.name.ilike(like)) | (Item.category.ilike(like)) | (Item.barcode.ilike(like)))
    allowed_statuses = {"all", "low", "service", "inactive"}
    status = status if status in allowed_statuses else "all"
    items = query.order_by(Item.code, Item.id).all()
    product_ids = [it.id for it in items if it.item_type == ItemTypeEnum.product]
    balances = {}
    if product_ids:
        rows = db.query(
            StockMovement.item_id,
            func.coalesce(func.sum(
                case((StockMovement.movement_type.in_(IN_TYPES), StockMovement.quantity), else_=-StockMovement.quantity)
            ), 0)
        ).filter(StockMovement.company_id == cid, StockMovement.item_id.in_(product_ids)).group_by(StockMovement.item_id).all()
        balances = {item_id: D(balance or 0) for item_id, balance in rows}
    rows = []
    for it in items:
        stock = balances.get(it.id, D(0)) if it.item_type == ItemTypeEnum.product else None
        low = stock is not None and D(it.min_stock or 0) > 0 and stock <= D(it.min_stock)
        rows.append({"item": it, "stock": stock, "low": low})
    if status == "low":
        rows = [r for r in rows if r["low"]]
    elif status == "service":
        rows = [r for r in rows if r["stock"] is None]
    elif status == "inactive":
        rows = [r for r in rows if not r["item"].is_active]
    can_edit = user.role.value == "admin" or _has_edit(db, user, "inventory")
    return templates.TemplateResponse(request, "inventory_list.html", {
        "user": user, "rows": rows, "q": q, "status": status, "can_edit": can_edit, "section": "inventory"
    })


def _has_edit(db: Session, user: User, module_key: str) -> bool:
    from ..models import ModulePermission
    perm = db.query(ModulePermission).filter_by(user_id=user.id, module_key=module_key).first()
    return bool(perm and perm.can_edit)


@router.get("/export")
def export_items_csv(q: str = "", db: Session = Depends(get_db),
                     user: User = Depends(require_module("inventory"))):
    """Export only items belonging to the current company, preventing cross-tenant data leakage."""
    cid = company_id()
    query = db.query(Item).filter(Item.company_id == cid)
    if q:
        like = f"%{q}%"
        query = query.filter((Item.code.ilike(like)) | (Item.name.ilike(like)) | (Item.category.ilike(like)))
    items = query.order_by(Item.code).all()
    output = StringIO()
    writer = csv.writer(output)
    writer.writerow(["الكود", "الصنف", "النوع", "الفئة", "الوحدة", "سعر الشراء", "سعر البيع", "الحد الأدنى", "الرصد الحالي", "الحالة"])
    for item in items:
        stock = compute_stock(db, item.id, cid) if item.item_type == ItemTypeEnum.product else None
        low = stock is not None and item.min_stock and stock <= item.min_stock
        writer.writerow([
            item.code, item.name, "منتج" if item.item_type == ItemTypeEnum.product else "خدمة",
            item.category or "", item.unit or "", item.purchase_price, item.sale_price, item.min_stock,
            "" if stock is None else stock, "مخزون منخفض" if low else ("خدمة" if stock is None else "سليم")
        ])
    output.seek(0)
    return StreamingResponse(iter(["\ufeff" + output.getvalue()]), media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=inventory.csv"})


@router.get("/new", response_class=HTMLResponse)
def new_item_form(request: Request, user: User = Depends(require_module("inventory", need_edit=True))):
    return templates.TemplateResponse(request, "item_form.html", {
        "user": user, "item": None, "types": list(ItemTypeEnum)
    })


@router.post("/new")
def create_item(db: Session = Depends(get_db), user: User = Depends(require_module("inventory", need_edit=True)),
                 code: str = Form(...), name: str = Form(...), item_type: str = Form(...),
                 category: str = Form(""), unit: str = Form("قطعة"), name_en: str = Form(""), short_name: str = Form(""), description: str = Form(""),
                 item_group: str = Form(""), brand: str = Form(""), manufacturer: str = Form(""), model: str = Form(""), country_of_origin: str = Form(""),
                 purchase_unit: str = Form(""), issue_unit: str = Form(""), conversion_factor: Decimal = Form(1),
                 purchase_price: Decimal = Form(0), sale_price: Decimal = Form(0), standard_cost: Decimal = Form(0),
                 min_stock: Decimal = Form(0), max_stock: Decimal = Form(0), reorder_level: Decimal = Form(0), safety_stock: Decimal = Form(0), reorder_qty: Decimal = Form(0), lead_time_days: int = Form(0),
                 allow_negative_stock: str = Form(None), inspection_required: str = Form(None), mir_required: str = Form(None), certificate_required: str = Form(None), barcode: str = Form(""), valuation_method: str = Form("weighted_average"), tax_rate: Decimal = Form(0), track_serial: str = Form(None), track_expiry: str = Form(None)):
    cid = company_id()
    code = _clean_text(code, "كود الصنف", 30)
    name = _clean_text(name, "اسم الصنف", 150)
    _validate_item_numbers(purchase_price, sale_price, standard_cost, min_stock, max_stock, reorder_level, safety_stock, reorder_qty, conversion_factor, tax_rate)
    if db.query(Item).filter(Item.company_id == cid, Item.code == code).first():
        raise HTTPException(status_code=400, detail="كود الصنف ده مستخدم بالفعل")
    barcode = (barcode or "").strip() or None
    if barcode and db.query(Item).filter(Item.company_id == cid, Item.barcode == barcode).first():
        raise HTTPException(status_code=409, detail="الباركود مستخدم بالفعل داخل الشركة الحالية")
    item = Item(company_id=cid, code=code.strip(), name=name.strip(), item_type=ItemTypeEnum(item_type) if item_type in {x.value for x in ItemTypeEnum} else (_ for _ in ()).throw(HTTPException(status_code=422, detail="نوع الصنف غير صالح")), category=category.strip() or None, unit=unit.strip() or "قطعة",
                name_en=name_en.strip() or None, short_name=short_name.strip() or None, description=description.strip() or None, item_group=item_group.strip() or None,
                brand=brand.strip() or None, manufacturer=manufacturer.strip() or None, model=model.strip() or None, country_of_origin=country_of_origin.strip() or None,
                purchase_unit=purchase_unit.strip() or None, issue_unit=issue_unit.strip() or None, conversion_factor=conversion_factor,
                purchase_price=purchase_price, sale_price=sale_price, standard_cost=standard_cost, min_stock=min_stock, max_stock=max_stock, reorder_level=reorder_level, safety_stock=safety_stock, reorder_qty=reorder_qty, lead_time_days=max(lead_time_days,0),
                allow_negative_stock=_checkbox(allow_negative_stock), inspection_required=_checkbox(inspection_required), mir_required=_checkbox(mir_required), certificate_required=_checkbox(certificate_required), barcode=barcode.strip() or None, valuation_method=valuation_method if valuation_method in {'weighted_average','fifo','standard'} else 'weighted_average', tax_rate=max(Decimal('0'), min(tax_rate, Decimal('100'))), track_serial=_checkbox(track_serial), track_expiry=_checkbox(track_expiry))
    db.add(item)
    db.commit()
    return RedirectResponse(url="/inventory", status_code=303)


@router.get("/{item_id}", response_class=HTMLResponse)
def item_detail(item_id: int, request: Request, db: Session = Depends(get_db),
                 user: User = Depends(require_module("inventory"))):
    cid = company_id()
    item = db.query(Item).filter(Item.id == item_id, Item.company_id == cid).first()
    if not item:
        raise HTTPException(status_code=404, detail="الصنف مش موجود")
    stock = compute_stock(db, item.id, cid) if item.item_type == ItemTypeEnum.product else None
    movements = db.query(StockMovement).filter(StockMovement.company_id == cid, StockMovement.item_id == item.id)\
        .order_by(StockMovement.created_at.desc()).limit(50).all()
    can_edit = user.role.value == "admin" or _has_edit(db, user, "inventory")
    return templates.TemplateResponse(request, "item_detail.html", {
        "user": user, "item": item, "stock": stock, "movements": movements,
        "can_edit": can_edit, "movement_types": list(MovementTypeEnum)
    })


@router.get("/{item_id}/edit", response_class=HTMLResponse)
def edit_item_form(item_id: int, request: Request, db: Session = Depends(get_db),
                    user: User = Depends(require_module("inventory", need_edit=True))):
    cid = company_id()
    item = db.query(Item).filter(Item.id == item_id, Item.company_id == cid).first()
    if not item:
        raise HTTPException(status_code=404, detail="الصنف مش موجود")
    return templates.TemplateResponse(request, "item_form.html", {
        "user": user, "item": item, "types": list(ItemTypeEnum)
    })


@router.post("/{item_id}/edit")
def update_item(item_id: int, db: Session = Depends(get_db),
                 user: User = Depends(require_module("inventory", need_edit=True)),
                 name: str = Form(...), item_type: str = Form(...),
                 category: str = Form(""), unit: str = Form("قطعة"), name_en: str = Form(""), short_name: str = Form(""), description: str = Form(""),
                 item_group: str = Form(""), brand: str = Form(""), manufacturer: str = Form(""), model: str = Form(""), country_of_origin: str = Form(""), purchase_unit: str = Form(""), issue_unit: str = Form(""), conversion_factor: Decimal = Form(1),
                 purchase_price: Decimal = Form(0), sale_price: Decimal = Form(0), standard_cost: Decimal = Form(0), min_stock: Decimal = Form(0), max_stock: Decimal = Form(0), reorder_level: Decimal = Form(0), safety_stock: Decimal = Form(0), reorder_qty: Decimal = Form(0), lead_time_days: int = Form(0),
                 allow_negative_stock: str = Form(None), inspection_required: str = Form(None), mir_required: str = Form(None), certificate_required: str = Form(None), is_active: str = Form(None), barcode: str = Form(""), valuation_method: str = Form("weighted_average"), tax_rate: Decimal = Form(0), track_serial: str = Form(None), track_expiry: str = Form(None)):
    cid = company_id()
    item = db.query(Item).filter(Item.id == item_id, Item.company_id == cid).first()
    if not item:
        raise HTTPException(status_code=404, detail="الصنف مش موجود")
    code = _clean_text(item.code, "كود الصنف", 30)
    name = _clean_text(name, "اسم الصنف", 150)
    _validate_item_numbers(purchase_price, sale_price, standard_cost, min_stock, max_stock, reorder_level, safety_stock, reorder_qty, conversion_factor, tax_rate)
    if item.item_type == ItemTypeEnum.product and ItemTypeEnum(item_type) == ItemTypeEnum.service:
        movement_count = db.query(func.count(StockMovement.id)).filter(StockMovement.company_id == cid, StockMovement.item_id == item.id).scalar() or 0
        if movement_count:
            raise HTTPException(status_code=409, detail="لا يمكن تحويل صنف له حركات مخزون إلى خدمة؛ أنشئ صنف خدمة مستقلًا")
    normalized_barcode = (barcode or "").strip() or None
    if normalized_barcode:
        duplicate = db.query(Item.id).filter(Item.company_id == cid, Item.barcode == normalized_barcode, Item.id != item.id).first()
        if duplicate:
            raise HTTPException(status_code=409, detail="الباركود مستخدم بالفعل داخل الشركة الحالية")
    item.name = name; item.item_type = ItemTypeEnum(item_type); item.category = category.strip() or None; item.unit = unit.strip() or "قطعة"
    item.name_en=name_en.strip() or None; item.short_name=short_name.strip() or None; item.description=description.strip() or None; item.item_group=item_group.strip() or None
    item.brand=brand.strip() or None; item.manufacturer=manufacturer.strip() or None; item.model=model.strip() or None; item.country_of_origin=country_of_origin.strip() or None
    item.purchase_unit=purchase_unit.strip() or None; item.issue_unit=issue_unit.strip() or None; item.conversion_factor=conversion_factor
    item.purchase_price=purchase_price; item.sale_price=sale_price; item.standard_cost=standard_cost; item.min_stock=min_stock; item.max_stock=max_stock; item.reorder_level=reorder_level; item.safety_stock=safety_stock; item.reorder_qty=reorder_qty; item.lead_time_days=max(lead_time_days,0)
    item.allow_negative_stock=_checkbox(allow_negative_stock); item.inspection_required=_checkbox(inspection_required); item.mir_required=_checkbox(mir_required); item.certificate_required=_checkbox(certificate_required); item.barcode=barcode.strip() or None; item.valuation_method=valuation_method if valuation_method in {'weighted_average','fifo','standard'} else 'weighted_average'; item.tax_rate=max(Decimal('0'), min(tax_rate, Decimal('100'))); item.track_serial=_checkbox(track_serial); item.track_expiry=_checkbox(track_expiry); item.is_active=_checkbox(is_active)
    item.lifecycle_status = "active" if item.is_active else "blocked"
    db.commit()
    return RedirectResponse(url=f"/inventory/{item_id}", status_code=303)


@router.post("/{item_id}/movement")
def add_movement(item_id: int, db: Session = Depends(get_db),
                  user: User = Depends(require_module("inventory", need_edit=True)),
                  movement_type: str = Form(...), quantity: Decimal = Form(...),
                  note: str = Form("")):
    cid = company_id()
    item = db.query(Item).filter(Item.id == item_id, Item.company_id == cid).with_for_update().first()
    if not item:
        raise HTTPException(status_code=404, detail="الصنف مش موجود")
    if item.item_type != ItemTypeEnum.product:
        raise HTTPException(status_code=400, detail="الخدمات مالهاش حركة مخزون")
    if not item.is_active:
        raise HTTPException(status_code=409, detail="لا يمكن إنشاء حركة لصنف موقوف")
    if quantity <= 0:
        raise HTTPException(status_code=400, detail="الكمية لازم تكون أكبر من صفر")
    mtype = MovementTypeEnum(movement_type)
    if mtype in OUT_TYPES and compute_stock(db, item_id, cid) < quantity:
        raise HTTPException(status_code=400, detail=f"المخزون غير كافٍ. المتاح: {compute_stock(db, item_id, cid):g}")

    unit_cost = money(item.purchase_price or 0)
    quantity = D(quantity)
    total_cost = money(quantity * unit_cost)
    mv = StockMovement(company_id=cid, item_id=item_id, movement_type=mtype, quantity=quantity,
                        unit_cost=unit_cost, total_cost=total_cost, warehouse_id=None,
                        operational_date=utcnow(), source_type="inventory_adjustment",
                        note=note or None, created_by_id=user.id)
    db.add(mv)
    db.flush()

    # حركات الجرد/التسوية تؤثر على الدفاتر أيضًا. الوارد = زيادة أصل مقابل ربح تسوية،
    # والصادر = خسارة/مصروف مقابل خفض المخزون. الحركات العادية الواردة/الصادرة
    # مصدرها مستندات الشراء/البيع ولا يتم ترحيلها هنا مرة ثانية.
    if mtype == MovementTypeEnum.adjustment_in and total_cost > 0:
        create_entry(db, f"تسوية مخزون بالزيادة - {item.name}", user.id,
                     [("1300", total_cost, 0), ("5300", 0, total_cost)],
                     "inventory_adjustment", mv.id)
    elif mtype == MovementTypeEnum.adjustment_out and total_cost > 0:
        create_entry(db, f"تسوية مخزون بالنقص - {item.name}", user.id,
                     [("5200", total_cost, 0), ("1300", 0, total_cost)],
                     "inventory_adjustment", mv.id)

    db.commit()
    return RedirectResponse(url=f"/inventory/{item_id}", status_code=303)
