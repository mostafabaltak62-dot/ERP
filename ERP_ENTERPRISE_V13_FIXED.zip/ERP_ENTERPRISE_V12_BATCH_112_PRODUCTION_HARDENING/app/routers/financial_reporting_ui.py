# -*- coding: utf-8 -*-
"""Financial reporting workspace UI with tenant-aware drill-downs."""
import datetime
import csv
import io
from fastapi import APIRouter, Depends, Request, HTTPException, Query
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import or_, func
from ..database import get_db
from ..models import User, Account, JournalEntry, JournalLine, Supplier
from ..enterprise_models import Branch, UserCompanyAccess
from ..governance_models import GovernanceAuditLog
from ..auth import require_module
from ..governance import get_request_context, resolve_tenant
from ..financial_reporting import trial_balance, general_ledger, profit_and_loss, balance_sheet, cash_flow, changes_in_equity, validate_financials
from ..deep_transactions import ar_aging, ap_aging
from ..report_exports import excel_response, pdf_response
from ..enterprise_models import Project, ProjectCost, Contract, Budget, BudgetLine
from ..construction_services import project_profitability

router = APIRouter(prefix="/accounting/reports", tags=["Financial Reporting UI"])
templates = Jinja2Templates(directory="templates")

def _cid(db, user):
    ctx = get_request_context(); cid = ctx.get("company_id")
    if cid is None: cid = getattr(user, "company_id", None)
    if cid is None: raise HTTPException(403, "لم يتم تحديد الشركة الحالية")
    return cid

def _branches(db, user, cid):
    q=(db.query(Branch).join(UserCompanyAccess, UserCompanyAccess.branch_id==Branch.id)
       .filter(UserCompanyAccess.user_id==user.id, UserCompanyAccess.company_id==cid, Branch.is_active.is_(True)))
    if db.query(UserCompanyAccess).filter(UserCompanyAccess.user_id==user.id, UserCompanyAccess.company_id==cid, UserCompanyAccess.branch_id.is_(None)).first():
        q=db.query(Branch).filter(Branch.company_id==cid, Branch.is_active.is_(True))
    return q.order_by(Branch.name).all()

def _branch(db,user,cid,branch_id):
    if branch_id is None: return None
    _, bid=resolve_tenant(db,user,cid,int(branch_id)); return bid

def _dates(start,end):
    today=datetime.date.today()
    try:
        s=datetime.date.fromisoformat(start) if start else today.replace(month=1,day=1)
        e=datetime.date.fromisoformat(end) if end else today
    except (TypeError, ValueError):
        raise HTTPException(422,"صيغة التاريخ غير صحيحة؛ استخدم YYYY-MM-DD")
    if s>e: raise HTTPException(422,"تاريخ البداية يجب ألا يتجاوز تاريخ النهاية")
    return s,e

@router.get("", response_class=HTMLResponse, operation_id="ui_financial_reports_center")
def reports_home(request:Request, branch_id:int|None=None, db:Session=Depends(get_db), user:User=Depends(require_module("accounting"))):
    # The hub is itself tenant/branch aware so every child report starts from the
    # same governed scope. A branch_id is never trusted without resolve_tenant.
    cid,bid=_report_ctx(db,user,branch_id)
    return templates.TemplateResponse(request,"financial_reports_hub.html",{
        "user":user,"branches":_branches(db,user,cid),"branch_id":bid,
    })

@router.get("/general-ledger", response_class=HTMLResponse, operation_id="ui_general_ledger")
def general_ledger_page(request:Request,start_date:str="",end_date:str="",account_id:int|None=None,branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid=_cid(db,user); s,e=_dates(start_date,end_date); bid=_branch(db,user,cid,branch_id)
    # Resolve account filters inside the active tenant/branch scope before querying the ledger.
    if account_id is not None:
        aq_check=db.query(Account).filter(Account.id==account_id,Account.company_id==cid)
        if bid is not None:
            aq_check=aq_check.filter((Account.branch_id==bid)|(Account.branch_id.is_(None)))
        if not aq_check.first():
            raise HTTPException(404,"الحساب غير موجود ضمن نطاق الشركة/الفرع الحالي")
    rows=general_ledger(db,cid,s,e,account_id,bid)
    # Historical ledger activity must remain visible even when an account has
    # subsequently been deactivated. Include active accounts plus accounts that
    # have posted activity in the selected period.
    active_q=db.query(Account).filter(Account.company_id==cid)
    if bid is not None:
        active_q=active_q.filter((Account.branch_id==bid)|(Account.branch_id.is_(None)))
    accounts=active_q.order_by(Account.code,Account.branch_id.desc()).all()
    return templates.TemplateResponse(request,"financial_general_ledger.html",{"user":user,"rows":rows,"accounts":accounts,"account_id":account_id,"branch_id":bid,"branches":_branches(db,user,cid),"start_date":s,"end_date":e,"total_debit":sum((x["debit"] for x in rows),0),"total_credit":sum((x["credit"] for x in rows),0)})

@router.get("/general-ledger/export/{fmt}", operation_id="ui_general_ledger_export")
def general_ledger_export(fmt:str,start_date:str="",end_date:str="",account_id:int|None=None,branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    if fmt not in ("xlsx","pdf"):
        raise HTTPException(404,"صيغة التقرير غير مدعومة")
    cid=_cid(db,user); s,e=_dates(start_date,end_date); bid=_branch(db,user,cid,branch_id)
    if account_id is not None:
        aq=db.query(Account).filter(Account.id==account_id,Account.company_id==cid)
        if bid is not None:
            aq=aq.filter((Account.branch_id==bid)|(Account.branch_id.is_(None)))
        if not aq.first():
            raise HTTPException(404,"الحساب غير موجود ضمن نطاق الشركة/الفرع الحالي")
    rows=general_ledger(db,cid,s,e,account_id,bid)
    headers=["التاريخ","رقم القيد","الكود","الحساب","البيان","المصدر","مدين","دائن","الرصيد الافتتاحي","الرصيد الجاري"]
    data=[(r["date"],r["entry_number"],r["account_code"],r["account_name"],r["description"],f'{r["source_type"] or "-"} / {r["source_id"] or "-"}',r["debit"],r["credit"],r["opening_balance"],r["running_balance"]) for r in rows]
    if fmt=="xlsx":
        return excel_response("General Ledger",headers,data,"general_ledger.xlsx")
    return pdf_response("General Ledger",headers,data,"general_ledger.pdf")

@router.get("/account-statement/{account_id}", response_class=HTMLResponse, operation_id="ui_account_statement")
def account_statement(account_id:int,request:Request,start_date:str="",end_date:str="",branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid=_cid(db,user); s,e=_dates(start_date,end_date); bid=_branch(db,user,cid,branch_id)
    acc_q=db.query(Account).filter(Account.id==account_id,Account.company_id==cid)
    if bid is not None:
        acc_q=acc_q.filter((Account.branch_id==bid)|(Account.branch_id.is_(None)))
    acc=acc_q.first()
    if not acc: raise HTTPException(404,"الحساب غير موجود ضمن نطاق الشركة/الفرع الحالي")
    rows=general_ledger(db,cid,s,e,account_id,bid)
    return templates.TemplateResponse(request,"financial_account_statement.html",{"user":user,"account":acc,"rows":rows,"branch_id":bid,"branches":_branches(db,user,cid),"start_date":s,"end_date":e})



def _report_ctx(db, user, branch_id=None):
    cid=_cid(db,user); bid=_branch(db,user,cid,branch_id); return cid,bid

def _render_report(request, template, user, title, data, branches, branch_id=None):
    payload={"user":user,"title":title,"branches":branches,"branch_id":branch_id,**data}
    return templates.TemplateResponse(request,template,payload)

@router.get("/trial-balance", response_class=HTMLResponse, operation_id="ui_trial_balance")
def trial_balance_page(request:Request,start_date:str="",end_date:str="",branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid,bid=_report_ctx(db,user,branch_id); s,e=_dates(start_date,end_date); rows=trial_balance(db,cid,s,e,bid)
    total_debit=sum((r["debit"] for r in rows), 0); total_credit=sum((r["credit"] for r in rows), 0)
    return _render_report(request,"trial_balance.html",user,"ميزان المراجعة",{"rows":rows,"start_date":s,"end_date":e,"total_debit":total_debit,"total_credit":total_credit,"balanced":total_debit==total_credit},_branches(db,user,cid),bid)

@router.get("/trial-balance/export/{fmt}", operation_id="ui_trial_balance_export")
def trial_balance_export(fmt:str,start_date:str="",end_date:str="",branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    if fmt not in ("xlsx","pdf"): raise HTTPException(404,"صيغة التقرير غير مدعومة")
    cid,bid=_report_ctx(db,user,branch_id); s,e=_dates(start_date,end_date); rows=trial_balance(db,cid,s,e,bid)
    headers=["الكود","الحساب","الرصيد الافتتاحي","مدين","دائن","الرصيد الختامي"]
    data=[(r["code"],r["name"],r["opening_balance"],r["debit"],r["credit"],r["closing_balance"]) for r in rows]
    data.append(("","الإجمالي","",sum((r["debit"] for r in rows),0),sum((r["credit"] for r in rows),0),""))
    if fmt=="xlsx": return excel_response("Trial Balance",headers,data,"trial_balance.xlsx")
    return pdf_response("Trial Balance",headers,data,"trial_balance.pdf")

@router.get("/income-statement", response_class=HTMLResponse, operation_id="ui_income_statement")
def income_statement_page(request:Request,start_date:str="",end_date:str="",branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid,bid=_report_ctx(db,user,branch_id); s,e=_dates(start_date,end_date); data=profit_and_loss(db,cid,s,e,bid)
    return templates.TemplateResponse(request,"income_statement.html",{
        "user":user,"report":data,"revenue_lines":data["revenue_lines"],"expense_lines":data["expense_lines"],
        "revenue_total":data["revenue_total"],"expense_total":data["expense_total"],
        "gross_profit":data["gross_profit"],"operating_expenses":data["operating_expenses"],
        "operating_profit":data["operating_profit"],"net_profit":data["net_profit"],
        "gross_margin_pct":data["gross_margin_pct"],"net_margin_pct":data["net_margin_pct"],
        "start_date":s,"end_date":e,"branch_id":bid,"branches":_branches(db,user,cid),
    })

@router.get("/income-statement/export/{fmt}", operation_id="ui_income_statement_export")
def income_statement_export(fmt:str,start_date:str="",end_date:str="",branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    if fmt not in ("xlsx","pdf"): raise HTTPException(404,"صيغة التقرير غير مدعومة")
    cid,bid=_report_ctx(db,user,branch_id); s,e=_dates(start_date,end_date); r=profit_and_loss(db,cid,s,e,bid)
    headers=["القسم","الكود","الحساب","المبلغ"]; data=[]
    data += [("الإيرادات",x["code"],x["name"],x["amount"]) for x in r["revenue_lines"]]
    data.append(("الإيرادات","","إجمالي الإيرادات",r["revenue_total"]))
    data += [("تكلفة المبيعات" if x["statement_section"]=="cost_of_sales" else "المصروفات التشغيلية",x["code"],x["name"],x["amount"]) for x in r["expense_lines"]]
    data += [("الربحية","","مجمل الربح",r["gross_profit"]),("الربحية","","المصروفات التشغيلية",r["operating_expenses"]),("الربحية","","الربح التشغيلي",r["operating_profit"]),("الربحية","","صافي الربح",r["net_profit"])]
    if fmt=="xlsx": return excel_response("Income Statement",headers,data,"income_statement.xlsx")
    return pdf_response("Income Statement",headers,data,"income_statement.pdf")

@router.get("/balance-sheet", response_class=HTMLResponse, operation_id="ui_balance_sheet")
def balance_sheet_page(request:Request,as_of_date:str="",branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid,bid=_report_ctx(db,user,branch_id)
    try:
        d=datetime.date.fromisoformat(as_of_date) if as_of_date else datetime.date.today()
    except ValueError:
        raise HTTPException(422,"صيغة تاريخ المركز المالي غير صحيحة؛ استخدم YYYY-MM-DD")
    data=balance_sheet(db,cid,d,bid)
    return _render_report(request,"financial_statement.html",user,"قائمة المركز المالي",{"report":data,"rows":data["assets"]+data["liabilities"]+data["equity"],"as_of_date":d,"kind":"bs"},_branches(db,user,cid),bid)

@router.get("/cash-flow", response_class=HTMLResponse, operation_id="ui_cash_flow")
def cash_flow_page(request:Request,start_date:str="",end_date:str="",branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid,bid=_report_ctx(db,user,branch_id); s,e=_dates(start_date,end_date); data=cash_flow(db,cid,s,e,bid)
    return _render_report(request,"financial_statement.html",user,"التدفقات النقدية",{"report":data,"rows":data["rows"],"start_date":s,"end_date":e,"kind":"cf"},_branches(db,user,cid),bid)

@router.get("/cash-flow/export/{fmt}", operation_id="ui_cash_flow_export")
def cash_flow_export(fmt:str,start_date:str="",end_date:str="",branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    if fmt not in ("xlsx", "pdf"):
        raise HTTPException(404, "صيغة التقرير غير مدعومة")
    cid,bid=_report_ctx(db,user,branch_id); s,e=_dates(start_date,end_date); report=cash_flow(db,cid,s,e,bid)
    headers=["التاريخ","رقم القيد","البيان","التصنيف","صافي النقد"]
    labels={"operating":"تشغيلي","investing":"استثماري","financing":"تمويلي","mixed":"متعدد التصنيف"}
    data=[(r["date"],r["entry_number"],r["description"],labels.get(r["classification"],r["classification"]),r["net_cash"]) for r in report["rows"]]
    data += [("","","التدفقات التشغيلية","تشغيلي",report["operating"]),
             ("","","التدفقات الاستثمارية","استثماري",report["investing"]),
             ("","","التدفقات التمويلية","تمويلي",report["financing"]),
             ("","","صافي التغير","",report["net_change"]),
             ("","","النقدية أول المدة","",report["opening_cash"]),
             ("","","النقدية آخر المدة","",report["closing_cash"])]
    if fmt=="xlsx":
        return excel_response("Cash Flow",headers,data,"cash_flow.xlsx")
    return pdf_response("Cash Flow",headers,data,"cash_flow.pdf")

@router.get("/equity", response_class=HTMLResponse, operation_id="ui_changes_in_equity")
def equity_page(request:Request,start_date:str="",end_date:str="",branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid,bid=_report_ctx(db,user,branch_id); s,e=_dates(start_date,end_date); data=changes_in_equity(db,cid,s,e,bid)
    return _render_report(request,"financial_statement.html",user,"التغير في حقوق الملكية",{"report":data,"rows":data["accounts"],"start_date":s,"end_date":e,"kind":"equity"},_branches(db,user,cid),bid)

@router.get("/equity/export/{fmt}", operation_id="ui_changes_in_equity_export")
def equity_export(fmt:str,start_date:str="",end_date:str="",branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    if fmt not in ("xlsx", "pdf"): raise HTTPException(404, "صيغة التقرير غير مدعومة")
    cid,bid=_report_ctx(db,user,branch_id); s,e=_dates(start_date,end_date); r=changes_in_equity(db,cid,s,e,bid)
    headers=["الكود","الحساب","رصيد أول المدة","حركة الفترة","ربح الفترة","رصيد آخر المدة"]; data=[]
    for x in r["accounts"]:
        data.append((x["code"],x["name"],x["opening_equity"],x["period_movement"],0,x["closing_equity"]))
    data.append(("","إجمالي حقوق الملكية",r["opening_equity"],r["equity_movements"],r["profit_for_period"],r["closing_equity"]))
    if fmt=="xlsx": return excel_response("Statement of Changes in Equity",headers,data,"changes_in_equity.xlsx")
    return pdf_response("Statement of Changes in Equity",headers,data,"changes_in_equity.pdf")

@router.get("/validation", response_class=HTMLResponse, operation_id="ui_financial_validation")
def validation_page(request:Request,start_date:str="",end_date:str="",branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid,bid=_report_ctx(db,user,branch_id); s,e=_dates(start_date,end_date); data=validate_financials(db,cid,s,e,bid)
    return _render_report(request,"financial_statement.html",user,"التحقق المالي",{"report":data,"rows":[],"start_date":s,"end_date":e,"kind":"validation"},_branches(db,user,cid),bid)

@router.get("/validation/export/{fmt}")
def validation_export(fmt:str,start_date:str="",end_date:str="",branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    if fmt not in ("xlsx","pdf"): raise HTTPException(404,"صيغة التقرير غير مدعومة")
    cid,bid=_report_ctx(db,user,branch_id); s,e=_dates(start_date,end_date); data=validate_financials(db,cid,s,e,bid)
    headers=["الفحص","الحالة","التفاصيل"]
    rows=[(x["name"],"PASS" if x["ok"] else "FAIL",x["detail"]) for x in data["checks"]]
    rows.append(("النتيجة الإجمالية","PASS" if data["overall"] else "FAIL",f"{data['passed']}/{data['total']}"))
    if fmt=="xlsx":
        return excel_response("Financial Validation",headers,rows,"financial_validation.xlsx")
    return pdf_response("Financial Validation",headers,rows,"financial_validation.pdf")

@router.get("/ar-aging", response_class=HTMLResponse, operation_id="ui_ar_aging")
def ar_aging_page(request:Request,as_of_date:str="",branch_id:int|None=None,customer_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid,bid=_report_ctx(db,user,branch_id)
    try:
        d=datetime.date.fromisoformat(as_of_date) if as_of_date else datetime.date.today()
    except ValueError:
        raise HTTPException(422,"صيغة التاريخ غير صحيحة؛ استخدم YYYY-MM-DD")
    customers_q=db.query(__import__('app.models',fromlist=['Customer']).Customer).filter(__import__('app.models',fromlist=['Customer']).Customer.company_id==cid)
    customers=customers_q.order_by(__import__('app.models',fromlist=['Customer']).Customer.name).all()
    if customer_id is not None and not any(c.id==customer_id for c in customers):
        raise HTTPException(404,"العميل غير موجود ضمن الشركة الحالية")
    rows=ar_aging(db,cid,d,bid,customer_id)
    return _render_report(request,"aging_report.html",user,"أعمار الذمم المدينة",{"rows":rows,"as_of_date":d,"kind":"ar","customer_id":customer_id,"customers":customers},_branches(db,user,cid),bid)

@router.get("/ar-aging/export/{fmt}", operation_id="ui_ar_aging_export")
def ar_aging_export(fmt:str,as_of_date:str="",branch_id:int|None=None,customer_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    if fmt not in ("xlsx","pdf"):
        raise HTTPException(404,"صيغة التقرير غير مدعومة")
    cid,bid=_report_ctx(db,user,branch_id)
    try:
        d=datetime.date.fromisoformat(as_of_date) if as_of_date else datetime.date.today()
    except ValueError:
        raise HTTPException(422,"صيغة التاريخ غير صحيحة؛ استخدم YYYY-MM-DD")
    if customer_id is not None and not db.query(__import__('app.models',fromlist=['Customer']).Customer).filter(__import__('app.models',fromlist=['Customer']).Customer.id==customer_id,__import__('app.models',fromlist=['Customer']).Customer.company_id==cid).first():
        raise HTTPException(404,"العميل غير موجود ضمن الشركة الحالية")
    rows=ar_aging(db,cid,d,bid,customer_id)
    headers=["العميل","رقم الفاتورة","تاريخ الفاتورة","تاريخ الاستحقاق","أصل المديونية","المدفوع","المرتجع","المتبقي","أيام التأخير","شريحة العمر"]
    data=[(r["customer_name"],r["invoice_number"],r["invoice_date"],r["due_date"],r["original"],r["paid"],r["returned"],r["outstanding"],r["overdue_days"],r["bucket"]) for r in rows]
    data.append(("","الإجمالي","","",sum((r["original"] for r in rows),0),sum((r["paid"] for r in rows),0),sum((r["returned"] for r in rows),0),sum((r["outstanding"] for r in rows),0),"",""))
    if fmt=="xlsx": return excel_response("Accounts Receivable Aging",headers,data,"ar_aging.xlsx")
    return pdf_response("Accounts Receivable Aging",headers,data,"ar_aging.pdf")

@router.get("/ap-aging", response_class=HTMLResponse)
def ap_aging_page(request:Request,as_of_date:str="",branch_id:int|None=None,supplier_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid,bid=_report_ctx(db,user,branch_id)
    try:
        d=datetime.date.fromisoformat(as_of_date) if as_of_date else datetime.date.today()
    except ValueError:
        raise HTTPException(422,"صيغة التاريخ غير صحيحة؛ استخدم YYYY-MM-DD")
    suppliers=db.query(Supplier).filter(Supplier.company_id==cid).order_by(Supplier.code,Supplier.name).all()
    if supplier_id is not None and not db.query(Supplier).filter(Supplier.id==supplier_id,Supplier.company_id==cid).first():
        raise HTTPException(404,"المورد غير موجود ضمن الشركة الحالية")
    rows=ap_aging(db,cid,d,bid,supplier_id)
    return _render_report(request,"aging_report.html",user,"أعمار الذمم الدائنة",{"rows":rows,"as_of_date":d,"kind":"ap","supplier_id":supplier_id,"suppliers":suppliers},_branches(db,user,cid),bid)

@router.get("/ap-aging/export/{fmt}", operation_id="ui_ap_aging_export")
def ap_aging_export(fmt:str,as_of_date:str="",branch_id:int|None=None,supplier_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    if fmt not in ("xlsx","pdf"):
        raise HTTPException(404,"صيغة التقرير غير مدعومة")
    cid,bid=_report_ctx(db,user,branch_id)
    try:
        d=datetime.date.fromisoformat(as_of_date) if as_of_date else datetime.date.today()
    except ValueError:
        raise HTTPException(422,"صيغة التاريخ غير صحيحة؛ استخدم YYYY-MM-DD")
    if supplier_id is not None and not db.query(Supplier).filter(Supplier.id==supplier_id,Supplier.company_id==cid).first():
        raise HTTPException(404,"المورد غير موجود ضمن الشركة الحالية")
    rows=ap_aging(db,cid,d,bid,supplier_id)
    headers=["المورد","رقم الفاتورة","تاريخ الفاتورة","تاريخ الاستحقاق","أصل المديونية","المدفوع","المرتجع","المتبقي","أيام التأخير","شريحة العمر"]
    data=[(r["supplier_name"],r["invoice_number"],r["invoice_date"],r["due_date"],r["original"],r["paid"],r["returned"],r["outstanding"],r["overdue_days"],r["bucket"]) for r in rows]
    data.append(("","الإجمالي","","",sum((r["original"] for r in rows),0),sum((r["paid"] for r in rows),0),sum((r["returned"] for r in rows),0),sum((r["outstanding"] for r in rows),0),"",""))
    if fmt=="xlsx": return excel_response("Accounts Payable Aging",headers,data,"ap_aging.xlsx")
    return pdf_response("Accounts Payable Aging",headers,data,"ap_aging.pdf")

@router.get("/project-profitability", response_class=HTMLResponse)
def project_profitability_page(request:Request,project_id:int|None=None,branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid,bid=_report_ctx(db,user,branch_id)
    q_projects=db.query(Project).filter(Project.company_id==cid)
    if bid is not None:
        q_projects=q_projects.filter(Project.branch_id==bid)
    projects=q_projects.order_by(Project.code).all()
    rows=[]
    for p in projects:
        r=project_profitability(db,cid,p.id)
        rows.append({"project":p,**r})
    selected=next((r for r in rows if project_id and r["project"].id==project_id),None)
    summary={
        "المشاريع":len(rows),
        "إجمالي الميزانية":sum((r["budget"] for r in rows),0),
        "إجمالي الالتزامات":sum((r["commitment"] for r in rows),0),
        "إجمالي التكلفة الفعلية":sum((r["actual"] for r in rows),0),
        "إجمالي الإيراد المعتمد":sum((r["certified_revenue"] for r in rows),0),
        "إجمالي الربح الفعلي":sum((r["actual_profit"] for r in rows),0),
        "إجمالي EAC":sum((r["eac"] for r in rows),0),
        "إجمالي الربح المتوقع":sum((r["forecast_profit"] for r in rows),0),
    }
    return _render_report(request,"project_profitability_report.html",user,"ربحية المشاريع",
        {"rows":rows,"selected":selected,"summary":summary},_branches(db,user,cid),bid)

@router.get("/project-profitability/export/{fmt}", operation_id="ui_project_profitability_export")
def project_profitability_export(fmt:str,project_id:int|None=None,branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    if fmt not in ("xlsx","pdf"):
        raise HTTPException(404,"صيغة التقرير غير مدعومة")
    cid,bid=_report_ctx(db,user,branch_id)
    q_projects=db.query(Project).filter(Project.company_id==cid)
    if bid is not None:
        q_projects=q_projects.filter(Project.branch_id==bid)
    if project_id is not None:
        q_projects=q_projects.filter(Project.id==project_id)
    projects=q_projects.order_by(Project.code).all()
    if project_id is not None and not projects:
        raise HTTPException(404,"المشروع غير موجود ضمن نطاق الشركة/الفرع الحالي")
    headers=["المشروع","الميزانية","الالتزامات","التكلفة الفعلية","ETC","EAC","الإيراد المعتمد","الربح الفعلي","الهامش الفعلي %","الربح المتوقع","الهامش المتوقع %","انحراف EAC عن الميزانية"]
    data=[]
    for p in projects:
        r=project_profitability(db,cid,p.id)
        data.append((p.code+" — "+p.name,r["budget"],r["commitment"],r["actual"],r["forecast_etc"],r["eac"],r["certified_revenue"],r["actual_profit"],r["actual_margin_pct"],r["forecast_profit"],r["forecast_margin_pct"],r["variance_at_completion"]))
    if fmt=="xlsx": return excel_response("Project Profitability",headers,data,"project_profitability.xlsx")
    return pdf_response("Project Profitability",headers,data,"project_profitability.pdf")

@router.get("/budget-vs-actual", response_class=HTMLResponse, operation_id="ui_budget_vs_actual")
def budget_vs_actual_page(request:Request,budget_id:int|None=None,branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    cid,bid=_report_ctx(db,user,branch_id)
    bq=db.query(Budget).filter(Budget.company_id==cid)
    if bid is not None: bq=bq.filter((Budget.branch_id==bid)|(Budget.branch_id.is_(None)))
    budgets=bq.order_by(Budget.fiscal_year.desc(),Budget.code).all()
    report=None
    if budget_id is not None:
        bcheck=bq.filter(Budget.id==budget_id).first()
        if not bcheck: raise HTTPException(404,"الموازنة غير موجودة ضمن نطاق الشركة/الفرع الحالي")
        try: report=budget_vs_actual(db,cid,budget_id,bid)
        except ValueError as exc: raise HTTPException(422,str(exc))
    summary=report["summary"] if report else {"budget":0,"actual":0,"forecast":0,"variance":0,"forecast_variance":0}
    return _render_report(request,"budget_actual_report.html",user,"الموازنة مقابل الفعلي",
                          {"budgets":budgets,"budget_id":budget_id,"report":report,"rows":report["rows"] if report else [],
                           "summary":summary,"exceptions":report["exceptions"] if report else []},_branches(db,user,cid),bid)

@router.get("/budget-vs-actual/export/{fmt}", operation_id="ui_budget_vs_actual_export")
def budget_vs_actual_export(fmt:str,budget_id:int,branch_id:int|None=None,db:Session=Depends(get_db),user:User=Depends(require_module("accounting"))):
    if fmt not in ("xlsx","pdf"): raise HTTPException(404,"صيغة التقرير غير مدعومة")
    cid,bid=_report_ctx(db,user,branch_id)
    try: report=budget_vs_actual(db,cid,budget_id,bid)
    except ValueError as exc: raise HTTPException(404,str(exc))
    headers=["الفترة","الحساب","مركز التكلفة","الموازنة","الفعلي","التوقع","انحراف فعلي","انحراف توقع","الحالة"]
    data=[(r["period"],f'{r["account_code"]} — {r["account_name"]}',r["cost_center_name"] or "—",r["budget"],r["actual"],r["forecast"],r["variance"],r["forecast_variance"],r["status"]) for r in report["rows"]]
    if fmt=="xlsx": return excel_response("Budget vs Actual",headers,data,"budget_vs_actual.xlsx")
    return pdf_response("Budget vs Actual",headers,data,"budget_vs_actual.pdf")

def _audit_query(db, cid, start_date, end_date, action="", entity_type="", user_id=None, search="", branch_id=None):
    s, e = _dates(start_date, end_date)
    q = db.query(GovernanceAuditLog).filter(
        GovernanceAuditLog.company_id == cid,
        GovernanceAuditLog.created_at >= datetime.datetime.combine(s, datetime.time.min),
        GovernanceAuditLog.created_at < datetime.datetime.combine(e + datetime.timedelta(days=1), datetime.time.min),
    )
    if branch_id is not None:
        q = q.filter(GovernanceAuditLog.branch_id == branch_id)
    if action:
        q = q.filter(GovernanceAuditLog.action == action)
    if entity_type:
        q = q.filter(GovernanceAuditLog.entity_type.ilike(f"%{entity_type}%"))
    if user_id is not None:
        q = q.filter(GovernanceAuditLog.user_id == user_id)
    if search:
        term = f"%{search.strip()}%"
        q = q.filter(or_(GovernanceAuditLog.entity_id.ilike(term), GovernanceAuditLog.reason.ilike(term), GovernanceAuditLog.request_id.ilike(term)))
    return q, s, e


def _audit_branches(db, user, cid):
    return _branches(db, user, cid)


@router.get("/audit", response_class=HTMLResponse, operation_id="ui_audit_log")
def audit_page(request:Request, start_date:str="", end_date:str="", action:str="", entity_type:str="", user_id:int|None=None, search:str="", branch_id:int|None=None, page:int=1, db:Session=Depends(get_db), user:User=Depends(require_module("audit"))):
    cid = _cid(db, user)
    bid = _branch(db, user, cid, branch_id)
    q, s, e = _audit_query(db, cid, start_date, end_date, action, entity_type, user_id, search, bid)
    page = max(1, page); per_page = 50
    total = q.count()
    logs = q.order_by(GovernanceAuditLog.id.desc()).offset((page - 1) * per_page).limit(per_page).all()
    user_q = db.query(User).join(GovernanceAuditLog, User.id == GovernanceAuditLog.user_id, isouter=True).filter(GovernanceAuditLog.company_id == cid)
    if bid is not None:
        user_q = user_q.filter(GovernanceAuditLog.branch_id == bid)
    users = user_q.distinct().order_by(User.full_name).all()
    dim_q = db.query(GovernanceAuditLog).filter(GovernanceAuditLog.company_id == cid)
    if bid is not None:
        dim_q = dim_q.filter(GovernanceAuditLog.branch_id == bid)
    actions = [x[0] for x in dim_q.with_entities(GovernanceAuditLog.action).distinct().order_by(GovernanceAuditLog.action).all()]
    entities = [x[0] for x in dim_q.with_entities(GovernanceAuditLog.entity_type).distinct().order_by(GovernanceAuditLog.entity_type).all()]
    return templates.TemplateResponse(request, "audit_v2.html", {
        "user":user,"logs":logs,"users":users,"actions":actions,"entities":entities,
        "branches":_audit_branches(db,user,cid),"branch_id":bid,"start_date":s,"end_date":e,
        "action":action,"entity_type":entity_type,"user_id":user_id,"search":search,
        "page":page,"pages":max(1,(total+per_page-1)//per_page),"total":total,
    })


def _audit_export_rows(db, cid, start_date, end_date, action="", entity_type="", user_id=None, search="", branch_id=None):
    q, s, e = _audit_query(db, cid, start_date, end_date, action, entity_type, user_id, search, branch_id)
    return q.order_by(GovernanceAuditLog.id.desc()).all(), s, e


@router.get("/audit/export.csv", operation_id="ui_audit_export")
def audit_export_csv(request: Request, start_date: str = "", end_date: str = "", action: str = "", entity_type: str = "", user_id: int | None = None, search: str = "", branch_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(require_module("audit"))):
    cid = _cid(db, user); bid = _branch(db, user, cid, branch_id)
    rows, s, e = _audit_export_rows(db, cid, start_date, end_date, action, entity_type, user_id, search, bid)
    buf = io.StringIO(); writer = csv.writer(buf)
    writer.writerow(["id","created_at","user_id","company_id","branch_id","request_id","action","entity_type","entity_id","ip_address","reason"])
    for x in rows:
        writer.writerow([x.id, x.created_at.isoformat(), x.user_id or "", x.company_id or "", x.branch_id or "", x.request_id or "", x.action, x.entity_type, x.entity_id or "", x.ip_address or "", x.reason or ""])
    return StreamingResponse(iter([buf.getvalue().encode("utf-8-sig")]), media_type="text/csv", headers={"Content-Disposition":"attachment; filename=audit-log.csv"})


@router.get("/audit/export/{fmt}", operation_id="ui_audit_export_structured")
def audit_export(fmt:str, start_date:str="", end_date:str="", action:str="", entity_type:str="", user_id:int|None=None, search:str="", branch_id:int|None=None, db:Session=Depends(get_db), user:User=Depends(require_module("audit"))):
    if fmt not in ("xlsx", "pdf"):
        raise HTTPException(404, "صيغة التقرير غير مدعومة")
    cid = _cid(db, user); bid = _branch(db, user, cid, branch_id)
    rows, s, e = _audit_export_rows(db, cid, start_date, end_date, action, entity_type, user_id, search, bid)
    headers=["ID","التاريخ","المستخدم","الفرع","الطلب","العملية","الكيان","Record","IP","السبب"]
    data=[(x.id, x.created_at.isoformat(), x.user.full_name if x.user else "-", x.branch_id or "شركة", x.request_id or "-", x.action, x.entity_type, x.entity_id or "-", x.ip_address or "-", x.reason or "-") for x in rows]
    if fmt == "xlsx":
        return excel_response("Enterprise Audit Log", headers, data, "enterprise_audit_log.xlsx")
    return pdf_response("Enterprise Audit Log", headers, data, "enterprise_audit_log.pdf")


@router.get("/audit/{audit_id}", response_class=HTMLResponse, operation_id="ui_audit_detail")
def audit_detail(audit_id:int, request:Request, db:Session=Depends(get_db), user:User=Depends(require_module("audit"))):
    cid = _cid(db, user)
    log = db.query(GovernanceAuditLog).filter(GovernanceAuditLog.id == audit_id, GovernanceAuditLog.company_id == cid).first()
    if not log:
        raise HTTPException(404, "سجل التدقيق غير موجود")
    return templates.TemplateResponse(request, "audit_detail.html", {"user":user,"log":log})
