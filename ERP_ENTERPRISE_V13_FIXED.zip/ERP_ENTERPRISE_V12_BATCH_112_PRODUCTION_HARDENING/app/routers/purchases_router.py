# -*- coding: utf-8 -*-
from fastapi import APIRouter, Depends, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import func, or_
from sqlalchemy.exc import IntegrityError
import csv
import io
from decimal import Decimal, InvalidOperation

from ..database import get_db
from ..models import (Supplier, PurchaseOrder, PurchaseOrderLine, Item, ItemTypeEnum,
                       StockMovement, MovementTypeEnum, User, ModulePermission, PurchaseReceipt, AuditLog, PurchaseInvoice)
from ..accounting import next_number, create_entry, D, money
from ..deep_transactions import receive_purchase_order
from ..governance import get_request_context
from ..workflows import request_approval
from ..construction_services import create_commitment
from ..enterprise_models import Project
from ..warehouse_models import Warehouse
from ..auth import require_module
from .inventory_router import compute_stock

router = APIRouter(prefix="/purchases")
templates = Jinja2Templates(directory="templates")


def _has_edit(db: Session, user: User, module_key: str) -> bool:
    if user.role.value == "admin":
        return True
    perm = db.query(ModulePermission).filter_by(user_id=user.id, module_key=module_key).first()
    return bool(perm and perm.can_edit)


def _next_po_number(db: Session) -> str:
    return next_number(db, "purchase_order", "PO")


# --------------------------------------------------------------- موردين
@router.get("/suppliers", response_class=HTMLResponse)
def supplier_list(request: Request, q: str = "", page: int = 1, status: str = "active",
                  db: Session = Depends(get_db), user: User = Depends(require_module("purchases"))):
    """Tenant-safe, paginated supplier master view.

    Deliberately excludes banking fields from the list and never uses an
    unbounded .all(); supplier master data is operationally sensitive and can
    grow large in enterprise tenants.
    """
    company_id = get_request_context().get("company_id")
    if not company_id:
        raise HTTPException(403, "سياق الشركة غير محدد")
    page = max(1, min(page, 100000))
    page_size = 50
    status = status if status in {"active", "inactive", "all"} else "active"
    query = db.query(Supplier).filter(Supplier.company_id == company_id)
    if status == "active":
        query = query.filter(Supplier.is_active.is_(True))
    elif status == "inactive":
        query = query.filter(Supplier.is_active.is_(False))
    q = (q or "").strip()
    if q:
        like = f"%{q}%"
        query = query.filter(or_(Supplier.code.ilike(like), Supplier.name.ilike(like),
                                 Supplier.tax_number.ilike(like), Supplier.registration_number.ilike(like)))
    total_count = query.count()
    suppliers = query.order_by(Supplier.name.asc(), Supplier.id.asc()).offset((page - 1) * page_size).limit(page_size).all()
    supplier_ids = [s.id for s in suppliers]
    po_counts = {}
    invoice_counts = {}
    if supplier_ids:
        po_counts = {sid: n for sid, n in db.query(PurchaseOrder.supplier_id, func.count(PurchaseOrder.id)).filter(
            PurchaseOrder.company_id == company_id, PurchaseOrder.supplier_id.in_(supplier_ids)
        ).group_by(PurchaseOrder.supplier_id).all()}
        invoice_counts = {sid: n for sid, n in db.query(PurchaseInvoice.supplier_id, func.count(PurchaseInvoice.id)).filter(
            PurchaseInvoice.company_id == company_id, PurchaseInvoice.supplier_id.in_(supplier_ids)
        ).group_by(PurchaseInvoice.supplier_id).all()}
    rows = [{"supplier": s, "po_count": po_counts.get(s.id, 0), "invoice_count": invoice_counts.get(s.id, 0)} for s in suppliers]
    total_active = db.query(func.count(Supplier.id)).filter(Supplier.company_id == company_id, Supplier.is_active.is_(True)).scalar() or 0
    total_inactive = db.query(func.count(Supplier.id)).filter(Supplier.company_id == company_id, Supplier.is_active.is_(False)).scalar() or 0
    has_next = page * page_size < total_count
    can_edit = _has_edit(db, user, "purchases")
    return templates.TemplateResponse(request, "supplier_list.html", {
        "user": user, "rows": rows, "q": q, "status": status, "page": page,
        "page_size": page_size, "total_count": total_count, "has_next": has_next,
        "total_active": total_active, "total_inactive": total_inactive, "can_edit": can_edit
    })


def _supplier_or_404(db: Session, supplier_id: int):
    cid = get_request_context().get("company_id")
    if not cid:
        raise HTTPException(403, "سياق الشركة غير محدد")
    supplier = db.query(Supplier).filter(Supplier.id == supplier_id, Supplier.company_id == cid).first()
    if not supplier:
        raise HTTPException(404, "المورد غير موجود")
    return supplier


def _masked(value: str | None, visible: int = 4) -> str | None:
    if not value:
        return None
    value = str(value)
    return "*" * max(0, len(value) - visible) + value[-visible:]


def _clean_supplier_payload(code, name, phone, email, address, legal_name, supplier_type, contact_person,
                            tax_number, registration_number, country, city, postal_code, payment_terms_days,
                            preferred_payment_method, currency_code, credit_limit, bank_name, bank_account_name,
                            bank_account_number, iban, swift_code):
    import re
    code = (code or "").strip().upper(); name = (name or "").strip(); email = (email or "").strip().lower()
    if not re.fullmatch(r"[A-Z0-9][A-Z0-9._/-]{1,29}", code): raise HTTPException(422, "كود المورد يجب أن يكون من 2 إلى 30 حرفًا/رقمًا بدون مسافات")
    if len(name) < 2 or len(name) > 150: raise HTTPException(422, "اسم المورد يجب أن يكون بين 2 و150 حرفًا")
    if email and (len(email) > 100 or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email)): raise HTTPException(422, "البريد الإلكتروني غير صحيح")
    try: terms=int(payment_terms_days or 0); limit=Decimal(str(credit_limit or "0"))
    except (ValueError, InvalidOperation): raise HTTPException(422, "بيانات الائتمان أو شروط الدفع غير صحيحة")
    if terms < 0 or terms > 3650 or not limit.is_finite() or limit < 0: raise HTTPException(422, "شروط الدفع أو الحد الائتماني خارج النطاق المسموح")
    currency=(currency_code or "EGP").strip().upper()
    if not re.fullmatch(r"[A-Z]{3}", currency): raise HTTPException(422, "رمز العملة يجب أن يكون ISO من 3 أحرف")
    supplier_type=(supplier_type or "company").strip().lower()
    if supplier_type not in {"company","individual","contractor","manufacturer","service_provider"}: raise HTTPException(422, "نوع المورد غير صالح")
    return dict(code=code,name=name,phone=(phone or "").strip() or None,email=email or None,address=(address or "").strip() or None,legal_name=(legal_name or "").strip() or None,supplier_type=supplier_type,contact_person=(contact_person or "").strip() or None,tax_number=(tax_number or "").strip() or None,registration_number=(registration_number or "").strip() or None,country=(country or "").strip() or None,city=(city or "").strip() or None,postal_code=(postal_code or "").strip() or None,payment_terms_days=terms,preferred_payment_method=(preferred_payment_method or "").strip() or None,currency_code=currency,credit_limit=limit,bank_name=(bank_name or "").strip() or None,bank_account_name=(bank_account_name or "").strip() or None,bank_account_number=(bank_account_number or "").strip() or None,iban=(iban or "").replace(" ","").strip() or None,swift_code=(swift_code or "").strip().upper() or None)

@router.get("/suppliers/new", response_class=HTMLResponse)
def new_supplier_form(request: Request, user: User = Depends(require_module("purchases", need_edit=True))):
    return templates.TemplateResponse(request, "supplier_form.html", {"request": request, "user": user, "supplier": None, "errors": []})

@router.post("/suppliers/new")
def create_supplier(db: Session = Depends(get_db), user: User = Depends(require_module("purchases", need_edit=True)),
    code: str = Form(...), name: str = Form(...), phone: str = Form(""), email: str = Form(""), address: str = Form(""),
    legal_name: str = Form(""), supplier_type: str = Form("company"), contact_person: str = Form(""),
    tax_number: str = Form(""), registration_number: str = Form(""), country: str = Form(""), city: str = Form(""), postal_code: str = Form(""),
    payment_terms_days: str = Form("0"), preferred_payment_method: str = Form(""), currency_code: str = Form("EGP"), credit_limit: str = Form("0"),
    bank_name: str = Form(""), bank_account_name: str = Form(""), bank_account_number: str = Form(""), iban: str = Form(""), swift_code: str = Form("")):
    data=_clean_supplier_payload(code,name,phone,email,address,legal_name,supplier_type,contact_person,tax_number,registration_number,country,city,postal_code,payment_terms_days,preferred_payment_method,currency_code,credit_limit,bank_name,bank_account_name,bank_account_number,iban,swift_code)
    cid=get_request_context().get("company_id")
    if not cid: raise HTTPException(403, "سياق الشركة غير محدد")
    if db.query(Supplier).filter(Supplier.company_id==cid, func.lower(Supplier.code)==data["code"].lower()).first(): raise HTTPException(409,"كود المورد مستخدم بالفعل داخل الشركة الحالية")
    if data["tax_number"] and db.query(Supplier).filter(Supplier.company_id==cid, Supplier.tax_number==data["tax_number"]).first(): raise HTTPException(409,"الرقم الضريبي مستخدم بالفعل داخل الشركة الحالية")
    s=Supplier(company_id=cid,**data)
    try:
        db.add(s); db.flush(); db.add(AuditLog(user_id=user.id,action="create",entity_type="supplier",entity_id=s.id,description=f"إنشاء مورد {s.code} - {s.name}")); db.commit()
    except IntegrityError:
        db.rollback(); raise HTTPException(409,"تعذر حفظ المورد بسبب تعارض بيانات فريدة")
    return RedirectResponse(url="/purchases/suppliers",status_code=303)

@router.get("/suppliers/{supplier_id}", response_class=HTMLResponse)
def supplier_detail(supplier_id: int, request: Request, db: Session = Depends(get_db),
                    user: User = Depends(require_module("purchases"))):
    supplier = _supplier_or_404(db, supplier_id)
    cid = get_request_context().get("company_id")
    pos = db.query(PurchaseOrder).filter(PurchaseOrder.company_id == cid, PurchaseOrder.supplier_id == supplier.id).order_by(PurchaseOrder.id.desc()).limit(50).all()
    invoices = db.query(PurchaseInvoice).filter(PurchaseInvoice.company_id == cid, PurchaseInvoice.supplier_id == supplier.id).order_by(PurchaseInvoice.id.desc()).limit(50).all()
    po_total = sum((p.total for p in pos), Decimal("0"))
    invoice_total = sum((i.total_amount or Decimal("0") for i in invoices), Decimal("0"))
    can_edit = _has_edit(db, user, "purchases")
    return templates.TemplateResponse(request, "supplier_detail.html", {
        "request": request, "user": user, "supplier": supplier, "pos": pos, "invoices": invoices,
        "po_total": po_total, "invoice_total": invoice_total, "can_edit": can_edit,
        "masked_account": _masked(supplier.bank_account_number), "masked_iban": _masked(supplier.iban, 4),
    })


@router.get("/suppliers/{supplier_id}/edit", response_class=HTMLResponse)
def edit_supplier_form(supplier_id: int, request: Request, db: Session = Depends(get_db),
                       user: User = Depends(require_module("purchases", need_edit=True))):
    supplier = _supplier_or_404(db, supplier_id)
    return templates.TemplateResponse(request, "supplier_form.html", {"request": request, "user": user, "supplier": supplier, "errors": []})


@router.post("/suppliers/{supplier_id}/edit")
def update_supplier(supplier_id: int, db: Session = Depends(get_db), user: User = Depends(require_module("purchases", need_edit=True)),
    name: str = Form(...), phone: str = Form(""), email: str = Form(""), address: str = Form(""),
    legal_name: str = Form(""), supplier_type: str = Form("company"), contact_person: str = Form(""),
    tax_number: str = Form(""), registration_number: str = Form(""), country: str = Form(""), city: str = Form(""), postal_code: str = Form(""),
    payment_terms_days: str = Form("0"), preferred_payment_method: str = Form(""), currency_code: str = Form("EGP"), credit_limit: str = Form("0"),
    bank_name: str = Form(""), bank_account_name: str = Form(""), bank_account_number: str = Form(""), iban: str = Form(""), swift_code: str = Form("")):
    supplier = _supplier_or_404(db, supplier_id)
    data = _clean_supplier_payload(supplier.code, name, phone, email, address, legal_name, supplier_type, contact_person,
        tax_number, registration_number, country, city, postal_code, payment_terms_days, preferred_payment_method,
        currency_code, credit_limit, bank_name, bank_account_name, bank_account_number, iban, swift_code)
    cid = get_request_context().get("company_id")
    if not cid: raise HTTPException(403, "سياق الشركة غير محدد")
    has_financial_history = db.query(PurchaseInvoice.id).filter(PurchaseInvoice.company_id == cid, PurchaseInvoice.supplier_id == supplier.id).first() is not None
    if has_financial_history and data["currency_code"] != supplier.currency_code:
        raise HTTPException(409, "لا يمكن تغيير عملة المورد بعد وجود فواتير شراء؛ استخدم موردًا جديدًا أو إعدادًا متعدد العملات معتمدًا")
    if data["tax_number"] and db.query(Supplier).filter(Supplier.company_id == cid, Supplier.tax_number == data["tax_number"], Supplier.id != supplier.id).first():
        raise HTTPException(409, "الرقم الضريبي مستخدم بالفعل داخل الشركة الحالية")
    for key, value in data.items():
        setattr(supplier, key, value)
    try:
        db.add(AuditLog(user_id=user.id, action="update", entity_type="supplier", entity_id=supplier.id,
                        description=f"تعديل بيانات المورد {supplier.code} - {supplier.name}"))
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "تعذر حفظ المورد بسبب تعارض بيانات فريدة")
    return RedirectResponse(url=f"/purchases/suppliers/{supplier.id}", status_code=303)


@router.post("/suppliers/{supplier_id}/toggle-status")
def toggle_supplier_status(supplier_id: int, db: Session = Depends(get_db), user: User = Depends(require_module("purchases", need_edit=True))):
    supplier = _supplier_or_404(db, supplier_id)
    supplier.is_active = not bool(supplier.is_active)
    action = "activate" if supplier.is_active else "deactivate"
    db.add(AuditLog(user_id=user.id, action=action, entity_type="supplier", entity_id=supplier.id,
                    description=f"{'تفعيل' if supplier.is_active else 'إيقاف'} المورد {supplier.code} - {supplier.name}"))
    db.commit()
    return RedirectResponse(url=f"/purchases/suppliers/{supplier.id}", status_code=303)


# ------------------------------------------------------------- أوامر شراء
@router.get("", response_class=HTMLResponse)
def po_list(request: Request, q: str = "", page: int = 1, db: Session = Depends(get_db),
            user: User = Depends(require_module("purchases"))):
    page = max(1, min(page, 100000))
    page_size = 50
    company_id = get_request_context().get("company_id")
    query = db.query(PurchaseOrder).filter(PurchaseOrder.company_id == company_id)
    branch_id = get_request_context().get("branch_id")
    if branch_id is not None:
        query = query.filter(PurchaseOrder.branch_id == branch_id)
    if q:
        like = f"%{q}%"
        query = query.join(Supplier).filter(
            (PurchaseOrder.po_number.ilike(like)) | (Supplier.name.ilike(like))
        )
    total_count = query.count()
    orders = query.order_by(PurchaseOrder.id.desc()).offset((page - 1) * page_size).limit(page_size).all()
    supplier_count = db.query(func.count(Supplier.id)).filter(Supplier.company_id == company_id, Supplier.is_active.is_(True)).scalar() or 0
    # Page total is intentionally labeled as displayed value; the query is bounded for production safety.
    total_value = sum((po.total for po in orders), 0)
    has_next = page * page_size < total_count
    can_edit = _has_edit(db, user, "purchases")
    return templates.TemplateResponse(request, "purchases_list.html", {
        "user": user, "orders": orders, "q": q, "can_edit": can_edit,
        "supplier_count": supplier_count, "total_value": total_value, "page": page, "page_size": page_size, "total_count": total_count, "has_next": has_next
    })


@router.get("/export/csv")
def export_purchase_orders(q: str = "", db: Session = Depends(get_db), user: User = Depends(require_module("purchases"))):
    company_id = get_request_context().get("company_id")
    query = db.query(PurchaseOrder).filter(PurchaseOrder.company_id == company_id)
    branch_id = get_request_context().get("branch_id")
    if branch_id is not None:
        query = query.filter(PurchaseOrder.branch_id == branch_id)
    if q:
        like = f"%{q}%"
        query = query.join(Supplier).filter((PurchaseOrder.po_number.ilike(like)) | (Supplier.name.ilike(like)))
    rows = query.order_by(PurchaseOrder.id.desc()).all()
    out = io.StringIO(); w = csv.writer(out)
    w.writerow(["رقم الأمر", "المورد", "التاريخ", "طريقة الدفع", "الإجمالي"])
    for po in rows: w.writerow([po.po_number, po.supplier.name if po.supplier else "", po.order_date.isoformat() if po.order_date else "", po.payment_method or "", po.total])
    return Response("\ufeff" + out.getvalue(), media_type="text/csv; charset=utf-8", headers={"Content-Disposition":"attachment; filename=purchase_orders.csv"})


@router.get("/new", response_class=HTMLResponse)
def new_po_form(request: Request, db: Session = Depends(get_db),
                 user: User = Depends(require_module("purchases", need_edit=True))):
    suppliers = db.query(Supplier).filter(Supplier.company_id==get_request_context().get("company_id"), Supplier.is_active == True).order_by(Supplier.name).all()
    items = db.query(Item).filter(Item.company_id==get_request_context().get("company_id"), Item.is_active == True).order_by(Item.name).all()
    items_data = [{
        "id": it.id, "code": it.code, "name": it.name, "price": it.purchase_price,
        "is_product": it.item_type == ItemTypeEnum.product,
        "stock": compute_stock(db, it.id) if it.item_type == ItemTypeEnum.product else None
    } for it in items]
    warehouses = db.query(Warehouse).filter(Warehouse.company_id==get_request_context().get("company_id"), Warehouse.is_active.is_(True)).order_by(Warehouse.name).all()
    projects = db.query(Project).filter(Project.company_id==get_request_context().get("company_id")).order_by(Project.name).all()
    return templates.TemplateResponse(request, "po_form.html", {
        "user": user, "suppliers": suppliers, "items_data": items_data, "warehouses": warehouses, "projects": projects
    })


def _parse_po_decimal(value: str, field_name: str) -> Decimal:
    try:
        value = str(value).strip()
        if not value:
            raise InvalidOperation
        d = Decimal(value)
    except (InvalidOperation, ValueError, TypeError):
        raise HTTPException(status_code=422, detail=f"{field_name} غير صالح")
    if not d.is_finite():
        raise HTTPException(status_code=422, detail=f"{field_name} يجب أن يكون رقمًا محدودًا")
    return d


def _validate_po_payment_method(value: str) -> str:
    allowed = {"نقدي", "آجل", "تحويل بنكي", "شيك", "cash", "credit", "bank_transfer", "check"}
    value = (value or "نقدي").strip()
    if value not in allowed:
        raise HTTPException(status_code=422, detail="طريقة الدفع غير صالحة")
    return value


def _ensure_po_commitment(db: Session, po: PurchaseOrder):
    """Create one project cost commitment for an approved PO, idempotently."""
    if not po.project_id or getattr(po, "approval_status", "approved") != "approved":
        return None
    from ..construction_models import ConstructionCommitment
    existing = db.query(ConstructionCommitment).filter(
        ConstructionCommitment.company_id == po.company_id,
        ConstructionCommitment.project_id == po.project_id,
        ConstructionCommitment.source_type == "purchase_order",
        ConstructionCommitment.source_id == po.id,
    ).first()
    if existing:
        return existing
    return create_commitment(
        db, po.company_id, po.project_id,
        f"Purchase Order {po.po_number}",
        po.total,
        (po.order_date.date() if getattr(po.order_date, "date", None) else po.order_date),
        source_type="purchase_order", source_id=po.id,
    )


@router.post("/new")
async def create_po(request: Request, db: Session = Depends(get_db),
                     user: User = Depends(require_module("purchases", need_edit=True))):
    form = await request.form()
    supplier_id = form.get("supplier_id")
    payment_method = _validate_po_payment_method(form.get("payment_method", "نقدي"))
    notes = (form.get("notes", "") or "").strip()
    if len(notes) > 255:
        raise HTTPException(status_code=422, detail="الملاحظات تتجاوز 255 حرفًا")
    try:
        warehouse_id = int(form.get("warehouse_id")) if form.get("warehouse_id") else None
        project_id = int(form.get("project_id")) if form.get("project_id") else None
        supplier_id_int = int(supplier_id) if supplier_id else None
    except (ValueError, TypeError):
        raise HTTPException(status_code=422, detail="معرّف المورد/المخزن/المشروع غير صالح")
    item_ids = form.getlist("item_id[]")
    quantities = form.getlist("quantity[]")
    prices = form.getlist("unit_price[]")

    if not supplier_id_int:
        raise HTTPException(status_code=400, detail="لازم تختار مورد")
    if len(item_ids) != len(quantities) or len(item_ids) != len(prices):
        raise HTTPException(status_code=422, detail="بيانات بنود أمر الشراء غير متطابقة")
    if len(item_ids) > 500:
        raise HTTPException(status_code=422, detail="أمر الشراء يتجاوز الحد الأقصى وهو 500 بند")
    lines_data = []
    seen_items = set()
    for iid, qty, price in zip(item_ids, quantities, prices):
        if not iid and not qty and not price:
            continue
        try:
            item_id = int(iid)
        except (ValueError, TypeError):
            raise HTTPException(status_code=422, detail="معرّف الصنف غير صالح")
        if item_id in seen_items:
            raise HTTPException(status_code=422, detail="لا يمكن تكرار نفس الصنف في أكثر من بند؛ استخدم كمية واحدة لكل صنف")
        seen_items.add(item_id)
        qty_f = _parse_po_decimal(qty, "الكمية")
        price_f = _parse_po_decimal(price or "0", "سعر الوحدة")
        if qty_f <= 0 or price_f < 0:
            raise HTTPException(status_code=422, detail="الكمية يجب أن تكون أكبر من صفر والسعر لا يمكن أن يكون سالبًا")
        if qty_f > Decimal("1000000000000") or price_f > Decimal("1000000000000"):
            raise HTTPException(status_code=422, detail="الكمية أو السعر يتجاوز الحد المسموح")
        lines_data.append((item_id, qty_f, price_f))

    if not lines_data:
        raise HTTPException(status_code=400, detail="لازم تضيف صنف واحد على الأقل بكمية أكبر من صفر")

    ctx = get_request_context()
    company_id = ctx.get("company_id")
    branch_id = ctx.get("branch_id")
    if company_id is None:
        raise HTTPException(status_code=403, detail="Company context is required")
    supplier = db.query(Supplier).filter(Supplier.id == supplier_id_int, Supplier.company_id == company_id, Supplier.is_active.is_(True)).first()
    if not supplier:
        raise HTTPException(status_code=422, detail="المورد غير صالح للشركة الحالية")
    item_ids_valid = {x[0] for x in db.query(Item.id).filter(Item.company_id == company_id, Item.id.in_([x[0] for x in lines_data]), Item.is_active.is_(True)).all()}
    if item_ids_valid != {x[0] for x in lines_data}:
        raise HTTPException(status_code=422, detail="يوجد صنف غير صالح للشركة الحالية")
    if warehouse_id:
        warehouse = db.query(Warehouse).filter(
            Warehouse.id == warehouse_id, Warehouse.company_id == company_id,
            Warehouse.is_active.is_(True)
        ).first()
        if not warehouse:
            raise HTTPException(status_code=422, detail="المخزن غير صالح للشركة الحالية")
        if branch_id is not None and warehouse.branch_id is not None and warehouse.branch_id != branch_id:
            raise HTTPException(status_code=422, detail="المخزن لا يتبع الفرع الحالي")
    if project_id:
        project = db.query(Project).filter(Project.id == project_id, Project.company_id == company_id).first()
        if not project:
            raise HTTPException(status_code=422, detail="المشروع غير صالح للشركة الحالية")
        if branch_id is not None and project.branch_id is not None and project.branch_id != branch_id:
            raise HTTPException(status_code=422, detail="المشروع لا يتبع الفرع الحالي")
    product_item_ids = {x[0] for x in lines_data if db.query(Item.item_type).filter(Item.id == x[0], Item.company_id == company_id).scalar() == ItemTypeEnum.product}
    if product_item_ids and not warehouse_id:
        raise HTTPException(status_code=422, detail="يجب تحديد المخزن المستلم لأوامر شراء الأصناف المخزنية")

    po = PurchaseOrder(
        company_id=company_id, branch_id=branch_id,
        po_number=_next_po_number(db),
        supplier_id=supplier_id_int,
        payment_method=payment_method,
        warehouse_id=warehouse_id, project_id=project_id,
        notes=notes or None,
        created_by_id=user.id,
    )
    db.add(po)
    db.flush()

    for item_id, qty, price in lines_data:
        line = PurchaseOrderLine(company_id=company_id, po_id=po.id, item_id=item_id, quantity=qty,
                                  unit_price=money(price), line_total=money(qty * price))
        db.add(line)
        # أمر الشراء لا يدخل المخزون؛ الاستلام يتم من خلال /receive بعد وصول البضاعة.
        pass

    db.flush()
    approval = request_approval(db, company_id=po.company_id, branch_id=po.branch_id, document_type="purchase_order", document_id=po.id, requested_by_id=user.id, amount=po.total)
    if approval:
        po.approval_status = approval.status
        po.approval_request_id = approval.id
    if po.approval_status == "approved":
        _ensure_po_commitment(db, po)
    db.add(AuditLog(
        user_id=user.id, action="create", entity_type="purchase_order", entity_id=po.id,
        description=f"إنشاء أمر شراء {po.po_number} بقيمة {money(po.total)}"
    ))
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="تعذر حفظ أمر الشراء بسبب تعارض في البيانات؛ أعد المحاولة")
    return RedirectResponse(url=f"/purchases/{po.id}", status_code=303)


@router.post("/{po_id}/receive")
async def receive_po(po_id: int, request: Request, db: Session = Depends(get_db),
                     user: User = Depends(require_module("purchases", need_edit=True))):
    ctx = get_request_context(); company_id = ctx.get("company_id")
    if company_id is None:
        raise HTTPException(status_code=403, detail="Company context is required")
    po = db.query(PurchaseOrder).filter(PurchaseOrder.id == po_id, PurchaseOrder.company_id == company_id).first()
    if not po:
        raise HTTPException(404, "Purchase order not found")
    branch_id = ctx.get("branch_id")
    if branch_id is not None and po.branch_id != branch_id:
        raise HTTPException(403, "Purchase order is outside the current branch")
    if getattr(po, "approval_status", "approved") != "approved":
        raise HTTPException(409, "Purchase order requires approval before receipt")
    form = await request.form()
    quantities = {}
    ids = form.getlist("po_line_id[]"); values = form.getlist("quantity[]")
    for lid, qty in zip(ids, values):
        if lid and qty not in (None, ""):
            try:
                line_id = int(lid)
            except (TypeError, ValueError):
                raise HTTPException(422, "معرّف بند أمر الشراء غير صالح")
            quantities[str(line_id)] = qty
    receipt = receive_purchase_order(db, company_id, po_id, user.id, quantities or None)
    db.commit()
    return RedirectResponse(url=f"/purchases/{po_id}", status_code=303)


@router.get("/{po_id}", response_class=HTMLResponse)
def po_detail(po_id: int, request: Request, db: Session = Depends(get_db),
              user: User = Depends(require_module("purchases"))):
    ctx = get_request_context(); company_id = ctx.get("company_id"); branch_id = ctx.get("branch_id")
    q = db.query(PurchaseOrder).filter(PurchaseOrder.id == po_id, PurchaseOrder.company_id == company_id)
    if branch_id is not None: q = q.filter(PurchaseOrder.branch_id == branch_id)
    po = q.first()
    if not po:
        raise HTTPException(status_code=404, detail="أمر الشراء مش موجود")
    received_by_line = {}
    for receipt in po.receipts:
        for rl in receipt.lines:
            received_by_line[rl.po_line_id] = received_by_line.get(rl.po_line_id, Decimal("0")) + D(rl.quantity)
    remaining_by_line = {l.id: max(D(l.quantity) - received_by_line.get(l.id, Decimal("0")), Decimal("0")) for l in po.lines}
    can_receive = po.approval_status == "approved" and any(v > 0 for v in remaining_by_line.values())
    return templates.TemplateResponse(request, "po_detail.html", {"user": user, "po": po, "remaining_by_line": remaining_by_line, "can_receive": can_receive})
