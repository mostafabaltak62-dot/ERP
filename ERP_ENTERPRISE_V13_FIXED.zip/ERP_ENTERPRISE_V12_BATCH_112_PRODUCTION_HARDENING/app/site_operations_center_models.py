from datetime import date, datetime
from sqlalchemy import Column, Integer, String, Numeric, Date, DateTime, ForeignKey, Text, Boolean, UniqueConstraint, CheckConstraint
from .db_base import Base
from .time_utils import utcnow

class SiteLocationNode(Base):
    __tablename__='site_location_nodes'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    parent_id=Column(Integer, ForeignKey('site_location_nodes.id'))
    code=Column(String(60), nullable=False); name=Column(String(180), nullable=False)
    node_type=Column(String(30), nullable=False) # zone/building/floor/area
    status=Column(String(30), nullable=False, default='active')
    created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint('project_id','code',name='uq_site_location_project_code'),)

class DailySiteReport(Base):
    __tablename__='daily_site_reports'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    report_date=Column(Date, nullable=False); weather=Column(String(80)); status=Column(String(30), default='draft', nullable=False)
    work_summary=Column(Text); constraints=Column(Text); tomorrow_plan=Column(Text); notes=Column(Text)
    prepared_by_id=Column(Integer, ForeignKey('users.id')); approved_by_id=Column(Integer, ForeignKey('users.id'))
    approved_at=Column(DateTime); created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint('company_id','project_id','report_date',name='uq_daily_site_report_project_date'),)

class SiteDiaryEntry(Base):
    __tablename__='site_diary_entries'
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True); event_date=Column(Date, nullable=False)
    event_type=Column(String(40), nullable=False, default='general'); title=Column(String(200), nullable=False); details=Column(Text)
    location_node_id=Column(Integer, ForeignKey('site_location_nodes.id')); created_by_id=Column(Integer, ForeignKey('users.id')); created_at=Column(DateTime, default=utcnow, nullable=False)

class SiteIssue(Base):
    __tablename__='site_issues'
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True); issue_no=Column(String(60), nullable=False)
    title=Column(String(200), nullable=False); description=Column(Text); severity=Column(String(20), default='medium', nullable=False)
    status=Column(String(30), default='open', nullable=False); due_date=Column(Date); location_node_id=Column(Integer, ForeignKey('site_location_nodes.id'))
    assigned_to_id=Column(Integer, ForeignKey('users.id')); created_by_id=Column(Integer, ForeignKey('users.id')); resolved_at=Column(DateTime); created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint('company_id','project_id','issue_no',name='uq_site_issue_no'),)

class SiteOperationsPlan(Base):
    __tablename__='site_operations_plans'
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True); plan_date=Column(Date, nullable=False)
    title=Column(String(200), nullable=False); description=Column(Text); responsible_id=Column(Integer, ForeignKey('users.id'))
    location_node_id=Column(Integer, ForeignKey('site_location_nodes.id')); status=Column(String(30), default='planned', nullable=False)
    created_by_id=Column(Integer, ForeignKey('users.id')); created_at=Column(DateTime, default=utcnow, nullable=False)

class SiteProgressEntry(Base):
    __tablename__='site_progress_entries'
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True); progress_date=Column(Date, nullable=False)
    wbs_node_id=Column(Integer, ForeignKey('construction_wbs_nodes.id')); boq_line_id=Column(Integer, ForeignKey('construction_boq_lines.id'))
    location_node_id=Column(Integer, ForeignKey('site_location_nodes.id')); planned_qty=Column(Numeric(20,6), default=0, nullable=False)
    actual_qty=Column(Numeric(20,6), default=0, nullable=False); notes=Column(Text); created_by_id=Column(Integer, ForeignKey('users.id')); created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(CheckConstraint('planned_qty >= 0 AND actual_qty >= 0',name='ck_site_progress_nonnegative'),)
