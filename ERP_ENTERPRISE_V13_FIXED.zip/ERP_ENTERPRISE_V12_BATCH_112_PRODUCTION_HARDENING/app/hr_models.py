from .time_utils import utcnow
"""Enterprise HR, project labor allocation, and scoped access control."""
import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Date, Numeric, ForeignKey, Text, UniqueConstraint, CheckConstraint, Index
from .db_base import Base

class EmployeeProfile(Base):
    __tablename__ = 'employee_profiles'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    employee_id=Column(Integer, ForeignKey('employees.id', ondelete='CASCADE'), nullable=False, unique=True, index=True)
    branch_id=Column(Integer, ForeignKey('branches.id', ondelete='SET NULL'), nullable=True, index=True)
    user_id=Column(Integer, ForeignKey('users.id', ondelete='SET NULL'), nullable=True, unique=True, index=True)
    manager_employee_id=Column(Integer, ForeignKey('employees.id', ondelete='SET NULL'), nullable=True, index=True)
    job_title=Column(String(150)); job_grade=Column(String(50)); employment_type=Column(String(50), nullable=False, default='full_time')
    employment_status=Column(String(40), nullable=False, default='active')
    termination_date=Column(Date); national_id=Column(String(100)); phone=Column(String(50)); email=Column(String(150)); address=Column(Text)
    basic_salary=Column(Numeric(20,6), nullable=False, default=0); overtime_rate=Column(Numeric(20,6), nullable=False, default=0)
    created_at=Column(DateTime, nullable=False, default=utcnow)

class EmployeeProjectAssignment(Base):
    __tablename__='employee_project_assignments'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    employee_id=Column(Integer, ForeignKey('employees.id', ondelete='CASCADE'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id', ondelete='CASCADE'), nullable=False, index=True)
    site_id=Column(Integer, ForeignKey('construction_sites.id', ondelete='SET NULL'), nullable=True, index=True)
    wbs_id=Column(Integer, ForeignKey('construction_wbs_nodes.id', ondelete='SET NULL'), nullable=True, index=True)
    cost_code_id=Column(Integer, ForeignKey('construction_cost_codes.id', ondelete='SET NULL'), nullable=True, index=True)
    allocation_percent=Column(Numeric(9,6), nullable=False, default=100)
    start_date=Column(Date, nullable=False); end_date=Column(Date); is_primary=Column(Boolean, nullable=False, default=False)
    __table_args__=(UniqueConstraint('employee_id','project_id','site_id','start_date',name='uq_employee_project_assignment'), CheckConstraint('allocation_percent > 0 AND allocation_percent <= 100','ck_employee_assignment_percent'))

class LeaveBalance(Base):
    __tablename__='leave_balances'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    employee_id=Column(Integer, ForeignKey('employees.id', ondelete='CASCADE'), nullable=False, index=True)
    year=Column(Integer, nullable=False); leave_type=Column(String(50), nullable=False)
    entitled_days=Column(Numeric(10,2), nullable=False, default=0); used_days=Column(Numeric(10,2), nullable=False, default=0); carried_days=Column(Numeric(10,2), nullable=False, default=0)
    __table_args__=(UniqueConstraint('employee_id','year','leave_type',name='uq_leave_balance'), CheckConstraint('entitled_days >= 0 AND used_days >= 0 AND carried_days >= 0','ck_leave_balance_nonnegative'))

class PayrollAllocation(Base):
    __tablename__='payroll_allocations'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    payroll_line_id=Column(Integer, ForeignKey('payroll_lines.id', ondelete='CASCADE'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id', ondelete='SET NULL'), nullable=True, index=True)
    site_id=Column(Integer, ForeignKey('construction_sites.id', ondelete='SET NULL'), nullable=True, index=True)
    wbs_id=Column(Integer, ForeignKey('construction_wbs_nodes.id', ondelete='SET NULL'), nullable=True)
    cost_code_id=Column(Integer, ForeignKey('construction_cost_codes.id', ondelete='SET NULL'), nullable=True)
    amount=Column(Numeric(20,6), nullable=False)
    allocation_percent=Column(Numeric(9,6), nullable=False, default=100)
    allocation_method=Column(String(40), nullable=False, default='project_assignment')
    __table_args__=(CheckConstraint('amount >= 0','ck_payroll_allocation_amount'), CheckConstraint('allocation_percent > 0 AND allocation_percent <= 100','ck_payroll_allocation_percent'))

class RoleScope(Base):
    __tablename__='role_scopes'
    id=Column(Integer, primary_key=True)
    role_id=Column(Integer, ForeignKey('roles.id', ondelete='CASCADE'), nullable=False, index=True)
    company_id=Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=True, index=True)
    branch_id=Column(Integer, ForeignKey('branches.id', ondelete='CASCADE'), nullable=True, index=True)
    project_id=Column(Integer, ForeignKey('projects.id', ondelete='CASCADE'), nullable=True, index=True)
    site_id=Column(Integer, ForeignKey('construction_sites.id', ondelete='CASCADE'), nullable=True, index=True)
    scope_type=Column(String(30), nullable=False, default='explicit')
    __table_args__=(UniqueConstraint('role_id','company_id','branch_id','project_id','site_id',name='uq_role_scope'),)

class UserScope(Base):
    __tablename__='user_scopes'
    id=Column(Integer, primary_key=True)
    user_id=Column(Integer, ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    company_id=Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=True, index=True)
    branch_id=Column(Integer, ForeignKey('branches.id', ondelete='CASCADE'), nullable=True, index=True)
    project_id=Column(Integer, ForeignKey('projects.id', ondelete='CASCADE'), nullable=True, index=True)
    site_id=Column(Integer, ForeignKey('construction_sites.id', ondelete='CASCADE'), nullable=True, index=True)
    can_view=Column(Boolean, nullable=False, default=True); can_edit=Column(Boolean, nullable=False, default=False); can_approve=Column(Boolean, nullable=False, default=False)
    __table_args__=(UniqueConstraint('user_id','company_id','branch_id','project_id','site_id',name='uq_user_scope'),)

class RoleApprovalLimit(Base):
    __tablename__='role_approval_limits'
    id=Column(Integer, primary_key=True)
    role_id=Column(Integer, ForeignKey('roles.id', ondelete='CASCADE'), nullable=False, index=True)
    company_id=Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    document_type=Column(String(100), nullable=False, index=True)
    max_amount=Column(Numeric(20,6), nullable=False)
    currency_code=Column(String(3), nullable=False, default='EGP')
    __table_args__=(UniqueConstraint('role_id','company_id','document_type',name='uq_role_approval_limit'), CheckConstraint('max_amount >= 0','ck_role_approval_limit_nonnegative'))

class HRDocument(Base):
    __tablename__='hr_documents'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    employee_id=Column(Integer, ForeignKey('employees.id', ondelete='CASCADE'), nullable=False, index=True)
    document_type=Column(String(80), nullable=False); document_number=Column(String(120)); issue_date=Column(Date); expiry_date=Column(Date); status=Column(String(30), default='active'); notes=Column(Text)
    created_at=Column(DateTime, nullable=False, default=utcnow)

class PerformanceReview(Base):
    __tablename__='performance_reviews'
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); employee_id=Column(Integer,ForeignKey('employees.id',ondelete='CASCADE'),nullable=False,index=True); reviewer_id=Column(Integer,ForeignKey('users.id')); review_date=Column(Date,nullable=False); period_label=Column(String(50),nullable=False); rating=Column(Numeric(5,2),nullable=False); goals=Column(Text); comments=Column(Text); status=Column(String(30),nullable=False,default='draft')
class TrainingRecord(Base):
    __tablename__='training_records'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); employee_id=Column(Integer,ForeignKey('employees.id',ondelete='CASCADE'),nullable=False,index=True); training_name=Column(String(180),nullable=False); provider=Column(String(180)); start_date=Column(Date); end_date=Column(Date); cost=Column(Numeric(20,6),nullable=False,default=0); status=Column(String(30),nullable=False,default='planned'); certificate_expiry=Column(Date); notes=Column(Text)
class PayrollComponent(Base):
    __tablename__='payroll_components'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); employee_id=Column(Integer,ForeignKey('employees.id',ondelete='CASCADE'),nullable=False,index=True); component_type=Column(String(30),nullable=False); code=Column(String(60),nullable=False); name=Column(String(150),nullable=False); amount=Column(Numeric(20,6),nullable=False,default=0); is_recurring=Column(Boolean,nullable=False,default=True); effective_from=Column(Date); effective_to=Column(Date); __table_args__=(UniqueConstraint('employee_id','code','effective_from',name='uq_payroll_component'),)

class DailyWorker(Base):
    """Daily-paid/site labor worker (السركي) who may not be a salaried employee."""
    __tablename__='daily_workers'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    worker_code=Column(String(60), nullable=False)
    name=Column(String(180), nullable=False)
    national_id=Column(String(100))
    phone=Column(String(50))
    trade=Column(String(100))
    worker_type=Column(String(50), nullable=False, default='daily')
    daily_rate=Column(Numeric(20,6), nullable=False, default=0)
    overtime_rate=Column(Numeric(20,6), nullable=False, default=0)
    normal_hours=Column(Numeric(10,2), nullable=False, default=8)
    status=Column(String(30), nullable=False, default='active')
    created_at=Column(DateTime, nullable=False, default=utcnow)
    __table_args__=(UniqueConstraint('company_id','worker_code',name='uq_daily_worker_company_code'), CheckConstraint('daily_rate >= 0','ck_daily_worker_daily_rate'), CheckConstraint('overtime_rate >= 0','ck_daily_worker_ot_rate'), CheckConstraint('normal_hours > 0','ck_daily_worker_normal_hours'))

class DailyLaborEntry(Base):
    """Daily labor attendance/sarky entry and payable calculation."""
    __tablename__='daily_labor_entries'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    worker_id=Column(Integer, ForeignKey('daily_workers.id', ondelete='CASCADE'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id', ondelete='CASCADE'), nullable=False, index=True)
    site_id=Column(Integer, ForeignKey('construction_sites.id', ondelete='SET NULL'), nullable=True, index=True)
    wbs_id=Column(Integer, ForeignKey('construction_wbs_nodes.id', ondelete='SET NULL'), nullable=True, index=True)
    cost_code_id=Column(Integer, ForeignKey('construction_cost_codes.id', ondelete='SET NULL'), nullable=True, index=True)
    boq_line_id=Column(Integer, ForeignKey('construction_boq_lines.id', ondelete='SET NULL'), nullable=True, index=True)
    work_date=Column(Date, nullable=False, index=True)
    check_in=Column(DateTime)
    check_out=Column(DateTime)
    regular_hours=Column(Numeric(10,2), nullable=False, default=0)
    overtime_hours=Column(Numeric(10,2), nullable=False, default=0)
    daily_rate=Column(Numeric(20,6), nullable=False, default=0)
    overtime_rate=Column(Numeric(20,6), nullable=False, default=0)
    regular_amount=Column(Numeric(20,6), nullable=False, default=0)
    overtime_amount=Column(Numeric(20,6), nullable=False, default=0)
    other_amount=Column(Numeric(20,6), nullable=False, default=0)
    deduction_amount=Column(Numeric(20,6), nullable=False, default=0)
    net_amount=Column(Numeric(20,6), nullable=False, default=0)
    status=Column(String(30), nullable=False, default='draft')
    approved_by_id=Column(Integer, ForeignKey('users.id', ondelete='SET NULL'))
    approved_at=Column(DateTime)
    project_cost_id=Column(Integer, ForeignKey('project_costs.id', ondelete='SET NULL'), nullable=True, unique=True)
    notes=Column(Text)
    __table_args__=(UniqueConstraint('worker_id','project_id','work_date',name='uq_daily_labor_worker_project_date'), CheckConstraint('regular_hours >= 0 AND overtime_hours >= 0','ck_daily_labor_hours_nonnegative'), CheckConstraint('daily_rate >= 0 AND overtime_rate >= 0','ck_daily_labor_rates_nonnegative'), CheckConstraint('other_amount >= 0 AND deduction_amount >= 0','ck_daily_labor_adjustments_nonnegative'))

class DailyLaborSettlement(Base):
    """Approved settlement period for daily workers."""
    __tablename__='daily_labor_settlements'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id', ondelete='CASCADE'), nullable=True, index=True)
    period_start=Column(Date, nullable=False)
    period_end=Column(Date, nullable=False)
    status=Column(String(30), nullable=False, default='draft')
    gross_amount=Column(Numeric(20,6), nullable=False, default=0)
    deductions=Column(Numeric(20,6), nullable=False, default=0)
    net_amount=Column(Numeric(20,6), nullable=False, default=0)
    approved_by_id=Column(Integer, ForeignKey('users.id', ondelete='SET NULL'))
    approved_at=Column(DateTime)
    __table_args__=(CheckConstraint('period_end >= period_start','ck_daily_labor_settlement_dates'),)


class EmployeeTimelineEvent(Base):
    __tablename__='employee_timeline_events'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    employee_id=Column(Integer, ForeignKey('employees.id', ondelete='CASCADE'), nullable=False, index=True)
    event_type=Column(String(60), nullable=False, index=True)
    title=Column(String(200), nullable=False)
    event_date=Column(Date, nullable=False, index=True)
    description=Column(Text)
    reference_type=Column(String(80)); reference_id=Column(Integer)
    created_by_id=Column(Integer, ForeignKey('users.id', ondelete='SET NULL'))
    created_at=Column(DateTime, nullable=False, default=utcnow)
