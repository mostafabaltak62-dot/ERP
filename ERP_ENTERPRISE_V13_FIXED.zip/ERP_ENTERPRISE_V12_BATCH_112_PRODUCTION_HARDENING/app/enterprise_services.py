"""Reusable enterprise services: workflow, FX, idempotency, and project controls."""
import hashlib, json
from decimal import Decimal
from datetime import datetime
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from .enterprise_models import WorkflowDefinition, WorkflowStep, WorkflowInstance, WorkflowAction, ExchangeRate, IdempotencyKey, ProjectCost, Project
from .governance import get_request_context


def start_workflow(db: Session, document_type: str, document_id: int, amount: Decimal = Decimal("0")):
    company_id = get_request_context().get("company_id")
    wfq = db.query(WorkflowDefinition)
    if company_id is not None:
        wfq = wfq.filter(WorkflowDefinition.company_id == company_id)
    wf = (wfq.filter(WorkflowDefinition.document_type == document_type, WorkflowDefinition.is_active == True).order_by(WorkflowDefinition.id).first())
    if not wf:
        return None
    existing = db.query(WorkflowInstance).filter(
        WorkflowInstance.company_id == (company_id or wf.company_id),
        WorkflowInstance.document_type == document_type,
        WorkflowInstance.document_id == document_id,
    ).first()
    if existing:
        return existing
    steps = db.query(WorkflowStep).filter_by(workflow_id=wf.id).order_by(WorkflowStep.sequence).all()
    if not steps:
        return None
    for step in steps:
        if step.min_amount is not None and amount < Decimal(str(step.min_amount)):
            continue
        if step.max_amount is not None and amount > Decimal(str(step.max_amount)):
            continue
        instance = WorkflowInstance(company_id=company_id or wf.company_id, branch_id=get_request_context().get("branch_id"), workflow_id=wf.id, document_type=document_type, document_id=document_id, current_step=step.sequence)
        db.add(instance); db.flush(); return instance
    return None


def decide_workflow(db: Session, instance_id: int, user_id: int, approved: bool, reason: str = ""):
    instance = db.query(WorkflowInstance).filter(WorkflowInstance.id == instance_id).with_for_update().first()
    if not instance or instance.status != "pending":
        raise ValueError("Workflow instance is not actionable")
    step = db.query(WorkflowStep).filter_by(workflow_id=instance.workflow_id, sequence=instance.current_step).first()
    if not step:
        raise ValueError("Workflow step not found")
    action = WorkflowAction(company_id=instance.company_id, instance_id=instance.id, step_id=step.id, user_id=user_id, decision="approved" if approved else "rejected", reason=reason)
    db.add(action)
    if not approved:
        instance.status = "rejected"
        return instance
    next_step = db.query(WorkflowStep).filter(WorkflowStep.workflow_id == instance.workflow_id, WorkflowStep.sequence > step.sequence).order_by(WorkflowStep.sequence).first()
    if next_step:
        instance.current_step = next_step.sequence
    else:
        instance.status = "approved"
    db.flush(); return instance


def fx_rate(db: Session, from_currency_id: int, to_currency_id: int, at: datetime):
    if from_currency_id == to_currency_id:
        return Decimal("1")
    row = (db.query(ExchangeRate).filter(ExchangeRate.from_currency_id == from_currency_id, ExchangeRate.to_currency_id == to_currency_id, ExchangeRate.effective_at <= at).order_by(ExchangeRate.effective_at.desc()).first())
    if not row:
        raise ValueError("No historical exchange rate is available")
    return Decimal(str(row.rate))


def request_fingerprint(payload) -> str:
    raw = json.dumps(payload, sort_keys=True, default=str, separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()


def claim_idempotency(db: Session, key: str, user_id: int, endpoint: str, payload):
    if not key or len(key) > 128:
        raise ValueError("A valid idempotency key is required")
    fp = request_fingerprint(payload)
    existing = db.query(IdempotencyKey).filter_by(company_id=get_request_context().get("company_id") or -1, key=key, user_id=user_id, endpoint=endpoint).with_for_update().first()
    if existing:
        if existing.request_hash != fp:
            raise ValueError("Idempotency key was reused with a different request")
        return existing, False
    row = IdempotencyKey(company_id=get_request_context().get("company_id") or -1, key=key, user_id=user_id, endpoint=endpoint, request_hash=fp)
    # The pre-check is fast, but two workers can still race. Use a savepoint so
    # a uniqueness collision does not poison the caller's transaction; then
    # resolve the winner and enforce the same-payload rule.
    try:
        with db.begin_nested():
            db.add(row)
            db.flush()
        return row, True
    except IntegrityError:
        existing = db.query(IdempotencyKey).filter_by(
            company_id=get_request_context().get("company_id") or -1,
            key=key, user_id=user_id, endpoint=endpoint).first()
        if existing is None:
            raise
        if existing.request_hash != fp:
            raise ValueError("Idempotency key was reused with a different request")
        return existing, False


def record_project_cost(db: Session, company_id: int, project_id: int, amount: Decimal, cost_type: str, source_type: str = None, source_id: int = None, description: str = None):
    if amount < 0:
        raise ValueError("Project cost cannot be negative")
    project = db.query(Project).filter(Project.id == project_id, Project.company_id == company_id).first()
    if not project:
        raise ValueError("Project not found")
    row = ProjectCost(company_id=company_id, project_id=project_id, amount=amount, cost_type=cost_type, source_type=source_type, source_id=source_id, description=description)
    db.add(row); db.flush(); return row

# --- Hardened generic workflow ----------------------------------------------------
def create_workflow_definition(db: Session, company_id: int, document_type: str, name: str, steps):
    if not document_type.strip() or not name.strip():
        raise ValueError("Workflow document type and name are required")
    if not steps:
        raise ValueError("Workflow requires at least one step")
    existing = db.query(WorkflowDefinition).filter(
        WorkflowDefinition.company_id == company_id,
        WorkflowDefinition.document_type == document_type,
        WorkflowDefinition.is_active.is_(True)).first()
    if existing:
        raise ValueError("An active workflow already exists for this document type")
    wf = WorkflowDefinition(company_id=company_id, document_type=document_type.strip(), name=name.strip(), is_active=True)
    db.add(wf); db.flush()
    seen = set()
    for item in steps:
        seq = int(item["sequence"]); perm = str(item["required_permission"] or "").strip()
        if seq in seen or seq < 1 or not perm:
            raise ValueError("Workflow steps must have unique positive sequences and permissions")
        seen.add(seq)
        db.add(WorkflowStep(company_id=company_id, workflow_id=wf.id, sequence=seq,
                            name=str(item.get("name") or f"Step {seq}"), required_permission=perm,
                            min_amount=item.get("min_amount"), max_amount=item.get("max_amount")))
    db.flush(); return wf


def decide_workflow_hardened(db: Session, instance_id: int, user_id: int, approved: bool,
                             reason: str = "", has_permission=None):
    from .governance import get_request_context
    instance = (db.query(WorkflowInstance)
                .filter(WorkflowInstance.id == instance_id,
                        WorkflowInstance.company_id == get_request_context().get("company_id"))
                .with_for_update().first())
    if not instance or instance.status != "pending":
        raise ValueError("Workflow instance is not actionable")
    step = db.query(WorkflowStep).filter_by(workflow_id=instance.workflow_id, sequence=instance.current_step).first()
    if not step:
        raise ValueError("Workflow step not found")
    if has_permission and not has_permission(step.required_permission):
        raise ValueError(f"Missing approval permission: {step.required_permission}")
    prior = db.query(WorkflowAction).filter_by(instance_id=instance.id, step_id=step.id, user_id=user_id).first()
    if prior:
        raise ValueError("User has already acted on this workflow step")
    action = WorkflowAction(company_id=instance.company_id, instance_id=instance.id, step_id=step.id,
                            user_id=user_id, decision="approved" if approved else "rejected", reason=reason)
    db.add(action)
    if not approved:
        instance.status = "rejected"
    else:
        next_step = (db.query(WorkflowStep)
                     .filter(WorkflowStep.workflow_id == instance.workflow_id,
                             WorkflowStep.sequence > step.sequence)
                     .order_by(WorkflowStep.sequence).first())
        if next_step: instance.current_step = next_step.sequence
        else: instance.status = "approved"
    db.flush(); return instance
