from .time_utils import utcnow
"""Production Celery application entry point for ERP background work.
Run worker: celery -A app.celery_app.celery worker --loglevel=INFO
Run beat:   celery -A app.celery_app.celery beat --loglevel=INFO
"""
import datetime
import os
from decimal import Decimal
from celery import Celery
from .celery_security import tenant_task_context
from .core_settings import redis_connection_url

celery = Celery(
    "erp",
    broker=os.getenv("CELERY_BROKER_URL", "").strip() or redis_connection_url(0) or "redis://localhost:6379/0",
    backend=os.getenv("CELERY_RESULT_BACKEND", "").strip() or redis_connection_url(1) or "redis://localhost:6379/1",
)
celery.conf.update(
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    worker_prefetch_multiplier=1,
    task_track_started=True,
    timezone="UTC",
    beat_schedule={
        "monthly-depreciation-dispatch": {"task": "erp.dispatch_monthly_depreciation", "schedule": 60 * 60 * 24},
        "recurring-journals-dispatch": {"task": "erp.dispatch_recurring_journals", "schedule": 60 * 60 * 24},
        "inventory-valuation-dispatch": {"task": "erp.dispatch_inventory_valuation", "schedule": 60 * 60 * 24},
        "refresh-reporting-views": {"task": "erp.refresh_reporting_views", "schedule": 60 * 60, "args": ()},
    },
)

def _admin_id(db):
    from .models import User, RoleEnum
    u = db.query(User).filter(User.role == RoleEnum.admin, User.is_active.is_(True)).order_by(User.id).first()
    return u.id if u else None

def _active_company_ids(db):
    from .models import Company
    query = db.query(Company.id)
    if hasattr(Company, "is_active"):
        query = query.filter(Company.is_active.is_(True))
    return [row[0] for row in query.order_by(Company.id).all()]


@celery.task(name="erp.dispatch_monthly_depreciation")
def dispatch_monthly_depreciation(period=None):
    from .database import SessionLocal
    db = SessionLocal()
    try:
        company_ids = _active_company_ids(db)
    finally:
        db.close()
    for company_id in company_ids:
        monthly_depreciation.delay(company_id, period)
    return {"status": "queued", "companies": len(company_ids)}


@celery.task(name="erp.dispatch_recurring_journals")
def dispatch_recurring_journals(as_of=None):
    from .database import SessionLocal
    db = SessionLocal()
    try:
        company_ids = _active_company_ids(db)
    finally:
        db.close()
    for company_id in company_ids:
        recurring_journals.delay(company_id, as_of)
    return {"status": "queued", "companies": len(company_ids)}


@celery.task(name="erp.dispatch_inventory_valuation")
def dispatch_inventory_valuation(as_of=None):
    from .database import SessionLocal
    db = SessionLocal()
    try:
        company_ids = _active_company_ids(db)
    finally:
        db.close()
    for company_id in company_ids:
        inventory_valuation.delay(company_id, as_of)
    return {"status": "queued", "companies": len(company_ids)}


@celery.task(name="erp.monthly_depreciation")
def monthly_depreciation(company_id=None, period=None):
    if company_id is None:
        return {"status": "skipped", "reason": "company_id_required"}
    from .database import SessionLocal
    from .models import FixedAsset
    from .governance_models import AssetDepreciationRun
    from .accounting import create_entry, money
    db = SessionLocal()
    period_label = period or utcnow().strftime("%Y-%m")
    try:
        with tenant_task_context(company_id, request_id=f"celery:depreciation:{company_id}:{period_label}"):
            user_id = _admin_id(db)
            if not user_id:
                return {"status": "skipped", "reason": "no_admin_user"}
            posted = 0
            for asset in db.query(FixedAsset).filter(FixedAsset.company_id == company_id, FixedAsset.is_active.is_(True)).all():
                if db.query(AssetDepreciationRun).filter_by(asset_id=asset.id, period_label=period_label).first():
                    continue
                monthly = money((asset.acquisition_cost - asset.residual_value) / asset.useful_life_months)
                remaining = money(asset.acquisition_cost - asset.residual_value - asset.accumulated_depreciation)
                amount = min(monthly, remaining)
                if amount <= 0:
                    asset.is_active = False
                    continue
                run = AssetDepreciationRun(company_id=asset.company_id, asset_id=asset.id, period_label=period_label, amount=amount)
                db.add(run); db.flush()
                entry = create_entry(db, f"إهلاك أصل ثابت {asset.asset_code} - {period_label}", user_id,
                    [(asset.depreciation_expense_account_code, amount, 0), (asset.accumulated_depreciation_account_code, 0, amount)],
                    "depreciation", run.id, utcnow())
                run.journal_entry_id = entry.id
                asset.accumulated_depreciation = money(asset.accumulated_depreciation + amount)
                if asset.accumulated_depreciation >= asset.acquisition_cost - asset.residual_value:
                    asset.is_active = False
                posted += 1
            db.commit()
            return {"status": "success", "posted": posted, "period": period_label, "company_id": company_id}
    except Exception:
        db.rollback(); raise
    finally:
        db.close()

@celery.task(name="erp.recurring_journals")
def recurring_journals(company_id=None, as_of=None):
    if company_id is None:
        return {"status": "skipped", "reason": "company_id_required"}
    from .database import SessionLocal
    from .governance_models import RecurringJournalTemplate
    from .accounting import create_entry
    db = SessionLocal(); today = datetime.datetime.fromisoformat(as_of) if as_of else utcnow()
    try:
        with tenant_task_context(company_id, request_id=f"celery:recurring:{company_id}:{today:%Y-%m-%d}"):
            user_id = _admin_id(db)
            if not user_id: return {"status":"skipped","reason":"no_admin_user"}
            generated=0
            for tpl in db.query(RecurringJournalTemplate).filter(RecurringJournalTemplate.company_id==company_id, RecurringJournalTemplate.is_active.is_(True)).all():
                if tpl.frequency == "monthly":
                    if tpl.day_of_month and today.day < tpl.day_of_month: continue
                    if tpl.last_generated_at and tpl.last_generated_at.strftime("%Y-%m") == today.strftime("%Y-%m"): continue
                lines=[(x["account_code"], Decimal(str(x.get("debit",0))), Decimal(str(x.get("credit",0)))) for x in tpl.lines_json]
                source_id=int(f"{tpl.id}{today:%Y%m}")
                create_entry(db, tpl.description or tpl.name, user_id, lines, "recurring_journal", source_id, today)
                tpl.last_generated_at=today; generated += 1
            db.commit(); return {"status":"success","generated":generated,"company_id":company_id}
    except Exception:
        db.rollback(); raise
    finally: db.close()

@celery.task(name="erp.inventory_valuation")
def inventory_valuation(company_id=None, as_of=None):
    if company_id is None:
        return {"status": "skipped", "reason": "company_id_required"}
    from .database import SessionLocal
    from .inventory_valuation import run_company_valuation
    db=SessionLocal()
    try:
        with tenant_task_context(company_id, request_id=f"celery:valuation:{company_id}:{as_of or ''}"):
            run=run_company_valuation(db, company_id=company_id)
            db.commit()
            return {"status":run.status,"company_id":company_id,"run_id":run.id,"total_quantity":str(run.total_quantity),"total_value":str(run.total_value)}
    except Exception:
        db.rollback(); raise
    finally: db.close()


@celery.task(name="erp.refresh_reporting_views")
def refresh_reporting_views():
    """Refresh PostgreSQL reporting views; SQLite deployments do not use them."""
    from .database import engine
    if engine.dialect.name != "postgresql":
        return {"status": "skipped", "reason": "postgresql_required"}
    from sqlalchemy import text
    # PostgreSQL forbids REFRESH MATERIALIZED VIEW CONCURRENTLY inside a transaction block.
    with engine.connect().execution_options(isolation_level="AUTOCOMMIT") as connection:
        connection.execute(text("REFRESH MATERIALIZED VIEW CONCURRENTLY mv_project_cost_summary"))
        connection.execute(text("REFRESH MATERIALIZED VIEW CONCURRENTLY mv_project_evm_current"))
    return {"status": "success"}
