# -*- coding: utf-8 -*-
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import re
from fastapi.responses import JSONResponse
from fastapi.responses import RedirectResponse
from .security_hardening import validate_same_origin, client_ip, rate_limit_check, AUTH_LIMIT, API_LIMIT
from .core_settings import redis_connection_url, allowed_origins
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session

from .database import Base, engine, SessionLocal
from .models import User, RoleEnum, ModulePermission
from .enterprise_models import Company, Branch, Currency, UserCompanyAccess
from .governance_models import Role, Permission, RolePermission, UserRole
from . import tenant_db  # noqa: F401
from . import field_ops_models  # noqa: F401
from . import commercial_completion_models  # noqa: F401
from . import warehouse_models  # noqa: F401
from . import hr_models
from .governance import ensure_role_catalog,  set_request_context, clear_request_context, new_request_id, resolve_tenant, _has_permission, route_permission, ensure_default_permissions, scope_allows
from .accounting import ensure_default_accounts
from .auth import NotAuthenticated, hash_password, decode_token
from .routers.auth_router import router as auth_router
from .routers import admin_security_router
from .routers.inventory_router import router as inventory_router
from .routers.sales_router import router as sales_router
from .routers.purchases_router import router as purchases_router
from .routers.accounting_router import router as accounting_router
from .routers.finance_router import router as finance_router
from .routers.advanced_finance_router import router as advanced_finance_router
from .routers.pro_ledger_router import router as pro_ledger_router
from .routers.enterprise_router import router as enterprise_router
from .routers.enterprise_api_router import router as enterprise_api_router
from .routers.erp_core_router import router as erp_core_router
from .routers.transactions_router import router as transactions_router
from .routers.deep_transactions_router import router as deep_transactions_router
from .routers.erp_financial_core_router import router as erp_financial_core_router
from .routers.reporting_router import router as reporting_router
from .routers.construction_router import router as construction_router
from .routers.hr_router import router as hr_router
from .routers.hr_ui_router import router as hr_ui_router
from .routers.document_controller_router import router as document_controller_router
from .routers.construction_document_forms_router import router as construction_document_forms_router
from .routers.enterprise_plus_router import router as enterprise_plus_router
from .routers.field_ops_router import router as field_ops_router
from .routers.command_center_router import router as command_center_router
from .routers.site_operations_router import router as site_operations_router
from .routers.organization_admin_router import router as organization_admin_router
from .routers.planning_costs_router import router as planning_costs_router
from .routers.financial_reporting_ui import router as financial_reporting_ui_router
from .routers.commercial_workspace_router import router as commercial_workspace_router
from .routers.commercial_completion_router import router as commercial_completion_router

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

@asynccontextmanager
async def lifespan(_app: FastAPI):
    initialize_application()
    yield


app = FastAPI(
    title="نظام ERP الخاص بالشركة",
    lifespan=lifespan,
    # Keep interactive API documentation available in development, but do not
    # expose the full API surface on production servers.
    docs_url=None if os.getenv("ERP_ENV", "development").lower() == "production" else "/docs",
    redoc_url=None if os.getenv("ERP_ENV", "development").lower() == "production" else "/redoc",
    openapi_url=None if os.getenv("ERP_ENV", "development").lower() == "production" else "/openapi.json",
)


@app.get("/health/live", include_in_schema=False)
def health_live():
    return {"status": "ok"}


@app.get("/health/ready", include_in_schema=False)
def health_ready():
    from sqlalchemy import text
    db = None
    try:
        db = SessionLocal()
        db.execute(text("SELECT 1"))
    except Exception:
        raise HTTPException(status_code=503, detail="Database is not ready")
    finally:
        if db is not None:
            db.close()
    broker_status = "not_required"
    if os.getenv("ERP_REQUIRE_BROKER_READY", "false").lower() == "true":
        try:
            import redis
            redis.from_url(os.getenv("CELERY_BROKER_URL", "").strip() or redis_connection_url(0), socket_connect_timeout=2).ping()
            broker_status = "ok"
        except Exception:
            raise HTTPException(status_code=503, detail="Background broker is not ready")
    return {"status": "ready", "database": "ok", "broker": broker_status}

# CORS is deny-by-default. Explicit origins may be supplied for a separate frontend.
_allowed_origins = allowed_origins()
app.add_middleware(
    CORSMiddleware,
    allow_origins=_allowed_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-Company-ID", "X-Branch-ID", "X-Request-ID", "X-CSRF-Token"],
)
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")



@app.middleware("http")
async def security_headers(request: Request, call_next):
    request_id = request.headers.get("X-Request-ID") or new_request_id()

    # IP-based sliding-window limits. Authentication endpoints are deliberately
    # stricter (5/min); the rest of the API is capped at 100/min/IP. This is a
    # local application guard and should be paired with a WAF/Redis limiter in
    # multi-worker/high-volume deployments.
    ip = client_ip(request)
    path = request.url.path
    is_auth_endpoint = path in {"/api/v1/mobile/auth/login", "/api/v1/mobile/auth/refresh", "/auth/refresh", "/forgot-password/request", "/forgot-password/verify", "/forgot-password/complete"}
    if request.method != "OPTIONS" and not path.startswith("/static") and path not in {"/health/live", "/health/ready", "/api/v1/health"}:
        limit = AUTH_LIMIT if is_auth_endpoint else (API_LIMIT if path.startswith("/api/") else None)
        if limit is not None:
            allowed, retry_after = rate_limit_check(f"{'auth' if is_auth_endpoint else 'api'}:{ip}", limit)
            if not allowed:
                return JSONResponse(status_code=429, content={"detail": "Too many requests. Try again later."}, headers={"Retry-After": str(retry_after), "X-RateLimit-Limit": str(limit), "X-RateLimit-Remaining": "0"})

    request.state.user = None
    user_id = None
    company_id = None
    branch_id = None
    token = request.cookies.get("access_token")
    if not token:
        authorization = request.headers.get("Authorization", "")
        if authorization.lower().startswith("bearer "):
            token = authorization[7:].strip()
    if token:
        payload = decode_token(token)
        if payload and payload.get("sub"):
            user_id = int(payload["sub"])
            db = SessionLocal()
            try:
                access = db.query(UserCompanyAccess).filter(UserCompanyAccess.user_id == user_id).order_by(UserCompanyAccess.id).first()
                if access:
                    company_id, branch_id = access.company_id, access.branch_id
            finally:
                db.close()
    if user_id:
        state_db = SessionLocal()
        try:
            request.state.user = state_db.get(User, user_id)
            if request.state.user is None or not request.state.user.is_active:
                request.state.user = None
            else:
                # Never trust tenant headers. They are only a requested context and
                # must be resolved against UserCompanyAccess before entering the app.
                header_company = request.headers.get("X-Company-ID")
                header_branch = request.headers.get("X-Branch-ID")
                try:
                    company_id, branch_id = resolve_tenant(
                        state_db, request.state.user,
                        int(header_company) if header_company else None,
                        int(header_branch) if header_branch else None,
                    )
                except ValueError:
                    return JSONResponse(status_code=400, content={"detail": "Invalid tenant header"})
                except HTTPException as exc:
                    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})
        finally:
            state_db.close()

    set_request_context(request_id=request_id, user_id=user_id, company_id=company_id, branch_id=branch_id, ip_address=request.client.host if request.client else None)

    # Never trust a tenant identifier supplied by a client. Admin organization
    # routes are intentionally allowed to operate on explicitly authorized
    # companies; all other business routes must use the resolved request context.
    if user_id and company_id is not None and not request.url.path.startswith("/admin/organization"):
        requested_company = request.query_params.get("company_id")
        if requested_company is not None:
            try:
                if int(requested_company) != int(company_id):
                    clear_request_context()
                    return JSONResponse(status_code=403, content={"detail": "Client company_id does not match authorized tenant context"})
            except ValueError:
                clear_request_context()
                return JSONResponse(status_code=400, content={"detail": "Invalid company_id"})
        if request.method in {"POST", "PUT", "PATCH"} and "application/json" in request.headers.get("content-type", "").lower():
            try:
                body = await request.body()
                if body:
                    import json
                    payload_body = json.loads(body)
                    body_company_ids = []
                    def _collect_company_ids(value):
                        if isinstance(value, dict):
                            for key, item in value.items():
                                if key == "company_id":
                                    body_company_ids.append(item)
                                _collect_company_ids(item)
                        elif isinstance(value, list):
                            for item in value:
                                _collect_company_ids(item)
                    _collect_company_ids(payload_body)
                    for requested in body_company_ids:
                        if requested is not None and int(requested) != int(company_id):
                            clear_request_context()
                            return JSONResponse(status_code=403, content={"detail": "Client company_id does not match authorized tenant context"})
            except (ValueError, TypeError, json.JSONDecodeError):
                clear_request_context()
                return JSONResponse(status_code=400, content={"detail": "Invalid JSON request"})

    # Browser CSRF defense for cookie-authenticated state-changing requests.
    # Same-origin requests remain compatible with existing HTML forms; cross-site
    # requests carrying Origin/Referer are rejected before business logic executes.
    if user_id and request.url.path not in {"/login", "/api/v1/mobile/auth/login", "/api/v1/mobile/auth/refresh", "/auth/refresh", "/forgot-password/request", "/forgot-password/verify", "/forgot-password/complete"} and request.method in {"POST", "PUT", "PATCH", "DELETE"} and not validate_same_origin(request):
        clear_request_context()
        return JSONResponse(status_code=403, content={"detail": "Cross-site request blocked"})


    # Endpoint-level RBAC enforcement. Legacy module dependencies remain for
    # backward compatibility, while this policy layer enforces granular actions
    # centrally for every protected business route.
    if request.state.user is not None and request.url.path not in {"/login", "/logout"} and not request.url.path.startswith("/static"):
        permission = route_permission(request.method, request.url.path)
        if permission:
            perm_db = SessionLocal()
            try:
                allowed = _has_permission(perm_db, request.state.user.id, permission, company_id, branch_id)
                if not allowed:
                    clear_request_context()
                    return JSONResponse(status_code=403, content={"detail": f"Missing permission: {permission}"})

                # Fine-grained project/site scope must be checked while the
                # authorization session is still alive.
                if permission not in {"admin:users", "admin:permissions", "admin:tenants"}:
                    path_ids = re.findall(r"/(?:projects|project)/([0-9]+)(?:/|$)", request.url.path)
                    project_param = request.query_params.get("project_id")
                    site_param = request.query_params.get("site_id")
                    project_id = int(path_ids[0]) if path_ids else (int(project_param) if project_param and project_param.isdigit() else None)
                    site_id = int(site_param) if site_param and site_param.isdigit() else None
                    if project_id is not None or site_id is not None:
                        scoped = scope_allows(
                            perm_db, request.state.user.id, company_id, branch_id,
                            project_id, site_id, request.method != "GET",
                        )
                        if not scoped:
                            clear_request_context()
                            return JSONResponse(status_code=403, content={"detail": "Access denied for this project/site scope"})
            finally:
                perm_db.close()

    try:
        response = await call_next(request)
    finally:
        # ContextVars must never leak into the next request when downstream code
        # raises an exception.
        clear_request_context()
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    response.headers.setdefault("Content-Security-Policy", "default-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'")
    if os.getenv("ERP_ENV", "development").lower() == "production":
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    response.headers.setdefault("X-Request-ID", request_id)
    if request.url.path.startswith("/api/"):
        response.headers.setdefault("Cache-Control", "no-store")
    return response

app.include_router(auth_router)
app.include_router(admin_security_router.router)
app.include_router(commercial_workspace_router)
app.include_router(inventory_router)
app.include_router(sales_router)
app.include_router(purchases_router)
app.include_router(accounting_router)
app.include_router(finance_router)
app.include_router(advanced_finance_router)
app.include_router(pro_ledger_router)
app.include_router(enterprise_router)
app.include_router(enterprise_api_router)
app.include_router(erp_core_router)
app.include_router(transactions_router)
app.include_router(deep_transactions_router)
app.include_router(erp_financial_core_router)
app.include_router(reporting_router)
app.include_router(construction_router)
app.include_router(hr_router)
app.include_router(hr_ui_router)
app.include_router(document_controller_router)
app.include_router(construction_document_forms_router)
app.include_router(enterprise_plus_router)
app.include_router(field_ops_router)
app.include_router(command_center_router)
app.include_router(site_operations_router)
app.include_router(organization_admin_router)
app.include_router(planning_costs_router)
app.include_router(financial_reporting_ui_router)
app.include_router(commercial_completion_router)


@app.exception_handler(NotAuthenticated)
async def not_authenticated_handler(request: Request, exc: NotAuthenticated):
    return RedirectResponse(url="/login")


def seed_default_admin():
    """Bootstrap the first administrator only when explicitly configured.

    Production must never create a known/default password.
    """
    password = os.getenv("ERP_BOOTSTRAP_ADMIN_PASSWORD")
    if not password:
        return
    if len(password) < 12:
        raise RuntimeError("ERP_BOOTSTRAP_ADMIN_PASSWORD must be at least 12 characters.")

    db: Session = SessionLocal()
    try:
        username = os.getenv("ERP_BOOTSTRAP_ADMIN_USERNAME", "admin").strip()
        full_name = os.getenv("ERP_BOOTSTRAP_ADMIN_NAME", "System Administrator").strip()
        email = os.getenv("ERP_BOOTSTRAP_ADMIN_EMAIL") or None
        admin = db.query(User).filter(User.username == username).first()
        # Bootstrap must be independent of unrelated pre-existing users. Never
        # overwrite an existing account/password; only create the configured
        # bootstrap administrator when that username is absent.
        if admin is None:
            admin = User(
                username=username,
                full_name=full_name,
                email=email,
                password_hash=hash_password(password),
                role=RoleEnum.admin,
            )
            db.add(admin)
            db.commit()
    finally:
        db.close()


def initialize_application():
    # Schema changes are managed by Alembic. Automatic table creation is opt-in
    # for local development only and must never be enabled in production.
    auto_create = os.getenv("ERP_AUTO_CREATE_SCHEMA", "false").lower() == "true"
    if auto_create and os.getenv("ERP_ENV", "development").lower() != "production":
        Base.metadata.create_all(bind=engine)
    seed_default_admin()
    db = SessionLocal()
    try:
        # Ensure a tenant context and system RBAC baseline exist after migrations.
        currency = db.query(Currency).filter(Currency.code == "EGP").first()
        if not currency:
            currency = Currency(code="EGP", name="Egyptian Pound", decimal_places=2, is_active=True); db.add(currency); db.flush()
        company = db.query(Company).filter(Company.code == "DEFAULT").first()
        if not company:
            company = Company(code="DEFAULT", name="Default Company", base_currency_id=currency.id, is_active=True); db.add(company); db.flush()
        branch = db.query(Branch).filter(Branch.company_id == company.id, Branch.code == "MAIN").first()
        if not branch:
            branch = Branch(company_id=company.id, code="MAIN", name="Main Branch", is_active=True); db.add(branch); db.flush()
        admin_role = db.query(Role).filter(Role.code == "system_admin").first()
        if not admin_role:
            admin_role = Role(code="system_admin", name="System Administrator", is_system=True, is_active=True); db.add(admin_role); db.flush()

        ensure_default_permissions(db)
        ensure_role_catalog(db)

        # Synchronize the legacy per-user module permissions into the governed RBAC
        # model. This is a compatibility bridge: authorization decisions now read
        # Permission/Role/UserRole, while existing users keep their effective access.
        all_permissions = db.query(Permission).filter(Permission.is_active.is_(True)).all()
        perm_by_code = {p.code: p for p in all_permissions}
        for p in all_permissions:
            if not db.query(RolePermission).filter_by(role_id=admin_role.id, permission_id=p.id).first():
                db.add(RolePermission(role_id=admin_role.id, permission_id=p.id))

        for u in db.query(User).all():
            if not db.query(UserCompanyAccess).filter_by(user_id=u.id, company_id=company.id, branch_id=branch.id).first():
                db.add(UserCompanyAccess(user_id=u.id, company_id=company.id, branch_id=branch.id, can_manage=(u.role == RoleEnum.admin)))
            # Administrators receive a company-wide scope as well, so the default
            # workspace is consolidated; they can then drill down to any branch.
            if u.role == RoleEnum.admin and not db.query(UserCompanyAccess).filter_by(user_id=u.id, company_id=company.id, branch_id=None).first():
                db.add(UserCompanyAccess(user_id=u.id, company_id=company.id, branch_id=None, can_manage=True))
            if u.role == RoleEnum.admin:
                if not db.query(UserRole).filter_by(user_id=u.id, role_id=admin_role.id, company_id=company.id, branch_id=branch.id).first():
                    db.add(UserRole(user_id=u.id, role_id=admin_role.id, company_id=company.id, branch_id=branch.id, is_active=True))
                continue

            legacy = db.query(ModulePermission).filter(ModulePermission.user_id == u.id).all()
            if not legacy:
                continue
            compat_code = f"legacy_user_{u.id}"
            compat_role = db.query(Role).filter(Role.code == compat_code).first()
            if not compat_role:
                compat_role = Role(code=compat_code, name=f"Legacy Access - {u.username}", is_system=False, is_active=True); db.add(compat_role); db.flush()
            if not db.query(UserRole).filter_by(user_id=u.id, role_id=compat_role.id, company_id=company.id, branch_id=branch.id).first():
                db.add(UserRole(user_id=u.id, role_id=compat_role.id, company_id=company.id, branch_id=branch.id, is_active=True))
            legacy_map = {
                "accounting": {"view": ["journal:view"], "edit": ["journal:create", "journal:post"]},
                "sales": {"view": ["sales:view"], "edit": ["sales:create", "sales:edit"]},
                "purchases": {"view": ["purchases:view"], "edit": ["purchases:create", "purchases:edit"]},
                "inventory": {"view": ["inventory:view"], "edit": ["inventory:create", "inventory:edit", "inventory:adjust", "inventory:transfer"]},
                "finance": {"view": ["reports:view"], "edit": ["journal:post"]},
                "advanced_finance": {"view": ["reports:view"], "edit": ["journal:post"]},
                "pro_finance": {"view": ["reports:view"], "edit": ["journal:post"]},
                "enterprise": {"view": ["reports:view"], "edit": ["journal:post"]},
            }
            for lp in legacy:
                codes = []
                codes.extend(legacy_map.get(lp.module_key, {}).get("view", []) if lp.can_view else [])
                codes.extend(legacy_map.get(lp.module_key, {}).get("edit", []) if lp.can_edit else [])
                # Preserve an exact granular permission when it already exists.
                if lp.can_view and f"{lp.module_key}:view" in perm_by_code: codes.append(f"{lp.module_key}:view")
                if lp.can_edit and f"{lp.module_key}:edit" in perm_by_code: codes.append(f"{lp.module_key}:edit")
                for code in set(codes):
                    permission = perm_by_code.get(code)
                    if permission and not db.query(RolePermission).filter_by(role_id=compat_role.id, permission_id=permission.id).first():
                        db.add(RolePermission(role_id=compat_role.id, permission_id=permission.id))
        db.commit()
        ensure_default_accounts(db, company.id)
    finally:
        db.close()

from . import construction_models as _construction_models  # noqa: E402,F401
from . import construction_document_forms_models as _construction_document_forms_models  # noqa: E402,F401
