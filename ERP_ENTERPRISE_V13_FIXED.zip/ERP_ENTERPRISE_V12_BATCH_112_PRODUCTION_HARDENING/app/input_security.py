"""Small, reusable input validation helpers.

Do not HTML-escape data before storing it: Jinja2 auto-escapes template output.
Instead reject control characters and enforce length/format at trust boundaries.
"""
import re
from pathlib import Path
from fastapi import HTTPException

_CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def clean_text(value: str | None, *, max_length: int = 255, required: bool = False) -> str | None:
    if value is None:
        if required:
            raise HTTPException(422, "Field is required")
        return None
    value = value.strip()
    if required and not value:
        raise HTTPException(422, "Field is required")
    if len(value) > max_length:
        raise HTTPException(422, "Field exceeds maximum length")
    if _CONTROL_RE.search(value):
        raise HTTPException(422, "Control characters are not allowed")
    return value


def safe_filename(filename: str, *, max_length: int = 120) -> str:
    name = Path(filename or "file").name
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("._") or "file"
    return name[:max_length]


def _is_text(data: bytes) -> bool:
    try:
        data.decode("utf-8")
        return True
    except UnicodeDecodeError:
        return False


def detect_file_type(data: bytes, filename: str) -> str | None:
    ext = Path(filename).suffix.lower()
    signatures = {
        ".pdf": data.startswith(b"%PDF-"),
        ".png": data.startswith(b"\x89PNG\r\n\x1a\n"),
        ".jpg": data.startswith(b"\xff\xd8\xff"),
        ".jpeg": data.startswith(b"\xff\xd8\xff"),
        ".gif": data.startswith((b"GIF87a", b"GIF89a")),
        ".webp": data.startswith(b"RIFF") and data[8:12] == b"WEBP",
        ".docx": data.startswith(b"PK\x03\x04"),
        ".xlsx": data.startswith(b"PK\x03\x04"),
        ".zip": data.startswith(b"PK\x03\x04"),
        ".doc": data.startswith(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"),
        ".xls": data.startswith(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"),
        ".dwg": data.startswith(b"AC10"),
        ".dxf": data.startswith(b"0\nSECTION") or data.startswith(b"0\r\nSECTION"),
        ".txt": b"\x00" not in data and _is_text(data),
        ".csv": b"\x00" not in data and _is_text(data),
    }
    if ext in signatures and signatures[ext]:
        return ext
    return None
