from .time_utils import utcnow
"""Phase 5.1 end-to-end transaction orchestration.

Business workflows are kept atomic: document + inventory/subledger + tax + GL
are committed by the caller in one transaction. No function in this module
commits on its own.
"""
from datetime import datetime
from decimal import Decimal
from sqlalchemy.orm import Session
from sqlalchemy import func, case
from sqlalchemy.exc import IntegrityError
from fastapi import HTTPException

from .models import (
    SalesOrder, SalesOrderLine, SalesDelivery, SalesDeliveryLine,
    SaleInvoice, SaleInvoiceLine, PurchaseOrder, PurchaseReceipt,
    PurchaseInvoice, PurchaseInvoiceLine, Item, ItemTypeEnum, StockMovement,
    MovementTypeEnum, TaxRate, TaxTransaction, FinanceVoucher, PaymentAllocation,
    Customer, Supplier,
)
from .accounting import D, money, next_number, create_entry
from .governance import get_request_context
from .inventory_valuation import receive as valuation_receive, issue as valuation_issue
from .commercial_completion_models import CustomerCreditPolicy
from .enterprise_models import PurchaseMatchLine
from .workflows import request_approval


def _tenant_entity(db, model, entity_id, company_id):
    obj = db.query(model).filter(model.id == entity_id, model.company_id == company_id).first()
    if not obj:
        raise HTTPException(404, f"{model.__name__} not found")
    return obj


def _line_total(qty, price):
    return money(D(qty) * D(price))


def create_sales_order(db: Session, company_id: int, user_id: int, customer_id: int, lines, payment_method="credit", notes=None):
    customer = _tenant_entity(db, Customer, customer_id, company_id)
    if not customer.is_active:
        raise HTTPException(409, "Customer is inactive")
    if not lines:
        raise HTTPException(422, "At least one order line is required")
    policy = db.query(CustomerCreditPolicy).filter(CustomerCreditPolicy.company_id==company_id, CustomerCreditPolicy.customer_id==customer.id, CustomerCreditPolicy.is_active.is_(True)).first()
    order = SalesOrder(order_number=next_number(db, "sales_order", "SO"), company_id=company_id,
                       customer_id=customer.id, payment_method=payment_method, notes=notes,
                       created_by_id=user_id, status="draft")
    db.add(order); db.flush()
    subtotal = Decimal("0")
    for row in lines:
        item = _tenant_entity(db, Item, int(row["item_id"]), company_id)
        qty, price = D(row["quantity"]), money(row["unit_price"])
        if qty <= 0 or price < 0:
            raise HTTPException(422, "Invalid sales order quantity or price")
        total = _line_total(qty, price); subtotal += total
        db.add(SalesOrderLine(company_id=company_id, order_id=order.id, item_id=item.id,
                              quantity=qty, unit_price=price, line_total=total))
    if policy and D(policy.credit_limit) > 0:
        current = Decimal("0")
        for inv in db.query(SaleInvoice).filter(SaleInvoice.company_id==company_id, SaleInvoice.customer_id==customer.id).all():
            current += max(Decimal("0"), D(inv.total_amount) - D(_allocated(db, "sale", inv.id, company_id)))
        if policy.block_on_overlimit and current + subtotal > D(policy.credit_limit):
            raise HTTPException(409, f"Credit limit exceeded. Available: {money(D(policy.credit_limit)-current)}")
    db.flush()
    approval = request_approval(db, company_id=company_id, branch_id=get_request_context().get("branch_id"), document_type="sales_order", document_id=order.id, requested_by_id=user_id, amount=subtotal)
    if approval:
        order.approval_status = approval.status
    db.flush()
    return order


def confirm_sales_order(db: Session, order_id: int, company_id: int):
    order = _tenant_entity(db, SalesOrder, order_id, company_id)
    if order.status != "draft":
        raise HTTPException(409, f"Order cannot be confirmed from {order.status}")
    if getattr(order, "approval_status", "approved") != "approved":
        raise HTTPException(409, "Sales order requires approval before confirmation")
    order.status = "confirmed"
    db.flush()
    return order


def deliver_sales_order(db: Session, order_id: int, company_id: int, user_id: int, quantities=None):
    order = db.query(SalesOrder).filter(SalesOrder.id == order_id, SalesOrder.company_id == company_id).with_for_update().first()
    if not order:
        raise HTTPException(404, "SalesOrder not found")
    if order.status not in {"confirmed", "partially_delivered"}:
        raise HTTPException(409, "Sales order is not ready for delivery")
    quantities = quantities or {}
    delivery = SalesDelivery(company_id=company_id, delivery_number=next_number(db, "sales_delivery", "DN"),
                             order_id=order.id, warehouse_id=order.warehouse_id, created_by_id=user_id, status="posted")
    db.add(delivery); db.flush()
    delivered_any = False
    for line in order.lines:
        remaining = D(line.quantity) - D(line.delivered_quantity)
        requested = D(quantities.get(str(line.id), quantities.get(line.id, remaining)))
        if requested <= 0:
            continue
        if requested > remaining:
            raise HTTPException(422, "Delivery quantity exceeds remaining order quantity")
        item = _tenant_entity(db, Item, line.item_id, company_id)
        if item.item_type == ItemTypeEnum.product:
            # Authoritative COGS comes from the configured FIFO/weighted-average
            # valuation engine, never from Item.purchase_price.
            total_cost, _ = valuation_issue(db, company_id, item.id, requested,
                                             "sales_delivery", delivery.id, delivery.delivery_date)
            unit_cost = money(total_cost / requested) if requested else Decimal("0")
            db.add(StockMovement(company_id=company_id, item_id=item.id, movement_type=MovementTypeEnum.out,
                                 quantity=requested, unit_cost=unit_cost, total_cost=total_cost, warehouse_id=delivery.warehouse_id,
                                 note=f"Delivery {delivery.delivery_number}", created_by_id=user_id,
                                 source_type="sales_delivery", source_id=delivery.id, operational_date=delivery.delivery_date))
        else:
            unit_cost = Decimal("0"); total_cost = Decimal("0")
        db.add(SalesDeliveryLine(company_id=company_id, delivery_id=delivery.id, order_line_id=line.id,
                                 item_id=item.id, quantity=requested, unit_cost=unit_cost, total_cost=total_cost))
        line.delivered_quantity = money(D(line.delivered_quantity) + requested)
        delivered_any = True
    if not delivered_any:
        raise HTTPException(422, "No delivery quantity was supplied")
    remaining = any(D(x.quantity) > D(x.delivered_quantity) for x in order.lines)
    order.status = "partially_delivered" if remaining else "delivered"
    db.flush()
    return delivery


def invoice_sales_delivery(db: Session, delivery_id: int, company_id: int, user_id: int, tax_rate_id=None, discount=0):
    delivery = _tenant_entity(db, SalesDelivery, delivery_id, company_id)
    if db.query(SaleInvoice).filter(SaleInvoice.delivery_id == delivery.id).first():
        raise HTTPException(409, "Delivery is already invoiced")
    order = delivery.order
    subtotal = Decimal("0")
    cogs = Decimal("0")
    branch_id=get_request_context().get("branch_id")
    invoice = SaleInvoice(company_id=company_id, branch_id=branch_id, invoice_number=next_number(db, "sales_invoice", "INV"),
                          customer_id=order.customer_id, payment_method=order.payment_method,
                          order_id=order.id, delivery_id=delivery.id, created_by_id=user_id,
                          status="posted")
    db.add(invoice); db.flush()
    order_lines = {x.id: x for x in order.lines}
    for dl in delivery.lines:
        ol = order_lines[dl.order_line_id]
        qty = D(dl.quantity)
        line_total = _line_total(qty, ol.unit_price)
        subtotal += line_total
        cogs += D(dl.total_cost)
        db.add(SaleInvoiceLine(company_id=company_id, invoice_id=invoice.id, item_id=dl.item_id,
                               quantity=qty, unit_price=money(ol.unit_price), line_total=line_total))
    discount = money(discount)
    if discount < 0 or discount > subtotal:
        raise HTTPException(422, "Invalid discount")
    tax_amount = Decimal("0")
    tax = None
    if tax_rate_id:
        tax = _tenant_entity(db, TaxRate, tax_rate_id, company_id)
        if not tax.is_active or D(tax.rate) < 0:
            raise HTTPException(422, "Invalid tax rate")
        tax_amount = money((subtotal - discount) * D(tax.rate) / Decimal("100"))
    total = money(subtotal - discount + tax_amount)
    invoice.subtotal, invoice.discount_amount, invoice.tax_amount, invoice.total_amount = subtotal, discount, tax_amount, total
    debit_account = "1100" if order.payment_method == "نقدي" else ("1110" if order.payment_method in {"بنكي", "تحويل بنكي"} else "1200")
    lines = [(debit_account, total, 0), ("4100", 0, subtotal - discount)]
    if tax_amount:
        lines.append((tax.tax_account_code, 0, tax_amount))
    if cogs:
        lines.extend([("5100", cogs, 0), ("1300", 0, cogs)])
    entry = create_entry(db, f"Sales invoice {invoice.invoice_number}", user_id, lines, "sale_invoice", invoice.id, company_id=company_id, branch_id=branch_id)
    if tax_amount:
        db.add(TaxTransaction(company_id=company_id, branch_id=branch_id, tax_rate_id=tax.id, source_type="sale_invoice",
                              source_id=invoice.id, taxable_amount=subtotal-discount, tax_amount=tax_amount,
                              tax_direction="output", rate_applied=tax.rate, tax_code_snapshot=tax.code, tax_name_snapshot=tax.name,
                              tax_account_code_snapshot=tax.tax_account_code, journal_entry_id=entry.id, created_by_id=user_id))
    db.flush()
    return invoice


def create_purchase_invoice(db: Session, company_id: int, user_id: int, supplier_id: int, lines,
                             po_id=None, tax_rate_id=None, discount=0, payment_method="credit", notes=None):
    supplier=_tenant_entity(db,Supplier,supplier_id,company_id)
    if not supplier.is_active: raise HTTPException(409,"Supplier is inactive")
    branch_id=get_request_context().get("branch_id"); po=None
    if po_id:
        po=db.query(PurchaseOrder).filter(PurchaseOrder.id==po_id,PurchaseOrder.company_id==company_id).with_for_update().first()
        if not po: raise HTTPException(404,"Purchase order not found")
        if po.supplier_id!=supplier.id: raise HTTPException(422,"Purchase order supplier mismatch")
        if getattr(po,"approval_status","approved")!="approved": raise HTTPException(409,"Purchase order requires approval before invoicing")
        if D(discount)!=0: raise HTTPException(422,"PO-backed invoices cannot use header discount; use an approved PO price/variance policy")
    if not lines: raise HTTPException(422,"At least one purchase invoice line is required")
    po_by_id={x.id:x for x in po.lines} if po else {}; po_by_item={}
    if po:
        for x in po.lines: po_by_item.setdefault(x.item_id,[]).append(x)
    normalized=[]; seen=set(); subtotal=Decimal("0")
    for row in lines:
        item=_tenant_entity(db,Item,int(row["item_id"]),company_id); qty,price=D(row["quantity"]),money(row["unit_price"])
        if qty<=0 or price<0: raise HTTPException(422,"Invalid purchase invoice line")
        polid=row.get("po_line_id") if po else None
        if po:
            polid=int(polid) if polid is not None else (po_by_item.get(item.id,[None])[0].id if len(po_by_item.get(item.id,[]))==1 else None)
            pol=po_by_id.get(polid)
            if not pol or pol.item_id!=item.id: raise HTTPException(422,"Invoice line does not match the selected PO line")
            if polid in seen: raise HTTPException(422,"A PO line may appear only once on a supplier invoice")
            seen.add(polid)
            if abs(price-D(pol.unit_price))>Decimal("0.01"): raise HTTPException(409,"Invoice price differs from PO price beyond the three-way-match tolerance")
        subtotal+=_line_total(qty,price); normalized.append((item,qty,price,polid))
    if po:
        invoice=PurchaseInvoice(company_id=company_id,branch_id=branch_id,invoice_number=next_number(db,"purchase_invoice","PINV"),supplier_id=supplier.id,po_id=po.id,created_by_id=user_id,status="draft",approval_status="approved",notes=notes)
        db.add(invoice); db.flush()
        for item,qty,price,polid in normalized: db.add(PurchaseInvoiceLine(company_id=company_id,invoice_id=invoice.id,item_id=item.id,quantity=qty,unit_price=price,line_total=_line_total(qty,price),po_line_id=polid))
        db.flush(); from .deep_transactions import validate_three_way_match; validate_three_way_match(db,company_id,invoice.id)
        matched_value=money(sum((D(m.matched_amount) for m in db.query(PurchaseMatchLine).filter(PurchaseMatchLine.company_id==company_id,PurchaseMatchLine.purchase_invoice_id==invoice.id,PurchaseMatchLine.status=="matched").all()),Decimal("0")))
        if matched_value!=subtotal: raise HTTPException(409,"Three-way match total does not equal invoice subtotal")
    else:
        invoice=PurchaseInvoice(company_id=company_id,branch_id=branch_id,invoice_number=next_number(db,"purchase_invoice","PINV"),supplier_id=supplier.id,created_by_id=user_id,status="posted",approval_status="approved",notes=notes)
        db.add(invoice); db.flush()
        for item,qty,price,_ in normalized:
            line=PurchaseInvoiceLine(company_id=company_id,invoice_id=invoice.id,item_id=item.id,quantity=qty,unit_price=price,line_total=_line_total(qty,price)); db.add(line); db.flush()
            if item.item_type==ItemTypeEnum.product:
                db.add(StockMovement(company_id=company_id,item_id=item.id,movement_type=MovementTypeEnum.in_,quantity=qty,unit_cost=price,total_cost=_line_total(qty,price),note=f"Purchase invoice {invoice.invoice_number}",created_by_id=user_id, source_type="purchase_invoice_line", source_id=line.id, operational_date=invoice.invoice_date)); db.flush(); valuation_receive(db,company_id,item.id,qty,price,"purchase_invoice_line",line.id,invoice.invoice_date)
    discount=money(discount)
    if discount<0 or discount>subtotal: raise HTTPException(422,"Invalid discount")
    tax_amount=Decimal("0"); tax=None
    if tax_rate_id:
        tax=_tenant_entity(db,TaxRate,tax_rate_id,company_id)
        if not tax.is_active or D(tax.rate)<0: raise HTTPException(422,"Invalid tax rate")
        tax_amount=money((subtotal-discount)*D(tax.rate)/Decimal("100"))
    total=money(subtotal-discount+tax_amount); invoice.subtotal,invoice.discount_amount,invoice.tax_amount,invoice.total_amount=subtotal,discount,tax_amount,total
    if po:
        lines_j=[("2120",subtotal,0)]
        if tax_amount: lines_j.append(("2220" if tax.tax_account_code=="2200" else tax.tax_account_code,tax_amount,0))
        lines_j.append(("2100",0,total))
    else:
        credit="1100" if payment_method=="نقدي" else ("1110" if payment_method in {"بنكي","تحويل بنكي"} else "2100")
        lines_j=[("1300",subtotal-discount,0)]
        if tax_amount: lines_j.append(("2220" if tax.tax_account_code=="2200" else tax.tax_account_code,tax_amount,0))
        lines_j.append((credit,0,total))
    entry=create_entry(db,f"Purchase invoice {invoice.invoice_number}",user_id,lines_j,"purchase_invoice",invoice.id,invoice.invoice_date,company_id=company_id,branch_id=branch_id)
    if tax_amount: db.add(TaxTransaction(company_id=company_id,branch_id=branch_id,tax_rate_id=tax.id,source_type="purchase_invoice",source_id=invoice.id,taxable_amount=subtotal-discount,tax_amount=tax_amount,tax_direction="input",rate_applied=tax.rate,tax_code_snapshot=tax.code,tax_name_snapshot=tax.name,tax_account_code_snapshot=tax.tax_account_code,journal_entry_id=entry.id,created_by_id=user_id))
    invoice.status="posted"; db.flush(); return invoice


def _allocated(db, invoice_kind, invoice_id, company_id):
    q = db.query(func.coalesce(func.sum(PaymentAllocation.amount), 0)).filter(PaymentAllocation.company_id == company_id)
    if invoice_kind == "sale":
        q = q.filter(PaymentAllocation.sale_invoice_id == invoice_id)
    else:
        q = q.filter(PaymentAllocation.purchase_invoice_id == invoice_id)
    return money(q.scalar() or 0)


def create_customer_receipt(db: Session, company_id: int, user_id: int, invoice_id: int, amount, account_code="1100", payment_date=None, idempotency_key=None):
    invoice = db.query(SaleInvoice).filter(SaleInvoice.id == invoice_id, SaleInvoice.company_id == company_id).with_for_update().first()
    if not invoice:
        raise HTTPException(404, "SaleInvoice not found")
    if idempotency_key:
        existing = db.query(FinanceVoucher).filter(FinanceVoucher.company_id == company_id, FinanceVoucher.idempotency_key == idempotency_key).first()
        if existing:
            return existing
    amount = money(amount)
    outstanding = money(invoice.total - _allocated(db, "sale", invoice.id, company_id))
    if amount <= 0 or amount > outstanding:
        raise HTTPException(409, f"Payment exceeds outstanding balance ({outstanding})")
    v = FinanceVoucher(company_id=company_id, voucher_number=next_number(db, "voucher", "VCH"),
                      voucher_type="receipt", voucher_date=payment_date or utcnow(), amount=amount,
                      description=f"Customer payment for {invoice.invoice_number}", account_code=account_code,
                      party_type="customer", party_id=invoice.customer_id, created_by_id=user_id, idempotency_key=idempotency_key)
    db.add(v); db.flush()
    create_entry(db, v.description, user_id, [(account_code, amount, 0), ("1200", 0, amount)],
                 "finance_voucher", v.id, v.voucher_date)
    db.add(PaymentAllocation(company_id=company_id, voucher_id=v.id, sale_invoice_id=invoice.id, amount=amount))
    db.flush()
    return v


def create_supplier_payment(db: Session, company_id: int, user_id: int, invoice_id: int, amount, account_code="1100", payment_date=None, idempotency_key=None):
    invoice = db.query(PurchaseInvoice).filter(PurchaseInvoice.id == invoice_id, PurchaseInvoice.company_id == company_id).with_for_update().first()
    if not invoice:
        raise HTTPException(404, "PurchaseInvoice not found")
    if idempotency_key:
        existing = db.query(FinanceVoucher).filter(FinanceVoucher.company_id == company_id, FinanceVoucher.idempotency_key == idempotency_key).first()
        if existing:
            return existing
    amount = money(amount)
    outstanding = money(invoice.total_amount - _allocated(db, "purchase", invoice.id, company_id))
    if amount <= 0 or amount > outstanding:
        raise HTTPException(409, f"Payment exceeds outstanding balance ({outstanding})")
    v = FinanceVoucher(company_id=company_id, voucher_number=next_number(db, "voucher", "VCH"),
                      voucher_type="payment", voucher_date=payment_date or utcnow(), amount=amount,
                      description=f"Supplier payment for {invoice.invoice_number}", account_code=account_code,
                      party_type="supplier", party_id=invoice.supplier_id, created_by_id=user_id, idempotency_key=idempotency_key)
    db.add(v); db.flush()
    create_entry(db, v.description, user_id, [("2100", amount, 0), (account_code, 0, amount)],
                 "finance_voucher", v.id, v.voucher_date)
    db.add(PaymentAllocation(company_id=company_id, voucher_id=v.id, purchase_invoice_id=invoice.id, amount=amount))
    db.flush()
    return v
