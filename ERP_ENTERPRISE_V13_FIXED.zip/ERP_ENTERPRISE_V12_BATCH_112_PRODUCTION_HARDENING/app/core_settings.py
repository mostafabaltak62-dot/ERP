"""Fail-closed runtime configuration using pydantic-settings.

Configuration is loaded once from environment/.env without silent security fallbacks.
Importing ORM metadata does not require these settings; runtime startup does.
"""
from __future__ import annotations

from functools import lru_cache
from urllib.parse import quote
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from dotenv import load_dotenv

# Make .env values visible to os.getenv() consumers too (bootstrap admin, CSRF flags,
# schema flags). Real environment variables always win (override=False).
load_dotenv(override=False)


class EnvironmentSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    DATABASE_URL: str | None = None
    ERP_DB_DIALECT: str = "postgresql+psycopg"
    ERP_DB_HOST: str | None = None
    ERP_DB_PORT: str = "5432"
    ERP_DB_NAME: str | None = None
    ERP_DB_USER: str | None = None
    ERP_DB_PASSWORD: str | None = None

    JWT_SECRET_KEY: str | None = None
    ENCRYPTION_KEY: str | None = None
    ERP_ENV: str = "development"

    # Prefer the new ALLOWED_ORIGINS name while keeping ERP_ALLOWED_ORIGINS
    # available for existing deployments.
    ALLOWED_ORIGINS: str = ""
    ERP_ALLOWED_ORIGINS: str = ""

    ERP_DB_POOL_SIZE: int = Field(default=10, ge=1, le=200)
    ERP_DB_MAX_OVERFLOW: int = Field(default=20, ge=0, le=500)
    ERP_DB_POOL_TIMEOUT: int = Field(default=30, ge=1, le=300)
    ERP_DB_POOL_RECYCLE: int = Field(default=1800, ge=30, le=86400)


@lru_cache(maxsize=1)
def runtime_settings() -> EnvironmentSettings:
    return EnvironmentSettings()


def _required(value: str | None, name: str, min_len: int = 1) -> str:
    value = (value or "").strip()
    upper_value = value.upper()
    placeholder_markers = (
        "CHANGE_ME", "CHANGE_THIS", "YOUR_", "REPLACE_", "EXAMPLE", "TODO",
        "GENERATE", "RANDOM_SECRET", "USER:PASSWORD@HOST", "SECRET_AT_LEAST",
    )
    if not value or any(marker in upper_value for marker in placeholder_markers) or len(value) < min_len:
        raise RuntimeError(
            f"{name} must be provided through environment configuration, must not "
            "be a placeholder, and must meet the minimum length requirement"
        )
    return value


def _database_url(settings: EnvironmentSettings) -> str:
    explicit = (settings.DATABASE_URL or "").strip()
    if explicit:
        return _required(explicit, "DATABASE_URL", 20)

    host = _required(settings.ERP_DB_HOST, "ERP_DB_HOST")
    name = _required(settings.ERP_DB_NAME, "ERP_DB_NAME")
    user = _required(settings.ERP_DB_USER, "ERP_DB_USER")
    password = _required(settings.ERP_DB_PASSWORD, "ERP_DB_PASSWORD")
    port = str(settings.ERP_DB_PORT).strip()
    if not port.isdigit() or not (1 <= int(port) <= 65535):
        raise RuntimeError("ERP_DB_PORT must be a valid TCP port")
    dialect = (settings.ERP_DB_DIALECT or "postgresql+psycopg").strip()
    return f"{dialect}://{quote(user, safe='')}:{quote(password, safe='')}@{host}:{port}/{quote(name, safe='')}"


def allowed_origins() -> list[str]:
    settings = runtime_settings()
    raw = settings.ALLOWED_ORIGINS or settings.ERP_ALLOWED_ORIGINS
    origins = [x.strip().rstrip("/") for x in raw.split(",") if x.strip()]
    if "*" in origins:
        raise RuntimeError("Wildcard CORS origins are forbidden")
    return origins


@lru_cache(maxsize=4)
def security_settings(*, require_database: bool = True) -> dict[str, str]:
    # Construct directly so test/deployment configuration reloads are controlled
    # by security_settings.cache_clear() and never depend on a stale nested cache.
    settings = EnvironmentSettings()
    result = {
        "JWT_SECRET_KEY": _required(settings.JWT_SECRET_KEY, "JWT_SECRET_KEY", 32),
        "ENCRYPTION_KEY": _required(settings.ENCRYPTION_KEY, "ENCRYPTION_KEY", 32),
    }
    if require_database:
        result["DATABASE_URL"] = _database_url(settings)
    return result


def validate_runtime_config(*, require_database: bool = True):
    settings = runtime_settings()
    required = security_settings(require_database=require_database)
    if require_database:
        url = required["DATABASE_URL"]
        if settings.ERP_ENV.lower() == "production":
            if not url.startswith(("postgresql://", "postgresql+psycopg://", "postgresql+asyncpg://")):
                raise RuntimeError("Production DATABASE_URL must use PostgreSQL")
            lowered = url.lower()
            if "sslmode=disable" in lowered:
                raise RuntimeError("Production PostgreSQL connections must not disable TLS")
    return required


def redis_connection_url(db: int = 0) -> str:
    # Redis remains environment-driven because deployments commonly use a managed URL.
    import os
    if not isinstance(db, int) or db < 0:
        raise ValueError("Redis database index must be a non-negative integer")
    explicit = os.getenv("REDIS_URL", "").strip()
    if explicit:
        return explicit.rstrip("/") + f"/{db}" if explicit.rsplit("/", 1)[-1].isdigit() is False else explicit
    host = os.getenv("ERP_REDIS_HOST", "").strip()
    if not host:
        return ""
    port = os.getenv("ERP_REDIS_PORT", "6379").strip()
    if not port.isdigit() or not (1 <= int(port) <= 65535):
        raise RuntimeError("ERP_REDIS_PORT must be a valid TCP port")
    password = os.getenv("REDIS_PASSWORD", "")
    auth = f":{quote(password, safe='')}@" if password else ""
    return f"redis://{auth}{host}:{port}/{db}"
