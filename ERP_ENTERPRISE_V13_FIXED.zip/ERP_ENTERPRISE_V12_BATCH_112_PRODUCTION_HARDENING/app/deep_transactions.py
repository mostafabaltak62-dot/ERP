from .time_utils import utcnow
"""Phase 5.3 deep transaction integrity services.

Authoritative workflows for receiving/matching, sales and purchase returns,
AR/AP aging, and subledger-to-GL reconciliation. Functions are transaction-
owned: they never commit independently.
"""
from datetime import datetime
from decimal import Decimal
from sqlalchemy.orm import Session
from sqlalchemy import func, case
from fastapi import HTTPException

from .models import (
    PurchaseOrder, PurchaseOrderLine, PurchaseReceipt, SaleInvoice,
    SaleInvoiceLine, PurchaseInvoice, PurchaseInvoiceLine, StockMovement,
    MovementTypeEnum, ItemTypeEnum, Customer, Supplier, PaymentAllocation, FinanceVoucher,
)
from .enterprise_models import (
    PurchaseReceiptLine, PurchaseMatchLine, SalesReturn, SalesReturnLine,
    PurchaseReturn, PurchaseReturnLine, SubledgerReconciliation,
)
from .commercial_completion_models import CustomerCreditPolicy, SupplierCreditPolicy
from .accounting import D, money, next_number, create_entry
from .inventory_valuation import receive as valuation_receive, issue as valuation_issue
from .transaction_services import _tenant_entity, _allocated
from .warehouse_models import Warehouse
from .models import AuditLog


def receive_purchase_order(db: Session, company_id: int, po_id: int, user_id: int, quantities=None):
    """Post one GRN against a PO; supports partial and multiple receipts atomically."""
    po = (db.query(PurchaseOrder).filter(PurchaseOrder.id == po_id, PurchaseOrder.company_id == company_id)
          .with_for_update().first())
    if not po: raise HTTPException(404, "PurchaseOrder not found")
    if getattr(po, "approval_status", "approved") != "approved":
        raise HTTPException(409, "Purchase order requires approval before receipt")
    if not po.lines: raise HTTPException(409, "Purchase order has no lines")
    quantities = quantities or {}
    rows = (db.query(PurchaseReceiptLine.po_line_id, func.coalesce(func.sum(PurchaseReceiptLine.quantity), 0))
            .join(PurchaseReceipt, PurchaseReceipt.id == PurchaseReceiptLine.receipt_id)
            .filter(PurchaseReceipt.company_id == company_id, PurchaseReceipt.po_id == po.id,
                    PurchaseReceiptLine.company_id == company_id).group_by(PurchaseReceiptLine.po_line_id).all())
    received_by_line = {int(k): D(v) for k,v in rows}
    receipt = PurchaseReceipt(company_id=company_id, receipt_number=next_number(db,"purchase_receipt","GRN"),
                              po_id=po.id, warehouse_id=po.warehouse_id, created_by_id=user_id)
    db.add(receipt); db.flush(); any_line=False; inventory_total=Decimal("0")
    for line in po.lines:
        if line.company_id not in (None, company_id): raise HTTPException(409,"Purchase order line tenant mismatch")
        already=received_by_line.get(line.id,Decimal("0")); remaining=D(line.quantity)-already
        requested=quantities.get(str(line.id),quantities.get(line.id,remaining)); qty=D(requested)
        if qty < 0: raise HTTPException(422,"Receipt quantity cannot be negative")
        if qty == 0: continue
        if remaining <= 0: raise HTTPException(409,f"Purchase order line {line.id} is already fully received")
        if qty > remaining: raise HTTPException(422,f"Receipt quantity exceeds remaining PO quantity ({remaining})")
        item=_tenant_entity(db,__import__('app.models',fromlist=['Item']).Item,line.item_id,company_id)
        if item.item_type == ItemTypeEnum.product:
            if not po.warehouse_id: raise HTTPException(422,"A warehouse is required for stocked-item receipts")
            if not db.query(Warehouse.id).filter(Warehouse.id==po.warehouse_id,Warehouse.company_id==company_id,Warehouse.is_active.is_(True)).first():
                raise HTTPException(422,"Purchase order warehouse is invalid for the current company")
        rl=PurchaseReceiptLine(company_id=company_id,receipt_id=receipt.id,po_line_id=line.id,item_id=item.id,quantity=qty,unit_cost=money(line.unit_price))
        db.add(rl); db.flush(); any_line=True; value=money(qty*D(line.unit_price)); inventory_total += D(value)
        if item.item_type == ItemTypeEnum.product:
            db.add(StockMovement(company_id=company_id,item_id=item.id,movement_type=MovementTypeEnum.in_,quantity=qty,unit_cost=money(line.unit_price),total_cost=value,warehouse_id=po.warehouse_id,note=f"Receipt {po.po_number} / GRN {receipt.receipt_number}",created_by_id=user_id)); db.flush()
            valuation_receive(db,company_id,item.id,qty,line.unit_price,"purchase_receipt_line",rl.id,receipt.receipt_date)
    if not any_line: raise HTTPException(422,"No remaining receipt quantity was supplied")
    if inventory_total > 0:
        create_entry(db,f"Goods receipt {po.po_number} / GRN {receipt.receipt_number}",user_id,[("1300",money(inventory_total),0),("2120",0,money(inventory_total))],"purchase_receipt",receipt.id,receipt.receipt_date,company_id=company_id,branch_id=po.branch_id)
    db.add(AuditLog(user_id=user_id,action="post",entity_type="purchase_receipt",entity_id=receipt.id,description=f"ترحيل استلام {receipt.receipt_number} لأمر الشراء {po.po_number}"))
    db.flush(); return receipt


def validate_three_way_match(db: Session, company_id: int, invoice_id: int, price_tolerance=Decimal("0.01")):
    """Match supplier invoice cumulatively against all GRNs for its PO."""
    invoice=_tenant_entity(db,PurchaseInvoice,invoice_id,company_id)
    if not invoice.po_id: return []
    po=db.query(PurchaseOrder).filter(PurchaseOrder.id==invoice.po_id,PurchaseOrder.company_id==company_id).with_for_update().first()
    if not po: raise HTTPException(404,"Purchase order not found")
    receipts=db.query(PurchaseReceipt).filter(PurchaseReceipt.po_id==po.id,PurchaseReceipt.company_id==company_id).order_by(PurchaseReceipt.receipt_date,PurchaseReceipt.id).all()
    if not receipts: raise HTTPException(409,"Three-way match requires at least one goods receipt")
    receipt_lines=db.query(PurchaseReceiptLine).filter(PurchaseReceiptLine.company_id==company_id,PurchaseReceiptLine.receipt_id.in_([r.id for r in receipts])).all()
    by_po={}
    for rl in receipt_lines: by_po.setdefault(rl.po_line_id,[]).append(rl)
    po_by_id={x.id:x for x in po.lines}; po_by_item={}
    for x in po.lines: po_by_item.setdefault(x.item_id,[]).append(x)
    created=[]
    for il in invoice.lines:
        po_line=po_by_id.get(getattr(il,"po_line_id",None)) if getattr(il,"po_line_id",None) else None
        if po_line is None:
            candidates=po_by_item.get(il.item_id,[])
            if len(candidates)!=1: raise HTTPException(409,"PO invoice line must identify an unambiguous PO line")
            po_line=candidates[0]; il.po_line_id=po_line.id
        if po_line.item_id != il.item_id: raise HTTPException(409,"Invoice item does not match the PO line")
        qty=D(il.quantity); rls=by_po.get(po_line.id,[])
        received=sum((D(x.quantity) for x in rls),Decimal("0"))
        previous=D(db.query(func.coalesce(func.sum(PurchaseMatchLine.matched_quantity),0)).filter(PurchaseMatchLine.company_id==company_id,PurchaseMatchLine.po_line_id==po_line.id,PurchaseMatchLine.purchase_invoice_line_id!=il.id,PurchaseMatchLine.status=="matched").scalar() or 0)
        own=D(db.query(func.coalesce(func.sum(PurchaseMatchLine.matched_quantity),0)).filter(PurchaseMatchLine.company_id==company_id,PurchaseMatchLine.purchase_invoice_line_id==il.id,PurchaseMatchLine.status=="matched").scalar() or 0)
        if qty > received-previous+own: raise HTTPException(409,f"Invoice quantity exceeds cumulatively received quantity for PO line {po_line.id}")
        if any(abs(D(il.unit_price)-D(rl.unit_cost)) > D(price_tolerance) for rl in rls): raise HTTPException(409,"Invoice price exceeds configured three-way-match tolerance")
        remaining=qty-own
        if remaining<=0:
            created.extend(db.query(PurchaseMatchLine).filter(PurchaseMatchLine.company_id==company_id,PurchaseMatchLine.purchase_invoice_line_id==il.id,PurchaseMatchLine.status=="matched").all()); continue
        for rl in rls:
            matched=D(db.query(func.coalesce(func.sum(PurchaseMatchLine.matched_quantity),0)).filter(PurchaseMatchLine.company_id==company_id,PurchaseMatchLine.receipt_line_id==rl.id,PurchaseMatchLine.status=="matched").scalar() or 0)
            take=min(remaining,D(rl.quantity)-matched)
            if take<=0: continue
            m=PurchaseMatchLine(company_id=company_id,purchase_invoice_id=invoice.id,purchase_invoice_line_id=il.id,po_line_id=po_line.id,receipt_line_id=rl.id,matched_quantity=take,matched_amount=money(take*D(il.unit_price)),status="matched")
            db.add(m); db.flush(); created.append(m); remaining-=take
            if remaining<=0: break
        if remaining>0: raise HTTPException(409,"Unable to allocate invoice quantity across received GRNs")
    db.flush(); return created

def create_sales_return(db: Session, company_id: int, user_id: int, invoice_id: int, lines, tax_rate=None):
    invoice = _tenant_entity(db, SaleInvoice, invoice_id, company_id)
    ret = SalesReturn(company_id=company_id, return_number=next_number(db, "sales_return", "SRET"),
                      sale_invoice_id=invoice.id, customer_id=invoice.customer_id, created_by_id=user_id)
    db.add(ret); db.flush()
    subtotal = Decimal("0"); cost_total = Decimal("0"); tax_amount = Decimal("0")
    invoice_lines = {x.id: x for x in invoice.lines}
    for row in lines:
        il = invoice_lines.get(int(row["invoice_line_id"]))
        if not il: raise HTTPException(404, "Invoice line not found")
        qty = D(row["quantity"])
        already = money(db.query(func.coalesce(func.sum(SalesReturnLine.quantity), 0)).filter(
            SalesReturnLine.company_id == company_id, SalesReturnLine.invoice_line_id == il.id).scalar() or 0)
        if qty <= 0 or already + qty > D(il.quantity):
            raise HTTPException(409, "Return quantity exceeds invoiced quantity")
        line_total = money(qty * D(il.unit_price))
        # Restore stock at the actual cost that was issued for the originating delivery.
        unit_cost = D(row.get("unit_cost", 0))
        if unit_cost <= 0 and invoice.delivery_id:
            from .models import SalesDeliveryLine
            dl = db.query(SalesDeliveryLine).filter(SalesDeliveryLine.delivery_id == invoice.delivery_id,
                                                     SalesDeliveryLine.item_id == il.item_id).first()
            if dl: unit_cost = D(dl.unit_cost)
        cost = money(qty * unit_cost)
        db.add(SalesReturnLine(company_id=company_id, return_id=ret.id, invoice_line_id=il.id,
                               item_id=il.item_id, quantity=qty, unit_price=money(il.unit_price),
                               unit_cost=money(unit_cost), line_total=line_total, cost_total=cost))
        if il.item.item_type == ItemTypeEnum.product:
            if unit_cost > 0:
                valuation_receive(db, company_id, il.item_id, qty, unit_cost, "sales_return", ret.id, ret.return_date)
            db.add(StockMovement(company_id=company_id, item_id=il.item_id, movement_type=MovementTypeEnum.in_,
                                 quantity=qty, unit_cost=money(unit_cost), total_cost=cost,
                                 note=f"Sales return {ret.return_number}", created_by_id=user_id, source_type="sales_return", source_id=ret.id, operational_date=ret.return_date))
        subtotal += line_total; cost_total += cost
    if tax_rate is not None:
        tax_amount = money(subtotal * D(tax_rate) / Decimal("100"))
    elif D(invoice.subtotal) > 0 and D(invoice.tax_amount) > 0:
        tax_amount = money(subtotal * D(invoice.tax_amount) / D(invoice.subtotal))
    total = money(subtotal + tax_amount)
    ret.subtotal, ret.tax_amount, ret.total_amount, ret.cogs_reversal = subtotal, tax_amount, total, cost_total
    lines_j = [("4200", subtotal, 0), ("1200", 0, total)]
    if tax_amount: lines_j.append(("2200", tax_amount, 0))
    if cost_total: lines_j.extend([("1300", cost_total, 0), ("5100", 0, cost_total)])
    create_entry(db, f"Sales return {ret.return_number}", user_id, lines_j, "sales_return", ret.id, ret.return_date)
    db.flush(); return ret


def create_purchase_return(db: Session, company_id: int, user_id: int, invoice_id: int, lines, tax_rate=None,
                           warehouse_id: int | None = None, reason: str | None = None, notes: str | None = None):
    """Create and post an authoritative purchase return.

    The workflow is tenant scoped, prevents cumulative over-returns, reduces valued
    inventory, reverses AP/VAT, and records a full stock movement trail.
    """
    invoice = _tenant_entity(db, PurchaseInvoice, invoice_id, company_id)
    if getattr(invoice, "status", "posted") != "posted":
        raise HTTPException(409, "Only posted purchase invoices can be returned")
    if warehouse_id is not None:
        wh = db.query(Warehouse).filter(Warehouse.id == warehouse_id, Warehouse.company_id == company_id).first()
        if not wh:
            raise HTTPException(404, "Warehouse not found")
    ret = PurchaseReturn(company_id=company_id, return_number=next_number(db, "purchase_return", "PRET"),
                         purchase_invoice_id=invoice.id, supplier_id=invoice.supplier_id,
                         created_by_id=user_id, warehouse_id=warehouse_id, reason=reason, notes=notes,
                         status="posted")
    db.add(ret); db.flush()
    subtotal = Decimal("0"); inventory_credit = Decimal("0")
    invoice_lines = {x.id: x for x in invoice.lines}
    for row in lines:
        il = invoice_lines.get(int(row["invoice_line_id"]))
        if not il: raise HTTPException(404, "Invoice line not found")
        qty = D(row["quantity"])
        already = D(db.query(func.coalesce(func.sum(PurchaseReturnLine.quantity), 0)).join(
            PurchaseReturn, PurchaseReturn.id == PurchaseReturnLine.return_id
        ).filter(PurchaseReturnLine.company_id == company_id,
                 PurchaseReturnLine.invoice_line_id == il.id,
                 PurchaseReturn.status != "cancelled").scalar() or 0)
        if qty <= 0 or already + qty > D(il.quantity):
            raise HTTPException(409, "Return quantity exceeds remaining purchased quantity")
        cost, _ = valuation_issue(db, company_id, il.item_id, qty, "purchase_return", ret.id, ret.return_date)
        if D(cost) <= 0:
            # Do not silently create an unvalued return when stock valuation cannot support it.
            raise HTTPException(409, "Insufficient valued inventory available for this purchase return")
        line_total = money(qty * D(il.unit_price)); subtotal += line_total; inventory_credit += D(cost)
        db.add(PurchaseReturnLine(company_id=company_id, return_id=ret.id, invoice_line_id=il.id,
                                  item_id=il.item_id, quantity=qty, unit_price=money(il.unit_price),
                                  line_total=line_total, return_reason=row.get("return_reason"),
                                  condition=row.get("condition"), notes=row.get("notes")))
        db.add(StockMovement(company_id=company_id, item_id=il.item_id, movement_type=MovementTypeEnum.out,
                             quantity=qty, unit_cost=money(D(cost) / qty), total_cost=money(cost),
                             warehouse_id=warehouse_id,
                             note=f"Purchase return {ret.return_number}", created_by_id=user_id, source_type="purchase_return", source_id=ret.id, operational_date=ret.return_date))
    if tax_rate is not None:
        tax_amount = money(subtotal * D(tax_rate) / Decimal("100"))
    elif D(invoice.subtotal) > 0 and D(invoice.tax_amount) > 0:
        tax_amount = money(subtotal * D(invoice.tax_amount) / D(invoice.subtotal))
    else:
        tax_amount = Decimal("0")
    total = money(subtotal + tax_amount)
    ret.subtotal, ret.tax_amount, ret.total_amount = money(subtotal), tax_amount, total
    ret.posted_at = utcnow()

    # Debit AP by the supplier credit, credit inventory at carrying value, and
    # route any purchase-price/valuation difference to the existing variance account.
    lines_j = [("2100", total, 0), ("1300", 0, money(inventory_credit))]
    variance = money(D(subtotal) - inventory_credit)
    if variance > 0:
        lines_j.append(("4300", 0, variance))
    elif variance < 0:
        lines_j.append(("4300", abs(variance), 0))
    if tax_amount:
        lines_j.append(("2200", 0, tax_amount))
    create_entry(db, f"Purchase return {ret.return_number}", user_id, lines_j,
                 "purchase_return", ret.id, ret.return_date)
    db.flush(); return ret

def ar_aging(db: Session, company_id: int, as_of=None, branch_id: int | None = None, customer_id: int | None = None):
    """Authoritative customer receivable aging from posted invoices, returns and allocations.

    The report is reproducible as-of a supplied date. Only posted invoices effective by
    that date are included; payments are counted only when their voucher date is effective
    and their company/branch scope agrees with the invoice; posted returns linked to the
    invoice reduce the receivable. Due dates use the active customer credit policy because
    the current schema does not keep a historical policy snapshot.
    """
    from datetime import date, datetime as dt, timedelta
    as_of = as_of or utcnow()
    if isinstance(as_of, dt):
        as_of_date = as_of.date()
        as_of_dt = as_of
    elif isinstance(as_of, date):
        as_of_date = as_of
        as_of_dt = dt.combine(as_of, dt.max.time())
    else:
        raise HTTPException(422, "تاريخ التقرير غير صحيح")

    q = db.query(SaleInvoice).filter(
        SaleInvoice.company_id == company_id,
        SaleInvoice.status == "posted",
        SaleInvoice.invoice_date <= as_of_dt,
    )
    if branch_id is not None:
        q = q.filter(SaleInvoice.branch_id == branch_id)
    if customer_id is not None:
        q = q.filter(SaleInvoice.customer_id == customer_id)
    invoices = q.order_by(SaleInvoice.invoice_date, SaleInvoice.id).all()
    if not invoices:
        return []

    invoice_ids = [inv.id for inv in invoices]
    customer_ids = {inv.customer_id for inv in invoices}

    # Batch-load effective allocations, returns and credit policies. Besides improving
    # performance, this makes the scope rules explicit and avoids per-row N+1 queries.
    allocations = db.query(PaymentAllocation).join(
        FinanceVoucher, FinanceVoucher.id == PaymentAllocation.voucher_id
    ).filter(
        PaymentAllocation.company_id == company_id,
        PaymentAllocation.sale_invoice_id.in_(invoice_ids),
        PaymentAllocation.amount > 0,
        FinanceVoucher.company_id == company_id,
        FinanceVoucher.voucher_date <= as_of_dt,
    ).all()
    invoice_by_id = {x.id: x for x in invoices}
    payments_by_invoice = {}
    for pa in allocations:
        inv = invoice_by_id.get(pa.sale_invoice_id)
        if inv is None:
            continue
        voucher = pa.voucher
        # A payment allocation cannot silently cross branch boundaries. Legacy NULL
        # branch values remain acceptable for company-global historical records.
        if pa.branch_id not in (None, inv.branch_id):
            continue
        if voucher and voucher.branch_id not in (None, inv.branch_id):
            continue
        payments_by_invoice[inv.id] = payments_by_invoice.get(inv.id, Decimal("0")) + D(pa.amount)

    returns = db.query(SalesReturn).filter(
        SalesReturn.company_id == company_id,
        SalesReturn.sale_invoice_id.in_(invoice_ids),
        SalesReturn.status == "posted",
        SalesReturn.return_date <= as_of_dt,
        SalesReturn.total_amount > 0,
    ).all()
    returns_by_invoice = {}
    for ret in returns:
        returns_by_invoice[ret.sale_invoice_id] = returns_by_invoice.get(ret.sale_invoice_id, Decimal("0")) + D(ret.total_amount)

    policies = db.query(CustomerCreditPolicy).filter(
        CustomerCreditPolicy.company_id == company_id,
        CustomerCreditPolicy.customer_id.in_(customer_ids),
        CustomerCreditPolicy.is_active.is_(True),
    ).all()
    policy_by_customer = {x.customer_id: x for x in policies}

    rows = []
    for inv in invoices:
        invoice_total = money(inv.total_amount)
        paid = money(payments_by_invoice.get(inv.id, Decimal("0")))
        returned = money(returns_by_invoice.get(inv.id, Decimal("0")))
        # Never allow malformed over-payment/return data to create a negative receivable.
        outstanding = money(max(D(invoice_total) - D(paid) - D(returned), Decimal("0")))
        if outstanding <= 0:
            continue

        policy = policy_by_customer.get(inv.customer_id)
        terms_days = max(int(policy.payment_terms_days or 0), 0) if policy else 0
        invoice_date = inv.invoice_date.date() if hasattr(inv.invoice_date, "date") else inv.invoice_date
        due_date = invoice_date + timedelta(days=terms_days)
        overdue_days = max((as_of_date - due_date).days, 0)
        age_days = max((as_of_date - invoice_date).days, 0)
        bucket = ("current" if as_of_date <= due_date else
                  "1-30" if overdue_days <= 30 else
                  "31-60" if overdue_days <= 60 else
                  "61-90" if overdue_days <= 90 else "90+")
        customer = inv.customer
        rows.append({
            "invoice_id": inv.id,
            "customer_id": inv.customer_id,
            "customer_name": customer.name if customer else "-",
            "invoice_number": inv.invoice_number,
            "invoice_date": invoice_date,
            "due_date": due_date,
            "original": invoice_total,
            "outstanding": outstanding,
            "paid": paid,
            "returned": returned,
            "days": age_days,
            "overdue_days": overdue_days,
            "bucket": bucket,
        })
    return rows


def ap_aging(db: Session, company_id: int, as_of=None, branch_id: int | None = None, supplier_id: int | None = None):
    """Authoritative supplier payable aging as-of a supplied date.

    Only posted purchase invoices effective by the report date create AP. Payments
    are counted only when the linked voucher is effective by that date and its
    company/branch scope agrees with the invoice. Posted purchase returns reduce
    the liability. Due dates use the active supplier credit policy when configured,
    otherwise the supplier master payment terms. Outstanding balances are clamped
    at zero so malformed overpayments/returns cannot create negative AP.
    """
    from datetime import date, datetime as dt, timedelta
    as_of = as_of or utcnow()
    if isinstance(as_of, dt):
        as_of_date = as_of.date()
        as_of_dt = as_of
    elif isinstance(as_of, date):
        as_of_date = as_of
        as_of_dt = dt.combine(as_of, dt.max.time())
    else:
        raise HTTPException(422, "تاريخ التقرير غير صحيح")

    q = db.query(PurchaseInvoice).filter(
        PurchaseInvoice.company_id == company_id,
        PurchaseInvoice.status == "posted",
        PurchaseInvoice.invoice_date <= as_of_dt,
    )
    if branch_id is not None:
        q = q.filter(PurchaseInvoice.branch_id == branch_id)
    if supplier_id is not None:
        q = q.filter(PurchaseInvoice.supplier_id == supplier_id)
    invoices = q.order_by(PurchaseInvoice.invoice_date, PurchaseInvoice.id).all()
    if not invoices:
        return []

    invoice_ids = [inv.id for inv in invoices]
    supplier_ids = {inv.supplier_id for inv in invoices}

    # Load only allocations whose voucher date is effective at the as-of date.
    # Branch is checked against the invoice because PaymentAllocation historically
    # permits NULL branch values while the voucher carries the operational scope.
    allocations = db.query(PaymentAllocation).join(
        FinanceVoucher, FinanceVoucher.id == PaymentAllocation.voucher_id
    ).filter(
        PaymentAllocation.company_id == company_id,
        PaymentAllocation.purchase_invoice_id.in_(invoice_ids),
        PaymentAllocation.amount > 0,
        FinanceVoucher.company_id == company_id,
        FinanceVoucher.voucher_date <= as_of_dt,
    ).all()
    invoice_by_id = {x.id: x for x in invoices}
    payments_by_invoice = {}
    for pa in allocations:
        inv = invoice_by_id.get(pa.purchase_invoice_id)
        if inv is None:
            continue
        voucher = pa.voucher
        if pa.branch_id not in (None, inv.branch_id):
            continue
        if voucher and voucher.branch_id not in (None, inv.branch_id):
            continue
        payments_by_invoice[inv.id] = payments_by_invoice.get(inv.id, Decimal("0")) + D(pa.amount)

    returns = db.query(PurchaseReturn).filter(
        PurchaseReturn.company_id == company_id,
        PurchaseReturn.purchase_invoice_id.in_(invoice_ids),
        PurchaseReturn.status == "posted",
        PurchaseReturn.return_date <= as_of_dt,
        PurchaseReturn.total_amount > 0,
    ).all()
    returns_by_invoice = {}
    for ret in returns:
        # PurchaseReturn has no branch column; its invoice relationship is the
        # authoritative branch scope and the invoice set is already tenant filtered.
        returns_by_invoice[ret.purchase_invoice_id] = returns_by_invoice.get(ret.purchase_invoice_id, Decimal("0")) + D(ret.total_amount)

    policies = db.query(SupplierCreditPolicy).filter(
        SupplierCreditPolicy.company_id == company_id,
        SupplierCreditPolicy.supplier_id.in_(supplier_ids),
    ).all()
    policy_by_supplier = {x.supplier_id: x for x in policies}

    rows = []
    for inv in invoices:
        invoice_total = money(inv.total_amount)
        paid = money(payments_by_invoice.get(inv.id, Decimal("0")))
        returned = money(returns_by_invoice.get(inv.id, Decimal("0")))
        outstanding = money(max(D(invoice_total) - D(paid) - D(returned), Decimal("0")))
        if outstanding <= 0:
            continue

        supplier = inv.supplier
        policy = policy_by_supplier.get(inv.supplier_id)
        if policy is not None:
            terms = max(int(policy.payment_terms_days or 0), 0)
        else:
            terms = max(int(getattr(supplier, "payment_terms_days", 0) or 0), 0) if supplier else 0
        invoice_date = inv.invoice_date.date() if hasattr(inv.invoice_date, "date") else inv.invoice_date
        due_date = invoice_date + timedelta(days=terms)
        overdue_days = max((as_of_date - due_date).days, 0)
        age_days = max((as_of_date - invoice_date).days, 0)
        bucket = ("current" if as_of_date <= due_date else
                  "1-30" if overdue_days <= 30 else
                  "31-60" if overdue_days <= 60 else
                  "61-90" if overdue_days <= 90 else "90+")
        rows.append({
            "invoice_id": inv.id,
            "supplier_id": inv.supplier_id,
            "supplier_name": supplier.name if supplier else "-",
            "invoice_number": inv.invoice_number,
            "invoice_date": invoice_date,
            "due_date": due_date,
            "original": invoice_total,
            "outstanding": outstanding,
            "paid": paid,
            "returned": returned,
            "days": age_days,
            "overdue_days": overdue_days,
            "bucket": bucket,
        })
    return rows


def reconcile_inventory_valuation(db: Session, company_id: int, as_of=None, user_id=None):
    """Reconcile stock movement value against remaining valued inventory layers."""
    from .models import Item
    from .enterprise_models import InventoryCostLayer, InventoryCostConsumption
    as_of = as_of or utcnow()
    rows=[]
    items = db.query(Item).filter(Item.company_id == company_id, Item.item_type == ItemTypeEnum.product).all()
    for item in items:
        movement_value = money(db.query(func.coalesce(func.sum(
            case((StockMovement.movement_type.in_([MovementTypeEnum.in_, MovementTypeEnum.adjustment_in]), StockMovement.total_cost),
                 else_=-StockMovement.total_cost)), 0)).filter(
            StockMovement.company_id == company_id, StockMovement.item_id == item.id,
            StockMovement.operational_date <= as_of).scalar() or 0)
        remaining_value = money(db.query(func.coalesce(func.sum(InventoryCostLayer.remaining_qty * InventoryCostLayer.unit_cost), 0)).filter(
            InventoryCostLayer.company_id == company_id, InventoryCostLayer.item_id == item.id, InventoryCostLayer.received_at <= as_of).scalar() or 0)
        consumed_value = money(db.query(func.coalesce(func.sum(InventoryCostConsumption.total_cost), 0)).filter(
            InventoryCostConsumption.company_id == company_id, InventoryCostConsumption.item_id == item.id, InventoryCostConsumption.consumed_at <= as_of).scalar() or 0)
        # Movement value = inbound - outbound. Remaining valued stock = inbound - consumed.
        diff = money(movement_value - remaining_value)
        rows.append({"item_id": item.id, "movement_value": movement_value, "valued_remaining": remaining_value, "consumed_value": consumed_value, "difference": diff, "status": "reconciled" if diff == 0 else "exception"})
    return rows


def reconcile_inventory_to_gl(db: Session, company_id: int, as_of=None, inventory_account_code="1300", cogs_account_code="5100"):
    """Reconcile valued inventory and consumed cost to posted GL balances."""
    from .models import Account, JournalLine, JournalEntry
    from .enterprise_models import InventoryCostLayer, InventoryCostConsumption
    as_of=as_of or utcnow()
    inv=db.query(Account).filter(Account.company_id==company_id, Account.code==inventory_account_code).first()
    cogs=db.query(Account).filter(Account.company_id==company_id, Account.code==cogs_account_code).first()
    if not inv or not cogs: raise HTTPException(422,"Inventory/COGS reconciliation accounts are missing")
    def gl_balance(acc):
        debit,credit=db.query(func.coalesce(func.sum(JournalLine.debit),0),func.coalesce(func.sum(JournalLine.credit),0)).join(JournalEntry,JournalEntry.id==JournalLine.entry_id).filter(JournalLine.company_id==company_id,JournalLine.account_id==acc.id,JournalEntry.entry_date<=as_of,JournalEntry.status=="posted").one()
        return money(D(debit)-D(credit))
    valuation=money(db.query(func.coalesce(func.sum(InventoryCostLayer.remaining_qty*InventoryCostLayer.unit_cost),0)).filter(InventoryCostLayer.company_id==company_id,InventoryCostLayer.received_at<=as_of).scalar() or 0)
    consumed=money(db.query(func.coalesce(func.sum(InventoryCostConsumption.total_cost),0)).filter(InventoryCostConsumption.company_id==company_id,InventoryCostConsumption.consumed_at<=as_of).scalar() or 0)
    inv_gl=gl_balance(inv); cogs_gl=gl_balance(cogs)
    return {"as_of":as_of,"inventory_valuation":valuation,"inventory_gl":inv_gl,"inventory_difference":money(valuation-inv_gl),"consumed_cost":consumed,"cogs_gl":cogs_gl,"cogs_difference":money(consumed-cogs_gl),"status":"reconciled" if valuation==inv_gl and consumed==cogs_gl else "exception"}


def reconcile_ar_ap(db: Session, company_id: int, as_of=None, user_id=None):
    as_of=as_of or utcnow(); results=[]
    for typ, rows, account_code in (("ar", ar_aging(db,company_id,as_of), "1200"),("ap", ap_aging(db,company_id,as_of), "2100")):
        sub=money(sum((D(r["outstanding"]) for r in rows),Decimal("0")))
        # GL balance is derived from posted journal lines up to the same date.
        from .models import Account, JournalLine, JournalEntry
        acc=db.query(Account).filter(Account.company_id==company_id, Account.code==account_code).first()
        if not acc: raise HTTPException(422, f"Required reconciliation account {account_code} missing")
        debit,credit=db.query(func.coalesce(func.sum(JournalLine.debit),0),func.coalesce(func.sum(JournalLine.credit),0)).join(JournalEntry,JournalEntry.id==JournalLine.entry_id).filter(JournalLine.company_id==company_id,JournalLine.account_id==acc.id,JournalEntry.entry_date<=as_of,JournalEntry.status=="posted").one()
        gl=money(D(debit)-D(credit)); gl=abs(gl) if typ=="ap" else gl
        diff=money(sub-gl); status="reconciled" if diff==0 else "exception"
        rec=SubledgerReconciliation(company_id=company_id,as_of_date=as_of,subledger_type=typ,subledger_total=sub,gl_total=gl,difference=diff,status=status,created_by_id=user_id); db.add(rec); results.append(rec)
    db.flush(); return results
