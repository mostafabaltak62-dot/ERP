"""Strict API schemas for financially and inventory-sensitive operations."""
from __future__ import annotations

from decimal import Decimal
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class StrictSchema(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class InvoiceItemCreate(StrictSchema):
    product_id: int = Field(gt=0)
    quantity: Decimal = Field(gt=0, max_digits=20, decimal_places=6)
    unit_price: Decimal = Field(gt=0, max_digits=20, decimal_places=6)
    tax_rate: Decimal = Field(default=Decimal("0"), ge=0, le=1, max_digits=8, decimal_places=6)


class InvoiceCreate(StrictSchema):
    customer_id: int = Field(gt=0)
    items: list[InvoiceItemCreate] = Field(min_length=1, max_length=1000)

    @field_validator("items")
    @classmethod
    def unique_products(cls, items: list[InvoiceItemCreate]):
        ids = [item.product_id for item in items]
        if len(ids) != len(set(ids)):
            raise ValueError("Duplicate products must be consolidated before invoice creation")
        return items


class InventoryReceiptCreate(StrictSchema):
    item_id: int = Field(gt=0)
    warehouse_id: int = Field(gt=0)
    quantity: Decimal = Field(gt=0, max_digits=20, decimal_places=6)
    unit_cost: Decimal = Field(ge=0, max_digits=20, decimal_places=6)


class JournalLineCreate(StrictSchema):
    account_id: int = Field(gt=0)
    debit: Decimal = Field(default=Decimal("0"), ge=0, max_digits=20, decimal_places=6)
    credit: Decimal = Field(default=Decimal("0"), ge=0, max_digits=20, decimal_places=6)

    @model_validator(mode="after")
    def exactly_one_side(self):
        if (self.debit > 0) == (self.credit > 0):
            raise ValueError("Exactly one of debit or credit must be greater than zero")
        return self
