from .time_utils import utcnow
"""Enterprise ERP extension models.

These models provide reusable ERP Core primitives for organization, workflow,
projects, contracts, documents, notifications, HR/payroll, manufacturing,
fleet, and integration/idempotency concerns. Industry modules build on these
rather than creating separate ERP applications.
"""
import datetime
import enum
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Date, Numeric, ForeignKey, Text, JSON, UniqueConstraint, Index, CheckConstraint
from sqlalchemy.orm import relationship
from .db_base import Base

class RecordStatus(str, enum.Enum):
    draft="draft"; submitted="submitted"; approved="approved"; rejected="rejected"; cancelled="cancelled"; posted="posted"; closed="closed"
class ApprovalDecision(str, enum.Enum):
    pending="pending"; approved="approved"; rejected="rejected"
class ContractType(str, enum.Enum):
    customer="customer"; supplier="supplier"; subcontractor="subcontractor"; service="service"; rental="rental"; maintenance="maintenance"
class PayrollStatus(str, enum.Enum):
    draft="draft"; approved="approved"; posted="posted"; paid="paid"

class Company(Base):
    __tablename__="companies"
    id=Column(Integer, primary_key=True); code=Column(String(30), unique=True, nullable=False, index=True); name=Column(String(200), nullable=False)
    legal_name=Column(String(250)); tax_number=Column(String(100), unique=True); base_currency_id=Column(Integer, ForeignKey("currencies.id")); is_active=Column(Boolean, default=True, nullable=False)
    created_at=Column(DateTime, default=utcnow, nullable=False)

class Branch(Base):
    __tablename__="branches"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); code=Column(String(30), nullable=False); name=Column(String(150), nullable=False); is_active=Column(Boolean, default=True, nullable=False)
    __table_args__=(UniqueConstraint("company_id","code",name="uq_branch_company_code"),)

class Department(Base):
    __tablename__="departments"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); code=Column(String(30), nullable=False); name=Column(String(150), nullable=False); is_active=Column(Boolean, default=True, nullable=False)
    __table_args__=(UniqueConstraint("company_id","code",name="uq_department_company_code"),)

class Currency(Base):
    __tablename__="currencies"
    id=Column(Integer, primary_key=True); code=Column(String(3), unique=True, nullable=False); name=Column(String(80), nullable=False); decimal_places=Column(Integer, default=2, nullable=False); is_active=Column(Boolean, default=True, nullable=False)

class ExchangeRate(Base):
    __tablename__="exchange_rates"
    id=Column(Integer, primary_key=True); from_currency_id=Column(Integer, ForeignKey("currencies.id"), nullable=False); to_currency_id=Column(Integer, ForeignKey("currencies.id"), nullable=False); rate=Column(Numeric(28,12), nullable=False); effective_at=Column(DateTime, nullable=False); source=Column(String(80)); created_by_id=Column(Integer, ForeignKey("users.id"))
    __table_args__=(Index("ix_fx_pair_date","from_currency_id","to_currency_id","effective_at"),)

class UserCompanyAccess(Base):
    __tablename__="user_company_access"
    id=Column(Integer, primary_key=True); user_id=Column(Integer, ForeignKey("users.id"), nullable=False); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False); branch_id=Column(Integer, ForeignKey("branches.id")); can_manage=Column(Boolean, default=False, nullable=False)
    __table_args__=(UniqueConstraint("user_id","company_id","branch_id",name="uq_user_company_branch"),)

class AnalyticalDimension(Base):
    __tablename__="analytical_dimensions"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False); code=Column(String(40), nullable=False); name=Column(String(120), nullable=False); is_active=Column(Boolean, default=True, nullable=False)
    __table_args__=(UniqueConstraint("company_id","code",name="uq_dimension_company_code"),)
class DimensionValue(Base):
    __tablename__="dimension_values"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); dimension_id=Column(Integer, ForeignKey("analytical_dimensions.id"), nullable=False); code=Column(String(40), nullable=False); name=Column(String(150), nullable=False); is_active=Column(Boolean, default=True, nullable=False)
    __table_args__=(UniqueConstraint("dimension_id","code",name="uq_dimension_value_code"),)

class WorkflowDefinition(Base):
    __tablename__="workflow_definitions"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id")); document_type=Column(String(80), nullable=False); name=Column(String(150), nullable=False); is_active=Column(Boolean, default=True, nullable=False)
class WorkflowStep(Base):
    __tablename__="workflow_steps"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); workflow_id=Column(Integer, ForeignKey("workflow_definitions.id"), nullable=False); sequence=Column(Integer, nullable=False); name=Column(String(120), nullable=False); required_permission=Column(String(120)); min_amount=Column(Numeric(20,6)); max_amount=Column(Numeric(20,6));
class WorkflowInstance(Base):
    __tablename__="workflow_instances"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); branch_id=Column(Integer, ForeignKey("branches.id"), nullable=True, index=True); workflow_id=Column(Integer, ForeignKey("workflow_definitions.id"), nullable=False); document_type=Column(String(80), nullable=False); document_id=Column(Integer, nullable=False); status=Column(String(30), default="pending", nullable=False); current_step=Column(Integer, default=1, nullable=False); started_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint("company_id","document_type","document_id",name="uq_workflow_company_document"),)
class WorkflowAction(Base):
    __tablename__="workflow_actions"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); instance_id=Column(Integer, ForeignKey("workflow_instances.id"), nullable=False); step_id=Column(Integer, ForeignKey("workflow_steps.id"), nullable=False); user_id=Column(Integer, ForeignKey("users.id"), nullable=False); decision=Column(String(30), nullable=False); reason=Column(Text); acted_at=Column(DateTime, default=utcnow, nullable=False)

class Project(Base):
    __tablename__="projects"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False); branch_id=Column(Integer, ForeignKey("branches.id")); code=Column(String(50), nullable=False); name=Column(String(200), nullable=False); customer_id=Column(Integer, ForeignKey("customers.id")); start_date=Column(Date); end_date=Column(Date); budget=Column(Numeric(20,6), default=0, nullable=False); status=Column(String(30), default="draft", nullable=False)
    __table_args__=(UniqueConstraint("company_id","code",name="uq_project_company_code"),)
class ProjectPhase(Base):
    __tablename__="project_phases"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); project_id=Column(Integer, ForeignKey("projects.id"), nullable=False); code=Column(String(50), nullable=False); name=Column(String(150), nullable=False); budget=Column(Numeric(20,6), default=0, nullable=False)
class ProjectCost(Base):
    __tablename__="project_costs"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); project_id=Column(Integer, ForeignKey("projects.id"), nullable=False); phase_id=Column(Integer, ForeignKey("project_phases.id")); cost_type=Column(String(50), nullable=False); source_type=Column(String(80)); source_id=Column(Integer); amount=Column(Numeric(20,6), nullable=False); cost_date=Column(DateTime, default=utcnow, nullable=False); description=Column(Text)

class Contract(Base):
    __tablename__="contracts"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False); contract_number=Column(String(60), nullable=False); contract_type=Column(String(30), nullable=False); customer_id=Column(Integer, ForeignKey("customers.id")); supplier_id=Column(Integer, ForeignKey("suppliers.id")); project_id=Column(Integer, ForeignKey("projects.id")); value=Column(Numeric(20,6), default=0, nullable=False); start_date=Column(Date); end_date=Column(Date); retention_rate=Column(Numeric(9,6), default=0, nullable=False); advance_amount=Column(Numeric(20,6), default=0, nullable=False); status=Column(String(30), default="draft", nullable=False)
    __table_args__=(UniqueConstraint("company_id","contract_number",name="uq_contract_company_number"),)
class ContractMilestone(Base):
    __tablename__="contract_milestones"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); contract_id=Column(Integer, ForeignKey("contracts.id"), nullable=False); name=Column(String(150), nullable=False); due_date=Column(Date); amount=Column(Numeric(20,6), default=0, nullable=False); completed_at=Column(DateTime)

class BOQItem(Base):
    __tablename__="boq_items"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); project_id=Column(Integer, ForeignKey("projects.id"), nullable=False); code=Column(String(60), nullable=False); description=Column(Text, nullable=False); unit=Column(String(30), nullable=False); contract_qty=Column(Numeric(20,6), default=0, nullable=False); contract_rate=Column(Numeric(20,6), default=0, nullable=False); executed_qty=Column(Numeric(20,6), default=0, nullable=False); previous_qty=Column(Numeric(20,6), default=0, nullable=False); current_qty=Column(Numeric(20,6), default=0, nullable=False)
    __table_args__=(UniqueConstraint("project_id","code",name="uq_boq_project_code"),)
class ProgressCertificate(Base):
    __tablename__="progress_certificates"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); project_id=Column(Integer, ForeignKey("projects.id"), nullable=False); contract_id=Column(Integer, ForeignKey("contracts.id")); certificate_number=Column(String(60), nullable=False); certificate_date=Column(Date, nullable=False); gross_amount=Column(Numeric(20,6), nullable=False); retention_amount=Column(Numeric(20,6), default=0, nullable=False); advance_recovery=Column(Numeric(20,6), default=0, nullable=False); net_amount=Column(Numeric(20,6), nullable=False); status=Column(String(30), default="draft", nullable=False); approved_at=Column(DateTime); approved_by_id=Column(Integer, ForeignKey("users.id")); journal_entry_id=Column(Integer, ForeignKey("journal_entries.id"))

class Employee(Base):
    __tablename__="employees"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False); employee_code=Column(String(50), nullable=False); name=Column(String(180), nullable=False); department_id=Column(Integer, ForeignKey("departments.id")); position=Column(String(120)); hire_date=Column(Date); base_salary=Column(Numeric(20,6), default=0, nullable=False); is_active=Column(Boolean, default=True, nullable=False)
    __table_args__=(UniqueConstraint("company_id","employee_code",name="uq_employee_company_code"),)
class AttendanceRecord(Base):
    __tablename__="attendance_records"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); employee_id=Column(Integer, ForeignKey("employees.id"), nullable=False); work_date=Column(Date, nullable=False); check_in=Column(DateTime); check_out=Column(DateTime); overtime_hours=Column(Numeric(10,2), default=0, nullable=False); status=Column(String(30), default="present", nullable=False)
    __table_args__=(UniqueConstraint("employee_id","work_date",name="uq_attendance_employee_date"),)
class LeaveRequest(Base):
    __tablename__="leave_requests"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); employee_id=Column(Integer, ForeignKey("employees.id"), nullable=False); start_date=Column(Date, nullable=False); end_date=Column(Date, nullable=False); leave_type=Column(String(50), nullable=False); status=Column(String(30), default="pending", nullable=False)
class PayrollRun(Base):
    __tablename__="payroll_runs"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False); period_label=Column(String(30), nullable=False); start_date=Column(Date, nullable=False); end_date=Column(Date, nullable=False); status=Column(String(30), default="draft", nullable=False); total_gross=Column(Numeric(20,6), default=0, nullable=False); total_deductions=Column(Numeric(20,6), default=0, nullable=False); total_net=Column(Numeric(20,6), default=0, nullable=False); journal_entry_id=Column(Integer, ForeignKey("journal_entries.id", ondelete="SET NULL"), nullable=True, index=True)
class PayrollLine(Base):
    __tablename__="payroll_lines"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); payroll_run_id=Column(Integer, ForeignKey("payroll_runs.id"), nullable=False); employee_id=Column(Integer, ForeignKey("employees.id"), nullable=False); gross=Column(Numeric(20,6), nullable=False); deductions=Column(Numeric(20,6), default=0, nullable=False); net=Column(Numeric(20,6), nullable=False); project_id=Column(Integer, ForeignKey("projects.id"))

class BOM(Base):
    __tablename__="boms"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False); product_item_id=Column(Integer, ForeignKey("items.id"), nullable=False); version=Column(String(30), nullable=False); quantity=Column(Numeric(20,6), nullable=False); is_active=Column(Boolean, default=True, nullable=False)
class BOMLine(Base):
    __tablename__="bom_lines"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); bom_id=Column(Integer, ForeignKey("boms.id"), nullable=False); component_item_id=Column(Integer, ForeignKey("items.id"), nullable=False); quantity=Column(Numeric(20,6), nullable=False); scrap_rate=Column(Numeric(9,6), default=0, nullable=False)
class ProductionOrder(Base):
    __tablename__="production_orders"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False); order_number=Column(String(60), nullable=False); bom_id=Column(Integer, ForeignKey("boms.id")); product_item_id=Column(Integer, ForeignKey("items.id"), nullable=False); planned_qty=Column(Numeric(20,6), nullable=False); produced_qty=Column(Numeric(20,6), default=0, nullable=False); status=Column(String(30), default="draft", nullable=False)

class Equipment(Base):
    __tablename__="equipment"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False); code=Column(String(50), nullable=False); name=Column(String(150), nullable=False); equipment_type=Column(String(80)); acquisition_cost=Column(Numeric(20,6), default=0, nullable=False); hourly_rate=Column(Numeric(20,6), default=0, nullable=False); km_rate=Column(Numeric(20,6), default=0, nullable=False); project_id=Column(Integer, ForeignKey("projects.id")); is_active=Column(Boolean, default=True, nullable=False)
    __table_args__=(UniqueConstraint("company_id","code",name="uq_equipment_company_code"),)
class FuelTransaction(Base):
    __tablename__="fuel_transactions"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); equipment_id=Column(Integer, ForeignKey("equipment.id")); employee_id=Column(Integer, ForeignKey("employees.id")); transaction_date=Column(DateTime, default=utcnow, nullable=False); quantity=Column(Numeric(20,6), nullable=False); unit_cost=Column(Numeric(20,6), nullable=False); meter_reading=Column(Numeric(20,6)); total_cost=Column(Numeric(20,6), nullable=False)
class MaintenanceRecord(Base):
    __tablename__="maintenance_records"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); equipment_id=Column(Integer, ForeignKey("equipment.id"), nullable=False); maintenance_date=Column(Date, nullable=False); description=Column(Text); cost=Column(Numeric(20,6), default=0, nullable=False); next_due_date=Column(Date)

class DocumentAttachment(Base):
    __tablename__="document_attachments"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id")); entity_type=Column(String(80), nullable=False); entity_id=Column(Integer, nullable=False); file_name=Column(String(255), nullable=False); storage_key=Column(String(500), nullable=False, unique=True); content_type=Column(String(120)); file_size=Column(Integer); version=Column(Integer, default=1, nullable=False); uploaded_by_id=Column(Integer, ForeignKey("users.id")); expires_at=Column(DateTime); created_at=Column(DateTime, default=utcnow, nullable=False)
class Notification(Base):
    __tablename__="notifications"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); branch_id=Column(Integer, ForeignKey("branches.id"), nullable=True, index=True); user_id=Column(Integer, ForeignKey("users.id"), nullable=False); notification_type=Column(String(80), nullable=False); title=Column(String(200), nullable=False); message=Column(Text, nullable=False); entity_type=Column(String(80)); entity_id=Column(Integer); is_read=Column(Boolean, default=False, nullable=False); created_at=Column(DateTime, default=utcnow, nullable=False)
class IdempotencyKey(Base):
    __tablename__="idempotency_keys"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True); key=Column(String(128), nullable=False); user_id=Column(Integer, ForeignKey("users.id"), nullable=False); endpoint=Column(String(200), nullable=False); request_hash=Column(String(64), nullable=False); response_status=Column(Integer); response_body=Column(JSON); created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint("key","user_id","endpoint",name="uq_idempotency_request"),)
class EInvoiceSubmission(Base):
    __tablename__="einvoice_submissions"
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey("companies.id"), nullable=False); document_type=Column(String(80), nullable=False); document_id=Column(Integer, nullable=False); provider=Column(String(80), nullable=False); external_id=Column(String(200)); status=Column(String(40), default="pending", nullable=False); request_hash=Column(String(64)); response_payload=Column(JSON); submitted_at=Column(DateTime); last_error=Column(Text)
    __table_args__=(UniqueConstraint("provider","document_type","document_id",name="uq_einvoice_document_provider"),)

# =====================================================================
# Enterprise Inventory Valuation (FIFO / Weighted Average)
# =====================================================================
class InventoryValuationPolicy(Base):
    __tablename__ = "inventory_valuation_policies"
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    item_id=Column(Integer, ForeignKey("items.id"), nullable=False, index=True)
    method=Column(String(20), nullable=False, default="weighted_average")
    allow_negative=Column(Boolean, default=False, nullable=False)
    effective_from=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint("company_id","item_id",name="uq_inventory_policy_company_item"),)

class InventoryCostLayer(Base):
    __tablename__ = "inventory_cost_layers"
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    item_id=Column(Integer, ForeignKey("items.id"), nullable=False, index=True)
    source_type=Column(String(50), nullable=False)
    source_id=Column(Integer, nullable=False)
    received_at=Column(DateTime, nullable=False, default=utcnow, index=True)
    original_qty=Column(Numeric(20,6), nullable=False)
    remaining_qty=Column(Numeric(20,6), nullable=False)
    unit_cost=Column(Numeric(20,6), nullable=False)
    total_cost=Column(Numeric(20,6), nullable=False)
    __table_args__=(Index("ix_inventory_layers_fifo", "company_id","item_id","received_at","id"),
                    CheckConstraint("original_qty >= 0", name="ck_inventory_layer_original_qty"),
                    CheckConstraint("remaining_qty >= 0", name="ck_inventory_layer_remaining_qty"),)

class InventoryCostConsumption(Base):
    __tablename__ = "inventory_cost_consumptions"
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    item_id=Column(Integer, ForeignKey("items.id"), nullable=False, index=True)
    layer_id=Column(Integer, ForeignKey("inventory_cost_layers.id"), nullable=False, index=True)
    source_type=Column(String(50), nullable=False)
    source_id=Column(Integer, nullable=False)
    quantity=Column(Numeric(20,6), nullable=False)
    unit_cost=Column(Numeric(20,6), nullable=False)
    total_cost=Column(Numeric(20,6), nullable=False)
    consumed_at=Column(DateTime, nullable=False, default=utcnow)
    __table_args__=(UniqueConstraint("company_id","layer_id","source_type","source_id",name="uq_inventory_consumption_source"),)

class InventoryTraceability(Base):
    """Serial/lot/expiry trace attached to an authoritative stock movement."""
    __tablename__ = "inventory_traceability"
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    item_id=Column(Integer, ForeignKey("items.id"), nullable=False, index=True)
    stock_movement_id=Column(Integer, ForeignKey("stock_movements.id", ondelete="CASCADE"), nullable=False, index=True)
    serial_no=Column(String(120), nullable=True)
    lot_no=Column(String(120), nullable=True)
    expiry_date=Column(DateTime, nullable=True, index=True)
    quantity=Column(Numeric(20,6), nullable=False)
    created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(
        UniqueConstraint("company_id","item_id","stock_movement_id","serial_no",name="uq_inventory_trace_movement_serial"),
        Index("ix_inventory_trace_lot_expiry","company_id","item_id","lot_no","expiry_date"),
        CheckConstraint("quantity > 0", name="ck_inventory_trace_positive_qty"),
    )

class InventoryValuationRun(Base):
    __tablename__ = "inventory_valuation_runs"
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    run_date=Column(DateTime, nullable=False, default=utcnow)
    status=Column(String(20), nullable=False, default="completed")
    total_quantity=Column(Numeric(20,6), nullable=False, default=0)
    total_value=Column(Numeric(20,6), nullable=False, default=0)
    method=Column(String(20), nullable=False)
    created_by_id=Column(Integer, ForeignKey("users.id"))

# =====================================================================
# Phase 5.3 — Deep transaction integrity: receipts, matching, returns,
# reconciliation and authoritative AR/AP subledger snapshots.
# =====================================================================
class PurchaseReceiptLine(Base):
    __tablename__ = "purchase_receipt_lines"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    receipt_id = Column(Integer, ForeignKey("purchase_receipts.id", ondelete="CASCADE"), nullable=False, index=True)
    po_line_id = Column(Integer, ForeignKey("purchase_order_lines.id"), nullable=False, index=True)
    item_id = Column(Integer, ForeignKey("items.id"), nullable=False, index=True)
    quantity = Column(Numeric(20, 6), nullable=False)
    unit_cost = Column(Numeric(20, 6), nullable=False)
    __table_args__ = (UniqueConstraint("company_id", "receipt_id", "po_line_id", name="uq_receipt_line"),)


class PurchaseMatchLine(Base):
    __tablename__ = "purchase_match_lines"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    purchase_invoice_id = Column(Integer, ForeignKey("purchase_invoices.id", ondelete="CASCADE"), nullable=False, index=True)
    purchase_invoice_line_id = Column(Integer, ForeignKey("purchase_invoice_lines.id"), nullable=False, index=True)
    po_line_id = Column(Integer, ForeignKey("purchase_order_lines.id"), nullable=False, index=True)
    receipt_line_id = Column(Integer, ForeignKey("purchase_receipt_lines.id"), nullable=False, index=True)
    matched_quantity = Column(Numeric(20, 6), nullable=False)
    matched_amount = Column(Numeric(20, 6), nullable=False)
    status = Column(String(20), nullable=False, default="matched")
    created_at = Column(DateTime, default=utcnow, nullable=False)
    __table_args__ = (UniqueConstraint("company_id", "purchase_invoice_line_id", "receipt_line_id", name="uq_purchase_match_line"),)


class SalesReturn(Base):
    __tablename__ = "sales_returns"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    return_number = Column(String(40), nullable=False, index=True)
    sale_invoice_id = Column(Integer, ForeignKey("sale_invoices.id"), nullable=False, index=True)
    customer_id = Column(Integer, ForeignKey("customers.id"), nullable=False, index=True)
    return_date = Column(DateTime, default=utcnow, nullable=False)
    status = Column(String(20), nullable=False, default="posted")
    subtotal = Column(Numeric(20, 6), nullable=False, default=0)
    tax_amount = Column(Numeric(20, 6), nullable=False, default=0)
    total_amount = Column(Numeric(20, 6), nullable=False, default=0)
    cogs_reversal = Column(Numeric(20, 6), nullable=False, default=0)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    __table_args__ = (UniqueConstraint("company_id", "return_number", name="uq_sales_return_number"),)


class SalesReturnLine(Base):
    __tablename__ = "sales_return_lines"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    return_id = Column(Integer, ForeignKey("sales_returns.id", ondelete="CASCADE"), nullable=False, index=True)
    invoice_line_id = Column(Integer, ForeignKey("sale_invoice_lines.id"), nullable=False, index=True)
    item_id = Column(Integer, ForeignKey("items.id"), nullable=False, index=True)
    quantity = Column(Numeric(20, 6), nullable=False)
    unit_price = Column(Numeric(20, 6), nullable=False)
    unit_cost = Column(Numeric(20, 6), nullable=False, default=0)
    line_total = Column(Numeric(20, 6), nullable=False)
    cost_total = Column(Numeric(20, 6), nullable=False, default=0)


class PurchaseReturn(Base):
    __tablename__ = "purchase_returns"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    return_number = Column(String(40), nullable=False, index=True)
    purchase_invoice_id = Column(Integer, ForeignKey("purchase_invoices.id"), nullable=False, index=True)
    supplier_id = Column(Integer, ForeignKey("suppliers.id"), nullable=False, index=True)
    return_date = Column(DateTime, default=utcnow, nullable=False)
    status = Column(String(20), nullable=False, default="posted")
    subtotal = Column(Numeric(20, 6), nullable=False, default=0)
    tax_amount = Column(Numeric(20, 6), nullable=False, default=0)
    total_amount = Column(Numeric(20, 6), nullable=False, default=0)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    warehouse_id = Column(Integer, ForeignKey("warehouses.id", ondelete="SET NULL"), nullable=True, index=True)
    reason = Column(String(80), nullable=True)
    notes = Column(String(500), nullable=True)
    posted_at = Column(DateTime, nullable=True)
    cancelled_at = Column(DateTime, nullable=True)
    cancelled_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    __table_args__ = (UniqueConstraint("company_id", "return_number", name="uq_purchase_return_number"),)


class PurchaseReturnLine(Base):
    __tablename__ = "purchase_return_lines"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    return_id = Column(Integer, ForeignKey("purchase_returns.id", ondelete="CASCADE"), nullable=False, index=True)
    invoice_line_id = Column(Integer, ForeignKey("purchase_invoice_lines.id"), nullable=False, index=True)
    item_id = Column(Integer, ForeignKey("items.id"), nullable=False, index=True)
    quantity = Column(Numeric(20, 6), nullable=False)
    unit_price = Column(Numeric(20, 6), nullable=False)
    line_total = Column(Numeric(20, 6), nullable=False)
    return_reason = Column(String(120), nullable=True)
    condition = Column(String(40), nullable=True)
    notes = Column(String(500), nullable=True)


class SubledgerReconciliation(Base):
    __tablename__ = "subledger_reconciliations"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    as_of_date = Column(DateTime, nullable=False, index=True)
    subledger_type = Column(String(20), nullable=False)
    subledger_total = Column(Numeric(20, 6), nullable=False)
    gl_total = Column(Numeric(20, 6), nullable=False)
    difference = Column(Numeric(20, 6), nullable=False)
    status = Column(String(20), nullable=False)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)


# =====================================================================
# ERP Core Financial Foundation — Budgets / Forecasts
# CostCenter is intentionally reused from app.models to avoid duplicate
# metadata/table definitions and preserve the existing accounting model.
# =====================================================================
class Budget(Base):
    __tablename__ = "budgets"
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    branch_id=Column(Integer, ForeignKey("branches.id"), nullable=True, index=True)
    code=Column(String(50), nullable=False)
    name=Column(String(180), nullable=False)
    fiscal_year=Column(Integer, nullable=False)
    scenario=Column(String(30), nullable=False, default="baseline")
    status=Column(String(30), nullable=False, default="draft")
    currency_id=Column(Integer, ForeignKey("currencies.id"), nullable=True)
    __table_args__=(UniqueConstraint("company_id","code","scenario",name="uq_budget_company_code_scenario"),)

class BudgetLine(Base):
    __tablename__ = "budget_lines"
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    budget_id=Column(Integer, ForeignKey("budgets.id"), nullable=False, index=True)
    account_id=Column(Integer, ForeignKey("accounts.id"), nullable=False)
    cost_center_id=Column(Integer, ForeignKey("cost_centers.id"), nullable=True)
    project_id=Column(Integer, ForeignKey("projects.id"), nullable=True)
    period=Column(Integer, nullable=False)
    budget_amount=Column(Numeric(20,6), nullable=False, default=0)
    forecast_amount=Column(Numeric(20,6), nullable=True)
    __table_args__=(UniqueConstraint("budget_id","account_id","cost_center_id","project_id","period",name="uq_budget_line"),)

class ProjectForecast(Base):
    __tablename__ = "project_forecasts"
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    as_of_date=Column(Date, nullable=False)
    budget_cost=Column(Numeric(20,6), nullable=False, default=0)
    committed_cost=Column(Numeric(20,6), nullable=False, default=0)
    actual_cost=Column(Numeric(20,6), nullable=False, default=0)
    forecast_final_cost=Column(Numeric(20,6), nullable=False, default=0)
    forecast_revenue=Column(Numeric(20,6), nullable=False, default=0)
    forecast_profit=Column(Numeric(20,6), nullable=False, default=0)
    __table_args__=(UniqueConstraint("project_id","as_of_date",name="uq_project_forecast_date"),)
