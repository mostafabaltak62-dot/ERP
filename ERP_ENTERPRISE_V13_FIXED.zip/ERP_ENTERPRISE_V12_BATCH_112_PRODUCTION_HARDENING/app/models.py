from .time_utils import utcnow
# -*- coding: utf-8 -*-
from decimal import Decimal
import datetime
import enum
from sqlalchemy import (Column, Integer, String, Boolean, DateTime, Numeric,
                         ForeignKey, Enum, UniqueConstraint, CheckConstraint, Index, Text)
from sqlalchemy.orm import relationship
from .db_base import Base


class RoleEnum(str, enum.Enum):
    admin = "admin"          # مدير عام - صلاحية كاملة على كل شيء دايمًا
    manager = "manager"      # مدير قسم - صلاحيات محددة حسب الموديولات المسموح له بيها
    employee = "employee"    # موظف - صلاحيات محدودة (غالبًا عرض/إدخال بس)


# قائمة الموديولات الثابتة في النظام (المرجع الأساسي لأي صلاحية)
MODULES = [
    ("inventory", "المخزون والأصناف"),
    ("sales", "المبيعات والفواتير"),
    ("purchases", "المشتريات وأوامر الشراء"),
    ("accounting", "الحسابات والقيود"),
    ("hr", "الموظفين والمرتبات"),
    ("crm", "متابعة العملاء (CRM)"),
    ("reports", "التقارير"),
]
MODULE_KEYS = [m[0] for m in MODULES]


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    full_name = Column(String(100), nullable=False)
    employee_code = Column(String(40), unique=True, nullable=True, index=True)
    job_title = Column(String(120), nullable=True)
    department = Column(String(120), nullable=True, index=True)
    manager_user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    email = Column(String(100), unique=True, nullable=True)
    phone = Column(String(30), unique=True, nullable=True, index=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(Enum(RoleEnum), nullable=False, default=RoleEnum.employee)
    # Batch 27 - Enterprise Item Master
    name_en = Column(String(150), nullable=True)
    short_name = Column(String(80), nullable=True)
    description = Column(Text, nullable=True)
    item_group = Column(String(80), nullable=True)
    brand = Column(String(80), nullable=True)
    manufacturer = Column(String(120), nullable=True)
    model = Column(String(80), nullable=True)
    country_of_origin = Column(String(80), nullable=True)
    purchase_unit = Column(String(30), nullable=True)
    issue_unit = Column(String(30), nullable=True)
    conversion_factor = Column(Numeric(20, 6), default=1, nullable=False)
    max_stock = Column(Numeric(20, 6), default=0, nullable=False)
    reorder_level = Column(Numeric(20, 6), default=0, nullable=False)
    safety_stock = Column(Numeric(20, 6), default=0, nullable=False)
    lead_time_days = Column(Integer, default=0, nullable=False)
    allow_negative_stock = Column(Boolean, default=False)
    inspection_required = Column(Boolean, default=False)
    mir_required = Column(Boolean, default=False)
    certificate_required = Column(Boolean, default=False)
    standard_cost = Column(Numeric(20, 6), default=0, nullable=False)
    # Batch 29 - Item edit & governance controls
    barcode = Column(String(100), nullable=True, index=True)
    valuation_method = Column(String(30), default='weighted_average', nullable=False)
    tax_rate = Column(Numeric(8, 2), default=0, nullable=False)
    track_serial = Column(Boolean, default=False)
    track_expiry = Column(Boolean, default=False)
    lifecycle_status = Column(String(30), default='active', nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=utcnow)

    permissions = relationship("ModulePermission", back_populates="user",
                                cascade="all, delete-orphan")


class RefreshToken(Base):
    """Opaque, hashed refresh token with server-side revocation."""
    __tablename__ = "refresh_tokens"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    token_hash = Column(String(64), unique=True, nullable=False, index=True)
    expires_at = Column(DateTime, nullable=False, index=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    revoked_at = Column(DateTime, nullable=True, index=True)
    user = relationship("User", backref="refresh_tokens")


class ModulePermission(Base):
    """صلاحية مستخدم معين على موديول معين (عرض / تعديل)."""
    __tablename__ = "module_permissions"
    __table_args__ = (UniqueConstraint("user_id", "module_key", name="uq_user_module"),)

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    module_key = Column(String(50), nullable=False)
    can_view = Column(Boolean, default=True)
    can_edit = Column(Boolean, default=False)

    user = relationship("User", back_populates="permissions")


# =====================================================================
# موديول المخزون
# =====================================================================
class ItemTypeEnum(str, enum.Enum):
    product = "product"    # منتج - له مخزون فعلي
    service = "service"    # خدمة - مفيش مخزون ليه


class Item(Base):
    """الصنف (منتج أو خدمة) في دليل الأصناف."""
    __tablename__ = "items"
    __table_args__ = (
        UniqueConstraint("company_id", "code", name="uq_item_company_code"),
        UniqueConstraint("company_id", "barcode", name="uq_item_company_barcode"),
        CheckConstraint("purchase_price >= 0", name="ck_item_purchase_price_nonnegative"),
        CheckConstraint("sale_price >= 0", name="ck_item_sale_price_nonnegative"),
        CheckConstraint("standard_cost >= 0", name="ck_item_standard_cost_nonnegative"),
        CheckConstraint("min_stock >= 0", name="ck_item_min_stock_nonnegative"),
        CheckConstraint("max_stock >= 0", name="ck_item_max_stock_nonnegative"),
        CheckConstraint("reorder_level >= 0", name="ck_item_reorder_level_nonnegative"),
        CheckConstraint("safety_stock >= 0", name="ck_item_safety_stock_nonnegative"),
        CheckConstraint("reorder_qty >= 0", name="ck_item_reorder_qty_nonnegative"),
        CheckConstraint("conversion_factor > 0", name="ck_item_conversion_factor_positive"),
        CheckConstraint("tax_rate >= 0 AND tax_rate <= 100", name="ck_item_tax_rate_range"),
    )

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    code = Column(String(30), unique=False, index=True, nullable=False)
    name = Column(String(150), nullable=False)
    item_type = Column(Enum(ItemTypeEnum), nullable=False, default=ItemTypeEnum.product)
    category = Column(String(80), nullable=True)
    unit = Column(String(30), nullable=True, default="قطعة")
    purchase_price = Column(Numeric(20, 6), default=0, nullable=False)
    sale_price = Column(Numeric(20, 6), default=0, nullable=False)
    min_stock = Column(Numeric(20, 6), default=0, nullable=False)      # حد أدنى للتنبيه
    reorder_qty = Column(Numeric(20, 6), default=0, nullable=False)    # كمية الطلب المقترحة عند نقص المخزون
    # Batch 27 - Enterprise Item Master
    name_en = Column(String(150), nullable=True)
    short_name = Column(String(80), nullable=True)
    description = Column(Text, nullable=True)
    item_group = Column(String(80), nullable=True)
    brand = Column(String(80), nullable=True)
    manufacturer = Column(String(120), nullable=True)
    model = Column(String(80), nullable=True)
    country_of_origin = Column(String(80), nullable=True)
    purchase_unit = Column(String(30), nullable=True)
    issue_unit = Column(String(30), nullable=True)
    conversion_factor = Column(Numeric(20, 6), default=1, nullable=False)
    max_stock = Column(Numeric(20, 6), default=0, nullable=False)
    reorder_level = Column(Numeric(20, 6), default=0, nullable=False)
    safety_stock = Column(Numeric(20, 6), default=0, nullable=False)
    lead_time_days = Column(Integer, default=0, nullable=False)
    allow_negative_stock = Column(Boolean, default=False)
    inspection_required = Column(Boolean, default=False)
    mir_required = Column(Boolean, default=False)
    certificate_required = Column(Boolean, default=False)
    standard_cost = Column(Numeric(20, 6), default=0, nullable=False)
    # Batch 29 - Item edit & governance controls
    barcode = Column(String(100), nullable=True, index=True)
    valuation_method = Column(String(30), default='weighted_average', nullable=False)
    tax_rate = Column(Numeric(8, 2), default=0, nullable=False)
    track_serial = Column(Boolean, default=False)
    track_expiry = Column(Boolean, default=False)
    lifecycle_status = Column(String(30), default='active', nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=utcnow)

    movements = relationship("StockMovement", back_populates="item", cascade="all, delete-orphan", lazy="selectin")


class MovementTypeEnum(str, enum.Enum):
    in_ = "in"                  # وارد (شراء / إضافة)
    out = "out"                 # صادر (بيع / صرف)
    adjustment_in = "adj_in"    # تسوية بالزيادة (جرد)
    adjustment_out = "adj_out"  # تسوية بالنقص (تالف / جرد)


class StockMovement(Base):
    """حركة مخزون على صنف معين (وارد / صادر / تسوية)."""
    __tablename__ = "stock_movements"
    __table_args__ = (
        CheckConstraint("quantity > 0", name="ck_stock_movement_positive_qty"),
        CheckConstraint("unit_cost >= 0", name="ck_stock_movement_nonnegative_unit_cost"),
        CheckConstraint("total_cost >= 0", name="ck_stock_movement_nonnegative_total_cost"),
        Index("ix_stock_movement_company_item_wh_date", "company_id", "item_id", "warehouse_id", "operational_date", "id"),
        Index("ix_stock_movement_source", "company_id", "source_type", "source_id"),
    )

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    item_id = Column(Integer, ForeignKey("items.id"), nullable=False)
    movement_type = Column(Enum(MovementTypeEnum), nullable=False)
    quantity = Column(Numeric(20, 6), nullable=False)
    unit_cost = Column(Numeric(20, 6), nullable=False, default=0)
    total_cost = Column(Numeric(20, 6), nullable=False, default=0)
    note = Column(String(255), nullable=True)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    warehouse_id = Column(Integer, ForeignKey("warehouses.id", ondelete="SET NULL"), nullable=True, index=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    operational_date = Column(DateTime, default=utcnow, nullable=False, index=True)
    source_type = Column(String(60), nullable=True, index=True)
    source_id = Column(Integer, nullable=True, index=True)
    transfer_id = Column(String(40), nullable=True, index=True)
    reversal_of_id = Column(Integer, ForeignKey("stock_movements.id", ondelete="SET NULL"), nullable=True, index=True)

    item = relationship("Item", back_populates="movements", lazy="joined")
    created_by = relationship("User")



class SalesOrderStatus(str, enum.Enum):
    draft = "draft"
    confirmed = "confirmed"
    partially_delivered = "partially_delivered"
    delivered = "delivered"
    cancelled = "cancelled"


class SalesOrder(Base):
    __tablename__ = "sales_orders"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    order_number = Column(String(30), unique=True, index=True, nullable=False)
    customer_id = Column(Integer, ForeignKey("customers.id"), nullable=False)
    order_date = Column(DateTime, default=utcnow, nullable=False)
    status = Column(String(30), nullable=False, default="draft", index=True)
    payment_method = Column(String(30), default="credit", nullable=False)
    notes = Column(String(255), nullable=True)
    warehouse_id = Column(Integer, ForeignKey("warehouses.id", ondelete="SET NULL"), nullable=True, index=True)
    approval_status = Column(String(30), nullable=False, default="approved", index=True)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    customer = relationship("Customer")
    lines = relationship("SalesOrderLine", back_populates="order", cascade="all, delete-orphan")

    @property
    def total(self):
        return sum((l.line_total for l in self.lines), Decimal("0"))


class SalesOrderLine(Base):
    __tablename__ = "sales_order_lines"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    order_id = Column(Integer, ForeignKey("sales_orders.id", ondelete="CASCADE"), nullable=False)
    item_id = Column(Integer, ForeignKey("items.id"), nullable=False)
    quantity = Column(Numeric(20, 6), nullable=False)
    unit_price = Column(Numeric(20, 6), nullable=False)
    line_total = Column(Numeric(20, 6), nullable=False)
    delivered_quantity = Column(Numeric(20, 6), nullable=False, default=0)
    order = relationship("SalesOrder", back_populates="lines")
    item = relationship("Item", lazy="joined")


class SalesDelivery(Base):
    __tablename__ = "sales_deliveries"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    delivery_number = Column(String(30), unique=True, index=True, nullable=False)
    order_id = Column(Integer, ForeignKey("sales_orders.id"), nullable=False)
    delivery_date = Column(DateTime, default=utcnow, nullable=False)
    status = Column(String(30), nullable=False, default="posted")
    warehouse_id = Column(Integer, ForeignKey("warehouses.id", ondelete="SET NULL"), nullable=True, index=True)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    order = relationship("SalesOrder")
    lines = relationship("SalesDeliveryLine", back_populates="delivery", cascade="all, delete-orphan")


class SalesDeliveryLine(Base):
    __tablename__ = "sales_delivery_lines"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    delivery_id = Column(Integer, ForeignKey("sales_deliveries.id", ondelete="CASCADE"), nullable=False)
    order_line_id = Column(Integer, ForeignKey("sales_order_lines.id"), nullable=False)
    item_id = Column(Integer, ForeignKey("items.id"), nullable=False)
    quantity = Column(Numeric(20, 6), nullable=False)
    unit_cost = Column(Numeric(20, 6), nullable=False)
    total_cost = Column(Numeric(20, 6), nullable=False)
    delivery = relationship("SalesDelivery", back_populates="lines")
    item = relationship("Item", lazy="joined")


# =====================================================================
# موديول المبيعات
# =====================================================================
class Customer(Base):
    __tablename__ = "customers"

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    code = Column(String(30), unique=True, index=True, nullable=False)
    name = Column(String(150), nullable=False)
    phone = Column(String(30), nullable=True)
    email = Column(String(100), nullable=True)
    address = Column(String(255), nullable=True)
    # Batch 27 - Enterprise Item Master
    name_en = Column(String(150), nullable=True)
    short_name = Column(String(80), nullable=True)
    description = Column(Text, nullable=True)
    item_group = Column(String(80), nullable=True)
    brand = Column(String(80), nullable=True)
    manufacturer = Column(String(120), nullable=True)
    model = Column(String(80), nullable=True)
    country_of_origin = Column(String(80), nullable=True)
    purchase_unit = Column(String(30), nullable=True)
    issue_unit = Column(String(30), nullable=True)
    conversion_factor = Column(Numeric(20, 6), default=1, nullable=False)
    max_stock = Column(Numeric(20, 6), default=0, nullable=False)
    reorder_level = Column(Numeric(20, 6), default=0, nullable=False)
    safety_stock = Column(Numeric(20, 6), default=0, nullable=False)
    lead_time_days = Column(Integer, default=0, nullable=False)
    allow_negative_stock = Column(Boolean, default=False)
    inspection_required = Column(Boolean, default=False)
    mir_required = Column(Boolean, default=False)
    certificate_required = Column(Boolean, default=False)
    standard_cost = Column(Numeric(20, 6), default=0, nullable=False)
    # Batch 29 - Item edit & governance controls
    barcode = Column(String(100), nullable=True, index=True)
    valuation_method = Column(String(30), default='weighted_average', nullable=False)
    tax_rate = Column(Numeric(8, 2), default=0, nullable=False)
    track_serial = Column(Boolean, default=False)
    track_expiry = Column(Boolean, default=False)
    lifecycle_status = Column(String(30), default='active', nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=utcnow)

    invoices = relationship("SaleInvoice", back_populates="customer")


class SaleInvoice(Base):
    __tablename__ = "sale_invoices"

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=True, index=True)
    invoice_number = Column(String(30), unique=True, index=True, nullable=False)
    customer_id = Column(Integer, ForeignKey("customers.id"), nullable=False)
    invoice_date = Column(DateTime, default=utcnow)
    payment_method = Column(String(30), default="نقدي")
    subtotal = Column(Numeric(20, 6), nullable=False, default=0)
    discount_amount = Column(Numeric(20, 6), nullable=False, default=0)
    tax_amount = Column(Numeric(20, 6), nullable=False, default=0)
    total_amount = Column(Numeric(20, 6), nullable=False, default=0)
    status = Column(String(30), nullable=False, default="posted", index=True)
    order_id = Column(Integer, ForeignKey("sales_orders.id"), nullable=True)
    delivery_id = Column(Integer, ForeignKey("sales_deliveries.id"), nullable=True)
    notes = Column(String(255), nullable=True)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    warehouse_id = Column(Integer, ForeignKey("warehouses.id", ondelete="SET NULL"), nullable=True, index=True)
    created_at = Column(DateTime, default=utcnow)

    customer = relationship("Customer", back_populates="invoices", lazy="joined")
    created_by = relationship("User")
    lines = relationship("SaleInvoiceLine", back_populates="invoice", cascade="all, delete-orphan", lazy="selectin")

    @property
    def total(self):
        if self.total_amount is not None and self.total_amount != 0:
            return self.total_amount
        return sum((l.line_total for l in self.lines), Decimal("0"))


class SaleInvoiceLine(Base):
    __tablename__ = "sale_invoice_lines"

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    invoice_id = Column(Integer, ForeignKey("sale_invoices.id"), nullable=False)
    item_id = Column(Integer, ForeignKey("items.id"), nullable=False)
    quantity = Column(Numeric(20, 6), nullable=False)
    unit_price = Column(Numeric(20, 6), nullable=False)
    line_total = Column(Numeric(20, 6), nullable=False)

    invoice = relationship("SaleInvoice", back_populates="lines", lazy="joined")
    item = relationship("Item", lazy="joined")


class PurchaseInvoice(Base):
    __tablename__ = "purchase_invoices"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=True, index=True)
    invoice_number = Column(String(40), unique=True, index=True, nullable=False)
    supplier_id = Column(Integer, ForeignKey("suppliers.id"), nullable=False)
    po_id = Column(Integer, ForeignKey("purchase_orders.id"), nullable=True)
    receipt_id = Column(Integer, ForeignKey("purchase_receipts.id"), nullable=True)
    invoice_date = Column(DateTime, default=utcnow, nullable=False)
    subtotal = Column(Numeric(20, 6), nullable=False, default=0)
    discount_amount = Column(Numeric(20, 6), nullable=False, default=0)
    tax_amount = Column(Numeric(20, 6), nullable=False, default=0)
    total_amount = Column(Numeric(20, 6), nullable=False, default=0)
    status = Column(String(30), nullable=False, default="posted", index=True)
    approval_status = Column(String(30), nullable=False, default="approved", index=True)
    approval_request_id = Column(Integer, ForeignKey("approval_requests.id", ondelete="SET NULL"), nullable=True)
    notes = Column(String(255), nullable=True)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    supplier = relationship("Supplier")
    lines = relationship("PurchaseInvoiceLine", back_populates="invoice", cascade="all, delete-orphan", lazy="selectin")


class PurchaseInvoiceLine(Base):
    __tablename__ = "purchase_invoice_lines"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    invoice_id = Column(Integer, ForeignKey("purchase_invoices.id", ondelete="CASCADE"), nullable=False)
    item_id = Column(Integer, ForeignKey("items.id"), nullable=False)
    quantity = Column(Numeric(20, 6), nullable=False)
    unit_price = Column(Numeric(20, 6), nullable=False)
    line_total = Column(Numeric(20, 6), nullable=False)
    po_line_id = Column(Integer, ForeignKey("purchase_order_lines.id", ondelete="SET NULL"), nullable=True, index=True)
    invoice = relationship("PurchaseInvoice", back_populates="lines", lazy="joined")
    item = relationship("Item", lazy="joined")


# =====================================================================
# موديول المشتريات
# =====================================================================
class Supplier(Base):
    __tablename__ = "suppliers"

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    code = Column(String(30), unique=True, index=True, nullable=False)
    name = Column(String(150), nullable=False)
    phone = Column(String(30), nullable=True)
    email = Column(String(100), nullable=True)
    address = Column(String(255), nullable=True)
    # Batch 40 - Supplier master governance (kept separate from Item Master fields)
    legal_name = Column(String(200), nullable=True)
    supplier_type = Column(String(40), nullable=False, default="company")
    contact_person = Column(String(120), nullable=True)
    tax_number = Column(String(80), nullable=True, index=True)
    registration_number = Column(String(80), nullable=True, index=True)
    country = Column(String(80), nullable=True)
    city = Column(String(80), nullable=True)
    postal_code = Column(String(30), nullable=True)
    payment_terms_days = Column(Integer, nullable=False, default=0)
    preferred_payment_method = Column(String(40), nullable=True)
    currency_code = Column(String(10), nullable=False, default="EGP")
    credit_limit = Column(Numeric(20, 2), nullable=False, default=0)
    bank_name = Column(String(120), nullable=True)
    bank_account_name = Column(String(150), nullable=True)
    bank_account_number = Column(String(80), nullable=True)
    iban = Column(String(80), nullable=True)
    swift_code = Column(String(30), nullable=True)
    blocked_reason = Column(String(255), nullable=True)
    # Batch 27 - Enterprise Item Master
    name_en = Column(String(150), nullable=True)
    short_name = Column(String(80), nullable=True)
    description = Column(Text, nullable=True)
    item_group = Column(String(80), nullable=True)
    brand = Column(String(80), nullable=True)
    manufacturer = Column(String(120), nullable=True)
    model = Column(String(80), nullable=True)
    country_of_origin = Column(String(80), nullable=True)
    purchase_unit = Column(String(30), nullable=True)
    issue_unit = Column(String(30), nullable=True)
    conversion_factor = Column(Numeric(20, 6), default=1, nullable=False)
    max_stock = Column(Numeric(20, 6), default=0, nullable=False)
    reorder_level = Column(Numeric(20, 6), default=0, nullable=False)
    safety_stock = Column(Numeric(20, 6), default=0, nullable=False)
    lead_time_days = Column(Integer, default=0, nullable=False)
    allow_negative_stock = Column(Boolean, default=False)
    inspection_required = Column(Boolean, default=False)
    mir_required = Column(Boolean, default=False)
    certificate_required = Column(Boolean, default=False)
    standard_cost = Column(Numeric(20, 6), default=0, nullable=False)
    # Batch 29 - Item edit & governance controls
    barcode = Column(String(100), nullable=True, index=True)
    valuation_method = Column(String(30), default='weighted_average', nullable=False)
    tax_rate = Column(Numeric(8, 2), default=0, nullable=False)
    track_serial = Column(Boolean, default=False)
    track_expiry = Column(Boolean, default=False)
    lifecycle_status = Column(String(30), default='active', nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=utcnow)

    purchase_orders = relationship("PurchaseOrder", back_populates="supplier")


class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=True, index=True)
    po_number = Column(String(30), unique=True, index=True, nullable=False)
    supplier_id = Column(Integer, ForeignKey("suppliers.id"), nullable=False)
    order_date = Column(DateTime, default=utcnow)
    payment_method = Column(String(30), default="نقدي")
    notes = Column(String(255), nullable=True)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    warehouse_id = Column(Integer, ForeignKey("warehouses.id", ondelete="SET NULL"), nullable=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="SET NULL"), nullable=True, index=True)
    approval_status = Column(String(30), nullable=False, default="approved", index=True)
    approval_request_id = Column(Integer, ForeignKey("approval_requests.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=utcnow)

    supplier = relationship("Supplier", back_populates="purchase_orders")
    created_by = relationship("User")
    lines = relationship("PurchaseOrderLine", back_populates="po", cascade="all, delete-orphan")
    receipts = relationship("PurchaseReceipt", back_populates="po", cascade="all, delete-orphan")

    @property
    def total(self):
        return sum(l.line_total for l in self.lines)


class PurchaseOrderLine(Base):
    __tablename__ = "purchase_order_lines"
    __table_args__ = (UniqueConstraint("company_id", "po_id", "item_id", name="uq_po_line_company_po_item"),)

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    po_id = Column(Integer, ForeignKey("purchase_orders.id"), nullable=False)
    item_id = Column(Integer, ForeignKey("items.id"), nullable=False)
    quantity = Column(Numeric(20, 6), nullable=False)
    unit_price = Column(Numeric(20, 6), nullable=False)
    line_total = Column(Numeric(20, 6), nullable=False)

    po = relationship("PurchaseOrder", back_populates="lines")
    item = relationship("Item", lazy="joined")

# =====================================================================
# المحاسبة العامة - General Ledger
# =====================================================================
class AccountTypeEnum(str, enum.Enum):
    asset = "asset"
    liability = "liability"
    equity = "equity"
    revenue = "revenue"
    expense = "expense"


class Account(Base):
    __tablename__ = "accounts"
    __table_args__ = (UniqueConstraint("company_id", "branch_id", "code", name="uq_account_company_branch_code"),)

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=True, index=True)
    code = Column(String(30), index=True, nullable=False)
    name = Column(String(150), nullable=False)
    account_type = Column(Enum(AccountTypeEnum), nullable=False)
    is_active = Column(Boolean, default=True)
    parent_id = Column(Integer, ForeignKey("accounts.id"), nullable=True, index=True)
    normal_balance = Column(String(10), nullable=True)  # debit / credit
    statement_section = Column(String(50), nullable=True)  # presentation mapping
    cash_flow_category = Column(String(20), nullable=True)  # operating / investing / financing

    parent = relationship("Account", remote_side=[id], backref="children")
    journal_lines = relationship("JournalLine", back_populates="account")


class JournalEntry(Base):
    __tablename__ = "journal_entries"
    __table_args__ = (
        Index("uq_journal_source", "source_type", "source_id", unique=True),
    )

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=True, index=True)
    entry_number = Column(String(30), unique=True, index=True, nullable=False)
    entry_date = Column(DateTime, default=utcnow)
    description = Column(String(255), nullable=False)
    source_type = Column(String(50), nullable=True)
    source_id = Column(Integer, nullable=True)
    status = Column(String(20), nullable=False, default="posted")
    posted_at = Column(DateTime, default=utcnow, nullable=False)
    posted_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    warehouse_id = Column(Integer, ForeignKey("warehouses.id", ondelete="SET NULL"), nullable=True, index=True)
    created_at = Column(DateTime, default=utcnow)

    created_by = relationship("User", foreign_keys=[created_by_id])
    posted_by = relationship("User", foreign_keys=[posted_by_id])
    lines = relationship("JournalLine", back_populates="entry", cascade="all, delete-orphan")


class JournalLine(Base):
    __tablename__ = "journal_lines"
    __table_args__ = (
        CheckConstraint("debit >= 0", name="ck_journal_debit_nonnegative"),
        CheckConstraint("credit >= 0", name="ck_journal_credit_nonnegative"),
        CheckConstraint("NOT (debit > 0 AND credit > 0)", name="ck_journal_not_both"),
    )

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=True, index=True)
    entry_id = Column(Integer, ForeignKey("journal_entries.id"), nullable=False)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    debit = Column(Numeric(20, 6), nullable=False, default=0)
    credit = Column(Numeric(20, 6), nullable=False, default=0)
    description = Column(String(255), nullable=True)

    entry = relationship("JournalEntry", back_populates="lines")
    account = relationship("Account", back_populates="journal_lines")


class SequenceCounter(Base):
    """عدادات أرقام المستندات بدل الاعتماد على COUNT()."""
    __tablename__ = "sequence_counters"

    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    key = Column(String(50), unique=True, nullable=False)
    next_value = Column(Integer, nullable=False, default=1)

class PurchaseReceipt(Base):
    __tablename__ = "purchase_receipts"

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    receipt_number = Column(String(40), unique=True, index=True, nullable=False)
    po_id = Column(Integer, ForeignKey("purchase_orders.id"), nullable=False, index=True)
    receipt_date = Column(DateTime, default=utcnow)
    warehouse_id = Column(Integer, ForeignKey("warehouses.id", ondelete="SET NULL"), nullable=True, index=True)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)

    po = relationship("PurchaseOrder", back_populates="receipts")
    lines = relationship("PurchaseReceiptLine", cascade="all, delete-orphan", primaryjoin="PurchaseReceipt.id==PurchaseReceiptLine.receipt_id", foreign_keys="PurchaseReceiptLine.receipt_id")
    created_by = relationship("User")


class AccountingPeriod(Base):
    __tablename__ = "accounting_periods"
    __table_args__ = (
        CheckConstraint("end_date >= start_date", name="ck_accounting_period_dates"),
        UniqueConstraint("company_id", "branch_id", "name", name="uq_accounting_period_scope_name"),
    )
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=True, index=True)
    name = Column(String(100), nullable=False)
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime, nullable=False)
    is_closed = Column(Boolean, default=False, nullable=False)
    closed_at = Column(DateTime, nullable=True)
    closed_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    closed_by = relationship("User")


class FinanceVoucher(Base):
    __tablename__ = "finance_vouchers"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=True, index=True)
    voucher_number = Column(String(30), unique=True, index=True, nullable=False)
    voucher_type = Column(String(20), nullable=False)  # receipt / payment / expense
    voucher_date = Column(DateTime, default=utcnow, nullable=False)
    amount = Column(Numeric(20, 6), nullable=False)
    description = Column(String(255), nullable=False)
    account_code = Column(String(30), nullable=False)  # cash/bank account receiving or paying
    party_type = Column(String(20), nullable=True)
    party_id = Column(Integer, nullable=True)
    expense_account_code = Column(String(30), nullable=True)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    idempotency_key = Column(String(180), nullable=True, index=True)
    created_by = relationship("User")
    __table_args__ = (UniqueConstraint("company_id", "idempotency_key", name="uq_finance_voucher_company_idempotency"),)


class PaymentAllocation(Base):
    """تخصيص دفعة على فاتورة/التزام محدد، لدعم السداد الجزئي وأعمار الديون."""
    __tablename__ = "payment_allocations"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=True, index=True)
    voucher_id = Column(Integer, ForeignKey("finance_vouchers.id"), nullable=False)
    sale_invoice_id = Column(Integer, ForeignKey("sale_invoices.id"), nullable=True)
    purchase_order_id = Column(Integer, ForeignKey("purchase_orders.id"), nullable=True)
    purchase_invoice_id = Column(Integer, ForeignKey("purchase_invoices.id"), nullable=True)
    amount = Column(Numeric(20, 6), nullable=False)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    __table_args__ = (
        CheckConstraint("amount > 0", name="ck_payment_allocation_positive"),
        Index("ix_payment_alloc_invoice", "company_id", "sale_invoice_id", "purchase_invoice_id"),
    )

    voucher = relationship("FinanceVoucher")
    sale_invoice = relationship("SaleInvoice")
    purchase_order = relationship("PurchaseOrder")
    purchase_invoice = relationship("PurchaseInvoice")


class BankReconciliationItem(Base):
    """Individual bank statement line used for matching and reconciliation."""
    __tablename__ = "bank_reconciliation_items"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=True, index=True)
    reconciliation_id = Column(Integer, ForeignKey("bank_reconciliations.id"), nullable=False, index=True)
    transaction_date = Column(DateTime, nullable=False)
    reference = Column(String(100), nullable=True)
    description = Column(String(255), nullable=True)
    amount = Column(Numeric(20, 6), nullable=False)
    direction = Column(String(10), nullable=False)  # debit / credit
    matched_journal_line_id = Column(Integer, ForeignKey("journal_lines.id"), nullable=True)
    status = Column(String(20), nullable=False, default="unmatched")
    created_at = Column(DateTime, default=utcnow, nullable=False)
    reconciliation = relationship("BankReconciliation", backref="items")
    matched_journal_line = relationship("JournalLine")
    __table_args__ = (
        Index("uq_bank_reconciliation_items_matched_journal_line", "matched_journal_line_id", unique=True),
        Index("ix_bank_reconciliation_items_company_status", "company_id", "status"),
    )


class BankReconciliation(Base):
    """تسوية كشف البنك مع الرصيد الدفتري في تاريخ محدد."""
    __tablename__ = "bank_reconciliations"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=True, index=True)
    reconciliation_number = Column(String(30), unique=True, index=True, nullable=False)
    bank_account_code = Column(String(30), nullable=False, default="1110")
    bank_account_id = Column(Integer, ForeignKey("accounts.id"), nullable=True, index=True)
    statement_date = Column(DateTime, nullable=False)
    statement_balance = Column(Numeric(20, 6), nullable=False)
    book_balance = Column(Numeric(20, 6), nullable=False)
    difference = Column(Numeric(20, 6), nullable=False)
    status = Column(String(20), nullable=False, default="open")
    notes = Column(String(255), nullable=True)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    closed_at = Column(DateTime, nullable=True)
    created_by = relationship("User")
    bank_account = relationship("Account", foreign_keys=[bank_account_id])


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String(50), nullable=False)
    entity_type = Column(String(50), nullable=False)
    entity_id = Column(Integer, nullable=True)
    description = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    user = relationship("User")

# =====================================================================
# المستوى المالي المتقدم V7
# =====================================================================
class CostCenter(Base):
    __tablename__ = "cost_centers"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id", ondelete="SET NULL"), nullable=True, index=True)
    branch = relationship("Branch")
    code = Column(String(30), index=True, nullable=False)
    name = Column(String(150), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True, index=True)
    __table_args__ = (UniqueConstraint("company_id", "branch_id", "code", name="uq_cost_center_company_branch_code"),)


class JournalLineCostCenter(Base):
    __tablename__ = "journal_line_cost_centers"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    journal_line_id = Column(Integer, ForeignKey("journal_lines.id"), nullable=False)
    cost_center_id = Column(Integer, ForeignKey("cost_centers.id"), nullable=False)
    amount = Column(Numeric(20, 6), nullable=False, default=0)
    allocation_percent = Column(Numeric(9, 6), nullable=True)
    journal_line = relationship("JournalLine")
    cost_center = relationship("CostCenter")


class TaxRate(Base):
    __tablename__ = "tax_rates"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id", ondelete="SET NULL"), nullable=True, index=True)
    branch = relationship("Branch")
    code = Column(String(30), nullable=False)
    name = Column(String(100), nullable=False)
    __table_args__ = (
        UniqueConstraint("company_id", "branch_id", "code", name="uq_tax_rate_company_branch_code"),
        CheckConstraint("rate >= 0 AND rate <= 100", name="ck_tax_rate_range"),
        CheckConstraint("tax_direction IN ('input','output')", name="ck_tax_direction"),
    )
    rate = Column(Numeric(12, 6), nullable=False, default=0)
    tax_account_code = Column(String(30), nullable=False)
    tax_direction = Column(String(20), nullable=False, default="output")  # input / output
    is_active = Column(Boolean, default=True, nullable=False)


class AccrualEntry(Base):
    __tablename__ = "accrual_entries"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id", ondelete="SET NULL"), nullable=True, index=True)
    branch = relationship("Branch")
    name = Column(String(150), nullable=False)
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime, nullable=False)
    total_amount = Column(Numeric(20, 6), nullable=False)
    recognized_amount = Column(Numeric(20, 6), nullable=False, default=0)
    expense_account_code = Column(String(30), nullable=False)
    balance_account_code = Column(String(30), nullable=False)
    frequency = Column(String(20), nullable=False, default="monthly")
    is_active = Column(Boolean, default=True, nullable=False)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_by = relationship("User")


class WithholdingTaxRate(Base):
    __tablename__ = "withholding_tax_rates"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id", ondelete="SET NULL"), nullable=True, index=True)
    branch = relationship("Branch")
    code = Column(String(30), nullable=False)
    name = Column(String(120), nullable=False)
    rate = Column(Numeric(12, 6), nullable=False, default=0)
    tax_account_code = Column(String(30), nullable=False, default="2230")
    is_active = Column(Boolean, default=True, nullable=False)
    __table_args__ = (UniqueConstraint("company_id", "branch_id", "code", name="uq_wht_company_branch_code"),)


class WithholdingTaxTransaction(Base):
    __tablename__ = "withholding_tax_transactions"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id", ondelete="SET NULL"), nullable=True, index=True)
    branch = relationship("Branch")
    rate_id = Column(Integer, ForeignKey("withholding_tax_rates.id"), nullable=False)
    source_type = Column(String(50), nullable=False)
    source_id = Column(Integer, nullable=False)
    taxable_amount = Column(Numeric(20, 6), nullable=False)
    tax_amount = Column(Numeric(20, 6), nullable=False)
    journal_entry_id = Column(Integer, ForeignKey("journal_entries.id"), nullable=True)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    rate = relationship("WithholdingTaxRate")
    journal_entry = relationship("JournalEntry")


class FixedAsset(Base):
    __tablename__ = "fixed_assets"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id", ondelete="SET NULL"), nullable=True, index=True)
    branch = relationship("Branch")
    asset_code = Column(String(30), nullable=False)
    name = Column(String(150), nullable=False)
    __table_args__ = (UniqueConstraint("company_id", "branch_id", "asset_code", name="uq_fixed_asset_company_branch_code"),)
    acquisition_date = Column(DateTime, nullable=False)
    acquisition_cost = Column(Numeric(20, 6), nullable=False)
    useful_life_months = Column(Integer, nullable=False)
    accumulated_depreciation = Column(Numeric(20, 6), nullable=False, default=0)
    asset_account_code = Column(String(30), nullable=False, default="1500")
    depreciation_expense_account_code = Column(String(30), nullable=False, default="5400")
    accumulated_depreciation_account_code = Column(String(30), nullable=False, default="1510")
    residual_value = Column(Numeric(20, 6), nullable=False, default=0)
    is_active = Column(Boolean, default=True, nullable=False)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_by = relationship("User")

class FixedAssetDisposal(Base):
    __tablename__ = "fixed_asset_disposals"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id", ondelete="SET NULL"), nullable=True, index=True)
    branch = relationship("Branch")
    asset_id = Column(Integer, ForeignKey("fixed_assets.id"), nullable=False, unique=True)
    disposal_date = Column(DateTime, nullable=False)
    proceeds = Column(Numeric(20, 6), nullable=False, default=0)
    net_book_value = Column(Numeric(20, 6), nullable=False)
    gain_loss = Column(Numeric(20, 6), nullable=False, default=0)
    journal_entry_id = Column(Integer, ForeignKey("journal_entries.id"), nullable=False)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    asset = relationship("FixedAsset")
    journal_entry = relationship("JournalEntry")


# =====================================================================
# Enterprise Core V8
# =====================================================================
class JournalReversal(Base):
    __tablename__ = "journal_reversals"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    original_entry_id = Column(Integer, ForeignKey("journal_entries.id"), unique=True, nullable=False)
    reversal_entry_id = Column(Integer, ForeignKey("journal_entries.id"), unique=True, nullable=False)
    reason = Column(String(255), nullable=False)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    original_entry = relationship("JournalEntry", foreign_keys=[original_entry_id])
    reversal_entry = relationship("JournalEntry", foreign_keys=[reversal_entry_id])
    created_by = relationship("User")


class TaxTransaction(Base):
    __tablename__ = "tax_transactions"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id", ondelete="SET NULL"), nullable=True, index=True)
    branch = relationship("Branch")
    tax_rate_id = Column(Integer, ForeignKey("tax_rates.id"), nullable=False)
    source_type = Column(String(50), nullable=False)  # sale_invoice / purchase_invoice / purchase_order
    source_id = Column(Integer, nullable=False)
    taxable_amount = Column(Numeric(20, 6), nullable=False)
    tax_amount = Column(Numeric(20, 6), nullable=False)
    tax_direction = Column(String(20), nullable=False)  # output / input
    # Historical snapshots: changing a master rate must never rewrite prior tax reporting.
    rate_applied = Column(Numeric(12, 6), nullable=False, default=0)
    tax_code_snapshot = Column(String(30), nullable=True)
    tax_name_snapshot = Column(String(100), nullable=True)
    tax_account_code_snapshot = Column(String(30), nullable=True)
    journal_entry_id = Column(Integer, ForeignKey("journal_entries.id"), nullable=True)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    __table_args__ = (
        CheckConstraint("taxable_amount >= 0", name="ck_tax_tx_taxable_nonnegative"),
        CheckConstraint("tax_amount >= 0", name="ck_tax_tx_amount_nonnegative"),
        CheckConstraint("tax_direction IN ('input','output')", name="ck_tax_tx_direction"),
        CheckConstraint("rate_applied >= 0 AND rate_applied <= 100", name="ck_tax_tx_rate_range"),
    )
    tax_rate = relationship("TaxRate")
    journal_entry = relationship("JournalEntry")
    created_by = relationship("User")


class PeriodClosingEntry(Base):
    __tablename__ = "period_closing_entries"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    period_id = Column(Integer, ForeignKey("accounting_periods.id"), nullable=False)
    closing_entry_id = Column(Integer, ForeignKey("journal_entries.id"), nullable=False)
    retained_earnings_account_code = Column(String(30), nullable=False, default="3100")
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    period = relationship("AccountingPeriod")
    closing_entry = relationship("JournalEntry")
    created_by = relationship("User")


class CashFlowAdjustment(Base):
    __tablename__ = "cash_flow_adjustments"
    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    entry_id = Column(Integer, ForeignKey("journal_entries.id"), nullable=False)
    classification = Column(String(20), nullable=False)  # operating / investing / financing
    note = Column(String(255), nullable=True)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    entry = relationship("JournalEntry")
    created_by = relationship("User")


# ---------------------------------------------------------------------
# Accounting immutability guard
# ---------------------------------------------------------------------
# Posted journals are append-only. Corrections must be represented by a
# separate reversal/adjustment entry rather than editing history.
from sqlalchemy import event
from sqlalchemy.orm import Session as _SASession
from sqlalchemy import inspect as _sa_inspect

@event.listens_for(_SASession, "before_flush")
def _protect_posted_journals(session, flush_context, instances):
    # Existing posted entries/lines may not be edited or deleted.
    for obj in list(session.dirty) + list(session.deleted):
        if isinstance(obj, (JournalEntry, JournalLine)):
            entry = obj if isinstance(obj, JournalEntry) else obj.entry
            if entry is None and isinstance(obj, JournalLine) and obj.entry_id:
                entry = session.get(JournalEntry, obj.entry_id)
            if entry is not None and entry.status == "posted":
                # Allow the single controlled transition draft -> posted during journal creation.
                if isinstance(obj, JournalEntry) and obj not in session.deleted:
                    history = _sa_inspect(obj).attrs.status.history
                    if history.has_changes() and history.deleted and history.deleted[0] != "posted":
                        continue
                action = "deleted" if obj in session.deleted else "modified"
                raise ValueError(
                    f"Posted journal entries cannot be {action}; create a reversal or adjustment entry."
                )

    # New lines must never be attached to an already-posted entry.
    for obj in list(session.new):
        if isinstance(obj, JournalLine):
            entry = obj.entry
            if entry is None and obj.entry_id:
                entry = session.get(JournalEntry, obj.entry_id)
            if entry is not None and entry.status == "posted" and entry not in session.new:
                raise ValueError(
                    "Posted journal entries cannot receive new lines; create a reversal or adjustment entry."
                )

# Enterprise ERP Core extensions. Imported here so Alembic sees one unified metadata graph.
from . import enterprise_models as _enterprise_models  # noqa: E402,F401
