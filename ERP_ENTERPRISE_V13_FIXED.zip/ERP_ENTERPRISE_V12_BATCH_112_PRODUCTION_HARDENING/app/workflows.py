from .time_utils import utcnow
"""Generic, amount-aware approval workflow service."""
import datetime
from decimal import Decimal
from sqlalchemy import select, and_
from sqlalchemy.orm import Session
from .governance_models import ApprovalRule, ApprovalRuleStep, ApprovalRequest, ApprovalAction
from .governance import _has_permission
from .models import User, RoleEnum
from .governance_models import UserRole
from .hr_models import RoleApprovalLimit



def assert_approval_limit(db: Session, *, user_id: int, company_id: int, document_type: str, amount=Decimal("0")):
    """Enforce role-level monetary approval limits when configured.

    If no limit is configured for the document type, existing workflow behavior
    remains unchanged. Administrators bypass monetary limits.
    """
    user=db.get(User,user_id)
    if user and user.role == RoleEnum.admin:
        return True
    roles=db.execute(select(UserRole).where(UserRole.user_id==user_id, UserRole.is_active.is_(True),
        (UserRole.company_id==company_id) | (UserRole.company_id.is_(None)))).scalars().all()
    role_ids=[r.role_id for r in roles]
    if not role_ids:
        return True
    limits=db.query(RoleApprovalLimit).filter(RoleApprovalLimit.role_id.in_(role_ids),
        RoleApprovalLimit.company_id==company_id,RoleApprovalLimit.document_type==document_type).all()
    if not limits:
        return True
    value=Decimal(str(amount))
    if not any(value <= Decimal(str(l.max_amount)) for l in limits):
        raise PermissionError(f"Approval limit exceeded for {document_type}: {value}")
    return True

def select_rule(db: Session, company_id: int, document_type: str, amount=Decimal("0")):
    rules = db.execute(select(ApprovalRule).where(
        ApprovalRule.company_id == company_id,
        ApprovalRule.document_type == document_type,
        ApprovalRule.is_active.is_(True)
    ).order_by(ApprovalRule.priority.asc())).scalars().all()
    for rule in rules:
        if rule.min_amount is not None and amount < rule.min_amount: continue
        if rule.max_amount is not None and amount > rule.max_amount: continue
        return rule
    return None


def request_approval(db: Session, *, company_id, branch_id, document_type, document_id, requested_by_id, amount=Decimal("0")):
    rule = select_rule(db, company_id, document_type, Decimal(str(amount)))
    if not rule: return None
    existing = db.execute(select(ApprovalRequest).where(
        ApprovalRequest.company_id == company_id,
        ApprovalRequest.document_type == document_type,
        ApprovalRequest.document_id == document_id,
        ApprovalRequest.rule_id == rule.id,
    )).scalar_one_or_none()
    if existing: return existing
    req = ApprovalRequest(company_id=company_id, branch_id=branch_id, document_type=document_type, document_id=document_id, rule_id=rule.id, requested_by_id=requested_by_id, amount=Decimal(str(amount)))
    db.add(req); db.flush()
    return req


def act_on_approval(db: Session, request_id: int, user_id: int, decision: str, reason=None, company_id=None):
    """Act on an approval request inside an explicit tenant boundary.

    ``Session.get()`` does not participate in SQLAlchemy loader criteria in the
    same way as normal ORM SELECT statements, so tenant-owned approval records
    are loaded through an explicit company filter whenever a tenant context is
    available. This keeps the application-layer boundary effective in tests and
    non-RLS environments as well as in PostgreSQL production.
    """
    if company_id is None:
        try:
            from .governance import get_request_context
            company_id = get_request_context().get("company_id")
        except Exception:
            company_id = None
    q = db.query(ApprovalRequest).filter(ApprovalRequest.id == request_id)
    if company_id is not None:
        q = q.filter(ApprovalRequest.company_id == company_id)
    req = q.first()
    if not req or req.status != "pending": raise ValueError("Approval request is not pending")
    step = db.execute(select(ApprovalRuleStep).where(ApprovalRuleStep.rule_id == req.rule_id, ApprovalRuleStep.sequence == req.current_sequence)).scalar_one_or_none()
    if not step: raise ValueError("Workflow step is missing")
    if not _has_permission(db, user_id, step.required_permission, req.company_id, req.branch_id): raise PermissionError(step.required_permission)
    assert_approval_limit(db,user_id=user_id,company_id=req.company_id,document_type=req.document_type,amount=req.amount)
    if decision not in {"approved", "rejected"}: raise ValueError("Invalid decision")
    db.add(ApprovalAction(request_id=req.id, sequence=req.current_sequence, user_id=user_id, decision=decision, reason=reason))
    if decision == "rejected":
        req.status = "rejected"; req.completed_at = utcnow()
    else:
        next_step = db.execute(select(ApprovalRuleStep).where(ApprovalRuleStep.rule_id == req.rule_id, ApprovalRuleStep.sequence > req.current_sequence).order_by(ApprovalRuleStep.sequence.asc()).limit(1)).scalar_one_or_none()
        if next_step:
            req.current_sequence = next_step.sequence
        else:
            req.status = "approved"; req.completed_at = utcnow()
    db.flush()
    return req
