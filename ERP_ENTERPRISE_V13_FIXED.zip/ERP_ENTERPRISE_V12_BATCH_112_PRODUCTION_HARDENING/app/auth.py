from .time_utils import utcnow
# -*- coding: utf-8 -*-
"""
منطق تسجيل الدخول والصلاحيات:
- تشفير كلمة المرور (bcrypt مباشرة، بدون passlib لتفادي مشاكل التوافق)
- إصدار وفك تشفير JWT محفوظ في كوكي httpOnly (آمن، الجافاسكريبت في المتصفح مش هيقدر يوصله)
- Dependencies لحماية أي endpoint حسب الدور أو صلاحية موديول معين
"""
import os
import secrets
import datetime
import hashlib
import base64
import hmac
import uuid
try:
    import bcrypt
except ImportError:  # development/test fallback; production requirements include bcrypt
    bcrypt = None
try:
    from jose import jwt, JWTError
except ImportError:  # development/test fallback; production requirements include python-jose
    import jwt as _pyjwt
    jwt = _pyjwt
    JWTError = _pyjwt.InvalidTokenError
from fastapi import Depends, HTTPException, status, Request, Header
from sqlalchemy.orm import Session

from .database import get_db
from .models import User, ModulePermission, RoleEnum, RefreshToken
from .governance_models import Permission, Role, RolePermission, UserRole

# مهم جدًا: على السيرفر الحقيقي غيّر ده لقيمة عشوائية طويلة وسرية عن طريق متغير بيئة
from .core_settings import security_settings, redis_connection_url
SECRET_KEY = security_settings()["JWT_SECRET_KEY"]
ALGORITHM = "HS256"
TOKEN_EXPIRE_HOURS = int(os.getenv("ERP_ACCESS_TOKEN_EXPIRE_HOURS", "1"))
REFRESH_TOKEN_EXPIRE_DAYS = int(os.getenv("ERP_REFRESH_TOKEN_EXPIRE_DAYS", "7"))


def validate_password_policy(password: str) -> None:
    if not isinstance(password, str) or len(password) < 12:
        raise ValueError("Password must be at least 12 characters long.")
    if len(password) > 200:
        raise ValueError("Password is too long.")
    if not any(c.islower() for c in password) or not any(c.isupper() for c in password) or not any(c.isdigit() for c in password):
        raise ValueError("Password must include upper, lower and numeric characters.")


def hash_password(password: str) -> str:
    validate_password_policy(password)
    if bcrypt is not None:
        return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
    # Safe deterministic fallback only for environments where optional native bcrypt
    # is unavailable. Production deployments should use bcrypt from requirements.txt.
    salt = secrets.token_bytes(16)
    rounds = 310000
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, rounds)
    return "pbkdf2_sha256$%d$%s$%s" % (rounds, base64.urlsafe_b64encode(salt).decode(), base64.urlsafe_b64encode(digest).decode())


def verify_password(password: str, password_hash: str) -> bool:
    try:
        if password_hash.startswith("pbkdf2_sha256$"):
            _, rounds, salt_b64, digest_b64 = password_hash.split("$", 3)
            salt = base64.urlsafe_b64decode(salt_b64.encode())
            expected = base64.urlsafe_b64decode(digest_b64.encode())
            actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, int(rounds))
            return hmac.compare_digest(actual, expected)
        if bcrypt is None:
            return False
        return bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("utf-8"))
    except (ValueError, TypeError, UnicodeError):
        return False


def create_access_token(user: User) -> str:
    expire = utcnow() + datetime.timedelta(hours=TOKEN_EXPIRE_HOURS)
    payload = {"sub": str(user.id), "username": user.username, "role": user.role.value, "type": "access", "jti": uuid.uuid4().hex, "authz_version": _authz_version(user.id), "exp": expire}
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def create_refresh_token() -> tuple[str, str, datetime.datetime]:
    raw = secrets.token_urlsafe(64)
    expires = utcnow() + datetime.timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    return raw, digest, expires

def issue_refresh_token(db, user: User) -> tuple[str, datetime.datetime]:
    raw, digest, expires = create_refresh_token()
    db.add(RefreshToken(user_id=user.id, token_hash=digest, expires_at=expires))
    db.commit()
    return raw, expires


def rotate_refresh_token(db, raw_token: str, user: User | None = None):
    if not raw_token:
        return None
    digest = hashlib.sha256(raw_token.encode("utf-8")).hexdigest()
    row = db.query(RefreshToken).filter(RefreshToken.token_hash == digest, RefreshToken.revoked_at.is_(None)).with_for_update().first()
    if not row or row.expires_at <= utcnow():
        return None
    if user is not None and row.user_id != user.id:
        return None
    owner = db.get(User, row.user_id)
    if not owner or not owner.is_active:
        return None
    row.revoked_at = utcnow()
    raw, new_digest, expires = create_refresh_token()
    db.add(RefreshToken(user_id=owner.id, token_hash=new_digest, expires_at=expires))
    db.commit()
    return owner, raw, expires


def revoke_refresh_token(db, raw_token: str) -> bool:
    if not raw_token:
        return False
    digest = hashlib.sha256(raw_token.encode("utf-8")).hexdigest()
    row = db.query(RefreshToken).filter(RefreshToken.token_hash == digest, RefreshToken.revoked_at.is_(None)).with_for_update().first()
    if not row:
        return False
    row.revoked_at = utcnow()
    db.commit()
    return True


_AUTH_REDIS_URL = os.getenv("ERP_AUTH_REDIS_URL", os.getenv("ERP_RATE_LIMIT_REDIS_URL", "")).strip() or redis_connection_url(0)
_auth_redis = None
if _AUTH_REDIS_URL:
    try:
        import redis as _redis_lib
        _auth_redis = _redis_lib.Redis.from_url(_AUTH_REDIS_URL, socket_connect_timeout=1, socket_timeout=1, decode_responses=True)
    except Exception:
        _auth_redis = None

_AUTHZ_PREFIX = "erp:authz:version:"
_REVOKED_PREFIX = "erp:auth:revoked:"
_authz_memory = {}
_revoked_memory = {}
_PRODUCTION = os.getenv("ERP_ENV", "development").lower() == "production"

class AuthBackendUnavailable(RuntimeError):
    """Security state backend is unavailable; production must fail closed."""

if _PRODUCTION and _auth_redis is None:
    raise RuntimeError("Redis is required in production for JWT revocation and authorization invalidation")

def _authz_version(user_id: int) -> int:
    if _auth_redis is not None:
        try:
            value = _auth_redis.get(f"{_AUTHZ_PREFIX}{user_id}")
            return int(value or 0)
        except Exception as exc:
            if _PRODUCTION:
                raise AuthBackendUnavailable("Redis authorization state is unavailable") from exc
    return int(_authz_memory.get(user_id, 0))

def revoke_access_token(token: str) -> None:
    payload = decode_token(token, check_revocation=False)
    if not payload:
        return
    jti = payload.get("jti")
    if not jti:
        return
    ttl = max(1, int(payload.get("exp", 0) - utcnow().timestamp()))
    if _auth_redis is not None:
        try:
            _auth_redis.setex(f"{_REVOKED_PREFIX}{jti}", ttl, "1")
            return
        except Exception as exc:
            if _PRODUCTION:
                raise AuthBackendUnavailable("Redis token revocation store is unavailable") from exc
    _revoked_memory[jti] = utcnow().timestamp() + ttl

def revoke_user_access_tokens(user_id: int) -> None:
    key = f"{_AUTHZ_PREFIX}{user_id}"
    if _auth_redis is not None:
        try:
            _auth_redis.incr(key)
            _auth_redis.expire(key, 86400 * 30)
            return
        except Exception as exc:
            if _PRODUCTION:
                raise AuthBackendUnavailable("Redis authorization state is unavailable") from exc
    _authz_memory[user_id] = _authz_memory.get(user_id, 0) + 1

def _token_revoked(payload) -> bool:
    jti = payload.get("jti")
    if not jti:
        return False
    if _auth_redis is not None:
        try:
            return bool(_auth_redis.exists(f"{_REVOKED_PREFIX}{jti}"))
        except Exception:
            # A production outage must never make a revoked token valid on a
            # different worker. Reject the request until the shared backend recovers.
            if _PRODUCTION:
                return True
    expires = _revoked_memory.get(jti)
    if expires and expires > utcnow().timestamp():
        return True
    if expires:
        _revoked_memory.pop(jti, None)
    return False

def decode_token(token: str, check_revocation: bool = True):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        if check_revocation and _token_revoked(payload):
            return None
        if check_revocation and payload.get("type") == "access" and payload.get("sub") is not None:
            if int(payload.get("authz_version", 0)) != _authz_version(int(payload["sub"])):
                return None
        return payload
    except (JWTError, AuthBackendUnavailable):
        return None


class NotAuthenticated(Exception):
    """يُرفع لما المستخدم مش مسجل دخول أو الجلسة منتهية - بيتحول لصفحة /login."""
    pass


def get_current_user(request: Request, db: Session = Depends(get_db)) -> User:
    token = request.cookies.get("access_token")
    if not token:
        authorization = request.headers.get("Authorization", "")
        if authorization.lower().startswith("bearer "):
            token = authorization[7:].strip()
    if not token:
        raise NotAuthenticated()
    payload = decode_token(token)
    if not payload or not payload.get("sub"):
        raise NotAuthenticated()
    try:
        user_id = int(payload["sub"])
    except (TypeError, ValueError):
        raise NotAuthenticated()
    user = db.query(User).filter(User.id == user_id).first()
    if not user or not user.is_active:
        raise NotAuthenticated()
    return user


def require_module(module_key: str, need_edit: bool = False):
    """
    Dependency factory: يتحقق إن المستخدم عنده صلاحية عرض (أو تعديل) على موديول معين.
    الأدمن دايمًا عنده كل الصلاحيات تلقائيًا.
    """
    def checker(user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> User:
        if user.role == RoleEnum.admin:
            return user
        action = "edit" if need_edit else "view"
        code = f"{module_key}:{action}"
        governed = db.query(Permission.id).join(RolePermission, RolePermission.permission_id == Permission.id).join(UserRole, UserRole.role_id == RolePermission.role_id).filter(UserRole.user_id == user.id, UserRole.is_active == True, Permission.code == code, Permission.is_active == True).first()
        if governed:
            return user
        perm = db.query(ModulePermission).filter_by(user_id=user.id, module_key=module_key).first()
        allowed = perm and (perm.can_edit if need_edit else perm.can_view)
        if not allowed:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="مفيش عندك صلاحية تدخل على القسم ده")
        return user
    return checker
