from .time_utils import utcnow
from sqlalchemy import Column, Integer, String, DateTime, Date, ForeignKey, Text, Boolean, UniqueConstraint, Index
from .db_base import Base

class ConstructionDocumentForm(Base):
    __tablename__ = 'construction_document_forms'
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey('projects.id', ondelete='CASCADE'), nullable=False, index=True)
    document_id = Column(Integer, ForeignKey('project_documents.id', ondelete='SET NULL'), nullable=True, index=True)
    form_type = Column(String(30), nullable=False, index=True)
    form_no = Column(String(100), nullable=False)
    title = Column(String(255), nullable=False)
    status = Column(String(30), nullable=False, default='draft', index=True)
    submission_type = Column(String(30), nullable=False, default='new')
    discipline = Column(String(80))
    zone = Column(String(120))
    level = Column(String(120))
    issue_date = Column(Date)
    due_date = Column(Date)
    data_json = Column(Text, nullable=False, default='{}')
    contractor_representative = Column(String(160))
    consultant_representative = Column(String(160))
    current_revision = Column(Integer, nullable=False, default=0)
    created_by_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    created_at = Column(DateTime, nullable=False, default=utcnow)
    updated_at = Column(DateTime, nullable=False, default=utcnow, onupdate=utcnow)
    closed_at = Column(DateTime)
    __table_args__ = (
        UniqueConstraint('company_id', 'form_no', name='uq_construction_document_form_company_no'),
        Index('ix_construction_form_project_type_status', 'project_id', 'form_type', 'status'),
    )

class ConstructionDocumentFormDecision(Base):
    __tablename__ = 'construction_document_form_decisions'
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    form_id = Column(Integer, ForeignKey('construction_document_forms.id', ondelete='CASCADE'), nullable=False, index=True)
    decision = Column(String(40), nullable=False)
    comments = Column(Text)
    decided_by_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    decided_at = Column(DateTime, nullable=False, default=utcnow)
    is_final = Column(Boolean, nullable=False, default=False)


class ConstructionDocumentFormAttachment(Base):
    __tablename__ = 'construction_document_form_attachments'
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    form_id = Column(Integer, ForeignKey('construction_document_forms.id', ondelete='CASCADE'), nullable=False, index=True)
    file_name = Column(String(255), nullable=False)
    stored_path = Column(String(1000), nullable=False)
    mime_type = Column(String(150), nullable=False)
    file_size = Column(Integer, nullable=False)
    sha256 = Column(String(64), nullable=False, index=True)
    attachment_type = Column(String(50), nullable=False, default='supporting_document')
    description = Column(Text)
    uploaded_by_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    uploaded_at = Column(DateTime, nullable=False, default=utcnow)

class ControlledDocumentCopy(Base):
    __tablename__ = 'controlled_document_copies'
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    document_id = Column(Integer, ForeignKey('project_documents.id', ondelete='CASCADE'), nullable=False, index=True)
    revision_no = Column(Integer, nullable=False, default=0)
    copy_no = Column(String(80), nullable=False)
    holder_user_id = Column(Integer, ForeignKey('users.id'), nullable=True)
    holder_name = Column(String(160))
    issued_at = Column(DateTime, nullable=False, default=utcnow)
    acknowledged_at = Column(DateTime)
    recalled_at = Column(DateTime)
    status = Column(String(30), nullable=False, default='active', index=True)
    __table_args__ = (UniqueConstraint('company_id','document_id','copy_no', name='uq_controlled_copy_document_no'),)

class DocumentRevisionRegister(Base):
    __tablename__ = 'document_revision_register'
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    document_id = Column(Integer, ForeignKey('project_documents.id', ondelete='CASCADE'), nullable=False, index=True)
    revision_no = Column(Integer, nullable=False)
    revision_reason = Column(Text)
    supersedes_revision_id = Column(Integer, ForeignKey('document_revision_register.id'), nullable=True)
    issued_by_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    issued_at = Column(DateTime, nullable=False, default=utcnow)
    is_current = Column(Boolean, nullable=False, default=True, index=True)
    status = Column(String(30), nullable=False, default='issued')
    __table_args__ = (UniqueConstraint('company_id','document_id','revision_no', name='uq_document_revision_no'),)
