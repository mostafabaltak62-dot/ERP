from .time_utils import utcnow
from datetime import date, datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
from sqlalchemy.orm import Session
from sqlalchemy import func, case
from .construction_models import (ConstructionCostCode, WBSNode, BOQRevision, BOQLine, BOQExecution,
    ConstructionMeasurement, ConstructionMeasurementLine, ConstructionVariation, ConstructionAdvance,
    ConstructionProgressCertificateLine, SubcontractorProgress, ConstructionCostBudgetLine, ConstructionCostForecast, WBSNode, ConstructionActivity, ConstructionScheduleBaseline, ConstructionActivityBaseline, ConstructionProgressPeriod, ConstructionActivityProgress, ConstructionTimePhasedBudget, ConstructionEVMSnapshot, ConstructionEVMCostAllocation, ConstructionPerformanceAlert, ConstructionRecoveryPlan, ConstructionRecoveryAction, ConstructionScheduleCalendar, ConstructionActivityDependency, ConstructionScheduleDelayEvent, ConstructionScheduleResource, ConstructionTimeImpactAnalysis, ConstructionScheduleUpdatePeriod, ConstructionScheduleResourcePeriod, ConstructionRecoveryScheduleLink, ConstructionEOTClaim, ConstructionScheduleUpdateLine, ConstructionCostControlSnapshot, ConstructionCostBudgetRevision, ConstructionCostBudgetRevisionLine, ConstructionTimePhasedCost, ConstructionCostForecastVersion, ConstructionCostForecastVersionLine, ConstructionCostVariance, ConstructionAuthoritativeBudgetLine, ConstructionCostReconciliation, ConstructionCostAlert, ConstructionCostCashFlowSnapshot)
from .enterprise_models import Project, Contract, BOQItem, ProgressCertificate, ProjectCost, ProjectForecast
from .accounting import create_entry

MONEY = Decimal('0.01')
QTY = Decimal('0.000001')

def D(v): return Decimal(str(v or 0))
def q(v): return D(v).quantize(MONEY, rounding=ROUND_HALF_UP)
def qr(v): return D(v).quantize(Decimal('0.00000001'), rounding=ROUND_HALF_UP)

def company_project(db, company_id, project_id):
    return db.query(Project).filter(Project.id==project_id, Project.company_id==company_id).with_for_update().first()

def create_cost_code(db, company_id, code, name, category, parent_id=None):
    if db.query(ConstructionCostCode).filter_by(company_id=company_id, code=code).first(): raise ValueError('Cost code already exists')
    if category not in {'material','labor','equipment','subcontract','overhead','other'}: raise ValueError('Invalid cost code category')
    if parent_id and not db.query(ConstructionCostCode).filter_by(id=parent_id, company_id=company_id).first(): raise ValueError('Invalid parent cost code')
    row=ConstructionCostCode(company_id=company_id, code=code.strip(), name=name.strip(), category=category, parent_id=parent_id)
    db.add(row); db.flush(); return row

def create_wbs(db, company_id, project_id, code, name, budget_amount=0, parent_id=None):
    if not company_project(db, company_id, project_id): raise ValueError('Project not found')
    if db.query(WBSNode).filter_by(project_id=project_id, code=code).first(): raise ValueError('WBS code already exists')
    level=1
    if parent_id:
        parent=db.query(WBSNode).filter_by(id=parent_id, project_id=project_id, company_id=company_id).first()
        if not parent: raise ValueError('Invalid WBS parent')
        level=parent.level+1
    row=WBSNode(company_id=company_id,project_id=project_id,parent_id=parent_id,code=code.strip(),name=name.strip(),level=level,budget_amount=q(budget_amount))
    db.add(row); db.flush(); return row

def create_boq_revision(db, company_id, project_id, revision_no, effective_date, reason, user_id, lines):
    if not company_project(db, company_id, project_id): raise ValueError('Project not found')
    if db.query(BOQRevision).filter_by(project_id=project_id, revision_no=revision_no).first(): raise ValueError('BOQ revision already exists')
    row=BOQRevision(company_id=company_id,project_id=project_id,revision_no=revision_no,effective_date=effective_date,reason=reason,created_by_id=user_id)
    db.add(row); db.flush()
    seen=set()
    total=Decimal('0')
    for x in lines:
        if x['item_code'] in seen: raise ValueError('Duplicate BOQ item code')
        seen.add(x['item_code'])
        qty=D(x['contract_qty']); rate=D(x['contract_rate'])
        if qty<0 or rate<0: raise ValueError('BOQ quantity/rate cannot be negative')
        if x.get('wbs_id') and not db.query(WBSNode).filter_by(id=x['wbs_id'],project_id=project_id,company_id=company_id).first(): raise ValueError('Invalid WBS')
        if x.get('cost_code_id') and not db.query(ConstructionCostCode).filter_by(id=x['cost_code_id'],company_id=company_id).first(): raise ValueError('Invalid cost code')
        line=BOQLine(company_id=company_id,revision_id=row.id,project_id=project_id,boq_item_id=x.get('boq_item_id'),wbs_id=x.get('wbs_id'),cost_code_id=x.get('cost_code_id'),item_code=x['item_code'],description=x['description'],unit=x['unit'],contract_qty=qty,contract_rate=rate)
        db.add(line); total += qty*rate
    db.flush(); return row, q(total)

def record_measurement(db, company_id, project_id, measurement_no, measurement_date, user_id, lines, notes=''):
    if not company_project(db,company_id,project_id): raise ValueError('Project not found')
    if db.query(ConstructionMeasurement).filter_by(company_id=company_id,measurement_no=measurement_no).first(): raise ValueError('Measurement number already exists')
    m=ConstructionMeasurement(company_id=company_id,project_id=project_id,measurement_no=measurement_no,measurement_date=measurement_date,created_by_id=user_id,notes=notes)
    db.add(m); db.flush()
    total=Decimal('0')
    for x in lines:
        line=db.query(BOQLine).filter_by(id=x['boq_line_id'],project_id=project_id,company_id=company_id).first()
        if not line: raise ValueError('Invalid BOQ line')
        current=D(x['current_qty']); cumulative=D(x.get('cumulative_qty'))
        executed=D(db.query(func.coalesce(func.sum(BOQExecution.quantity),0)).filter(BOQExecution.boq_line_id==line.id,BOQExecution.company_id==company_id).scalar())
        if current<0 or cumulative < executed+current: raise ValueError('Invalid cumulative measurement')
        if cumulative > D(line.contract_qty): raise ValueError('Cumulative quantity exceeds contract quantity')
        amount=q(current*D(line.contract_rate))
        ml=ConstructionMeasurementLine(company_id=company_id,measurement_id=m.id,boq_line_id=line.id,current_qty=current,cumulative_qty=cumulative,amount=amount)
        db.add(ml)
        db.add(BOQExecution(company_id=company_id,project_id=project_id,boq_line_id=line.id,measurement_id=m.id,quantity=current,execution_date=measurement_date))
        total += amount
    db.flush(); return m,q(total)

def approve_measurement(db, company_id, measurement_id):
    m=db.query(ConstructionMeasurement).filter_by(id=measurement_id,company_id=company_id).with_for_update().first()
    if not m: raise ValueError('Measurement not found')
    if m.status!='draft': raise ValueError('Measurement is not draft')
    m.status='approved'; db.flush(); return m

def create_progress_certificate(db, company_id, project_id, certificate_number, certificate_date, user_id, lines, retention_rate=0, advance_recovery=0, contract_id=None):
    project=company_project(db,company_id,project_id)
    if not project: raise ValueError('Project not found')
    if contract_id and not db.query(Contract).filter_by(id=contract_id,company_id=company_id,project_id=project_id,contract_type='customer').first(): raise ValueError('Invalid customer contract')
    if db.query(ProgressCertificate).filter_by(company_id=company_id,certificate_number=certificate_number).first(): raise ValueError('Certificate number already exists')
    gross=Decimal('0'); retained=Decimal('0'); recovery=D(advance_recovery)
    cert=ProgressCertificate(company_id=company_id,project_id=project_id,contract_id=contract_id,certificate_number=certificate_number,certificate_date=certificate_date,gross_amount=0,retention_amount=0,advance_recovery=0,net_amount=0,status='draft')
    db.add(cert); db.flush()
    for x in lines:
        boq=db.query(BOQLine).filter_by(id=x['boq_line_id'],project_id=project_id,company_id=company_id).first()
        if not boq: raise ValueError('Invalid BOQ line')
        qty=D(x['current_qty']); cum=D(x.get('cumulative_qty'))
        if qty<0 or cum>D(boq.contract_qty): raise ValueError('Certificate quantity exceeds contract quantity')
        amount=q(qty*D(boq.contract_rate)); r=q(amount*D(retention_rate)/Decimal('100'))
        gross+=amount; retained+=r
        db.add(ConstructionProgressCertificateLine(company_id=company_id,certificate_id=cert.id,boq_line_id=boq.id,current_qty=qty,cumulative_qty=cum,gross_amount=amount,retention_amount=r,advance_recovery=0,net_amount=q(amount-r)))
    if recovery<0 or recovery>gross-retained: raise ValueError('Invalid advance recovery')
    cert.gross_amount=q(gross); cert.retention_amount=q(retained); cert.advance_recovery=q(recovery); cert.net_amount=q(gross-retained-recovery)
    db.flush(); return cert

def approve_variation(db, company_id, variation_id, user_id):
    v=db.query(ConstructionVariation).filter_by(id=variation_id,company_id=company_id).with_for_update().first()
    if not v: raise ValueError('Variation not found')
    if v.status!='draft': raise ValueError('Variation is not draft')
    v.status='approved'; v.approved_at=utcnow(); v.approved_by_id=user_id; db.flush(); return v

def add_variation(db, company_id, project_id, variation_no, description, amount, contract_id=None):
    if not company_project(db,company_id,project_id): raise ValueError('Project not found')
    if db.query(ConstructionVariation).filter_by(company_id=company_id,variation_no=variation_no).first(): raise ValueError('Variation number already exists')
    if contract_id and not db.query(Contract).filter_by(id=contract_id,company_id=company_id,project_id=project_id).first(): raise ValueError('Invalid contract')
    v=ConstructionVariation(company_id=company_id,project_id=project_id,contract_id=contract_id,variation_no=variation_no,description=description,amount=q(amount))
    db.add(v); db.flush(); return v

def project_control(db, company_id, project_id):
    p=db.query(Project).filter_by(id=project_id,company_id=company_id).first()
    if not p: raise ValueError('Project not found')
    boq_budget=D(db.query(func.coalesce(func.sum(BOQLine.contract_qty*BOQLine.contract_rate),0)).filter(BOQLine.project_id==project_id,BOQLine.company_id==company_id).scalar())
    variations=D(db.query(func.coalesce(func.sum(ConstructionVariation.amount),0)).filter(ConstructionVariation.project_id==project_id,ConstructionVariation.company_id==company_id,ConstructionVariation.status=='approved').scalar())
    actual=D(db.query(func.coalesce(func.sum(ProjectCost.amount),0)).filter(ProjectCost.project_id==project_id,ProjectCost.company_id==company_id).scalar())
    certified=D(db.query(func.coalesce(func.sum(ProgressCertificate.gross_amount),0)).filter(ProgressCertificate.project_id==project_id,ProgressCertificate.company_id==company_id,ProgressCertificate.status.in_(['approved','posted'])).scalar())
    revised_contract=boq_budget+variations
    remaining=revised_contract-actual
    profit=revised_contract-actual
    return {'project_id':project_id,'original_boq_value':q(boq_budget),'approved_variations':q(variations),'revised_contract_value':q(revised_contract),'actual_cost':q(actual),'certified_revenue':q(certified),'remaining_cost_budget':q(remaining),'forecast_profit':q(profit)}

def create_advance(db, company_id, project_id, contract_id, direction, amount, advance_date, reference=None, user_id=None):
    if direction not in {'received','payable'}: raise ValueError('Invalid advance direction')
    if not company_project(db,company_id,project_id): raise ValueError('Project not found')
    if not db.query(Contract).filter_by(id=contract_id,company_id=company_id,project_id=project_id).first(): raise ValueError('Invalid contract')
    amount=q(amount)
    if amount<=0: raise ValueError('Advance must be positive')
    row=ConstructionAdvance(company_id=company_id,project_id=project_id,contract_id=contract_id,direction=direction,amount=amount,advance_date=advance_date,reference=reference)
    db.add(row); db.flush()
    if user_id is not None:
        if direction == 'received':
            lines=[('1100',amount,0),('2300',0,amount)]
        else:
            lines=[('1400',amount,0),('1100',0,amount)]
        je=create_entry(db, f'Construction advance {reference or row.id}', user_id, lines, 'construction_advance', row.id, advance_date, company_id=company_id)
        row.journal_entry_id=je.id
    db.flush(); return row

def recover_advance(db, company_id, advance_id, amount):
    row=db.query(ConstructionAdvance).filter_by(id=advance_id,company_id=company_id).with_for_update().first()
    if not row: raise ValueError('Advance not found')
    recovery=q(amount)
    if recovery<=0 or row.recovered_amount+recovery>row.amount: raise ValueError('Advance recovery exceeds outstanding balance')
    row.recovered_amount=q(row.recovered_amount+recovery)
    if row.recovered_amount==row.amount: row.status='recovered'
    db.flush(); return row

def approve_certificate(db, company_id, certificate_id, user_id):
    row=db.query(ProgressCertificate).filter_by(id=certificate_id,company_id=company_id).with_for_update().first()
    if not row: raise ValueError('Certificate not found')
    if row.status!='draft': raise ValueError('Certificate is not draft')
    contract=None
    if row.contract_id:
        contract=db.query(Contract).filter_by(id=row.contract_id,company_id=company_id,project_id=row.project_id,contract_type='customer').first()
    if not contract:
        contract=db.query(Contract).filter_by(company_id=company_id,project_id=row.project_id,contract_type='customer').order_by(Contract.id.asc()).first()
    if not contract: raise ValueError('Customer contract is required before posting a progress certificate')
    lines=[('1200',row.net_amount,0)]
    if row.retention_amount: lines.append(('1210',row.retention_amount,0))
    if row.advance_recovery:
        outstanding=D(db.query(func.coalesce(func.sum(ConstructionAdvance.amount-ConstructionAdvance.recovered_amount),0)).filter(ConstructionAdvance.company_id==company_id,ConstructionAdvance.project_id==row.project_id,ConstructionAdvance.direction=='received',ConstructionAdvance.status=='open').scalar())
        if outstanding < D(row.advance_recovery): raise ValueError('Customer advance recovery exceeds outstanding advances')
        remaining=D(row.advance_recovery)
        advances=db.query(ConstructionAdvance).filter(ConstructionAdvance.company_id==company_id,ConstructionAdvance.project_id==row.project_id,ConstructionAdvance.direction=='received',ConstructionAdvance.status=='open').order_by(ConstructionAdvance.advance_date,ConstructionAdvance.id).with_for_update().all()
        for adv in advances:
            available=D(adv.amount)-D(adv.recovered_amount)
            take=min(available,remaining)
            adv.recovered_amount=q(D(adv.recovered_amount)+take)
            if adv.recovered_amount==adv.amount: adv.status='recovered'
            remaining-=take
            if remaining<=0: break
        lines.append(('2300',row.advance_recovery,0))
    lines.append(('4100',0,row.gross_amount))
    je=create_entry(db, f'Client progress certificate {row.certificate_number}', user_id, lines, 'construction_progress_certificate', row.id, row.certificate_date, company_id=company_id)
    row.status='posted'; row.approved_at=utcnow(); row.approved_by_id=user_id; row.journal_entry_id=je.id
    db.flush(); return row

def create_subcontractor_progress(db, company_id, project_id, contract_id, certificate_no, certificate_date, gross_amount, retention_amount=0, advance_recovery=0, deductions=0, user_id=None):
    if not company_project(db,company_id,project_id): raise ValueError('Project not found')
    contract=db.query(Contract).filter_by(id=contract_id,company_id=company_id,project_id=project_id,contract_type='subcontractor').first()
    if not contract: raise ValueError('Subcontractor contract not found')
    if db.query(SubcontractorProgress).filter_by(company_id=company_id,certificate_no=certificate_no).first(): raise ValueError('Subcontractor certificate already exists')
    gross,ret,adv,ded=map(q,(gross_amount,retention_amount,advance_recovery,deductions))
    if min(gross,ret,adv,ded)<0 or ret+adv+ded>gross: raise ValueError('Invalid subcontractor deductions')
    row=SubcontractorProgress(company_id=company_id,project_id=project_id,contract_id=contract_id,certificate_no=certificate_no,gross_amount=gross,retention_amount=ret,advance_recovery=adv,deductions=ded,net_amount=q(gross-ret-adv-ded),certificate_date=certificate_date)
    db.add(row); db.flush(); return row

def approve_subcontractor_progress(db, company_id, progress_id, user_id):
    row=db.query(SubcontractorProgress).filter_by(id=progress_id,company_id=company_id).with_for_update().first()
    if not row: raise ValueError('Subcontractor progress not found')
    if row.status!='draft': raise ValueError('Subcontractor progress is not draft')
    lines=[('5200',row.gross_amount,0),('2100',0,row.net_amount)]
    if row.retention_amount: lines.append(('2310',0,row.retention_amount))
    if row.advance_recovery:
        outstanding=D(db.query(func.coalesce(func.sum(ConstructionAdvance.amount-ConstructionAdvance.recovered_amount),0)).filter(ConstructionAdvance.company_id==company_id,ConstructionAdvance.project_id==row.project_id,ConstructionAdvance.direction=='payable',ConstructionAdvance.status=='open').scalar())
        if outstanding < D(row.advance_recovery): raise ValueError('Subcontractor advance recovery exceeds outstanding advances')
        remaining=D(row.advance_recovery)
        advances=db.query(ConstructionAdvance).filter(ConstructionAdvance.company_id==company_id,ConstructionAdvance.project_id==row.project_id,ConstructionAdvance.direction=='payable',ConstructionAdvance.status=='open').order_by(ConstructionAdvance.advance_date,ConstructionAdvance.id).with_for_update().all()
        for adv in advances:
            available=D(adv.amount)-D(adv.recovered_amount)
            take=min(available,remaining)
            adv.recovered_amount=q(D(adv.recovered_amount)+take)
            if adv.recovered_amount==adv.amount: adv.status='recovered'
            remaining-=take
            if remaining<=0: break
        lines.append(('1400',0,row.advance_recovery))
    if row.deductions: lines.append(('5200',0,row.deductions))
    je=create_entry(db, f'Subcontractor progress {row.certificate_no}', user_id, lines, 'subcontractor_progress', row.id, row.certificate_date, company_id=company_id)
    row.status='posted'; row.approved_at=utcnow(); row.approved_by_id=user_id; row.journal_entry_id=je.id
    db.flush(); return row

# Phase 6.1 — field operations / construction cost control
from .construction_models import ConstructionSite, SiteMaterialIssue, EquipmentUsage, ConstructionLaborEntry, SubcontractorBOQLine
from .models import Item, StockMovement, MovementTypeEnum
from .enterprise_models import Equipment, Employee

def create_site(db, company_id, project_id, code, name, location=None, manager_id=None):
    if not company_project(db, company_id, project_id): raise ValueError('Project not found')
    if db.query(ConstructionSite).filter_by(company_id=company_id, code=code).first(): raise ValueError('Site code already exists')
    row=ConstructionSite(company_id=company_id,project_id=project_id,code=code.strip(),name=name.strip(),location=location,manager_id=manager_id)
    db.add(row); db.flush(); return row

def issue_site_material(db, company_id, project_id, site_id, item_id, quantity, unit_cost, issue_date, reference=None):
    site=db.query(ConstructionSite).filter_by(id=site_id,company_id=company_id,project_id=project_id).first()
    if not site: raise ValueError('Site not found')
    item=db.query(Item).filter_by(id=item_id,company_id=company_id).with_for_update().first()
    if not item: raise ValueError('Item not found')
    qty=D(quantity); cost=q(unit_cost)
    if qty<=0 or cost<0: raise ValueError('Invalid material issue')
    available=D(db.query(func.coalesce(func.sum(case((StockMovement.movement_type.in_([MovementTypeEnum.in_, MovementTypeEnum.adjustment_in]), StockMovement.quantity), else_=-StockMovement.quantity)),0)).filter(StockMovement.company_id==company_id,StockMovement.item_id==item_id).scalar())
    if available < qty: raise ValueError('Insufficient stock for site material issue')
    row=SiteMaterialIssue(company_id=company_id,project_id=project_id,site_id=site_id,item_id=item_id,quantity=qty,unit_cost=cost,total_cost=q(qty*cost),issue_date=issue_date,reference=reference)
    db.add(row); db.flush()
    db.add(StockMovement(company_id=company_id,item_id=item_id,movement_type=MovementTypeEnum.out,quantity=qty,unit_cost=cost,total_cost=row.total_cost,note=f'Construction site issue {reference or row.id}'))
    pc=ProjectCost(company_id=company_id,project_id=project_id,cost_type='material',source_type='site_material_issue',source_id=row.id,amount=row.total_cost,cost_date=utcnow(),description=f'Site material issue {reference or row.id}')
    db.add(pc); db.flush(); return row

def record_equipment_usage(db, company_id, project_id, equipment_id, usage_date, start_reading, end_reading, rate_per_hour=None, site_id=None):
    if not company_project(db,company_id,project_id): raise ValueError('Project not found')
    eq=db.query(Equipment).filter_by(id=equipment_id,company_id=company_id,is_active=True).first()
    if not eq: raise ValueError('Equipment not found or inactive')
    start,end=D(start_reading),D(end_reading)
    rate=q(rate_per_hour if rate_per_hour is not None else (eq.hourly_rate or 0))
    if end < start: raise ValueError('Equipment meter reading cannot move backwards')
    if rate < 0: raise ValueError('Equipment hourly rate cannot be negative')
    hours=end-start
    if hours <= 0: raise ValueError('Equipment usage must contain positive working hours')
    duplicate=db.query(EquipmentUsage).filter_by(company_id=company_id,project_id=project_id,equipment_id=equipment_id,usage_date=usage_date,start_reading=start,end_reading=end).first()
    if duplicate: raise ValueError('Duplicate equipment usage entry')
    total=q(hours*rate)
    row=EquipmentUsage(company_id=company_id,project_id=project_id,equipment_id=equipment_id,site_id=site_id,usage_date=usage_date,start_reading=start,end_reading=end,hours=hours,rate_per_hour=rate,total_cost=total)
    db.add(row); db.flush()
    db.add(ProjectCost(company_id=company_id,project_id=project_id,cost_type='equipment',source_type='equipment_usage',source_id=row.id,amount=total,cost_date=utcnow(),description=f'Equipment usage {eq.code} — {eq.name}'))
    db.flush(); return row

def record_labor(db, company_id, project_id, employee_id, work_date, regular_hours, overtime_hours, regular_rate, overtime_rate, site_id=None):
    if not company_project(db,company_id,project_id): raise ValueError('Project not found')
    if not db.query(Employee).filter_by(id=employee_id,company_id=company_id).first(): raise ValueError('Employee not found')
    rh,oh,rr,orate=D(regular_hours),D(overtime_hours),q(regular_rate),q(overtime_rate)
    if min(rh,oh,rr,orate)<0: raise ValueError('Invalid labor values')
    total=q(rh*rr+oh*orate)
    row=ConstructionLaborEntry(company_id=company_id,project_id=project_id,site_id=site_id,employee_id=employee_id,work_date=work_date,regular_hours=rh,overtime_hours=oh,regular_rate=rr,overtime_rate=orate,total_cost=total)
    db.add(row); db.flush(); db.add(ProjectCost(company_id=company_id,project_id=project_id,cost_type='labor',source_type='construction_labor',source_id=row.id,amount=total,cost_date=utcnow(),description=f'Labor {employee_id}')); db.flush(); return row

def create_subcontractor_boq_line(db, company_id, project_id, contract_id, item_code, description, unit, contract_qty, contract_rate, cost_code_id=None):
    contract=db.query(Contract).filter_by(id=contract_id,company_id=company_id,project_id=project_id,contract_type='subcontractor').first()
    if not contract: raise ValueError('Subcontractor contract not found')
    if db.query(SubcontractorBOQLine).filter_by(contract_id=contract_id,item_code=item_code).first(): raise ValueError('Subcontractor BOQ item exists')
    qty,rate=D(contract_qty),q(contract_rate)
    if qty<0 or rate<0: raise ValueError('Invalid subcontractor BOQ values')
    if cost_code_id and not db.query(ConstructionCostCode).filter_by(id=cost_code_id,company_id=company_id).first(): raise ValueError('Invalid cost code')
    row=SubcontractorBOQLine(company_id=company_id,project_id=project_id,contract_id=contract_id,cost_code_id=cost_code_id,item_code=item_code,description=description,unit=unit,contract_qty=qty,contract_rate=rate)
    db.add(row); db.flush(); return row

def construction_cash_flow(db, company_id, project_id):
    if not db.query(Project).filter_by(id=project_id,company_id=company_id).first(): raise ValueError('Project not found')
    inflow=D(db.query(func.coalesce(func.sum(ProgressCertificate.net_amount),0)).filter(ProgressCertificate.project_id==project_id,ProgressCertificate.company_id==company_id,ProgressCertificate.status.in_(['approved','posted'])).scalar())
    material=D(db.query(func.coalesce(func.sum(SiteMaterialIssue.total_cost),0)).filter(SiteMaterialIssue.project_id==project_id,SiteMaterialIssue.company_id==company_id).scalar())
    equipment=D(db.query(func.coalesce(func.sum(EquipmentUsage.total_cost),0)).filter(EquipmentUsage.project_id==project_id,EquipmentUsage.company_id==company_id).scalar())
    labor=D(db.query(func.coalesce(func.sum(ConstructionLaborEntry.total_cost),0)).filter(ConstructionLaborEntry.project_id==project_id,ConstructionLaborEntry.company_id==company_id).scalar())
    subcontract=D(db.query(func.coalesce(func.sum(SubcontractorProgress.net_amount),0)).filter(SubcontractorProgress.project_id==project_id,SubcontractorProgress.company_id==company_id,SubcontractorProgress.status.in_(['approved','posted'])).scalar())
    out=material+equipment+labor+subcontract
    return {'project_id':project_id,'certified_inflow':q(inflow),'material_outflow':q(material),'equipment_outflow':q(equipment),'labor_outflow':q(labor),'subcontractor_outflow':q(subcontract),'net_cash_position':q(inflow-out)}


# ---------------------------------------------------------------------
# Phase 6.3 — Construction Cost Control & Subcontractor Management
# ---------------------------------------------------------------------
from .construction_models import (
    ConstructionCostBudgetLine, ConstructionCommitment,
    SubcontractorMeasurement, SubcontractorMeasurementLine,
    SubcontractorProgressLine, ConstructionCostForecast
)

def _project_exists(db, company_id, project_id):
    return db.query(Project).filter_by(id=project_id, company_id=company_id).first()

def create_cost_budget_line(db, company_id, project_id, description, budget_amount,
                            cost_code_id=None, wbs_id=None, boq_line_id=None, budget_date=None):
    if not _project_exists(db, company_id, project_id): raise ValueError('Project not found')
    amount=q(budget_amount)
    if amount < 0: raise ValueError('Budget amount cannot be negative')
    if cost_code_id and not db.query(ConstructionCostCode).filter_by(id=cost_code_id,company_id=company_id).first():
        raise ValueError('Invalid cost code')
    if wbs_id and not db.query(WBSNode).filter_by(id=wbs_id,company_id=company_id,project_id=project_id).first():
        raise ValueError('Invalid WBS')
    if boq_line_id and not db.query(BOQLine).filter_by(id=boq_line_id,company_id=company_id,project_id=project_id).first():
        raise ValueError('Invalid BOQ line')
    row=ConstructionCostBudgetLine(company_id=company_id,project_id=project_id,description=description,
        budget_amount=amount,cost_code_id=cost_code_id,wbs_id=wbs_id,boq_line_id=boq_line_id,budget_date=budget_date)
    db.add(row); db.flush(); return row

def create_commitment(db, company_id, project_id, description, committed_amount, commitment_date,
                      contract_id=None, cost_code_id=None, wbs_id=None, subcontractor_boq_line_id=None,
                      source_type='manual', source_id=None):
    if not _project_exists(db,company_id,project_id): raise ValueError('Project not found')
    if not description or not description.strip(): raise ValueError('Commitment description is required')
    if commitment_date is None: raise ValueError('Commitment date is required')
    amount=q(committed_amount)
    if amount < 0: raise ValueError('Commitment amount cannot be negative')
    if cost_code_id and not db.query(ConstructionCostCode).filter_by(id=cost_code_id,company_id=company_id,is_active=True).first():
        raise ValueError('Invalid or inactive cost code')
    if wbs_id and not db.query(WBSNode).filter_by(id=wbs_id,company_id=company_id,project_id=project_id,is_active=True).first():
        raise ValueError('Invalid WBS')
    if contract_id and not db.query(Contract).filter_by(id=contract_id,company_id=company_id,project_id=project_id).first():
        raise ValueError('Invalid contract')
    if subcontractor_boq_line_id:
        line=db.query(SubcontractorBOQLine).filter_by(id=subcontractor_boq_line_id,company_id=company_id,project_id=project_id).first()
        if not line: raise ValueError('Invalid subcontractor BOQ line')
        if contract_id and line.contract_id != contract_id: raise ValueError('Subcontractor BOQ line does not belong to contract')
    if source_id is not None:
        duplicate=db.query(ConstructionCommitment).filter_by(company_id=company_id,project_id=project_id,source_type=source_type,source_id=source_id).first()
        if duplicate: raise ValueError('Commitment source has already been recorded')
    # Budget-control policy is a real enforcement control, not display-only.
    # Import lazily to avoid a module cycle between construction and commercial
    # completion layers. Lock the project row so concurrent commitment writers
    # evaluate the same exposure before inserting.
    project=company_project(db, company_id, project_id)
    from .commercial_completion_models import BudgetControlPolicy
    policy=db.query(BudgetControlPolicy).filter_by(company_id=company_id,project_id=project_id,is_active=True).first()
    if policy and bool(policy.block_over_budget):
        budget=authoritative_budget_total(db,company_id,project_id)
        committed=D(db.query(func.coalesce(func.sum(ConstructionCommitment.committed_amount-ConstructionCommitment.released_amount),0)).filter(
            ConstructionCommitment.company_id==company_id,ConstructionCommitment.project_id==project_id,
            ConstructionCommitment.status.in_(['open','approved','active'])).scalar() or 0)
        actual=D(db.query(func.coalesce(func.sum(ProjectCost.amount),0)).filter(
            ProjectCost.company_id==company_id,ProjectCost.project_id==project_id).scalar() or 0)
        allowed=budget*(Decimal('1')+D(policy.tolerance_percent)/Decimal('100'))
        if budget <= 0 and amount > 0:
            raise ValueError('Budget control blocks unbudgeted commitment')
        if actual + committed + amount > allowed:
            raise ValueError('Commitment exceeds the configured budget-control limit')
    row=ConstructionCommitment(company_id=company_id,project_id=project_id,contract_id=contract_id,
        cost_code_id=cost_code_id,wbs_id=wbs_id,subcontractor_boq_line_id=subcontractor_boq_line_id,
        source_type=source_type,source_id=source_id,commitment_date=commitment_date,description=description.strip(),
        committed_amount=amount)
    db.add(row); db.flush(); return row

def create_subcontractor_measurement(db, company_id, project_id, contract_id, measurement_no,
                                     measurement_date, user_id, lines, notes=''):
    contract=db.query(Contract).filter_by(id=contract_id,company_id=company_id,project_id=project_id,contract_type='subcontractor').first()
    if not contract: raise ValueError('Subcontractor contract not found')
    if db.query(SubcontractorMeasurement).filter_by(company_id=company_id,measurement_no=measurement_no).first():
        raise ValueError('Subcontractor measurement number already exists')
    m=SubcontractorMeasurement(company_id=company_id,project_id=project_id,contract_id=contract_id,
        measurement_no=measurement_no,measurement_date=measurement_date,created_by_id=user_id,notes=notes)
    db.add(m); db.flush()
    total=Decimal('0')
    for x in lines:
        line=db.query(SubcontractorBOQLine).filter_by(id=x['subcontractor_boq_line_id'],company_id=company_id,
            project_id=project_id,contract_id=contract_id).first()
        if not line: raise ValueError('Invalid subcontractor BOQ line')
        current=D(x['current_qty']); cumulative=D(x.get('cumulative_qty',current))
        executed=D(db.query(func.coalesce(func.sum(SubcontractorMeasurementLine.current_qty),0)).join(
            SubcontractorMeasurement,SubcontractorMeasurement.id==SubcontractorMeasurementLine.measurement_id
        ).filter(SubcontractorMeasurementLine.company_id==company_id,
                SubcontractorMeasurementLine.subcontractor_boq_line_id==line.id,
                SubcontractorMeasurement.status.in_(['approved','certified'])).scalar())
        if current<0 or cumulative<executed+current or cumulative>D(line.contract_qty):
            raise ValueError('Invalid subcontractor cumulative measurement')
        amount=q(current*D(line.contract_rate))
        db.add(SubcontractorMeasurementLine(company_id=company_id,measurement_id=m.id,
            subcontractor_boq_line_id=line.id,current_qty=current,cumulative_qty=cumulative,amount=amount))
        total+=amount
    db.flush(); return m,q(total)

def approve_subcontractor_measurement(db, company_id, measurement_id):
    m=db.query(SubcontractorMeasurement).filter_by(id=measurement_id,company_id=company_id).with_for_update().first()
    if not m: raise ValueError('Subcontractor measurement not found')
    if m.status!='draft': raise ValueError('Subcontractor measurement is not draft')
    m.status='approved'; db.flush(); return m

def create_subcontractor_progress_from_measurement(db, company_id, project_id, contract_id, certificate_no,
                                                   certificate_date, measurement_id, retention_amount=0,
                                                   advance_recovery=0, deductions=0, user_id=None):
    m=db.query(SubcontractorMeasurement).filter_by(id=measurement_id,company_id=company_id,
        project_id=project_id,contract_id=contract_id).first()
    if not m or m.status not in ('approved','certified'): raise ValueError('Approved subcontractor measurement is required')
    lines=db.query(SubcontractorMeasurementLine).filter_by(measurement_id=m.id,company_id=company_id).all()
    if not lines: raise ValueError('Measurement has no lines')
    gross=q(sum(D(x.amount) for x in lines))
    row=create_subcontractor_progress(db,company_id,project_id,contract_id,certificate_no,certificate_date,
        gross,retention_amount,advance_recovery,deductions,user_id=user_id,measurement_id=measurement_id)
    for x in lines:
        db.add(SubcontractorProgressLine(company_id=company_id,progress_id=row.id,
            subcontractor_boq_line_id=x.subcontractor_boq_line_id,current_qty=x.current_qty,
            cumulative_qty=x.cumulative_qty,gross_amount=x.amount))
    db.flush(); return row

# Extend Phase 6.2 function without breaking its public signature.
_old_create_subcontractor_progress = create_subcontractor_progress
def create_subcontractor_progress(db, company_id, project_id, contract_id, certificate_no, certificate_date,
                                  gross_amount, retention_amount=0, advance_recovery=0, deductions=0,
                                  user_id=None, measurement_id=None):
    row=_old_create_subcontractor_progress(db,company_id,project_id,contract_id,certificate_no,certificate_date,
        gross_amount,retention_amount,advance_recovery,deductions,user_id)
    if measurement_id is not None:
        m=db.query(SubcontractorMeasurement).filter_by(id=measurement_id,company_id=company_id,
            project_id=project_id,contract_id=contract_id).first()
        if not m: raise ValueError('Invalid subcontractor measurement')
        row.measurement_id=measurement_id
    db.flush(); return row

def create_cost_forecast(db, company_id, project_id, description, etc_amount, forecast_date,
                         cost_code_id=None, wbs_id=None, user_id=None):
    if not _project_exists(db,company_id,project_id): raise ValueError('Project not found')
    if not description or not description.strip(): raise ValueError('Forecast description is required')
    if forecast_date is None: raise ValueError('Forecast date is required')
    amount=q(etc_amount)
    if amount<0: raise ValueError('ETC cannot be negative')
    if cost_code_id and not db.query(ConstructionCostCode).filter_by(id=cost_code_id,company_id=company_id,is_active=True).first():
        raise ValueError('Invalid or inactive cost code')
    if wbs_id and not db.query(WBSNode).filter_by(id=wbs_id,company_id=company_id,is_active=True).first():
        raise ValueError('Invalid WBS')
    row=ConstructionCostForecast(company_id=company_id,project_id=project_id,description=description.strip(),
        etc_amount=amount,forecast_date=forecast_date,cost_code_id=cost_code_id,wbs_id=wbs_id,created_by_id=user_id)
    db.add(row); db.flush(); return row

def _sum_project_actuals(db, company_id, project_id):
    # ProjectCost is the authoritative operational actual-cost subledger.
    return D(db.query(func.coalesce(func.sum(ProjectCost.amount),0)).filter(
        ProjectCost.company_id==company_id,ProjectCost.project_id==project_id).scalar())

def construction_cost_control(db, company_id, project_id):
    if not _project_exists(db,company_id,project_id): raise ValueError('Project not found')
    explicit_budget=D(db.query(func.coalesce(func.sum(ConstructionCostBudgetLine.budget_amount),0)).filter(
        ConstructionCostBudgetLine.company_id==company_id,ConstructionCostBudgetLine.project_id==project_id,
        ConstructionCostBudgetLine.status=='active').scalar())
    boq_budget=D(db.query(func.coalesce(func.sum(BOQLine.contract_qty*BOQLine.contract_rate),0)).filter(
        BOQLine.company_id==company_id,BOQLine.project_id==project_id).scalar())
    # Patch 89 — authoritative budget is the source of truth once materialized.
    # Do not fall back merely because the approved total is zero; the existence
    # of authoritative rows is what determines whether that ledger is active.
    auth_q=db.query(func.coalesce(func.sum(ConstructionAuthoritativeBudgetLine.approved_budget),0)).filter(
        ConstructionAuthoritativeBudgetLine.company_id==company_id,
        ConstructionAuthoritativeBudgetLine.project_id==project_id)
    auth_exists=db.query(ConstructionAuthoritativeBudgetLine.id).filter(
        ConstructionAuthoritativeBudgetLine.company_id==company_id,
        ConstructionAuthoritativeBudgetLine.project_id==project_id).first() is not None
    authoritative_budget=D(auth_q.scalar())
    budget=authoritative_budget if auth_exists else (explicit_budget if explicit_budget>0 else boq_budget)
    commitments=D(db.query(func.coalesce(func.sum(ConstructionCommitment.committed_amount-ConstructionCommitment.released_amount),0)).filter(
        ConstructionCommitment.company_id==company_id,ConstructionCommitment.project_id==project_id,
        ConstructionCommitment.status=='open').scalar())
    # Existing subcontractor BOQ is treated as a commitment source even if no manual commitment row exists.
    sub_boq=D(db.query(func.coalesce(func.sum(SubcontractorBOQLine.contract_qty*SubcontractorBOQLine.contract_rate),0)).filter(
        SubcontractorBOQLine.company_id==company_id,SubcontractorBOQLine.project_id==project_id).scalar())
    commitments=max(commitments,sub_boq)
    actual=_sum_project_actuals(db,company_id,project_id)
    manual_etc=D(db.query(func.coalesce(func.sum(ConstructionCostForecast.etc_amount),0)).filter(
        ConstructionCostForecast.company_id==company_id,ConstructionCostForecast.project_id==project_id,
        ConstructionCostForecast.status=='active').scalar())
    etc=manual_etc if manual_etc>0 else max(budget-actual,Decimal('0'))
    eac=actual+etc
    variance=budget-eac
    committed_remaining=max(commitments-actual,Decimal('0'))
    return {'project_id':project_id,'budget':q(budget),'explicit_budget':q(explicit_budget),
            'boq_budget':q(boq_budget),'commitment':q(commitments),'actual':q(actual),
            'forecast_etc':q(etc),'eac':q(eac),'variance_at_completion':q(variance),
            'committed_remaining':q(committed_remaining),
            'forecast_margin_cost':q(eac)}


def calculate_enterprise_cost_control(db, company_id, project_id, status_date=None, method='manual_etc'):
    """Authoritative cost-control calculation with explicit EAC method and CPI governance."""
    if not _project_exists(db, company_id, project_id): raise ValueError('Project not found')
    status_date = status_date or date.today()
    base = construction_cost_control(db, company_id, project_id)
    budget, committed, actual, manual_etc = map(D, (base['budget'], base['commitment'], base['actual'], base['forecast_etc']))
    evm = db.query(ConstructionEVMSnapshot).filter_by(company_id=company_id, project_id=project_id).filter(ConstructionEVMSnapshot.status_date <= status_date).order_by(ConstructionEVMSnapshot.status_date.desc()).first()
    cpi = D(evm.cpi) if evm and evm.cpi is not None and D(evm.cpi) > 0 else None
    if method not in {'manual_etc','cpi','remaining_budget'}: raise ValueError('Invalid EAC method')
    if method == 'cpi':
        if cpi is None: raise ValueError('Positive CPI is required for CPI-based EAC')
        eac = budget / cpi; etc = max(eac - actual, Decimal('0'))
    elif method == 'remaining_budget':
        etc = max(budget - actual, Decimal('0')); eac = actual + etc
    else:
        etc = manual_etc; eac = actual + etc
    variance = budget - eac
    return {'project_id':project_id,'status_date':status_date,'budget':q(budget),'committed':q(committed),'actual':q(actual),'etc':q(etc),'eac':q(eac),'variance':q(variance),'cpi':(q(cpi) if cpi is not None else None),'eac_method':method,'status':'over_budget' if variance < 0 else ('at_risk' if budget and variance < budget*Decimal('0.05') else 'on_track')}

def create_cost_control_snapshot(db, company_id, project_id, status_date, user_id=None, method='manual_etc'):
    calc=calculate_enterprise_cost_control(db,company_id,project_id,status_date,method)
    existing=db.query(ConstructionCostControlSnapshot, ConstructionCostBudgetRevision, ConstructionCostBudgetRevisionLine, ConstructionTimePhasedCost, ConstructionCostForecastVersion, ConstructionCostForecastVersionLine, ConstructionCostVariance).filter_by(company_id=company_id,project_id=project_id,status_date=status_date).first()
    if existing: raise ValueError('Cost-control snapshot already exists for this status date')
    row=ConstructionCostControlSnapshot(company_id=company_id,project_id=project_id,status_date=status_date,
        budget=calc['budget'],committed=calc['committed'],actual=calc['actual'],etc=calc['etc'],eac=calc['eac'],
        variance=calc['variance'],cpi=calc['cpi'],eac_method=method,status='draft',created_by_id=user_id)
    db.add(row); db.flush(); return row

def approve_cost_control_snapshot(db, company_id, snapshot_id, user_id):
    row=db.query(ConstructionCostControlSnapshot, ConstructionCostBudgetRevision, ConstructionCostBudgetRevisionLine, ConstructionTimePhasedCost, ConstructionCostForecastVersion, ConstructionCostForecastVersionLine, ConstructionCostVariance).filter_by(id=snapshot_id,company_id=company_id).with_for_update().first()
    if not row: raise ValueError('Cost-control snapshot not found')
    if row.status != 'draft': raise ValueError('Only draft snapshot can be approved')
    row.status='approved'; row.approved_by_id=user_id; row.approved_at=utcnow(); db.flush(); return row


def _next_project_revision(db, company_id, project_id, model):
    last=db.query(func.max(model.revision_no)).filter_by(company_id=company_id,project_id=project_id).scalar()
    return int(last or 0)+1

def _next_forecast_version(db, company_id, project_id):
    last=db.query(func.max(ConstructionCostForecastVersion.version_no)).filter_by(company_id=company_id,project_id=project_id).scalar()
    return int(last or 0)+1

def create_cost_budget_revision(db, company_id, project_id, revision_date, reason, user_id, lines):
    if not _project_exists(db,company_id,project_id): raise ValueError('Project not found')
    if not reason or not reason.strip(): raise ValueError('Revision reason is required')
    no=_next_project_revision(db,company_id,project_id,ConstructionCostBudgetRevision)
    r=ConstructionCostBudgetRevision(company_id=company_id,project_id=project_id,revision_no=no,revision_date=revision_date,reason=reason.strip(),created_by_id=user_id)
    db.add(r); db.flush()
    for x in lines:
        delta=D(x['delta_amount'])
        if delta==0: raise ValueError('Budget revision delta cannot be zero')
        if x.get('cost_code_id') and not db.query(ConstructionCostCode).filter_by(id=x['cost_code_id'],company_id=company_id).first(): raise ValueError('Invalid cost code')
        if x.get('wbs_id') and not db.query(WBSNode).filter_by(id=x['wbs_id'],company_id=company_id,project_id=project_id,is_active=True).first(): raise ValueError('Invalid WBS')
        db.add(ConstructionCostBudgetRevisionLine(company_id=company_id,revision_id=r.id,cost_code_id=x.get('cost_code_id'),wbs_id=x.get('wbs_id'),period_date=x['period_date'],delta_amount=q(delta)))
    db.flush(); return r

def approve_cost_budget_revision(db, company_id, revision_id, user_id):
    r=db.query(ConstructionCostBudgetRevision).filter_by(id=revision_id,company_id=company_id).with_for_update().first()
    if not r: raise ValueError('Budget revision not found')
    if r.status!='draft': raise ValueError('Only draft revisions can be approved')
    if not db.query(ConstructionCostBudgetRevisionLine).filter_by(company_id=company_id,revision_id=r.id).first(): raise ValueError('Revision must contain at least one line')
    r.status='approved'; r.approved_by_id=user_id; r.approved_at=utcnow(); db.flush(); return r

def build_time_phased_cost(db, company_id, project_id, period_date, cost_code_id=None, wbs_id=None, budget_amount=0, commitment_amount=0, actual_amount=0):
    if not _project_exists(db,company_id,project_id): raise ValueError('Project not found')
    vals=[D(budget_amount),D(commitment_amount),D(actual_amount)]
    if any(v<0 for v in vals): raise ValueError('Time-phased cost values cannot be negative')
    row=db.query(ConstructionTimePhasedCost).filter_by(company_id=company_id,project_id=project_id,cost_code_id=cost_code_id,wbs_id=wbs_id,period_date=period_date).with_for_update().first()
    if row:
        row.budget_amount=q(vals[0]); row.commitment_amount=q(vals[1]); row.actual_amount=q(vals[2])
    else:
        row=ConstructionTimePhasedCost(company_id=company_id,project_id=project_id,cost_code_id=cost_code_id,wbs_id=wbs_id,period_date=period_date,budget_amount=q(vals[0]),commitment_amount=q(vals[1]),actual_amount=q(vals[2])); db.add(row); db.flush()
    return row

def create_cost_forecast_version(db, company_id, project_id, status_date, user_id, method='manual', lines=None):
    if not _project_exists(db,company_id,project_id): raise ValueError('Project not found')
    if method not in {'manual','remaining_budget','cpi','cpi_spi'}: raise ValueError('Invalid forecast method')
    lines=lines or []
    if not lines: raise ValueError('Forecast version requires lines')
    no=_next_forecast_version(db,company_id,project_id)
    total_etc=Decimal('0'); total_eac=Decimal('0')
    for x in lines:
        etc=D(x['etc_amount']); eac=D(x['eac_amount'])
        if etc<0 or eac<0 or eac<etc: raise ValueError('Invalid ETC/EAC values')
        total_etc+=etc; total_eac+=eac
    v=ConstructionCostForecastVersion(company_id=company_id,project_id=project_id,version_no=no,status_date=status_date,method=method,status='draft',total_etc=q(total_etc),total_eac=q(total_eac),created_by_id=user_id)
    db.add(v); db.flush()
    for x in lines:
        db.add(ConstructionCostForecastVersionLine(company_id=company_id,version_id=v.id,cost_code_id=x.get('cost_code_id'),wbs_id=x.get('wbs_id'),etc_amount=q(x['etc_amount']),eac_amount=q(x['eac_amount'])))
    db.flush(); return v

def approve_cost_forecast_version(db, company_id, version_id, user_id):
    v=db.query(ConstructionCostForecastVersion).filter_by(id=version_id,company_id=company_id).with_for_update().first()
    if not v: raise ValueError('Forecast version not found')
    if v.status!='draft': raise ValueError('Only draft forecast versions can be approved')
    if not db.query(ConstructionCostForecastVersionLine).filter_by(company_id=company_id,version_id=v.id).first(): raise ValueError('Forecast version must contain lines')
    v.status='approved'; v.approved_by_id=user_id; v.approved_at=utcnow(); db.flush(); return v

def calculate_cost_variance(db, company_id, project_id, status_date):
    if not _project_exists(db,company_id,project_id): raise ValueError('Project not found')
    snap=db.query(ConstructionCostControlSnapshot).filter_by(company_id=company_id,project_id=project_id,status_date=status_date).first()
    if snap:
        budget,committed,actual,etc,eac=map(D,(snap.budget,snap.committed,snap.actual,snap.etc,snap.eac))
    else:
        base=construction_cost_control(db,company_id,project_id); budget,committed,actual,etc=map(D,(base['budget'],base['commitment'],base['actual'],base['forecast_etc'])); eac=actual+etc
    variance=budget-eac; pct=(variance/budget*Decimal('100')) if budget else Decimal('0')
    status='critical' if budget>0 and variance<0 else ('watch' if budget>0 and pct<Decimal('5') else ('unbudgeted' if budget<=0 and eac>0 else 'on_track'))
    row=db.query(ConstructionCostVariance).filter_by(company_id=company_id,project_id=project_id,status_date=status_date).first()
    data=dict(budget=q(budget),committed=q(committed),actual=q(actual),etc=q(etc),eac=q(eac),variance=q(variance),variance_pct=qr(pct),status=status)
    if row:
        for k,v in data.items(): setattr(row,k,v)
    else:
        row=ConstructionCostVariance(company_id=company_id,project_id=project_id,status_date=status_date,**data); db.add(row); db.flush()
    return row

def construction_cost_control_health(db, company_id, project_id):
    """Return auditable cost-control exposure/alerts without mutating accounting balances."""
    c=construction_cost_control(db,company_id,project_id)
    budget=D(c['budget']); actual=D(c['actual']); commitment=D(c['commitment']); etc=D(c['forecast_etc'])
    committed_remaining=max(commitment-actual,Decimal('0'))
    exposure=actual+committed_remaining+etc
    variance=budget-exposure
    utilization=(actual/budget*Decimal('100')) if budget else Decimal('0')
    alerts=[]
    if budget<=0 and exposure>0: alerts.append('UNBUDGETED_EXPOSURE')
    if budget>0 and exposure>budget: alerts.append('EAC_EXPOSURE_OVER_BUDGET')
    if budget>0 and utilization>=Decimal('90'): alerts.append('HIGH_ACTUAL_UTILIZATION')
    if budget>0 and commitment>budget: alerts.append('COMMITMENT_OVER_BUDGET')
    return {'budget':q(budget),'actual':q(actual),'commitment':q(commitment),'committed_remaining':q(committed_remaining),
            'etc':q(etc),'exposure':q(exposure),'variance':q(variance),'utilization_pct':q(utilization),
            'status':'critical' if alerts and ('EAC_EXPOSURE_OVER_BUDGET' in alerts or 'COMMITMENT_OVER_BUDGET' in alerts)
                     else ('watch' if alerts else 'on_track'),'alerts':alerts}

def project_cost_control_dashboard(db, company_id, project_id):
    """Enterprise project cost-control summary: budget, commitments, actuals, ETC/EAC and margin."""
    project = _project_exists(db, company_id, project_id)
    if not project:
        raise ValueError('Project not found')
    budget = D(db.query(func.coalesce(func.sum(ConstructionCostBudgetLine.budget_amount), 0)).filter(
        ConstructionCostBudgetLine.company_id==company_id,
        ConstructionCostBudgetLine.project_id==project_id,
        ConstructionCostBudgetLine.status=='active').scalar())
    boq_budget = D(db.query(func.coalesce(func.sum(BOQLine.contract_qty*BOQLine.contract_rate), 0)).filter(
        BOQLine.company_id==company_id, BOQLine.project_id==project_id).scalar())
    if budget <= 0:
        budget = boq_budget
    commitment = D(db.query(func.coalesce(func.sum(ConstructionCommitment.committed_amount-ConstructionCommitment.released_amount), 0)).filter(
        ConstructionCommitment.company_id==company_id, ConstructionCommitment.project_id==project_id,
        ConstructionCommitment.status=='open').scalar())
    sub_commitment = D(db.query(func.coalesce(func.sum(SubcontractorBOQLine.contract_qty*SubcontractorBOQLine.contract_rate), 0)).filter(
        SubcontractorBOQLine.company_id==company_id, SubcontractorBOQLine.project_id==project_id).scalar())
    commitment = max(commitment, sub_commitment)

    actual_rows = db.query(ProjectCost.cost_type, func.coalesce(func.sum(ProjectCost.amount),0)).filter(
        ProjectCost.company_id==company_id, ProjectCost.project_id==project_id).group_by(ProjectCost.cost_type).all()
    actual_by_type = {str(k or 'other'): D(v) for k,v in actual_rows}
    categories = {
        'materials': sum((v for k,v in actual_by_type.items() if k in {'material','materials','site_material','inventory','material_consumption'}), D(0)),
        'labor': sum((v for k,v in actual_by_type.items() if 'labor' in k or 'payroll' in k), D(0)),
        'equipment': sum((v for k,v in actual_by_type.items() if 'equipment' in k), D(0)),
        'subcontractors': sum((v for k,v in actual_by_type.items() if 'subcontract' in k), D(0)),
        'overhead': sum((v for k,v in actual_by_type.items() if 'overhead' in k or 'indirect' in k), D(0)),
    }
    known=sum(categories.values(), D(0))
    total_actual=sum(actual_by_type.values(), D(0))
    categories['other'] = max(total_actual-known, D(0))

    etc_manual=D(db.query(func.coalesce(func.sum(ConstructionCostForecast.etc_amount),0)).filter(
        ConstructionCostForecast.company_id==company_id, ConstructionCostForecast.project_id==project_id,
        ConstructionCostForecast.status=='active').scalar())
    remaining_budget=max(budget-total_actual, D(0))
    etc=etc_manual if etc_manual>0 else remaining_budget
    eac=total_actual+etc
    variance=budget-eac
    committed_remaining=max(commitment-total_actual, D(0))
    revenue=D(db.query(func.coalesce(func.sum(ProgressCertificate.gross_amount),0)).filter(
        ProgressCertificate.company_id==company_id, ProgressCertificate.project_id==project_id,
        ProgressCertificate.status=='posted').scalar())
    forecast_profit=revenue-eac
    margin_pct=(forecast_profit/revenue*D(100)) if revenue else D(0)
    budget_util=(total_actual/budget*D(100)) if budget else D(0)
    commitment_util=(commitment/budget*D(100)) if budget else D(0)
    return {
        'project_id':project_id,'budget':q(budget),'boq_budget':q(boq_budget),'commitment':q(commitment),
        'actual':q(total_actual),'etc':q(etc),'eac':q(eac),'variance':q(variance),
        'committed_remaining':q(committed_remaining),'revenue':q(revenue),'forecast_profit':q(forecast_profit),
        'margin_pct':q(margin_pct),'budget_utilization_pct':q(budget_util),'commitment_pct':q(commitment_util),
        'categories':{k:q(v) for k,v in categories.items()},
        'status':'over_budget' if variance < 0 else ('at_risk' if variance < budget*D('0.05') else 'on_track')
    }

def subcontractor_control(db, company_id, project_id, contract_id):
    contract=db.query(Contract).filter_by(id=contract_id,company_id=company_id,project_id=project_id,contract_type='subcontractor').first()
    if not contract: raise ValueError('Subcontractor contract not found')
    boq=D(db.query(func.coalesce(func.sum(SubcontractorBOQLine.contract_qty*SubcontractorBOQLine.contract_rate),0)).filter(
        SubcontractorBOQLine.company_id==company_id,SubcontractorBOQLine.project_id==project_id,
        SubcontractorBOQLine.contract_id==contract_id).scalar())
    measured=D(db.query(func.coalesce(func.sum(SubcontractorMeasurementLine.amount),0)).join(
        SubcontractorMeasurement,SubcontractorMeasurement.id==SubcontractorMeasurementLine.measurement_id).filter(
        SubcontractorMeasurement.company_id==company_id,SubcontractorMeasurement.project_id==project_id,
        SubcontractorMeasurement.contract_id==contract_id,SubcontractorMeasurement.status.in_(['approved','certified'])).scalar())
    certified=D(db.query(func.coalesce(func.sum(SubcontractorProgress.gross_amount),0)).filter(
        SubcontractorProgress.company_id==company_id,SubcontractorProgress.project_id==project_id,
        SubcontractorProgress.contract_id==contract_id,SubcontractorProgress.status=='posted').scalar())
    retention=D(db.query(func.coalesce(func.sum(SubcontractorProgress.retention_amount),0)).filter(
        SubcontractorProgress.company_id==company_id,SubcontractorProgress.project_id==project_id,
        SubcontractorProgress.contract_id==contract_id,SubcontractorProgress.status=='posted').scalar())
    advances=D(db.query(func.coalesce(func.sum(ConstructionAdvance.amount-ConstructionAdvance.recovered_amount),0)).filter(
        ConstructionAdvance.company_id==company_id,ConstructionAdvance.project_id==project_id,
        ConstructionAdvance.contract_id==contract_id,ConstructionAdvance.direction=='payable',
        ConstructionAdvance.status=='open').scalar())
    deductions=D(db.query(func.coalesce(func.sum(SubcontractorProgress.deductions),0)).filter(
        SubcontractorProgress.company_id==company_id,SubcontractorProgress.project_id==project_id,
        SubcontractorProgress.contract_id==contract_id,SubcontractorProgress.status=='posted').scalar())
    return {'project_id':project_id,'contract_id':contract_id,'boq_commitment':q(boq),'measured':q(measured),
            'certified_gross':q(certified),'retention_payable':q(retention),
            'advance_balance':q(advances),'deductions':q(deductions),
            'remaining_contract':q(max(boq-certified,Decimal('0')))}

def project_profitability(db, company_id, project_id):
    """Authoritative cumulative project profitability and forecast margin.

    Revenue is recognized only from posted progress certificates. Cost is the
    construction cost-control actual/EAC chain, using the authoritative budget
    when materialized. This keeps the project report aligned with budget,
    commitments, actuals and forecast rather than contract value alone.
    """
    p=_project_exists(db,company_id,project_id)
    if not p: raise ValueError('Project not found')
    revenue=D(db.query(func.coalesce(func.sum(ProgressCertificate.gross_amount),0)).filter(
        ProgressCertificate.company_id==company_id,ProgressCertificate.project_id==project_id,
        ProgressCertificate.status=='posted').scalar())
    cost=construction_cost_control(db,company_id,project_id)
    actual=D(cost['actual']); eac=D(cost['eac'])
    actual_profit=revenue-actual
    forecast_profit=revenue-eac
    actual_pct=(actual_profit/revenue*Decimal('100')) if revenue else Decimal('0')
    forecast_pct=(forecast_profit/revenue*Decimal('100')) if revenue else Decimal('0')
    return {'project_id':project_id,'certified_revenue':q(revenue),'budget':cost['budget'],
            'commitment':cost['commitment'],'actual':cost['actual'],'forecast_etc':cost['forecast_etc'],
            'eac':cost['eac'],'variance_at_completion':cost['variance_at_completion'],
            'actual_profit':q(actual_profit),'actual_margin_pct':q(actual_pct),
            'forecast_profit':q(forecast_profit),'forecast_margin_pct':q(forecast_pct)}

def construction_cash_flow_63(db, company_id, project_id):
    base=construction_cash_flow(db,company_id,project_id)
    retention_receivable=D(db.query(func.coalesce(func.sum(ProgressCertificate.retention_amount),0)).filter(
        ProgressCertificate.company_id==company_id,ProgressCertificate.project_id==project_id,
        ProgressCertificate.status=='posted').scalar())
    retention_payable=D(db.query(func.coalesce(func.sum(SubcontractorProgress.retention_amount),0)).filter(
        SubcontractorProgress.company_id==company_id,SubcontractorProgress.project_id==project_id,
        SubcontractorProgress.status=='posted').scalar())
    customer_advances=D(db.query(func.coalesce(func.sum(ConstructionAdvance.amount-ConstructionAdvance.recovered_amount),0)).filter(
        ConstructionAdvance.company_id==company_id,ConstructionAdvance.project_id==project_id,
        ConstructionAdvance.direction=='received',ConstructionAdvance.status=='open').scalar())
    sub_advances=D(db.query(func.coalesce(func.sum(ConstructionAdvance.amount-ConstructionAdvance.recovered_amount),0)).filter(
        ConstructionAdvance.company_id==company_id,ConstructionAdvance.project_id==project_id,
        ConstructionAdvance.direction=='payable',ConstructionAdvance.status=='open').scalar())
    return {**base,'customer_retention_receivable':q(retention_receivable),
            'subcontractor_retention_payable':q(retention_payable),
            'customer_advance_balance':q(customer_advances),
            'subcontractor_advance_balance':q(sub_advances),
            'cash_commitment_exposure':q(max(D(base['subcontractor_outflow'])+sub_advances,Decimal('0')))}

_old_approve_subcontractor_progress = approve_subcontractor_progress
def approve_subcontractor_progress(db, company_id, progress_id, user_id):
    row=_old_approve_subcontractor_progress(db,company_id,progress_id,user_id)
    # Recognized construction actual = gross certificate value less commercial deductions.
    actual_amount=q(D(row.gross_amount)-D(row.deductions))
    if actual_amount:
        existing=db.query(ProjectCost).filter_by(company_id=company_id,project_id=row.project_id,
            source_type='subcontractor_progress',source_id=row.id).first()
        if not existing:
            db.add(ProjectCost(company_id=company_id,project_id=row.project_id,cost_type='subcontract',
                source_type='subcontractor_progress',source_id=row.id,amount=actual_amount,
                cost_date=utcnow(),description=f'Subcontractor certificate {row.certificate_no}'))
    db.flush(); return row

# Phase 6.4 — Planning / EVM / Advanced Forecasting
from datetime import timedelta

def _activity(db, company_id, project_id, activity_id):
    r=db.query(ConstructionActivity).filter_by(id=activity_id, company_id=company_id, project_id=project_id).one_or_none()
    if not r: raise ValueError('Activity not found')
    return r

def create_schedule_calendar(db, company_id, project_id, name, workdays_mask='1111100', holidays=None, is_default=False):
    if not company_project(db, company_id, project_id): raise ValueError('Project not found')
    if len(workdays_mask) != 7 or any(c not in '01' for c in workdays_mask) or '1' not in workdays_mask: raise ValueError('Invalid workdays mask')
    if db.query(ConstructionScheduleCalendar).filter_by(project_id=project_id, name=name.strip()).first(): raise ValueError('Calendar name already exists')
    holiday_values=sorted({str(x) for x in (holidays or [])})
    if is_default:
        db.query(ConstructionScheduleCalendar).filter_by(company_id=company_id,project_id=project_id,is_default=True).update({'is_default':False}, synchronize_session=False)
    r=ConstructionScheduleCalendar(company_id=company_id,project_id=project_id,name=name.strip(),workdays_mask=workdays_mask,holidays=','.join(holiday_values),is_default=is_default)
    db.add(r); db.flush(); return r

def _calendar_days(cal, start, finish):
    if finish < start: return 0
    holidays=set((cal.holidays or '').split(',')) if cal else set()
    mask=cal.workdays_mask if cal else '1111100'
    cur=start; count=0
    while cur <= finish:
        if mask[cur.weekday()] == '1' and cur.isoformat() not in holidays: count += 1
        cur += timedelta(days=1)
    return count

def create_activity_dependency(db, company_id, project_id, predecessor_id, successor_id, dependency_type='FS', lag_days=0):
    if dependency_type not in {'FS','SS','FF','SF'}: raise ValueError('Invalid dependency type')
    a=_activity(db,company_id,project_id,predecessor_id); b=_activity(db,company_id,project_id,successor_id)
    if a.id == b.id: raise ValueError('Activity cannot depend on itself')
    if db.query(ConstructionActivityDependency).filter_by(project_id=project_id,predecessor_id=a.id,successor_id=b.id).first(): raise ValueError('Dependency already exists')
    # Prevent an immediate cycle and reject any dependency that closes a reachable path.
    frontier=[b.id]; seen=set()
    while frontier:
        cur=frontier.pop()
        if cur in seen: continue
        seen.add(cur)
        if cur == a.id: raise ValueError('Dependency would create a cycle')
        frontier.extend(x.successor_id for x in db.query(ConstructionActivityDependency).filter_by(project_id=project_id,predecessor_id=cur).all())
    r=ConstructionActivityDependency(company_id=company_id,project_id=project_id,predecessor_id=a.id,successor_id=b.id,dependency_type=dependency_type,lag_days=int(lag_days))
    db.add(r); db.flush(); return r

def calculate_schedule(db, company_id, project_id, calendar_id=None):
    activities=db.query(ConstructionActivity).filter_by(company_id=company_id,project_id=project_id).all()
    by_id={a.id:a for a in activities}
    if not activities: return {}
    cal=db.query(ConstructionScheduleCalendar).filter_by(id=calendar_id,company_id=company_id,project_id=project_id).one_or_none() if calendar_id else db.query(ConstructionScheduleCalendar).filter_by(company_id=company_id,project_id=project_id,is_default=True).one_or_none()
    deps=db.query(ConstructionActivityDependency).filter_by(company_id=company_id,project_id=project_id).all()
    incoming={a.id:[] for a in activities}
    for d in deps:
        if d.predecessor_id in by_id and d.successor_id in by_id: incoming[d.successor_id].append(d)
    indeg={k:len(v) for k,v in incoming.items()}; queue=[k for k,v in indeg.items() if v==0]; order=[]
    while queue:
        n=queue.pop(0); order.append(n)
        for d in deps:
            if d.predecessor_id==n:
                indeg[d.successor_id]-=1
                if indeg[d.successor_id]==0: queue.append(d.successor_id)
    if len(order)!=len(activities): raise ValueError('Schedule contains a dependency cycle')
    es={}; ef={}
    for aid in order:
        a=by_id[aid]; start=a.planned_start
        for d in incoming[aid]:
            p=by_id[d.predecessor_id]; lag=timedelta(days=d.lag_days)
            succ_dur=max(_calendar_days(cal,a.planned_start,a.planned_finish),1)
            if d.dependency_type=='FS': candidate=ef[p]+lag+timedelta(days=1)
            elif d.dependency_type=='SS': candidate=es[p]+lag
            elif d.dependency_type=='FF': candidate=ef[p]+lag-timedelta(days=succ_dur-1)
            else: candidate=es[p]+lag-timedelta(days=succ_dur-1)
            if candidate>start: start=candidate
        dur=max(_calendar_days(cal,a.planned_start,a.planned_finish),1)
        finish=start
        remaining=dur-1
        while remaining:
            finish += timedelta(days=1)
            if (cal.workdays_mask[finish.weekday()] if cal else '1111100'[finish.weekday()])=='1' and (not cal or finish.isoformat() not in set((cal.holidays or '').split(','))): remaining-=1
        es[aid]=start; ef[aid]=finish
    project_finish=max(ef.values()); lf={aid:project_finish for aid in by_id}; ls={}
    for aid in reversed(order):
        a=by_id[aid]; dur=max(_calendar_days(cal,a.planned_start,a.planned_finish),1); successors=[d for d in deps if d.predecessor_id==aid]
        if successors:
            lf[aid]=min((ls[d.successor_id]-timedelta(days=d.lag_days) for d in successors), default=project_finish)
        finish=lf[aid]; start=finish; remaining=dur-1
        while remaining:
            start -= timedelta(days=1)
            if (cal.workdays_mask[start.weekday()] if cal else '1111100'[start.weekday()])=='1' and (not cal or start.isoformat() not in set((cal.holidays or '').split(','))): remaining-=1
        ls[aid]=start
    return {aid:{'early_start':es[aid],'early_finish':ef[aid],'late_start':ls[aid],'late_finish':lf[aid],'total_float':(ls[aid]-es[aid]).days,'critical':(ls[aid]-es[aid]).days<=0} for aid in by_id}

def create_activity(db, company_id, project_id, code, name, planned_start, planned_finish, budget_amount, wbs_id=None, boq_line_id=None):
    p=_project_exists(db,company_id,project_id)
    if not p: raise ValueError('Project not found')
    if planned_finish < planned_start: raise ValueError('planned_finish cannot precede planned_start')
    if wbs_id and not db.query(WBSNode).filter_by(id=wbs_id,company_id=company_id,project_id=project_id).one_or_none(): raise ValueError('WBS not found')
    r=ConstructionActivity(company_id=company_id,project_id=project_id,wbs_id=wbs_id,boq_line_id=boq_line_id,code=code,name=name,planned_start=planned_start,planned_finish=planned_finish,budget_amount=budget_amount)
    db.add(r); db.flush(); return r

def create_schedule_baseline(db, company_id, project_id, baseline_no, baseline_date, activity_lines):
    p=_project_exists(db,company_id,project_id)
    if not p: raise ValueError('Project not found')
    b=ConstructionScheduleBaseline(company_id=company_id,project_id=project_id,baseline_no=baseline_no,baseline_date=baseline_date)
    db.add(b); db.flush()
    for x in activity_lines:
        a=_activity(db,company_id,project_id,x['activity_id'])
        if x['planned_finish'] < x['planned_start']: raise ValueError('Baseline finish cannot precede start')
        db.add(ConstructionActivityBaseline(company_id=company_id,baseline_id=b.id,activity_id=a.id,planned_start=x['planned_start'],planned_finish=x['planned_finish'],budget_amount=x.get('budget_amount',a.budget_amount)))
    db.flush(); return b

def create_progress_period(db, company_id, project_id, status_date, baseline_id=None):
    p=_project_exists(db,company_id,project_id)
    if not p: raise ValueError('Project not found')
    if baseline_id and not db.query(ConstructionScheduleBaseline).filter_by(id=baseline_id,company_id=company_id,project_id=project_id).one_or_none(): raise ValueError('Baseline not found')
    r=ConstructionProgressPeriod(company_id=company_id,project_id=project_id,status_date=status_date,baseline_id=baseline_id)
    db.add(r); db.flush(); return r

def set_activity_progress(db, company_id, project_id, period_id, activity_id, earned_percent, earned_value=None, notes=None):
    period=db.query(ConstructionProgressPeriod).filter_by(id=period_id,company_id=company_id,project_id=project_id).one_or_none()
    if not period: raise ValueError('Progress period not found')
    a=_activity(db,company_id,project_id,activity_id)
    earned_percent=Decimal(str(earned_percent))
    if earned_percent < 0 or earned_percent > 100: raise ValueError('Earned percent must be between 0 and 100')
    if period.status != 'open': raise ValueError('Progress period is not open')
    ev=Decimal(str(earned_value)) if earned_value is not None else q(Decimal(str(a.budget_amount))*Decimal(str(earned_percent))/Decimal('100'))
    if ev < 0 or ev > D(a.budget_amount): raise ValueError('Earned value must be between 0 and activity budget')
    r=db.query(ConstructionActivityProgress).filter_by(period_id=period_id,activity_id=activity_id).one_or_none()
    if r: r.earned_percent=earned_percent; r.earned_value=ev; r.notes=notes
    else: r=ConstructionActivityProgress(company_id=company_id,period_id=period_id,activity_id=activity_id,earned_percent=earned_percent,earned_value=ev,notes=notes); db.add(r)
    db.flush(); return r

def create_time_phased_budget(db, company_id, project_id, period_date, planned_value, baseline_id=None, activity_id=None):
    p=_project_exists(db,company_id,project_id)
    if not p: raise ValueError('Project not found')
    if baseline_id and not db.query(ConstructionScheduleBaseline).filter_by(id=baseline_id,company_id=company_id,project_id=project_id).one_or_none(): raise ValueError('Baseline not found')
    if activity_id: _activity(db,company_id,project_id,activity_id)
    r=db.query(ConstructionTimePhasedBudget).filter_by(company_id=company_id,project_id=project_id,baseline_id=baseline_id,activity_id=activity_id,period_date=period_date).one_or_none()
    if r: r.planned_value=q(planned_value)
    else:
        r=ConstructionTimePhasedBudget(company_id=company_id,project_id=project_id,baseline_id=baseline_id,activity_id=activity_id,period_date=period_date,planned_value=q(planned_value)); db.add(r)
    db.flush(); return r

def construction_evm(db, company_id, project_id, status_date, baseline_id=None, forecast_method='cpi'):
    p=_project_exists(db,company_id,project_id)
    if not p: raise ValueError('Project not found')
    if baseline_id is None:
        baseline_id=db.query(ConstructionScheduleBaseline.id).filter_by(company_id=company_id,project_id=project_id,status='approved').order_by(ConstructionScheduleBaseline.baseline_no.desc()).scalar()
    if baseline_id is None:
        baseline_id=db.query(ConstructionScheduleBaseline.id).filter_by(company_id=company_id,project_id=project_id).order_by(ConstructionScheduleBaseline.baseline_no.desc()).scalar()
    if baseline_id:
        bac=D(db.query(func.coalesce(func.sum(ConstructionActivityBaseline.budget_amount),0)).filter_by(company_id=company_id,baseline_id=baseline_id).scalar())
    else:
        bac=D(db.query(func.coalesce(func.sum(ConstructionCostBudgetLine.budget_amount),0)).filter_by(company_id=company_id,project_id=project_id,status='active').scalar())
        if not bac: bac=D(p.budget or 0)
    pv=D(db.query(func.coalesce(func.sum(ConstructionTimePhasedBudget.planned_value),0)).filter(ConstructionTimePhasedBudget.company_id==company_id,ConstructionTimePhasedBudget.project_id==project_id,ConstructionTimePhasedBudget.period_date<=status_date, *(([ConstructionTimePhasedBudget.baseline_id==baseline_id] if baseline_id else []))).scalar())
    latest_period=db.query(ConstructionProgressPeriod).filter(ConstructionProgressPeriod.company_id==company_id,ConstructionProgressPeriod.project_id==project_id,ConstructionProgressPeriod.status_date<=status_date).order_by(ConstructionProgressPeriod.status_date.desc()).first()
    ev=D(db.query(func.coalesce(func.sum(ConstructionActivityProgress.earned_value),0)).filter(ConstructionActivityProgress.company_id==company_id,ConstructionActivityProgress.period_id==latest_period.id).scalar()) if latest_period else Decimal('0')
    ac=D(db.query(func.coalesce(func.sum(ProjectCost.amount),0)).filter(ProjectCost.company_id==company_id,ProjectCost.project_id==project_id).scalar())
    cpi=(ev/ac) if ac else Decimal('0'); spi=(ev/pv) if pv else Decimal('0'); cv=ev-ac; sv=ev-pv
    if forecast_method=='cpi': eac=(bac/cpi) if cpi else ac
    elif forecast_method in ('cpi_spi','cpi×spi'): eac=(ac+(bac-ev)/(cpi*spi)) if cpi and spi else ac
    elif forecast_method=='manual': eac=ac+D(db.query(func.coalesce(func.sum(ConstructionCostForecast.etc_amount),0)).filter_by(company_id=company_id,project_id=project_id,status='active').scalar())
    else: raise ValueError('Unsupported forecast method')
    etc=max(eac-ac,Decimal('0')); vac=bac-eac
    tcpi_bac=((bac-ev)/(bac-ac)) if (bac-ac) else Decimal('0'); tcpi_eac=((bac-ev)/(eac-ac)) if (eac-ac) else Decimal('0')
    return {'project_id':project_id,'status_date':status_date,'baseline_id':baseline_id,'pv':q(pv),'ev':q(ev),'ac':q(ac),'bac':q(bac),'cpi':qr(cpi),'spi':qr(spi),'cv':q(cv),'sv':q(sv),'eac':q(eac),'etc':q(etc),'vac':q(vac),'tcpi_bac':qr(tcpi_bac),'tcpi_eac':qr(tcpi_eac),'forecast_method':forecast_method}


def create_evm_cost_allocation(db, company_id, project_id, project_cost_id, allocated_amount, wbs_id=None, boq_line_id=None, cost_code_id=None):
    pc=db.query(ProjectCost).filter_by(id=project_cost_id, company_id=company_id, project_id=project_id).one_or_none()
    if not pc: raise ValueError('Project cost not found')
    amount=q(allocated_amount)
    if amount <= 0: raise ValueError('Allocated amount must be positive')
    if wbs_id and not db.query(WBSNode).filter_by(id=wbs_id, company_id=company_id, project_id=project_id).one_or_none(): raise ValueError('WBS not found')
    if boq_line_id and not db.query(BOQLine).filter_by(id=boq_line_id, company_id=company_id, project_id=project_id).one_or_none(): raise ValueError('BOQ line not found')
    if cost_code_id and not db.query(ConstructionCostCode).filter_by(id=cost_code_id, company_id=company_id).one_or_none(): raise ValueError('Cost code not found')
    used=D(db.query(func.coalesce(func.sum(ConstructionEVMCostAllocation.allocated_amount),0)).filter_by(project_cost_id=project_cost_id,company_id=company_id).scalar())
    if used + amount > D(pc.amount): raise ValueError('Allocated amount exceeds ProjectCost amount')
    r=ConstructionEVMCostAllocation(company_id=company_id,project_id=project_id,project_cost_id=project_cost_id,wbs_id=wbs_id,boq_line_id=boq_line_id,cost_code_id=cost_code_id,allocated_amount=amount)
    db.add(r); db.flush(); return r

def _rollup_metrics(rows):
    out=[]
    for key, vals in rows.items():
        pv,ev,ac,bac=map(D,(vals.get('pv'),vals.get('ev'),vals.get('ac'),vals.get('bac')))
        cpi=(ev/ac) if ac else Decimal('0'); spi=(ev/pv) if pv else Decimal('0')
        out.append({'key':key,'pv':q(pv),'ev':q(ev),'ac':q(ac),'bac':q(bac),'cpi':qr(cpi),'spi':qr(spi),'cv':q(ev-ac),'sv':q(ev-pv)})
    return out

def construction_performance_dashboard(db, company_id, project_id, status_date, baseline_id=None):
    evm=construction_evm(db,company_id,project_id,status_date,baseline_id,'cpi')
    bid=evm['baseline_id']
    # Activity-level values are authoritative for EV/BAC; time-phased budget supplies PV.
    activities=db.query(ConstructionActivity, ConstructionActivityBaseline).join(ConstructionActivityBaseline, ConstructionActivityBaseline.activity_id==ConstructionActivity.id).filter(
        ConstructionActivity.company_id==company_id, ConstructionActivity.project_id==project_id, ConstructionActivityBaseline.baseline_id==bid).all() if bid else []
    latest=db.query(ConstructionProgressPeriod).filter(ConstructionProgressPeriod.company_id==company_id,ConstructionProgressPeriod.project_id==project_id,ConstructionProgressPeriod.status_date<=status_date).order_by(ConstructionProgressPeriod.status_date.desc()).first()
    progress={r.activity_id:D(r.earned_value) for r in db.query(ConstructionActivityProgress).filter(ConstructionActivityProgress.company_id==company_id,ConstructionActivityProgress.period_id==latest.id).all()} if latest else {}
    pv_by_activity={r.activity_id:D(r.planned_value) for r in db.query(ConstructionTimePhasedBudget).filter(ConstructionTimePhasedBudget.company_id==company_id,ConstructionTimePhasedBudget.project_id==project_id,ConstructionTimePhasedBudget.period_date<=status_date,ConstructionTimePhasedBudget.baseline_id==bid,ConstructionTimePhasedBudget.activity_id.isnot(None)).all()} if bid else {}
    rows=[]
    for a,b in activities:
        rows.append({'activity_id':a.id,'code':a.code,'name':a.name,'wbs_id':a.wbs_id,'boq_line_id':a.boq_line_id,'pv':q(pv_by_activity.get(a.id,0)),'ev':q(progress.get(a.id,0)),'bac':q(b.budget_amount)})
    # AC is allocated explicitly when mappings exist; unallocated AC remains visible at project level.
    allocations=db.query(ConstructionEVMCostAllocation).filter_by(company_id=company_id,project_id=project_id).all()
    ac_by_wbs={} ; ac_by_boq={} ; ac_by_cc={}
    for x in allocations:
        if x.wbs_id: ac_by_wbs[x.wbs_id]=ac_by_wbs.get(x.wbs_id,Decimal('0'))+D(x.allocated_amount)
        if x.boq_line_id: ac_by_boq[x.boq_line_id]=ac_by_boq.get(x.boq_line_id,Decimal('0'))+D(x.allocated_amount)
        if x.cost_code_id: ac_by_cc[x.cost_code_id]=ac_by_cc.get(x.cost_code_id,Decimal('0'))+D(x.allocated_amount)
    wbs_nodes=db.query(WBSNode).filter_by(company_id=company_id,project_id=project_id).order_by(WBSNode.level,WBSNode.code).all()
    wbs=[]
    for n in wbs_nodes:
        subset=[r for r in rows if r['wbs_id']==n.id]
        pv=sum((r['pv'] for r in subset),Decimal('0')); ev=sum((r['ev'] for r in subset),Decimal('0')); bac=sum((r['bac'] for r in subset),Decimal('0')); ac=ac_by_wbs.get(n.id,Decimal('0'))
        wbs.append({'id':n.id,'code':n.code,'name':n.name,'level':n.level,'parent_id':n.parent_id,'pv':q(pv),'ev':q(ev),'ac':q(ac),'bac':q(bac),'cpi':qr(ev/ac) if ac else Decimal('0'),'spi':qr(ev/pv) if pv else Decimal('0'),'cv':q(ev-ac),'sv':q(ev-pv)})
    boq_ids={r['boq_line_id'] for r in rows if r['boq_line_id']}
    boq=[]
    if boq_ids:
        for b in db.query(BOQLine).filter(BOQLine.id.in_(boq_ids),BOQLine.company_id==company_id).order_by(BOQLine.item_code).all():
            subset=[r for r in rows if r['boq_line_id']==b.id]; pv=sum((r['pv'] for r in subset),Decimal('0')); ev=sum((r['ev'] for r in subset),Decimal('0')); bac=sum((r['bac'] for r in subset),Decimal('0')); ac=ac_by_boq.get(b.id,Decimal('0'))
            boq.append({'id':b.id,'item_code':b.item_code,'description':b.description,'unit':b.unit,'contract_qty':q(b.contract_qty),'contract_rate':q(b.contract_rate),'pv':q(pv),'ev':q(ev),'ac':q(ac),'bac':q(bac),'cpi':qr(ev/ac) if ac else Decimal('0'),'spi':qr(ev/pv) if pv else Decimal('0'),'cv':q(ev-ac),'sv':q(ev-pv)})
    ccs=[]
    for cc in db.query(ConstructionCostCode).filter_by(company_id=company_id).order_by(ConstructionCostCode.code).all():
        ac=ac_by_cc.get(cc.id,Decimal('0')); subset=[r for r in rows if r['boq_line_id'] and db.query(BOQLine.cost_code_id).filter(BOQLine.id==r['boq_line_id']).scalar()==cc.id]
        ev=sum((r['ev'] for r in subset),Decimal('0')); pv=sum((r['pv'] for r in subset),Decimal('0')); bac=sum((r['bac'] for r in subset),Decimal('0'))
        if any((ac,pv,ev,bac)):
            ccs.append({'id':cc.id,'code':cc.code,'name':cc.name,'category':cc.category,'pv':q(pv),'ev':q(ev),'ac':q(ac),'bac':q(bac),'cpi':qr(ev/ac) if ac else Decimal('0'),'spi':qr(ev/pv) if pv else Decimal('0'),'cv':q(ev-ac),'sv':q(ev-pv)})
    snapshots=db.query(ConstructionEVMSnapshot).filter_by(company_id=company_id,project_id=project_id).order_by(ConstructionEVMSnapshot.status_date.desc()).limit(12).all()
    trend=[{'status_date':x.status_date,'pv':q(x.pv),'ev':q(x.ev),'ac':q(x.ac),'cpi':qr(x.cpi),'spi':qr(x.spi),'eac':q(x.eac),'vac':q(x.vac)} for x in reversed(snapshots)]
    allocated=D(sum((x.allocated_amount for x in allocations),Decimal('0'))); unallocated=max(D(evm['ac'])-allocated,Decimal('0'))
    return {'project':evm,'wbs':wbs,'boq':boq,'cost_codes':ccs,'activities':rows,'trend':trend,'ac_allocation':{'allocated':q(allocated),'unallocated':q(unallocated)}}

def save_evm_snapshot(db, company_id, project_id, status_date, baseline_id=None, forecast_method='cpi'):
    x=construction_evm(db,company_id,project_id,status_date,baseline_id,forecast_method)
    r=db.query(ConstructionEVMSnapshot).filter_by(company_id=company_id,project_id=project_id,status_date=status_date).one_or_none()
    vals={k:x[k] for k in ('pv','ev','ac','bac','cpi','spi','cv','sv','eac','etc','vac','tcpi_bac','tcpi_eac')}
    if r:
        for k,v in vals.items(): setattr(r,k,v)
        r.baseline_id=x['baseline_id']
    else:
        r=ConstructionEVMSnapshot(company_id=company_id,project_id=project_id,status_date=status_date,baseline_id=x['baseline_id'],**vals); db.add(r)
    db.flush(); return r,x


# Phase 6.4.2 — Performance Alerts, Thresholds & Forecast Governance

def evaluate_performance_alerts(db, company_id, project_id, status_date, baseline_id=None, thresholds=None, forecast_method='cpi'):
    """Create/update deterministic EVM alerts for the supplied status date.
    thresholds may contain cpi_warn, cpi_critical, spi_warn, spi_critical,
    vac_warn_pct, vac_critical_pct and tcpi_warn.
    """
    t={'cpi_warn':Decimal('0.95'),'cpi_critical':Decimal('0.90'),
       'spi_warn':Decimal('0.95'),'spi_critical':Decimal('0.90'),
       'vac_warn_pct':Decimal('-0.05'),'vac_critical_pct':Decimal('-0.10'),
       'tcpi_warn':Decimal('1.05')}
    if thresholds: t.update({k:D(v) for k,v in thresholds.items() if k in t})
    evm=construction_evm(db,company_id,project_id,status_date,baseline_id,forecast_method)
    snap=db.query(ConstructionEVMSnapshot).filter_by(company_id=company_id,project_id=project_id,status_date=status_date).one_or_none()
    if not snap:
        snap=ConstructionEVMSnapshot(company_id=company_id,project_id=project_id,status_date=status_date,baseline_id=evm['baseline_id'],**{k:evm[k] for k in ('pv','ev','ac','bac','cpi','spi','cv','sv','eac','etc','vac','tcpi_bac','tcpi_eac')})
        db.add(snap); db.flush()
    checks=[]
    cpi=D(evm['cpi']); spi=D(evm['spi']); vac=D(evm['vac']); bac=D(evm['bac']); vac_pct=(vac/bac if bac else Decimal('0')); tcpi=D(evm['tcpi_eac'])
    if cpi < t['cpi_critical']: checks.append(('cost','cpi','critical',t['cpi_critical'],cpi,'CPI below critical threshold'))
    elif cpi < t['cpi_warn']: checks.append(('cost','cpi','warning',t['cpi_warn'],cpi,'CPI below warning threshold'))
    if spi < t['spi_critical']: checks.append(('schedule','spi','critical',t['spi_critical'],spi,'SPI below critical threshold'))
    elif spi < t['spi_warn']: checks.append(('schedule','spi','warning',t['spi_warn'],spi,'SPI below warning threshold'))
    if vac_pct < t['vac_critical_pct']: checks.append(('forecast','vac_pct','critical',t['vac_critical_pct'],vac_pct,'VAC percentage below critical threshold'))
    elif vac_pct < t['vac_warn_pct']: checks.append(('forecast','vac_pct','warning',t['vac_warn_pct'],vac_pct,'VAC percentage below warning threshold'))
    if tcpi > t['tcpi_warn']: checks.append(('forecast','tcpi_eac','warning',t['tcpi_warn'],tcpi,'TCPI(EAC) above required-efficiency threshold'))
    desired={(a,m) for a,m,*_ in checks}
    existing=db.query(ConstructionPerformanceAlert).filter_by(company_id=company_id,project_id=project_id,status_date=status_date).all()
    for row in existing:
        if (row.alert_type,row.metric) not in desired and row.status=='open': row.status='closed'
    result=[]
    for alert_type,metric,severity,threshold,actual,message in checks:
        row=db.query(ConstructionPerformanceAlert).filter_by(company_id=company_id,project_id=project_id,status_date=status_date,alert_type=alert_type,metric=metric).one_or_none()
        if not row:
            row=ConstructionPerformanceAlert(company_id=company_id,project_id=project_id,snapshot_id=snap.id,status_date=status_date,alert_type=alert_type,metric=metric,severity=severity,threshold=threshold,actual_value=actual,status='open',message=message); db.add(row)
        else:
            row.snapshot_id=snap.id; row.severity=severity; row.threshold=threshold; row.actual_value=actual; row.message=message
            if row.status=='closed': row.status='open'
        result.append(row)
    db.flush(); return {'evm':evm,'alerts':result,'thresholds':t}

def acknowledge_performance_alert(db, company_id, alert_id, user_id):
    row=db.query(ConstructionPerformanceAlert).filter_by(id=alert_id,company_id=company_id).one_or_none()
    if not row: raise ValueError('Performance alert not found')
    if row.status not in ('open','acknowledged'): raise ValueError('Alert is not actionable')
    row.status='acknowledged'; row.acknowledged_by_id=user_id; row.acknowledged_at=utcnow(); db.flush(); return row

def resolve_performance_alert(db, company_id, alert_id, user_id, corrective_action):
    if not corrective_action or not corrective_action.strip(): raise ValueError('Corrective action is required')
    row=db.query(ConstructionPerformanceAlert).filter_by(id=alert_id,company_id=company_id).one_or_none()
    if not row: raise ValueError('Performance alert not found')
    if row.status not in ('open','acknowledged'): raise ValueError('Alert is already resolved')
    row.status='resolved'; row.corrective_action=corrective_action.strip(); row.resolved_by_id=user_id; row.resolved_at=utcnow(); db.flush(); return row


def create_recovery_plan(db, company_id, project_id, plan_no, title, target_date, owner_id=None, alert_id=None, target_cpi=None, target_spi=None, target_eac=None, notes=None):
    if not _project_exists(db, company_id, project_id): raise ValueError('Project not found')
    if db.query(ConstructionRecoveryPlan).filter_by(company_id=company_id, project_id=project_id, plan_no=plan_no).first(): raise ValueError('Recovery plan number already exists')
    if alert_id and not db.query(ConstructionPerformanceAlert).filter_by(id=alert_id, company_id=company_id, project_id=project_id).one_or_none(): raise ValueError('Performance alert not found')
    r=ConstructionRecoveryPlan(company_id=company_id,project_id=project_id,alert_id=alert_id,plan_no=plan_no.strip(),title=title.strip(),owner_id=owner_id,target_date=target_date,target_cpi=target_cpi,target_spi=target_spi,target_eac=target_eac,notes=notes)
    db.add(r); db.flush(); return r

def add_recovery_action(db, company_id, plan_id, action_no, description, due_date, owner_id=None):
    plan=db.query(ConstructionRecoveryPlan).filter_by(id=plan_id,company_id=company_id).one_or_none()
    if not plan: raise ValueError('Recovery plan not found')
    if db.query(ConstructionRecoveryAction).filter_by(plan_id=plan_id,action_no=action_no).first(): raise ValueError('Recovery action number already exists')
    r=ConstructionRecoveryAction(company_id=company_id,plan_id=plan_id,action_no=action_no.strip(),description=description.strip(),due_date=due_date,owner_id=owner_id)
    db.add(r); db.flush(); return r

def approve_recovery_plan(db, company_id, plan_id, user_id):
    r=db.query(ConstructionRecoveryPlan).filter_by(id=plan_id,company_id=company_id).with_for_update().one_or_none()
    if not r: raise ValueError('Recovery plan not found')
    if r.status not in ('draft','submitted'): raise ValueError('Recovery plan is not awaiting approval')
    r.status='approved'; r.approved_by_id=user_id; r.approved_at=utcnow(); db.flush(); return r

def close_recovery_plan(db, company_id, plan_id, user_id):
    r=db.query(ConstructionRecoveryPlan).filter_by(id=plan_id,company_id=company_id).with_for_update().one_or_none()
    if not r: raise ValueError('Recovery plan not found')
    actions=db.query(ConstructionRecoveryAction).filter_by(plan_id=plan_id,company_id=company_id).all()
    if any(D(a.completion_percent) < 100 for a in actions): raise ValueError('All recovery actions must be complete before closing the plan')
    r.status='closed'; r.closed_by_id=user_id; r.closed_at=utcnow(); db.flush(); return r

def update_recovery_action(db, company_id, action_id, status=None, completion_percent=None, evidence=None):
    r=db.query(ConstructionRecoveryAction).filter_by(id=action_id,company_id=company_id).one_or_none()
    if not r: raise ValueError('Recovery action not found')
    if status is not None:
        if status not in ('open','in_progress','completed','cancelled'): raise ValueError('Invalid recovery action status')
        r.status=status
    if completion_percent is not None:
        pct=D(completion_percent)
        if pct < 0 or pct > 100: raise ValueError('Completion percent must be between 0 and 100')
        r.completion_percent=pct
        if pct == 100: r.status='completed'; r.completed_at=utcnow()
    if evidence is not None: r.evidence=evidence.strip()
    db.flush(); return r


def create_delay_event(db, company_id, project_id, event_no, event_date, cause, description, claimed_days=0, excusable=False, compensable=False, activity_id=None, user_id=None):
    if not company_project(db, company_id, project_id): raise ValueError('Project not found')
    if activity_id and not _activity(db, company_id, project_id, activity_id): raise ValueError('Activity not found')
    if int(claimed_days) < 0: raise ValueError('Claimed days cannot be negative')
    if db.query(ConstructionScheduleDelayEvent).filter_by(project_id=project_id,event_no=event_no).first(): raise ValueError('Delay event number already exists')
    r=ConstructionScheduleDelayEvent(company_id=company_id,project_id=project_id,activity_id=activity_id,event_no=event_no,event_date=event_date,cause=cause.strip(),description=description.strip(),claimed_days=int(claimed_days),excusable=bool(excusable),compensable=bool(compensable),created_by_id=user_id)
    db.add(r); db.flush(); return r

def approve_delay_event(db, company_id, event_id, approved_days):
    r=db.query(ConstructionScheduleDelayEvent).filter_by(id=event_id,company_id=company_id).with_for_update().one_or_none()
    if not r: raise ValueError('Delay event not found')
    if r.status=='approved': raise ValueError('Delay event already approved')
    if int(approved_days)<0 or int(approved_days)>r.claimed_days: raise ValueError('Approved days must be within claimed days')
    r.approved_days=int(approved_days); r.status='approved'; return r

def schedule_baseline_variance(db, company_id, project_id, baseline_id=None):
    if baseline_id is None:
        baseline_id=db.query(ConstructionScheduleBaseline.id).filter_by(company_id=company_id,project_id=project_id,status='approved').order_by(ConstructionScheduleBaseline.baseline_no.desc()).scalar()
    if not baseline_id: return []
    rows=db.query(ConstructionActivity,ConstructionActivityBaseline).join(ConstructionActivityBaseline,ConstructionActivityBaseline.activity_id==ConstructionActivity.id).filter(ConstructionActivity.company_id==company_id,ConstructionActivity.project_id==project_id,ConstructionActivityBaseline.company_id==company_id,ConstructionActivityBaseline.baseline_id==baseline_id).all()
    result=[]
    for a,b in rows:
        start_var=(a.planned_start-b.planned_start).days; finish_var=(a.planned_finish-b.planned_finish).days
        actual_finish=a.actual_finish or a.planned_finish
        actual_var=(actual_finish-b.planned_finish).days if a.actual_finish else None
        result.append({'activity_id':a.id,'code':a.code,'name':a.name,'start_variance_days':start_var,'finish_variance_days':finish_var,'actual_finish_variance_days':actual_var,'budget_variance':q(D(a.budget_amount)-D(b.budget_amount))})
    return result

def add_schedule_resource(db, company_id, project_id, activity_id, resource_type, resource_name, planned_units, actual_units=0, unit_cost=0):
    _activity(db,company_id,project_id,activity_id)
    if D(planned_units)<0 or D(actual_units)<0 or D(unit_cost)<0: raise ValueError('Resource values cannot be negative')
    r=ConstructionScheduleResource(company_id=company_id,project_id=project_id,activity_id=activity_id,resource_type=resource_type.strip(),resource_name=resource_name.strip(),planned_units=D(planned_units),actual_units=D(actual_units),unit_cost=D(unit_cost))
    db.add(r); db.flush(); return r



def create_schedule_update_period(db, company_id, project_id, status_date, baseline_id=None):
    if not company_project(db, company_id, project_id): raise ValueError('Project not found')
    if baseline_id and not db.query(ConstructionScheduleBaseline).filter_by(id=baseline_id, company_id=company_id, project_id=project_id).one_or_none(): raise ValueError('Baseline not found')
    exists=db.query(ConstructionScheduleUpdatePeriod).filter_by(company_id=company_id, project_id=project_id, status_date=status_date).one_or_none()
    if exists: return exists
    row=ConstructionScheduleUpdatePeriod(company_id=company_id, project_id=project_id, status_date=status_date, baseline_id=baseline_id)
    db.add(row); db.flush(); return row

def approve_schedule_update_period(db, company_id, period_id, user_id):
    row=db.query(ConstructionScheduleUpdatePeriod).filter_by(id=period_id, company_id=company_id).with_for_update().one_or_none()
    if not row: raise ValueError('Schedule update period not found')
    if row.status!='open': raise ValueError('Schedule update period is not open')
    row.status='approved'; row.approved_by_id=user_id; row.approved_at=utcnow(); db.flush(); return row

def lock_schedule_update_period(db, company_id, period_id, user_id):
    row=db.query(ConstructionScheduleUpdatePeriod).filter_by(id=period_id, company_id=company_id).with_for_update().one_or_none()
    if not row: raise ValueError('Schedule update period not found')
    if row.status!='approved': raise ValueError('Only approved schedule periods can be locked')
    row.status='locked'; row.locked_by_id=user_id; row.locked_at=utcnow(); db.flush(); return row

def add_resource_period(db, company_id, project_id, resource_id, period_date, planned_units, actual_units=0):
    r=db.query(ConstructionScheduleResource).filter_by(id=resource_id, company_id=company_id, project_id=project_id).one_or_none()
    if not r: raise ValueError('Schedule resource not found')
    pu,au=D(planned_units),D(actual_units)
    if pu<0 or au<0: raise ValueError('Resource units cannot be negative')
    period=db.query(ConstructionScheduleUpdatePeriod).filter_by(company_id=company_id,project_id=project_id,status_date=period_date).one_or_none()
    if period and period.status=='locked': raise ValueError('Schedule update period is locked')
    row=db.query(ConstructionScheduleResourcePeriod).filter_by(company_id=company_id,project_id=project_id,resource_id=resource_id,period_date=period_date).one_or_none()
    planned_cost=q(pu*D(r.unit_cost)); actual_cost=q(au*D(r.unit_cost))
    if row:
        row.planned_units=pu; row.actual_units=au; row.planned_cost=planned_cost; row.actual_cost=actual_cost
    else:
        row=ConstructionScheduleResourcePeriod(company_id=company_id,project_id=project_id,activity_id=r.activity_id,resource_id=r.id,period_date=period_date,planned_units=pu,actual_units=au,planned_cost=planned_cost,actual_cost=actual_cost); db.add(row)
    db.flush(); return row

def resource_histogram(db, company_id, project_id, start_date=None, end_date=None):
    qy=db.query(ConstructionScheduleResourcePeriod).filter_by(company_id=company_id,project_id=project_id)
    if start_date: qy=qy.filter(ConstructionScheduleResourcePeriod.period_date>=start_date)
    if end_date: qy=qy.filter(ConstructionScheduleResourcePeriod.period_date<=end_date)
    rows=qy.order_by(ConstructionScheduleResourcePeriod.period_date.asc()).all(); grouped={}
    for r in rows:
        g=grouped.setdefault(r.period_date, {'period_date':r.period_date,'planned_units':Decimal('0'),'actual_units':Decimal('0'),'planned_cost':Decimal('0'),'actual_cost':Decimal('0')})
        g['planned_units']+=D(r.planned_units); g['actual_units']+=D(r.actual_units); g['planned_cost']+=D(r.planned_cost); g['actual_cost']+=D(r.actual_cost)
    return [{k:(q(v) if k!='period_date' else v) for k,v in x.items()} for x in grouped.values()]

def calculate_schedule_health(db, company_id, project_id, status_date=None, baseline_id=None):
    status_date = status_date or _date.today()
    activities=db.query(ConstructionActivity).filter_by(company_id=company_id,project_id=project_id).all()
    if not activities:
        return {'score':100,'status':'healthy','issues':[],'critical_delayed':0,'finish_variance_days':0,'open_delays':0,'resource_variance':Decimal('0'),'progress_stale':False}
    sched=calculate_schedule(db,company_id,project_id)
    approved=baseline_id or db.query(ConstructionScheduleBaseline.id).filter_by(company_id=company_id,project_id=project_id,status='approved').order_by(ConstructionScheduleBaseline.baseline_no.desc()).scalar()
    variance=schedule_baseline_variance(db,company_id,project_id,approved) if approved else []
    finish_variance=max((int(x['finish_variance_days']) for x in variance), default=0)
    critical_delayed=sum(1 for a in activities if sched.get(a.id,{}).get('critical') and a.status!='completed' and a.planned_finish < status_date)
    open_delays=db.query(ConstructionScheduleDelayEvent).filter_by(company_id=company_id,project_id=project_id).filter(ConstructionScheduleDelayEvent.status!='approved').count()
    resources=db.query(ConstructionScheduleResource).filter_by(company_id=company_id,project_id=project_id).all()
    resource_variance=sum((D(r.actual_units)-D(r.planned_units) for r in resources),Decimal('0'))
    latest_period=db.query(ConstructionProgressPeriod).filter_by(company_id=company_id,project_id=project_id).order_by(ConstructionProgressPeriod.status_date.desc()).first()
    progress_stale=bool(latest_period and latest_period.status_date < status_date)
    issues=[]
    score=100
    if critical_delayed: issues.append(f'{critical_delayed} critical activities are delayed'); score-=min(30,critical_delayed*10)
    if finish_variance>0: issues.append(f'finish variance is {finish_variance} days'); score-=min(25,finish_variance)
    if open_delays: issues.append(f'{open_delays} delay events are awaiting approval'); score-=min(15,open_delays*3)
    if resource_variance>0: issues.append('actual resource units exceed planned units'); score-=10
    if progress_stale: issues.append('latest progress period is behind the status date'); score-=10
    status='healthy' if score>=85 else ('watch' if score>=70 else 'critical')
    return {'score':max(score,0),'status':status,'issues':issues,'critical_delayed':critical_delayed,'finish_variance_days':finish_variance,'open_delays':open_delays,'resource_variance':q(resource_variance),'progress_stale':progress_stale}

def create_time_impact_analysis(db, company_id, project_id, delay_event_id, status_date=None, baseline_id=None, user_id=None, notes=None):
    status_date=status_date or _date.today()
    event=db.query(ConstructionScheduleDelayEvent).filter_by(id=delay_event_id,company_id=company_id,project_id=project_id).one_or_none()
    if not event: raise ValueError('Delay event not found')
    if event.status!='approved': raise ValueError('Only approved delay events can be analysed')
    existing=db.query(ConstructionTimeImpactAnalysis).filter_by(company_id=company_id,project_id=project_id,delay_event_id=delay_event_id).one_or_none()
    if existing: raise ValueError('Time impact analysis already exists for this delay event')
    sched=calculate_schedule(db,company_id,project_id)
    finishes=[v['early_finish'] for v in sched.values()]
    current_finish=max(finishes) if finishes else None
    baseline_id=baseline_id or db.query(ConstructionScheduleBaseline.id).filter_by(company_id=company_id,project_id=project_id,status='approved').order_by(ConstructionScheduleBaseline.baseline_no.desc()).scalar()
    baseline_finish=None
    if baseline_id:
        baseline_finish=db.query(func.max(ConstructionActivityBaseline.planned_finish)).filter_by(company_id=company_id,baseline_id=baseline_id).scalar()
    activity=sched.get(event.activity_id) if event.activity_id else None
    approved_days=int(event.approved_days or 0)
    critical=bool(activity and activity['critical'])
    float_days=int(activity['total_float']) if activity else 0
    impact=max(0,min(approved_days,approved_days-float_days)) if activity else approved_days
    impacted_finish=current_finish + timedelta(days=impact) if current_finish and impact else current_finish
    row=ConstructionTimeImpactAnalysis(company_id=company_id,project_id=project_id,delay_event_id=event.id,baseline_id=baseline_id,status_date=status_date,impacted_activity_id=event.activity_id,baseline_project_finish=baseline_finish,current_project_finish=current_finish,impacted_project_finish=impacted_finish,calculated_impact_days=impact,critical_path_impact=critical or impact>0,analysis_method='fragnet',status='draft',created_by_id=user_id,notes=notes)
    db.add(row); db.flush(); return row

def approve_time_impact_analysis(db, company_id, analysis_id, user_id):
    row=db.query(ConstructionTimeImpactAnalysis).filter_by(id=analysis_id,company_id=company_id).with_for_update().one_or_none()
    if not row: raise ValueError('Time impact analysis not found')
    if row.status!='draft': raise ValueError('Time impact analysis is not awaiting approval')
    row.status='approved'; row.approved_by_id=user_id; row.approved_at=utcnow(); db.flush(); return row


def link_recovery_activity(db, company_id, project_id, recovery_plan_id, activity_id, target_start=None, target_finish=None, target_progress=100, acceleration_factor=1, notes=None):
    plan=db.query(ConstructionRecoveryPlan).filter_by(id=recovery_plan_id,company_id=company_id,project_id=project_id).one_or_none()
    act=db.query(ConstructionActivity).filter_by(id=activity_id,company_id=company_id,project_id=project_id).one_or_none()
    if not plan or not act: raise ValueError('Recovery plan or activity not found')
    if plan.status not in ('draft','submitted','approved'): raise ValueError('Recovery plan is not active')
    if target_start and target_finish and target_finish < target_start: raise ValueError('Target finish cannot be before target start')
    if D(target_progress)<0 or D(target_progress)>100: raise ValueError('Target progress must be between 0 and 100')
    if D(acceleration_factor)<=0: raise ValueError('Acceleration factor must be positive')
    row=db.query(ConstructionRecoveryScheduleLink).filter_by(recovery_plan_id=plan.id,activity_id=act.id).one_or_none()
    if row: raise ValueError('Activity is already linked to this recovery plan')
    row=ConstructionRecoveryScheduleLink(company_id=company_id,project_id=project_id,recovery_plan_id=plan.id,activity_id=act.id,target_start=target_start,target_finish=target_finish,target_progress=D(target_progress),acceleration_factor=D(acceleration_factor),notes=notes)
    db.add(row); db.flush(); return row

def submit_eot_claim(db, company_id, claim_id, user_id):
    row=db.query(ConstructionEOTClaim).filter_by(id=claim_id,company_id=company_id).with_for_update().one_or_none()
    if not row: raise ValueError('EOT claim not found')
    if row.status!='draft': raise ValueError('EOT claim is not draft')
    if row.claimed_days<=0: raise ValueError('Claimed days must be greater than zero')
    row.status='submitted'; row.submitted_at=utcnow(); db.flush(); return row

def approve_eot_claim(db, company_id, claim_id, approved_days, user_id):
    row=db.query(ConstructionEOTClaim).filter_by(id=claim_id,company_id=company_id).with_for_update().one_or_none()
    if not row: raise ValueError('EOT claim not found')
    if row.status!='submitted': raise ValueError('EOT claim is not awaiting approval')
    if int(approved_days)<0 or int(approved_days)>int(row.claimed_days): raise ValueError('Approved days must be between 0 and claimed days')
    if not row.tia_id: raise ValueError('EOT claim requires an approved time impact analysis')
    tia=db.query(ConstructionTimeImpactAnalysis).filter_by(id=row.tia_id,company_id=company_id,project_id=row.project_id).one_or_none()
    if not tia or tia.status!='approved': raise ValueError('EOT claim requires an approved time impact analysis')
    if int(approved_days)>int(tia.calculated_impact_days): raise ValueError('Approved days cannot exceed calculated TIA impact')
    row.approved_days=int(approved_days); row.status='approved'; row.approved_by_id=user_id; row.approved_at=utcnow(); db.flush(); return row

def create_schedule_update_line(db, company_id, project_id, period_id, activity_id, actual_start=None, actual_finish=None, progress_percent=0):
    period=db.query(ConstructionScheduleUpdatePeriod).filter_by(id=period_id,company_id=company_id,project_id=project_id).one_or_none()
    act=db.query(ConstructionActivity).filter_by(id=activity_id,company_id=company_id,project_id=project_id).one_or_none()
    if not period or not act: raise ValueError('Schedule period or activity not found')
    if period.status=='locked': raise ValueError('Schedule update period is locked')
    pct=D(progress_percent)
    if pct<0 or pct>100: raise ValueError('Progress must be between 0 and 100')
    if actual_start and actual_finish and actual_finish<actual_start: raise ValueError('Actual finish cannot be before actual start')
    row=db.query(ConstructionScheduleUpdateLine).filter_by(company_id=company_id,project_id=project_id,period_id=period.id,activity_id=act.id).one_or_none()
    if row is None: row=ConstructionScheduleUpdateLine(company_id=company_id,project_id=project_id,period_id=period.id,activity_id=act.id); db.add(row)
    row.actual_start=actual_start; row.actual_finish=actual_finish; row.progress_percent=pct
    row.finish_variance_days=(actual_finish-act.planned_finish).days if actual_finish else 0
    act.actual_start=actual_start or act.actual_start; act.actual_finish=actual_finish or act.actual_finish
    if pct>=100: act.status='completed'
    elif pct>0 and act.status=='planned': act.status='in_progress'
    db.flush(); return row

def resource_curves(db, company_id, project_id, start_date=None, end_date=None):
    qy=db.query(ConstructionScheduleResourcePeriod).filter_by(company_id=company_id,project_id=project_id)
    if start_date: qy=qy.filter(ConstructionScheduleResourcePeriod.period_date>=start_date)
    if end_date: qy=qy.filter(ConstructionScheduleResourcePeriod.period_date<=end_date)
    rows=qy.order_by(ConstructionScheduleResourcePeriod.period_date).all(); out={}
    for r in rows:
        d=r.period_date.isoformat(); bucket=out.setdefault(d,{'date':d,'planned_units':Decimal('0'),'actual_units':Decimal('0'),'planned_cost':Decimal('0'),'actual_cost':Decimal('0')})
        bucket['planned_units']+=D(r.planned_units); bucket['actual_units']+=D(r.actual_units); bucket['planned_cost']+=D(r.planned_cost); bucket['actual_cost']+=D(r.actual_cost)
    return list(out.values())


# Patch 56 — authoritative budget + automatic reconciliation + forecast/cash/profitability linkage

def rebuild_authoritative_budget(db, company_id, project_id, revision_id=None):
    """Materialize authoritative budget = base active budget + all approved revision deltas."""
    if not _project_exists(db, company_id, project_id): raise ValueError('Project not found')
    db.query(ConstructionAuthoritativeBudgetLine).filter_by(company_id=company_id, project_id=project_id).delete(synchronize_session=False)
    base_buckets={}
    for b in db.query(ConstructionCostBudgetLine).filter_by(company_id=company_id, project_id=project_id, status='active').all():
        key=(b.cost_code_id,b.wbs_id,b.budget_date or date.min)
        base_buckets[key]=base_buckets.get(key,Decimal('0'))+D(b.budget_amount)
    revision_buckets={}
    approved=db.query(ConstructionCostBudgetRevision).filter_by(company_id=company_id,project_id=project_id,status='approved').order_by(ConstructionCostBudgetRevision.approved_at.asc(),ConstructionCostBudgetRevision.revision_no.asc()).all()
    for rev in approved:
        for line in db.query(ConstructionCostBudgetRevisionLine).filter_by(company_id=company_id,revision_id=rev.id).all():
            key=(line.cost_code_id,line.wbs_id,line.period_date)
            revision_buckets[key]=revision_buckets.get(key,Decimal('0'))+D(line.delta_amount)
    keys=set(base_buckets)|set(revision_buckets)
    for key in keys:
        base=base_buckets.get(key,Decimal('0')); delta=revision_buckets.get(key,Decimal('0')); amount=base+delta
        if amount < 0: raise ValueError(f'Approved budget would become negative for scope {key}')
        cc,wbs,period=key
        latest=None
        for rev in reversed(approved):
            if db.query(ConstructionCostBudgetRevisionLine).filter_by(company_id=company_id,revision_id=rev.id,cost_code_id=cc,wbs_id=wbs,period_date=period).first(): latest=rev.id; break
        db.add(ConstructionAuthoritativeBudgetLine(company_id=company_id,project_id=project_id,cost_code_id=cc,wbs_id=wbs,period_date=period,
            base_amount=q(base),revision_amount=q(delta),approved_budget=q(amount),last_revision_id=latest))
    db.flush()
    return q(sum((base_buckets.get(k,Decimal('0'))+revision_buckets.get(k,Decimal('0')) for k in keys),Decimal('0')))

_old_approve_cost_budget_revision = approve_cost_budget_revision
def approve_cost_budget_revision(db, company_id, revision_id, user_id):
    r=_old_approve_cost_budget_revision(db,company_id,revision_id,user_id)
    rebuild_authoritative_budget(db,company_id,r.project_id,r.id)
    return r

def authoritative_budget_total(db, company_id, project_id):
    # Once authoritative rows exist, their approved total is the source of truth
    # even when that approved total is legitimately zero.
    auth_exists=db.query(ConstructionAuthoritativeBudgetLine.id).filter_by(
        company_id=company_id, project_id=project_id).first() is not None
    if auth_exists:
        total=D(db.query(func.coalesce(func.sum(ConstructionAuthoritativeBudgetLine.approved_budget),0)).filter_by(
            company_id=company_id,project_id=project_id).scalar())
    else:
        total=D(db.query(func.coalesce(func.sum(ConstructionCostBudgetLine.budget_amount),0)).filter_by(
            company_id=company_id,project_id=project_id,status='active').scalar())
    return q(total)

def reconcile_project_costs(db, company_id, project_id, status_date):
    if not _project_exists(db,company_id,project_id): raise ValueError('Project not found')
    budget=authoritative_budget_total(db,company_id,project_id)
    commitment=D(db.query(func.coalesce(func.sum(ConstructionCommitment.committed_amount),0)).filter(
        ConstructionCommitment.company_id==company_id,ConstructionCommitment.project_id==project_id,
        ConstructionCommitment.commitment_date<=status_date,ConstructionCommitment.status.in_(['open','approved'])).scalar())
    released=D(db.query(func.coalesce(func.sum(ConstructionCommitment.released_amount),0)).filter(
        ConstructionCommitment.company_id==company_id,ConstructionCommitment.project_id==project_id,
        ConstructionCommitment.commitment_date<=status_date,ConstructionCommitment.status.in_(['open','approved'])).scalar())
    actual=D(db.query(func.coalesce(func.sum(ProjectCost.amount),0)).filter(
        ProjectCost.company_id==company_id,ProjectCost.project_id==project_id,ProjectCost.cost_date<=status_date).scalar())
    open_commitment=max(commitment-released,Decimal('0'))
    # A cost control reconciliation is balanced when actuals do not exceed open commitment + budget.
    unreconciled=max(actual-budget,Decimal('0'))
    status='exception' if unreconciled>0 else 'balanced'
    row=db.query(ConstructionCostReconciliation).filter_by(company_id=company_id,project_id=project_id,status_date=status_date).with_for_update().first()
    data=dict(budget_amount=q(budget),commitment_amount=q(commitment),actual_amount=q(actual),open_commitment_amount=q(open_commitment),unreconciled_amount=q(unreconciled),status=status)
    if row:
        for k,v in data.items(): setattr(row,k,v)
    else:
        row=ConstructionCostReconciliation(company_id=company_id,project_id=project_id,status_date=status_date,**data); db.add(row); db.flush()
    return row

def generate_cost_forecast(db, company_id, project_id, status_date, user_id, method='remaining_budget'):
    if method not in {'remaining_budget','cpi','cpi_spi'}: raise ValueError('Unsupported automatic forecast method')
    reconciliation=reconcile_project_costs(db,company_id,project_id,status_date)
    budget=D(reconciliation.budget_amount); actual=D(reconciliation.actual_amount)
    evm=db.query(ConstructionEVMSnapshot).filter_by(company_id=company_id,project_id=project_id).filter(ConstructionEVMSnapshot.status_date<=status_date).order_by(ConstructionEVMSnapshot.status_date.desc()).first()
    if method in {'cpi','cpi_spi'} and (not evm or D(evm.cpi)<=0): raise ValueError('Valid positive CPI is required for CPI forecast')
    if method=='remaining_budget': etc=max(budget-actual,Decimal('0'))
    elif method=='cpi': etc=max(budget-actual,Decimal('0')) / D(evm.cpi)
    else:
        cpi=D(evm.cpi); spi=D(evm.spi)
        if cpi<=0 or spi<=0: raise ValueError('Valid positive CPI and SPI are required')
        etc=max(budget-actual,Decimal('0'))/(cpi*spi)
    eac=actual+etc
    v=create_cost_forecast_version(db,company_id,project_id,status_date,user_id,method,[{'etc_amount':q(etc),'eac_amount':q(eac)}])
    return v

def refresh_cost_alerts(db, company_id, project_id, status_date):
    r=reconcile_project_costs(db,company_id,project_id,status_date)
    budget=D(r.budget_amount); actual=D(r.actual_amount); commitment=D(r.open_commitment_amount)
    alerts=[]
    def add(kind,severity,metric,threshold,value,message):
        row=db.query(ConstructionCostAlert).filter_by(company_id=company_id,project_id=project_id,status_date=status_date,alert_type=kind,metric=metric).with_for_update().first()
        if row:
            row.severity=severity; row.threshold=q(threshold) if threshold is not None else None; row.actual_value=qr(value) if value is not None else None; row.message=message; row.status='open'
        else:
            row=ConstructionCostAlert(company_id=company_id,project_id=project_id,status_date=status_date,alert_type=kind,severity=severity,metric=metric,threshold=q(threshold) if threshold is not None else None,actual_value=qr(value) if value is not None else None,message=message); db.add(row); db.flush()
        alerts.append(row)
    if budget<=0 and (actual+commitment)>0: add('UNBUDGETED_EXPOSURE','critical','exposure',Decimal('0'),actual+commitment,'Actual plus open commitments exist without an authoritative budget')
    elif budget>0:
        utilization=(actual/budget)*Decimal('100')
        if utilization>=Decimal('90'): add('HIGH_UTILIZATION','warning' if utilization<100 else 'critical','actual_utilization_pct',Decimal('90'),utilization,'Actual cost utilization reached the control threshold')
        if actual+commitment>budget: add('COMMITMENT_OVER_BUDGET','critical','cost_exposure',budget,actual+commitment,'Actual plus open commitments exceed the authoritative budget')
    if r.unreconciled_amount>0: add('RECONCILIATION_EXCEPTION','critical','unreconciled_amount',Decimal('0'),D(r.unreconciled_amount),'Cost reconciliation exception requires review')
    db.flush(); return alerts

def build_cost_cash_flow_snapshot(db, company_id, project_id, status_date):
    if not _project_exists(db,company_id,project_id): raise ValueError('Project not found')
    actual=construction_cash_flow_63(db,company_id,project_id)
    actual_in=D(actual['certified_inflow']); actual_out=D(actual['material_outflow'])+D(actual['equipment_outflow'])+D(actual['labor_outflow'])+D(actual['subcontractor_outflow'])
    rec=reconcile_project_costs(db,company_id,project_id,status_date)
    committed=D(rec.open_commitment_amount)
    # Forecast inflow is current posted revenue; forecast outflow is EAC less actual cash cost.
    profitability=project_profitability(db,company_id,project_id)
    forecast_in=D(profitability['certified_revenue'])
    forecast_out=D(profitability['eac'])
    row=db.query(ConstructionCostCashFlowSnapshot).filter_by(company_id=company_id,project_id=project_id,status_date=status_date).with_for_update().first()
    data=dict(actual_inflow=q(actual_in),actual_outflow=q(actual_out),committed_outflow=q(committed),forecast_inflow=q(forecast_in),forecast_outflow=q(forecast_out),forecast_net=q(forecast_in-forecast_out))
    if row:
        for k,v in data.items(): setattr(row,k,v)
    else:
        row=ConstructionCostCashFlowSnapshot(company_id=company_id,project_id=project_id,status_date=status_date,**data); db.add(row); db.flush()
    return row

def refresh_project_profitability_forecast(db, company_id, project_id, status_date):
    if not _project_exists(db,company_id,project_id): raise ValueError('Project not found')
    rec=reconcile_project_costs(db,company_id,project_id,status_date)
    actual=D(rec.actual_amount); budget=D(rec.budget_amount)
    approved=db.query(ConstructionCostForecastVersion).filter_by(company_id=company_id,project_id=project_id,status='approved').order_by(ConstructionCostForecastVersion.status_date.desc(),ConstructionCostForecastVersion.version_no.desc()).first()
    eac=D(approved.total_eac) if approved else max(budget,actual)
    revenue=D(db.query(func.coalesce(func.sum(ProgressCertificate.gross_amount),0)).filter(ProgressCertificate.company_id==company_id,ProgressCertificate.project_id==project_id,ProgressCertificate.status=='posted').scalar())
    profit=revenue-eac
    row=db.query(ProjectForecast).filter_by(company_id=company_id,project_id=project_id,as_of_date=status_date).with_for_update().first()
    data=dict(budget_cost=q(budget),committed_cost=q(rec.commitment_amount),actual_cost=q(actual),forecast_final_cost=q(eac),forecast_revenue=q(revenue),forecast_profit=q(profit))
    if row:
        for k,v in data.items(): setattr(row,k,v)
    else:
        row=ProjectForecast(company_id=company_id,project_id=project_id,as_of_date=status_date,**data); db.add(row); db.flush()
    return row
