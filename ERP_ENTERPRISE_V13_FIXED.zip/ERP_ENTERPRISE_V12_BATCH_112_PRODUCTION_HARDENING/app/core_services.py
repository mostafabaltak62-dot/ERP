"""ERP Core domain services: tenant-safe master data, contracts, dimensions and search."""
from decimal import Decimal
from sqlalchemy import or_, func
from sqlalchemy.orm import Session
from .enterprise_models import Company, Branch, Department, Currency, ExchangeRate, AnalyticalDimension, DimensionValue, Project, ProjectPhase, Contract, ContractMilestone, DocumentAttachment, Notification, Employee, Equipment, UserCompanyAccess
from .models import Customer, Supplier, Item, Account, User
from .governance import get_request_context


def tenant_company(db: Session, company_id: int):
    row = db.query(Company).filter(Company.id == company_id, Company.is_active.is_(True)).first()
    if not row:
        raise ValueError("Company not found or inactive")
    return row


def tenant_branch(db: Session, company_id: int, branch_id: int | None):
    if branch_id is None:
        return None
    row = db.query(Branch).filter(Branch.id == branch_id, Branch.company_id == company_id, Branch.is_active.is_(True)).first()
    if not row:
        raise ValueError("Branch does not belong to the selected company")
    return row


def create_project(db: Session, company_id: int, branch_id: int | None, code: str, name: str, customer_id=None, budget=Decimal("0")):
    tenant_company(db, company_id); tenant_branch(db, company_id, branch_id)
    ctx_branch = get_request_context().get("branch_id")
    if ctx_branch is not None and branch_id != ctx_branch:
        raise ValueError("Project branch must match the active branch context")
    if db.query(Project).filter_by(company_id=company_id, code=code).first():
        raise ValueError("Project code already exists")
    row = Project(company_id=company_id, branch_id=branch_id, code=code, name=name, customer_id=customer_id, budget=budget)
    db.add(row); db.flush(); return row


def create_contract(db: Session, company_id: int, contract_number: str, contract_type: str, **kwargs):
    tenant_company(db, company_id)
    if db.query(Contract).filter_by(company_id=company_id, contract_number=contract_number).first():
        raise ValueError("Contract number already exists")
    project_id = kwargs.get("project_id")
    if project_id is not None:
        project = db.query(Project).filter(Project.id == project_id, Project.company_id == company_id).first()
        if not project: raise ValueError("Project does not belong to the selected company")
        ctx_branch = get_request_context().get("branch_id")
        if ctx_branch is not None and project.branch_id not in (None, ctx_branch):
            raise ValueError("Project is outside the active branch context")
    customer_id = kwargs.get("customer_id")
    if customer_id is not None and not db.query(Customer).filter(Customer.id == customer_id, Customer.company_id == company_id).first():
        raise ValueError("Customer does not belong to the selected company")
    supplier_id = kwargs.get("supplier_id")
    if supplier_id is not None and not db.query(Supplier).filter(Supplier.id == supplier_id, Supplier.company_id == company_id).first():
        raise ValueError("Supplier does not belong to the selected company")
    value = Decimal(str(kwargs.get("value", 0)))
    retention = Decimal(str(kwargs.get("retention_rate", 0)))
    advance = Decimal(str(kwargs.get("advance_amount", 0)))
    if value < 0 or retention < 0 or retention > 100 or advance < 0:
        raise ValueError("Invalid contract financial values")
    row = Contract(company_id=company_id, contract_number=contract_number, contract_type=contract_type,
                   value=value, retention_rate=retention, advance_amount=advance,
                   customer_id=customer_id, supplier_id=supplier_id, project_id=project_id,
                   start_date=kwargs.get("start_date"), end_date=kwargs.get("end_date"))
    if row.start_date and row.end_date and row.end_date < row.start_date:
        raise ValueError("Contract end date cannot precede start date")
    db.add(row); db.flush(); return row


def add_dimension_value(db: Session, company_id: int, dimension_id: int, code: str, name: str):
    dim = db.query(AnalyticalDimension).filter(AnalyticalDimension.id == dimension_id, AnalyticalDimension.company_id == company_id).first()
    if not dim: raise ValueError("Dimension not found")
    if db.query(DimensionValue).filter_by(dimension_id=dimension_id, code=code).first():
        raise ValueError("Dimension value code already exists")
    row = DimensionValue(company_id=company_id, dimension_id=dimension_id, code=code, name=name)
    db.add(row); db.flush(); return row


def global_search(db: Session, company_id: int, query: str, limit: int = 25):
    q = (query or "").strip()
    if len(q) < 2: return []
    like = f"%{q}%"; results = []
    def add(entity, row, label, subtitle=None):
        if len(results) < limit:
            results.append({"entity": entity, "id": row.id, "label": label, "subtitle": subtitle})
    for row in db.query(Customer).filter(Customer.company_id == company_id, or_(Customer.name.ilike(like), Customer.code.ilike(like))).limit(limit).all(): add("customer", row, row.name, row.code)
    for row in db.query(Supplier).filter(Supplier.company_id == company_id, or_(Supplier.name.ilike(like), Supplier.code.ilike(like))).limit(limit).all(): add("supplier", row, row.name, row.code)
    for row in db.query(Item).filter(Item.company_id == company_id, or_(Item.name.ilike(like), Item.code.ilike(like))).limit(limit).all(): add("item", row, row.name, row.code)
    for row in db.query(Project).filter(Project.company_id == company_id, or_(Project.name.ilike(like), Project.code.ilike(like))).limit(limit).all(): add("project", row, row.name, row.code)
    for row in db.query(Contract).filter(Contract.company_id == company_id, Contract.contract_number.ilike(like)).limit(limit).all(): add("contract", row, row.contract_number, row.contract_type)
    for row in db.query(Employee).filter(Employee.company_id == company_id, or_(Employee.name.ilike(like), Employee.employee_code.ilike(like))).limit(limit).all(): add("employee", row, row.name, row.employee_code)
    for row in db.query(Equipment).filter(Equipment.company_id == company_id, or_(Equipment.name.ilike(like), Equipment.code.ilike(like))).limit(limit).all(): add("equipment", row, row.name, row.code)
    return results[:limit]


def mark_notification_read(db: Session, user_id: int, notification_id: int):
    row = db.query(Notification).filter(Notification.id == notification_id, Notification.user_id == user_id).first()
    if not row: raise ValueError("Notification not found")
    row.is_read = True; db.flush(); return row

# --- ERP Core governance services -------------------------------------------------
def create_document_attachment(db: Session, company_id: int, user_id: int, entity_type: str,
                               entity_id: int, file_name: str, storage_key: str,
                               content_type: str | None = None, file_size: int | None = None,
                               expires_at=None):
    if not storage_key or len(storage_key) > 500:
        raise ValueError("A valid storage key is required")
    if file_size is not None and file_size < 0:
        raise ValueError("File size cannot be negative")
    latest = (db.query(DocumentAttachment)
              .filter(DocumentAttachment.company_id == company_id,
                      DocumentAttachment.entity_type == entity_type,
                      DocumentAttachment.entity_id == entity_id)
              .order_by(DocumentAttachment.version.desc()).first())
    version = (latest.version + 1) if latest else 1
    row = DocumentAttachment(company_id=company_id, entity_type=entity_type, entity_id=entity_id,
                             file_name=file_name.strip(), storage_key=storage_key,
                             content_type=content_type, file_size=file_size, version=version,
                             uploaded_by_id=user_id, expires_at=expires_at)
    db.add(row); db.flush(); return row


def list_document_attachments(db: Session, company_id: int, entity_type: str, entity_id: int):
    return (db.query(DocumentAttachment)
            .filter(DocumentAttachment.company_id == company_id,
                    DocumentAttachment.entity_type == entity_type,
                    DocumentAttachment.entity_id == entity_id)
            .order_by(DocumentAttachment.version.desc(), DocumentAttachment.id.desc()).all())


def create_notification(db: Session, company_id: int, user_id: int, notification_type: str,
                        title: str, message: str, entity_type: str | None = None,
                        entity_id: int | None = None, branch_id: int | None = None):
    if not title.strip() or not message.strip():
        raise ValueError("Notification title and message are required")
    target = db.query(User).filter(User.id == user_id, User.is_active.is_(True)).first()
    if not target:
        raise ValueError("Notification recipient not found or inactive")
    # A notification must never be assigned across company boundaries.
    accesses = db.query(UserCompanyAccess).filter(
        UserCompanyAccess.user_id == user_id,
        UserCompanyAccess.company_id == company_id,
    ).first()
    if not accesses:
        raise ValueError("Notification recipient does not belong to the current company")
    row = Notification(company_id=company_id, branch_id=branch_id, user_id=user_id,
                       notification_type=notification_type, title=title.strip(),
                       message=message.strip(), entity_type=entity_type, entity_id=entity_id)
    db.add(row); db.flush(); return row
