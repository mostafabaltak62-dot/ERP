from .time_utils import utcnow
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func, select, update
from sqlalchemy.exc import IntegrityError
from .models import Account, AccountTypeEnum, JournalEntry, JournalLine, SequenceCounter, AccountingPeriod, AuditLog

MONEY_Q = Decimal("0.000001")


def D(value) -> Decimal:
    """Convert user/database values to Decimal without introducing binary float error."""
    try:
        if isinstance(value, Decimal):
            return value
        return Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        raise HTTPException(status_code=422, detail="قيمة مالية غير صالحة")


def money(value) -> Decimal:
    return D(value).quantize(MONEY_Q, rounding=ROUND_HALF_UP)


def next_number(db: Session, key: str, prefix: str, company_id=None) -> str:
    """Allocate a globally unique document number safely under concurrency.

    Document-number columns and ``SequenceCounter.key`` are globally unique in the
    current schema. The counter is therefore intentionally technical/global and is
    the only approved tenant-filter bypass. Existing rows are locked; concurrent
    first-use creation is handled through a SAVEPOINT and then reloaded.
    """
    from .governance import get_request_context
    key = str(key or "").strip()
    prefix = str(prefix or "").strip()
    if not key or not prefix:
        raise HTTPException(status_code=422, detail="Document sequence key and prefix are required")
    if len(key) > 50:
        raise HTTPException(status_code=422, detail="Document sequence key is too long")
    if company_id is None:
        company_id = get_request_context().get("company_id")

    def _locked_counter():
        return (db.query(SequenceCounter)
                .execution_options(skip_tenant_filter=True)
                .filter(SequenceCounter.key == key)
                .with_for_update()
                .first())

    counter = _locked_counter()
    if counter is None:
        # The first request for a sequence can race in horizontally scaled workers.
        # Use a SAVEPOINT so an IntegrityError does not poison the caller's outer
        # accounting/inventory transaction.
        try:
            with db.begin_nested():
                db.add(SequenceCounter(key=key, company_id=company_id, next_value=2))
                db.flush()
            return f"{prefix}-{1:06d}"
        except IntegrityError:
            # Another transaction created the global counter first; reload it under
            # row lock and continue with the authoritative sequence.
            counter = _locked_counter()
            if counter is None:
                raise

    value = int(counter.next_value)
    db.execute(
        update(SequenceCounter)
        .where(SequenceCounter.id == counter.id)
        .values(next_value=SequenceCounter.next_value + 1)
    )
    return f"{prefix}-{value:06d}"


def ensure_default_accounts(db: Session, company_id=None):
    if company_id is None:
        try:
            from .governance import get_request_context
            company_id = get_request_context().get("company_id")
        except Exception:
            company_id = None
    defaults = [
        # code, name, type, parent, normal balance, statement section, cash-flow category
        ("1000", "الأصول", AccountTypeEnum.asset, None, "debit", "assets", None),
        ("1100", "الخزينة الرئيسية", AccountTypeEnum.asset, "1000", "debit", "cash_and_equivalents", "operating"),
        ("1110", "البنوك والحسابات الجارية", AccountTypeEnum.asset, "1000", "debit", "cash_and_equivalents", "operating"),
        ("1200", "العملاء والذمم المدينة", AccountTypeEnum.asset, "1000", "debit", "trade_receivables", "operating"),
        ("1210", "احتجازات العملاء", AccountTypeEnum.asset, "1000", "debit", "other_current_assets", "operating"),
        ("1220", "مخصص خسائر الائتمان المتوقعة", AccountTypeEnum.asset, "1000", "credit", "trade_receivables_allowance", "operating"),
        ("1300", "المخزون", AccountTypeEnum.asset, "1000", "debit", "inventory", "operating"),
        ("1400", "سلف الموردين والمقاولين", AccountTypeEnum.asset, "1000", "debit", "other_current_assets", "operating"),
        ("1450", "مصروفات مدفوعة مقدمًا", AccountTypeEnum.asset, "1000", "debit", "other_current_assets", "operating"),
        ("1500", "الأصول الثابتة", AccountTypeEnum.asset, "1000", "debit", "property_plant_equipment", "investing"),
        ("1510", "مجمع إهلاك الأصول", AccountTypeEnum.asset, "1500", "credit", "accumulated_depreciation", "investing"),
        ("1550", "أصول حق الاستخدام", AccountTypeEnum.asset, "1000", "debit", "right_of_use_assets", "investing"),
        ("2000", "الخصوم", AccountTypeEnum.liability, None, "credit", "liabilities", None),
        ("2100", "الموردون والذمم الدائنة", AccountTypeEnum.liability, "2000", "credit", "trade_payables", "operating"),
        ("2120", "بضاعة مستلمة غير مفوترة", AccountTypeEnum.liability, "2000", "credit", "accruals", "operating"),
        ("2200", "ضريبة قيمة مضافة مخرجات", AccountTypeEnum.liability, "2000", "credit", "taxes_payable", "operating"),
        ("2210", "مصروفات مستحقة", AccountTypeEnum.liability, "2000", "credit", "accruals", "operating"),
        ("2220", "ضريبة قيمة مضافة مدخلات", AccountTypeEnum.asset, "1000", "debit", "other_current_assets", "operating"),
        ("2250", "قروض والتزامات تمويلية", AccountTypeEnum.liability, "2000", "credit", "borrowings", "financing"),
        ("2300", "سلف العملاء", AccountTypeEnum.liability, "2000", "credit", "contract_liabilities", "operating"),
        ("2310", "احتجازات مستحقة للموردين والمقاولين", AccountTypeEnum.liability, "2000", "credit", "accruals", "operating"),
        ("3000", "حقوق الملكية", AccountTypeEnum.equity, None, "credit", "equity", None),
        ("3100", "رأس المال", AccountTypeEnum.equity, "3000", "credit", "share_capital", "financing"),
        ("3200", "الأرباح المحتجزة", AccountTypeEnum.equity, "3000", "credit", "retained_earnings", "financing"),
        ("4000", "الإيرادات", AccountTypeEnum.revenue, None, "credit", "revenue", "operating"),
        ("4100", "إيرادات المبيعات", AccountTypeEnum.revenue, "4000", "credit", "revenue", "operating"),
        ("4200", "مرتجعات ومسموحات المبيعات", AccountTypeEnum.revenue, "4000", "credit", "contra_revenue", "operating"),
        ("4300", "إيرادات أخرى", AccountTypeEnum.revenue, "4000", "credit", "other_income", "operating"),
        ("5000", "المصروفات وتكلفة الإيرادات", AccountTypeEnum.expense, None, "debit", "expenses", "operating"),
        ("5100", "تكلفة المبيعات", AccountTypeEnum.expense, "5000", "debit", "cost_of_sales", "operating"),
        ("5200", "المصروفات التشغيلية", AccountTypeEnum.expense, "5000", "debit", "operating_expenses", "operating"),
        ("5300", "أرباح تسويات المخزون", AccountTypeEnum.revenue, "4000", "credit", "other_income", "operating"),
        ("5400", "مصروف الإهلاك", AccountTypeEnum.expense, "5000", "debit", "operating_expenses", "operating"),
        ("5500", "مصروفات تمويلية", AccountTypeEnum.expense, "5000", "debit", "finance_costs", "financing"),
        ("5600", "خسائر اضمحلال الأصول", AccountTypeEnum.expense, "5000", "debit", "operating_expenses", "operating"),
        ("5700", "مصروف ضريبة الدخل", AccountTypeEnum.expense, "5000", "debit", "income_tax", "operating"),
        ("5800", "فروق عملة وأرباح/خسائر أخرى", AccountTypeEnum.expense, "5000", "debit", "other_expenses", "operating"),
    ]
    created = {}
    for code, name, typ, parent_code, normal_balance, statement_section, cash_flow_category in defaults:
        q = db.query(Account).filter(Account.code == code)
        if company_id is not None:
            q = q.filter(Account.company_id == company_id)
        else:
            q = q.filter(Account.company_id.is_(None))
        acc = q.first()
        if not acc:
            parent_id = None
            if parent_code:
                parent = created.get(parent_code) or db.query(Account).filter(Account.code == parent_code, Account.company_id == company_id).first()
                parent_id = parent.id if parent else None
            acc = Account(code=code, company_id=company_id, name=name, account_type=typ, parent_id=parent_id,
                          normal_balance=normal_balance, statement_section=statement_section, cash_flow_category=cash_flow_category)
            db.add(acc)
            db.flush()
        else:
            acc.name = name
            acc.account_type = typ
            acc.normal_balance = normal_balance
            acc.statement_section = statement_section
            acc.cash_flow_category = cash_flow_category
            if parent_code and not acc.parent_id:
                parent = created.get(parent_code) or db.query(Account).filter(Account.code == parent_code, Account.company_id == company_id).first()
                if parent:
                    acc.parent_id = parent.id
        created[code] = acc
    db.flush()


def account(db: Session, code: str, company_id=None, branch_id=None) -> Account:
    from .governance import get_request_context
    code = (code or "").strip()
    ctx = get_request_context()
    if company_id is None:
        company_id = ctx.get("company_id")
    if branch_id is None:
        branch_id = ctx.get("branch_id")
    q = db.query(Account).filter(Account.code == code, Account.is_active == True)
    if company_id is not None:
        q = q.filter(Account.company_id == company_id)
    else:
        q = q.filter(Account.company_id.is_(None))
    # Branch-specific account wins; company-wide account is the fallback.
    if branch_id is not None:
        q = q.filter((Account.branch_id == branch_id) | (Account.branch_id.is_(None)))
        q = q.order_by(Account.branch_id.desc())
    acc = q.first()
    if not acc:
        raise HTTPException(status_code=422, detail=f"الحساب المحاسبي {code} غير موجود أو غير نشط")
    return acc


def assert_open_period(db: Session, effective_date, company_id=None, branch_id=None):
    q = db.query(AccountingPeriod).filter(
        AccountingPeriod.start_date <= effective_date,
        AccountingPeriod.end_date >= effective_date,
    )
    if company_id is not None:
        q = q.filter(AccountingPeriod.company_id == company_id)
    if branch_id is not None:
        q = q.filter((AccountingPeriod.branch_id == branch_id) | (AccountingPeriod.branch_id.is_(None)))
    period = q.order_by(AccountingPeriod.branch_id.desc()).first()
    if period and period.is_closed:
        raise HTTPException(status_code=409, detail=f"الفترة المحاسبية {period.name} مغلقة ولا يمكن إضافة قيود إليها")
    return period


def journal_totals(db: Session, entry_id: int) -> tuple[Decimal, Decimal]:
    """Return authoritative posted journal totals from database rows."""
    debit, credit = db.query(
        func.coalesce(func.sum(JournalLine.debit), 0),
        func.coalesce(func.sum(JournalLine.credit), 0),
    ).filter(JournalLine.entry_id == entry_id).one()
    return money(debit), money(credit)


def assert_journal_balanced(db: Session, entry_id: int) -> None:
    debit, credit = journal_totals(db, entry_id)
    if debit <= 0 or debit != credit:
        raise HTTPException(status_code=422, detail="القيد المحاسبي غير متوازن")


def create_entry(db: Session, description: str, user_id: int,
                 lines: list[tuple[str, object, object]],
                 source_type: str | None = None, source_id: int | None = None,
                 entry_date=None, company_id=None, line_metadata=None, branch_id=None):
    """Create an immediately-posted, immutable, balanced journal entry.

    Caller owns the surrounding transaction. No commit occurs here so the
    business document + subledger + journal can be committed atomically.
    """
    from datetime import datetime

    if not description or not description.strip():
        raise HTTPException(status_code=422, detail="وصف القيد مطلوب")
    if not lines:
        raise HTTPException(status_code=422, detail="القيد يجب أن يحتوي على سطر واحد على الأقل")

    from .governance import get_request_context
    ctx = get_request_context()
    explicit_company = company_id is not None
    company_id = company_id if explicit_company else ctx.get("company_id")
    # Explicit company-scoped service calls are commonly used by background jobs
    # and unit workflows; never leak a stale request branch into them. Web/API
    # callers that need branch posting pass branch_id explicitly or omit company_id.
    branch_id = branch_id if branch_id is not None else (None if explicit_company else ctx.get("branch_id"))
    effective_date = entry_date or utcnow()
    assert_open_period(db, effective_date, company_id=company_id, branch_id=branch_id)

    # Idempotency/business-source protection.
    if source_type is not None and source_id is not None:
        existing_q = db.query(JournalEntry).filter(
            JournalEntry.source_type == source_type,
            JournalEntry.source_id == source_id,
        )
        if company_id is not None:
            existing_q = existing_q.filter(JournalEntry.company_id == company_id)
        if branch_id is not None:
            existing_q = existing_q.filter(JournalEntry.branch_id == branch_id)
        existing = existing_q.first()
        if existing:
            raise HTTPException(status_code=409, detail=f"تم ترحيل القيد المصدر {source_type}#{source_id} بالفعل")

    # Serialize balance-changing operations on bank/cash accounts. The account row
    # is the stable lock target, so concurrent deposits/withdrawals for the same
    # account cannot both pass the read-before-write window.
    requested_codes = {str(code) for code, _, _ in lines}
    if requested_codes & {"1100", "1110"}:
        (db.query(Account)
           .filter(Account.company_id == company_id, Account.code.in_(requested_codes & {"1100", "1110"}), Account.is_active.is_(True))
           .with_for_update().all())

    normalized = []
    total_debit = Decimal("0")
    total_credit = Decimal("0")
    for code, debit, credit in lines:
        d, c = money(debit), money(credit)
        if d < 0 or c < 0 or (d > 0 and c > 0):
            raise HTTPException(status_code=422, detail="سطر القيد المحاسبي غير صالح")
        if d == 0 and c == 0:
            raise HTTPException(status_code=422, detail="لا يسمح بسطر محاسبي صفري")
        acc = account(db, code, company_id=company_id, branch_id=branch_id)
        normalized.append((acc, d, c))
        total_debit += d
        total_credit += c

    if total_debit <= 0 or total_debit != total_credit:
        raise HTTPException(status_code=422, detail="القيد المحاسبي غير متوازن: إجمالي المدين يجب أن يساوي إجمالي الدائن")

    entry = JournalEntry(
        entry_number=next_number(db, "journal", "JE", company_id=company_id),
        description=description.strip(),
        entry_date=effective_date,
        source_type=source_type,
        source_id=source_id,
        status="draft",
        posted_at=None,
        posted_by_id=None,
        created_by_id=user_id,
        company_id=company_id,
        branch_id=branch_id,
    )
    db.add(entry)
    db.flush()

    created_lines=[]
    for idx, (acc, debit, credit) in enumerate(normalized):
        meta = (line_metadata[idx] if line_metadata and idx < len(line_metadata) else {}) or {}
        db.add(JournalLine(entry_id=entry.id, account_id=acc.id, debit=debit, credit=credit, description=meta.get("description"), company_id=company_id, branch_id=branch_id))
        created_lines.append((acc, debit, credit, meta))
    db.flush()
    # Analytical allocations must be attached while the entry is still a draft;
    # posted journals are immutable by design.
    if line_metadata:
        from .models import JournalLineCostCenter, CostCenter
        for line, (_, debit, credit, meta) in zip(entry.lines, created_lines):
            cc_id=meta.get("cost_center_id")
            alloc=meta.get("allocation_amount")
            if cc_id and alloc is not None:
                alloc=money(alloc); line_total=money(debit+credit)
                if alloc <= 0 or alloc > line_total:
                    raise HTTPException(status_code=422, detail="تخصيص مركز التكلفة يجب أن يكون ضمن قيمة السطر")
                cc_q=db.query(CostCenter).filter(CostCenter.id==int(cc_id),CostCenter.company_id==company_id,CostCenter.is_active==True)
                if branch_id is not None:
                    cc_q=cc_q.filter((CostCenter.branch_id==branch_id)|(CostCenter.branch_id.is_(None)))
                else:
                    cc_q=cc_q.filter(CostCenter.branch_id.is_(None))
                cc=cc_q.first()
                if not cc: raise HTTPException(status_code=422, detail="مركز التكلفة غير صالح أو خارج نطاق الفرع")
                db.add(JournalLineCostCenter(company_id=company_id,journal_line_id=line.id,cost_center_id=cc.id,amount=alloc,allocation_percent=money(alloc/line_total*Decimal("100"))))
    db.flush()
    assert_journal_balanced(db, entry.id)
    entry.status = "posted"
    entry.posted_at = utcnow()
    entry.posted_by_id = user_id
    db.flush()

    db.add(AuditLog(
        user_id=user_id, action="post", entity_type="journal_entry",
        entity_id=entry.id, description=description.strip()
    ))
    return entry


def close_accounting_period(db: Session, period_id: int, user_id: int, company_id=None, branch_id=None):
    """Atomically close a fiscal period and create its closing entry."""
    from .models import PeriodClosingEntry
    from datetime import datetime

    period_q = db.query(AccountingPeriod).filter(AccountingPeriod.id == period_id)
    if company_id is not None:
        period_q = period_q.filter(AccountingPeriod.company_id == company_id)
    if branch_id is not None:
        period_q = period_q.filter(AccountingPeriod.branch_id == branch_id)
    period = period_q.with_for_update().first()
    if not period:
        raise HTTPException(status_code=404, detail="الفترة غير موجودة")
    if period.is_closed:
        raise HTTPException(status_code=409, detail="الفترة مغلقة بالفعل")
    if period.end_date < period.start_date:
        raise HTTPException(status_code=422, detail="الفترة المحاسبية غير صحيحة")
    if db.query(PeriodClosingEntry).filter(PeriodClosingEntry.period_id == period.id).first():
        raise HTTPException(status_code=409, detail="يوجد قيد إقفال مسجل لهذه الفترة")

    lines = []
    acc_q = db.query(Account).filter(Account.is_active == True)
    if company_id is not None:
        acc_q = acc_q.filter(Account.company_id == company_id)
    if branch_id is not None:
        acc_q = acc_q.filter((Account.branch_id == branch_id) | (Account.branch_id.is_(None)))
    for acc in acc_q.all():
        if acc.account_type not in (AccountTypeEnum.revenue, AccountTypeEnum.expense):
            continue
        debit = D(db.query(func.coalesce(func.sum(JournalLine.debit), 0))
                  .join(JournalEntry)
                  .filter(JournalLine.account_id == acc.id,
                          JournalEntry.entry_date >= period.start_date,
                          JournalEntry.entry_date <= period.end_date,
                          JournalEntry.company_id == period.company_id,
                          JournalEntry.branch_id == period.branch_id).scalar() or 0)
        credit = D(db.query(func.coalesce(func.sum(JournalLine.credit), 0))
                   .join(JournalEntry)
                   .filter(JournalLine.account_id == acc.id,
                           JournalEntry.entry_date >= period.start_date,
                           JournalEntry.entry_date <= period.end_date,
                           JournalEntry.company_id == period.company_id,
                           JournalEntry.branch_id == period.branch_id,
                           JournalLine.company_id == period.company_id).scalar() or 0)
        balance = debit - credit
        if balance == 0:
            continue
        if acc.account_type == AccountTypeEnum.revenue:
            # Revenue normally has a credit balance.
            lines.append((acc.code, max(-balance, Decimal("0")), max(balance, Decimal("0"))))
        else:
            # Expense normally has a debit balance.
            lines.append((acc.code, max(balance, Decimal("0")), max(-balance, Decimal("0"))))

    if lines:
        total_debit = sum((D(x[1]) for x in lines), Decimal("0"))
        total_credit = sum((D(x[2]) for x in lines), Decimal("0"))
        if total_debit > total_credit:
            lines.append(("3100", Decimal("0"), total_debit - total_credit))
        elif total_credit > total_debit:
            lines.append(("3100", total_credit - total_debit, Decimal("0")))

        closing = create_entry(
            db, f"إقفال الفترة {period.name}", user_id, lines,
            "period_close", period.id, period.end_date, company_id=period.company_id, branch_id=period.branch_id
        )
        db.add(PeriodClosingEntry(
            company_id=period.company_id, period_id=period.id, closing_entry_id=closing.id,
            created_by_id=user_id
        ))

    period.is_closed = True
    period.closed_at = utcnow()
    period.closed_by_id = user_id
    db.add(AuditLog(
        user_id=user_id, action="close", entity_type="accounting_period",
        entity_id=period.id, description=f"إغلاق الفترة {period.name}"
    ))
    return period


def create_reversing_entry(db: Session, original_entry_id: int, user_id: int, reason: str, reversal_date=None):
    """Create one immutable, balanced reversal for an eligible posted journal.

    Generic journal reversal deliberately does not reverse operational documents
    (sales, purchases, inventory, payroll, assets, etc.). Those modules must use
    their domain reversal workflow so subledgers and stock/asset state stay aligned.
    """
    from .models import JournalReversal, PeriodClosingEntry

    clean_reason = (reason or "").strip()
    if not clean_reason:
        raise HTTPException(422, "سبب العكس مطلوب")
    if len(clean_reason) > 255:
        raise HTTPException(422, "سبب العكس يجب ألا يتجاوز 255 حرفًا")

    original = (db.query(JournalEntry)
                .filter(JournalEntry.id == original_entry_id, JournalEntry.status == "posted")
                .with_for_update().first())
    if not original:
        raise HTTPException(404, "القيد المرحّل غير موجود")

    # Never allow reversing a reversal. It creates an ambiguous chain and should
    # instead be handled as an explicit adjustment.
    if original.source_type == "reversal":
        raise HTTPException(409, "لا يمكن عكس قيد عكس؛ أنشئ قيد تسوية واضحًا")

    # Closing entries have a dedicated period-governance workflow and must not be
    # bypassed through the generic reversal screen.
    if db.query(PeriodClosingEntry.id).filter(PeriodClosingEntry.closing_entry_id == original.id).first():
        raise HTTPException(409, "لا يمكن عكس قيد الإقفال من شاشة عكس القيود")

    # Source-linked operational postings require their owning module's reversal
    # so inventory, tax, receivables/payables, assets and other subledgers remain
    # synchronized with the GL.
    generic_sources = {None, "manual", "other", "accrual", "recurring_journal"}
    if original.source_type not in generic_sources:
        raise HTTPException(409, "القيد مرتبط بمستند تشغيلي؛ استخدم إجراء العكس الخاص بالمستند المصدر")

    if db.query(JournalReversal.id).filter(JournalReversal.original_entry_id == original.id).first():
        raise HTTPException(409, "القيد تم عكسه بالفعل")

    effective_date = reversal_date or utcnow()
    if effective_date < original.entry_date:
        raise HTTPException(422, "تاريخ العكس لا يمكن أن يسبق تاريخ القيد الأصلي")

    # create_entry enforces company/branch scope, open period, balance and
    # source idempotency. Use account IDs from the original lines so a future
    # duplicate account code in another scope can never redirect the reversal.
    normalized = []
    for line in original.lines:
        if line.account.company_id != original.company_id:
            raise HTTPException(409, "القيد الأصلي يحتوي على حساب خارج نطاق الشركة")
        normalized.append((line.account.code, money(line.credit), money(line.debit)))

    try:
        reversal = create_entry(
            db, f"عكس القيد {original.entry_number}: {clean_reason}", user_id, normalized,
            source_type="reversal", source_id=original.id,
            entry_date=effective_date, company_id=original.company_id, branch_id=original.branch_id
        )
        db.add(JournalReversal(
            company_id=original.company_id, original_entry_id=original.id,
            reversal_entry_id=reversal.id, reason=clean_reason, created_by_id=user_id
        ))
        db.add(AuditLog(
            user_id=user_id, action="reverse", entity_type="journal_entry",
            entity_id=original.id, description=f"عكس القيد {original.entry_number} -> {reversal.entry_number}: {clean_reason}"
        ))
        db.flush()
        return reversal
    except HTTPException:
        raise

