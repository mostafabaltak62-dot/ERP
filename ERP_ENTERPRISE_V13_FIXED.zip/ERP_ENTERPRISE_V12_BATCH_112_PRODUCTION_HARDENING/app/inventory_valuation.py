from .time_utils import utcnow
"""Authoritative inventory cost engine.

Supports FIFO and weighted-average costing using immutable receipt layers and
explicit consumption records. The service never silently permits negative
inventory unless the policy explicitly allows it.
"""
from datetime import datetime
from decimal import Decimal
from sqlalchemy import func
from sqlalchemy.orm import Session
from fastapi import HTTPException

from .accounting import D, money
from .enterprise_models import InventoryValuationPolicy, InventoryCostLayer, InventoryCostConsumption, InventoryValuationRun
from .models import Item, StockMovement, MovementTypeEnum


def calculate_weighted_average(current_qty, current_avg_cost, new_qty, new_price) -> Decimal:
    """Calculate moving weighted-average cost without float arithmetic.

    Inputs are normalized through the accounting Decimal helper and the result is
    quantized using the project's authoritative money precision.
    """
    current_qty = D(current_qty)
    current_avg_cost = D(current_avg_cost)
    new_qty = D(new_qty)
    new_price = money(new_price)
    if current_qty < 0 or new_qty < 0:
        raise HTTPException(422, "Inventory quantities cannot be negative for weighted-average valuation")
    total_qty = current_qty + new_qty
    if total_qty == 0:
        return Decimal("0")
    total_value = current_qty * current_avg_cost + new_qty * new_price
    return money(total_value / total_qty)


def get_policy(db: Session, company_id: int, item_id: int) -> InventoryValuationPolicy:
    policy = db.query(InventoryValuationPolicy).filter(
        InventoryValuationPolicy.company_id == company_id,
        InventoryValuationPolicy.item_id == item_id,
    ).with_for_update().first()
    if not policy:
        # Inventory Policy is the governance default for items that do not yet
        # have an explicit item-level valuation policy. Existing item policies
        # remain authoritative and are never silently overwritten.
        from .commercial_completion_models import InventoryPolicy
        default = db.query(InventoryPolicy).filter(
            InventoryPolicy.company_id == company_id,
            InventoryPolicy.warehouse_id.is_(None),
        ).first()
        method = default.costing_method if default else "weighted_average"
        allow_negative = bool(default.allow_negative_stock) if default else False
        policy = InventoryValuationPolicy(company_id=company_id, item_id=item_id, method=method, allow_negative=allow_negative)
        db.add(policy); db.flush()
    if policy.method not in {"fifo", "weighted_average", "standard"}:
        raise HTTPException(422, "Unsupported inventory valuation method")
    return policy


def receive(db: Session, company_id: int, item_id: int, quantity, unit_cost, source_type: str, source_id: int, received_at=None):
    qty, cost = D(quantity), money(unit_cost)
    if qty <= 0 or cost < 0:
        raise HTTPException(422, "Invalid inventory receipt valuation")
    existing = db.query(InventoryCostLayer).filter(
        InventoryCostLayer.company_id == company_id,
        InventoryCostLayer.item_id == item_id,
        InventoryCostLayer.source_type == source_type,
        InventoryCostLayer.source_id == source_id,
    ).first()
    if existing:
        raise HTTPException(409, "Inventory receipt valuation already exists for this source")
    layer = InventoryCostLayer(company_id=company_id, item_id=item_id, source_type=source_type,
                               source_id=source_id, received_at=received_at or utcnow(),
                               original_qty=qty, remaining_qty=qty, unit_cost=cost,
                               total_cost=money(qty * cost))
    db.add(layer); db.flush()
    return layer


def _available(db, company_id, item_id):
    return money(db.query(func.coalesce(func.sum(InventoryCostLayer.remaining_qty * InventoryCostLayer.unit_cost), 0)).filter(
        InventoryCostLayer.company_id == company_id, InventoryCostLayer.item_id == item_id,
        InventoryCostLayer.remaining_qty > 0).scalar() or 0)


def issue(db: Session, company_id: int, item_id: int, quantity, source_type: str, source_id: int, issued_at=None):
    # Serialize all balance-changing operations for an item. PostgreSQL uses a row lock;
    # SQLite remains safe for tests but serializes writes at the database level.
    item = db.query(Item).filter(Item.id == item_id, Item.company_id == company_id).with_for_update().first()
    if not item:
        raise HTTPException(404, "Item not found")
    qty = D(quantity)
    if qty <= 0:
        raise HTTPException(422, "Invalid inventory issue quantity")
    policy = get_policy(db, company_id, item_id)
    # Bring legacy inbound movements into the valuation ledger without changing
    # their historical quantities/costs. This is idempotent by source identity.
    legacy_in = db.query(StockMovement).filter(
        StockMovement.company_id == company_id,
        StockMovement.item_id == item_id,
        StockMovement.movement_type.in_([MovementTypeEnum.in_, MovementTypeEnum.adjustment_in]),
    ).order_by(StockMovement.operational_date.asc(), StockMovement.created_at.asc(), StockMovement.id.asc()).all()
    for m in legacy_in:
        exists = db.query(InventoryCostLayer.id).filter(
            InventoryCostLayer.company_id == company_id,
            InventoryCostLayer.item_id == item_id,
            InventoryCostLayer.source_type == "stock_movement",
            InventoryCostLayer.source_id == m.id,
        ).first()
        if not exists:
            receive(db, company_id, item_id, m.quantity, m.unit_cost, "stock_movement", m.id, m.operational_date or m.created_at)

    q = db.query(InventoryCostLayer).filter(
        InventoryCostLayer.company_id == company_id,
        InventoryCostLayer.item_id == item_id,
        InventoryCostLayer.remaining_qty > 0,
    )
    if policy.method == "fifo":
        q = q.order_by(InventoryCostLayer.received_at.asc(), InventoryCostLayer.id.asc())
        layers = q.with_for_update().all()
    else:
        layers = q.with_for_update().all()
    total_qty = sum((D(x.remaining_qty) for x in layers), Decimal("0"))
    if total_qty < qty and not policy.allow_negative:
        raise HTTPException(409, f"Insufficient valued inventory; available {total_qty}")
    consumptions=[]
    remaining=qty
    if policy.method == "standard":
        standard_cost = money(getattr(item, "standard_cost", 0) or 0)
        if standard_cost < 0:
            raise HTTPException(422, "Invalid standard cost")
        # Standard-cost valuation is explicit and item-master driven; no receipt
        # layer consumption is fabricated merely to obtain a cost.
        if total_qty < qty and not policy.allow_negative:
            raise HTTPException(409, f"Insufficient valued inventory; available {total_qty}")
        cost = money(qty * standard_cost)
        # Preserve the same layer-consumption audit trail where stock exists.
        for layer in layers:
            if remaining <= 0: break
            take = min(D(layer.remaining_qty), remaining)
            layer.remaining_qty = D(layer.remaining_qty) - take
            consumptions.append((layer, take, standard_cost, money(take * standard_cost)))
            remaining -= take
        if remaining > 0:
            raise HTTPException(409, "Standard-cost negative inventory requires an approved valuation adjustment")
        total_cost = cost
        for layer, take, unit_cost, layer_cost in consumptions:
            db.add(InventoryCostConsumption(company_id=company_id, item_id=item_id, layer_id=layer.id,
                                            source_type=source_type, source_id=source_id,
                                            quantity=take, unit_cost=unit_cost, total_cost=layer_cost,
                                            consumed_at=issued_at or utcnow()))
        db.flush()
        return total_cost, consumptions
    if policy.method == "weighted_average":
        total_value = sum((D(x.remaining_qty)*D(x.unit_cost) for x in layers), Decimal("0"))
        avg = (total_value / total_qty) if total_qty else Decimal("0")
        # Consume proportionally from layers, preserving exact layer quantities.
        for layer in layers:
            if remaining <= 0: break
            take = min(D(layer.remaining_qty), remaining)
            cost = money(take * avg)
            layer.remaining_qty = D(layer.remaining_qty) - take
            consumptions.append((layer, take, money(avg), cost))
            remaining -= take
    else:
        for layer in layers:
            if remaining <= 0: break
            take = min(D(layer.remaining_qty), remaining)
            cost = money(take * D(layer.unit_cost))
            layer.remaining_qty = D(layer.remaining_qty) - take
            consumptions.append((layer, take, money(layer.unit_cost), cost))
            remaining -= take
    if remaining > 0:
        if not policy.allow_negative:
            raise HTTPException(409, "Insufficient valued inventory")
        # Negative inventory is explicitly represented by a zero-cost pending deficit.
        raise HTTPException(409, "Negative inventory requires a valuation adjustment policy")
    total_cost = money(sum((x[3] for x in consumptions), Decimal("0")))
    for layer, take, unit_cost, cost in consumptions:
        db.add(InventoryCostConsumption(company_id=company_id, item_id=item_id, layer_id=layer.id,
                                        source_type=source_type, source_id=source_id,
                                        quantity=take, unit_cost=unit_cost, total_cost=cost,
                                        consumed_at=issued_at or utcnow()))
    db.flush()
    return total_cost, consumptions


def on_stock_movement(db: Session, movement: StockMovement):
    """Synchronize cost layers for legacy/direct stock movements.

    Call this from new receipt/issue paths; legacy rows should be migrated by a
    dedicated valuation rebuild rather than inventing historical costs.
    """
    if movement.movement_type in {MovementTypeEnum.in_, MovementTypeEnum.adjustment_in}:
        return receive(db, movement.company_id, movement.item_id, movement.quantity,
                       movement.unit_cost, "stock_movement", movement.id, movement.operational_date or movement.created_at)
    if movement.movement_type == MovementTypeEnum.out:
        return issue(db, movement.company_id, movement.item_id, movement.quantity,
                     "stock_movement", movement.id, movement.operational_date or movement.created_at)
    return None


def rebuild_item(db: Session, company_id: int, item_id: int, method=None):
    """Rebuild valuation layers from authoritative stock movements in date order.

    Intended for controlled migration/revaluation, not normal request handling.
    """
    policy = get_policy(db, company_id, item_id)
    if method:
        if method not in {"fifo", "weighted_average", "standard"}: raise HTTPException(422, "Invalid valuation method")
        policy.method = method
    db.query(InventoryCostConsumption).filter(InventoryCostConsumption.company_id == company_id,
                                                InventoryCostConsumption.item_id == item_id).delete(synchronize_session=False)
    db.query(InventoryCostLayer).filter(InventoryCostLayer.company_id == company_id,
                                         InventoryCostLayer.item_id == item_id).delete(synchronize_session=False)
    movements = db.query(StockMovement).filter(StockMovement.company_id == company_id,
                                                StockMovement.item_id == item_id).order_by(StockMovement.operational_date.asc(), StockMovement.created_at.asc(), StockMovement.id.asc()).all()
    for m in movements:
        if m.movement_type in {MovementTypeEnum.in_, MovementTypeEnum.adjustment_in}:
            receive(db, company_id, item_id, m.quantity, m.unit_cost, "stock_movement", m.id, m.operational_date or m.created_at)
        elif m.movement_type == MovementTypeEnum.out:
            issue(db, company_id, item_id, m.quantity, "stock_movement", m.id, m.created_at)
    db.flush()
    return policy


def run_company_valuation(db: Session, company_id: int, user_id=None):
    items = db.query(Item).filter(Item.company_id == company_id, Item.item_type == "product", Item.is_active == True).all()
    total_qty=Decimal("0"); total_value=Decimal("0"); methods=set()
    for item in items:
        policy=get_policy(db, company_id, item.id); methods.add(policy.method)
        qty=D(db.query(func.coalesce(func.sum(InventoryCostLayer.remaining_qty),0)).filter(
            InventoryCostLayer.company_id==company_id, InventoryCostLayer.item_id==item.id).scalar() or 0)
        value=_available(db, company_id, item.id)
        total_qty += qty; total_value += value
    method = next(iter(methods)) if len(methods)==1 else "mixed"
    run=InventoryValuationRun(company_id=company_id, method=method, total_quantity=total_qty, total_value=total_value, created_by_id=user_id)
    db.add(run); db.flush(); return run
