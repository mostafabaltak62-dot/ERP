"""Authoritative stock transaction primitives.

All balance-changing inventory operations should use this module so operational
 dates, source identity, warehouse scope, and valuation metadata are consistent.
"""
from datetime import datetime
from decimal import Decimal
from sqlalchemy import func, case
from sqlalchemy.orm import Session
from fastapi import HTTPException
from .models import Item, StockMovement, MovementTypeEnum, ItemTypeEnum
from .warehouse_models import Warehouse
from .accounting import D, money
from .time_utils import utcnow

IN_TYPES=(MovementTypeEnum.in_, MovementTypeEnum.adjustment_in)
OUT_TYPES=(MovementTypeEnum.out, MovementTypeEnum.adjustment_out)

def warehouse_balance(db: Session, company_id:int, item_id:int, warehouse_id:int|None=None, lock:bool=False)->Decimal:
    q=db.query(func.coalesce(func.sum(case((StockMovement.movement_type.in_(IN_TYPES), StockMovement.quantity), else_=-StockMovement.quantity)),0)).filter(
        StockMovement.company_id==company_id, StockMovement.item_id==item_id)
    if warehouse_id is not None: q=q.filter(StockMovement.warehouse_id==warehouse_id)
    return D(q.scalar() or 0)

def create_movement(db:Session, *, company_id:int, item_id:int, movement_type:MovementTypeEnum, quantity, unit_cost=0,
                    warehouse_id:int|None, user_id:int|None=None, note:str|None=None, source_type:str|None=None,
                    source_id:int|None=None, operational_date:datetime|None=None, transfer_id:str|None=None,
                    reversal_of_id:int|None=None, enforce_available:bool=True, serial_numbers=None, lot_no=None, expiry_date=None)->StockMovement:
    item=db.query(Item).filter(Item.id==item_id, Item.company_id==company_id).with_for_update().first()
    if not item: raise HTTPException(404,"Item not found")
    if item.item_type!=ItemTypeEnum.product: raise HTTPException(422,"Services cannot have stock movements")
    if not item.is_active: raise HTTPException(409,"Inactive item cannot receive stock movements")
    qty=D(quantity); cost=money(unit_cost)
    if qty<=0 or cost<0: raise HTTPException(422,"Invalid stock movement quantity/cost")
    if warehouse_id is not None:
        wh=db.query(Warehouse).filter(Warehouse.id==warehouse_id, Warehouse.company_id==company_id, Warehouse.is_active.is_(True)).first()
        if not wh: raise HTTPException(404,"Warehouse not found in current company")
    if source_type and source_id is not None:
        duplicate=db.query(StockMovement.id).filter(StockMovement.company_id==company_id, StockMovement.source_type==source_type,
                                                     StockMovement.source_id==source_id, StockMovement.movement_type==movement_type).first()
        if duplicate: raise HTTPException(409,"Stock movement already exists for this source")
    if movement_type in OUT_TYPES and enforce_available and not item.allow_negative_stock:
        available=warehouse_balance(db,company_id,item_id,warehouse_id)
        if available < qty: raise HTTPException(409,f"Insufficient stock; available {available}")
    mv=StockMovement(company_id=company_id,item_id=item_id,movement_type=movement_type,quantity=qty,
                     unit_cost=cost,total_cost=money(qty*cost),warehouse_id=warehouse_id,created_by_id=user_id,
                     note=note,source_type=source_type,source_id=source_id,operational_date=operational_date or utcnow(),
                     transfer_id=transfer_id,reversal_of_id=reversal_of_id)
    db.add(mv); db.flush()
    if serial_numbers is not None or lot_no is not None or expiry_date is not None or item.track_serial or item.track_expiry:
        from .inventory_traceability import attach_traceability
        attach_traceability(db, mv, serial_numbers=serial_numbers, lot_no=lot_no, expiry_date=expiry_date)
    return mv
