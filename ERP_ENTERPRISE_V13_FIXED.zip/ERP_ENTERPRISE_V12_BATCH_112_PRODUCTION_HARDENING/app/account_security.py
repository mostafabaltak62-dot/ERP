# -*- coding: utf-8 -*-
"""Administrative account lifecycle and dual-control password recovery."""
import hashlib, secrets, os, smtplib
from urllib.parse import urlparse
from email.message import EmailMessage
from datetime import timedelta
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from .db_base import Base
from .time_utils import utcnow

OTP_TTL_MINUTES = int(os.getenv('ERP_PASSWORD_RESET_OTP_MINUTES', '10'))
APPROVAL_TTL_HOURS = int(os.getenv('ERP_PASSWORD_RESET_APPROVAL_HOURS', '2'))

class PasswordResetRequest(Base):
    __tablename__ = 'password_reset_requests'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    request_token_hash = Column(String(64), unique=True, nullable=False, index=True)
    otp_hash = Column(String(64), nullable=False)
    otp_attempts = Column(Integer, nullable=False, default=0)
    otp_expires_at = Column(DateTime, nullable=False)
    expires_at = Column(DateTime, nullable=False, index=True)
    delivery_channel = Column(String(10), nullable=False)
    delivery_target = Column(String(255), nullable=False)
    admin_approved_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    admin_approved_at = Column(DateTime, nullable=True)
    senior_approved_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    senior_approved_at = Column(DateTime, nullable=True)
    verified_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    revoked_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, nullable=False, default=utcnow)
    user = relationship('User', foreign_keys=[user_id])
    admin_approver = relationship('User', foreign_keys=[admin_approved_by])
    senior_approver = relationship('User', foreign_keys=[senior_approved_by])


def _digest(value: str) -> str:
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def create_reset_request(db, user, channel: str):
    channel = channel.lower().strip()
    if channel not in {'email', 'phone'}:
        raise ValueError('Invalid recovery channel')
    target = (user.email if channel == 'email' else getattr(user, 'phone', None))
    if not target:
        raise ValueError('Selected recovery channel is not configured')
    now = utcnow()
    # Keep only one active recovery transaction per account. This limits OTP
    # spam and prevents a pile of valid reset tokens from being created.
    active = (db.query(PasswordResetRequest)
              .filter(PasswordResetRequest.user_id == user.id,
                      PasswordResetRequest.completed_at.is_(None),
                      PasswordResetRequest.revoked_at.is_(None),
                      PasswordResetRequest.expires_at > now)
              .all())
    for previous in active:
        previous.revoked_at = now
    raw_token = secrets.token_urlsafe(48)
    otp = f'{secrets.randbelow(1_000_000):06d}'
    row = PasswordResetRequest(
        user_id=user.id,
        request_token_hash=_digest(raw_token),
        otp_hash=_digest(otp),
        otp_expires_at=utcnow() + timedelta(minutes=OTP_TTL_MINUTES),
        expires_at=utcnow() + timedelta(hours=APPROVAL_TTL_HOURS),
        delivery_channel=channel,
        delivery_target=target,
    )
    db.add(row); db.commit(); db.refresh(row)
    return row, raw_token, otp


def send_otp(channel: str, target: str, otp: str):
    if channel == 'email':
        host = os.getenv('ERP_SMTP_HOST')
        if not host:
            if os.getenv('ERP_ENV', 'development').lower() == 'development' and os.getenv('ERP_ALLOW_DEV_OTP_LOG', 'false').lower() == 'true':
                return {'sent': True, 'provider': 'development'}
            raise RuntimeError('Email recovery is not configured')
        msg = EmailMessage()
        msg['Subject'] = 'ERP password recovery verification code'
        msg['From'] = os.getenv('ERP_SMTP_FROM', os.getenv('ERP_SMTP_USER', 'no-reply@example.com'))
        msg['To'] = target
        msg.set_content(f'Your ERP verification code is {otp}. It expires in {OTP_TTL_MINUTES} minutes. Do not share it.')
        port = int(os.getenv('ERP_SMTP_PORT', '587'))
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            if os.getenv('ERP_SMTP_STARTTLS', 'true').lower() == 'true': smtp.starttls()
            user = os.getenv('ERP_SMTP_USER'); password = os.getenv('ERP_SMTP_PASSWORD')
            if user and password: smtp.login(user, password)
            smtp.send_message(msg)
        return {'sent': True, 'provider': 'smtp'}
    if channel == 'phone':
        # Provider-neutral webhook integration; payload contains only the OTP and target.
        import json, urllib.request
        url = os.getenv('ERP_SMS_WEBHOOK_URL')
        if not url:
            raise RuntimeError('SMS recovery is not configured')
        validate_sms_webhook_url(url)
        payload = json.dumps({'to': target, 'message': f'ERP verification code: {otp}. Expires in {OTP_TTL_MINUTES} minutes.'}).encode()
        req = urllib.request.Request(url, data=payload, headers={'Content-Type': 'application/json'}, method='POST')
        with urllib.request.urlopen(req, timeout=15) as response:
            if response.status >= 300: raise RuntimeError('SMS provider rejected the request')
        return {'sent': True, 'provider': 'webhook'}
    raise ValueError('Invalid channel')


def verify_otp(row, otp: str):
    if row.revoked_at or row.completed_at or row.expires_at <= utcnow() or row.otp_expires_at <= utcnow(): return False
    if row.otp_attempts >= 5: return False
    row.otp_attempts += 1
    ok = secrets.compare_digest(row.otp_hash, _digest(otp.strip()))
    if ok: row.verified_at = utcnow()
    return ok


def validate_sms_webhook_url(url: str) -> None:
    parsed = urlparse(url)
    if os.getenv('ERP_ENV', 'development').lower() == 'production' and parsed.scheme != 'https':
        raise RuntimeError('SMS recovery webhook must use HTTPS in production')
    if parsed.scheme not in {'http', 'https'} or not parsed.netloc:
        raise RuntimeError('Invalid SMS recovery webhook URL')
