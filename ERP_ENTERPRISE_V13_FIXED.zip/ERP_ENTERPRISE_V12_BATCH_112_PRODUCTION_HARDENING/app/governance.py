"""Phase 4 governance runtime: tenant context, granular RBAC, approvals, and audit."""
import logging
import contextvars, datetime, hashlib, json, uuid, re
from decimal import Decimal
from functools import wraps
from sqlalchemy import event, select
from sqlalchemy.orm import Session, with_loader_criteria
from fastapi import Depends, HTTPException, Request, status

from .database import get_db, Base
from .models import User, RoleEnum
from .enterprise_models import Company, Branch, UserCompanyAccess
from .governance_models import Permission, Role, RolePermission, UserRole, ApprovalRule, ApprovalRuleStep, ApprovalRequest, ApprovalAction, GovernanceAuditLog

DEFAULT_PERMISSION_CODES = [
    ("admin:users", "admin", "إدارة المستخدمين"),
    ("admin:permissions", "admin", "إدارة الصلاحيات"),
    ("admin:tenants", "admin", "إدارة الشركات والفروع"),
    ("admin:password_reset_approve", "admin", "اعتماد استرداد كلمات المرور من الإدارة العليا"),
    ("audit:view", "audit", "عرض سجل التدقيق"),
    ("journal:view", "accounting", "عرض قيود اليومية"),
    ("journal:create", "accounting", "إنشاء قيد يومية"),
    ("journal:post", "accounting", "ترحيل قيد يومية"),
    ("journal:reverse", "accounting", "عكس قيد يومية"),
    ("reports:view", "reports", "عرض التقارير المالية"),
    ("sales:view", "sales", "عرض المبيعات"),
    ("sales:create", "sales", "إنشاء مستند بيع"),
    ("sales:edit", "sales", "تعديل مستند بيع"),
    ("sales:post", "sales", "ترحيل مستند بيع"),
    ("sales:cancel", "sales", "إلغاء مستند بيع"),
    ("sales:reverse", "sales", "عكس/إرجاع مستند بيع"),
    ("sales:approve", "sales", "اعتماد مستندات المبيعات"),
    ("purchases:view", "purchases", "عرض المشتريات"),
    ("purchases:create", "purchases", "إنشاء مستند شراء"),
    ("purchases:edit", "purchases", "تعديل مستند شراء"),
    ("purchases:post", "purchases", "ترحيل مستند شراء"),
    ("purchases:cancel", "purchases", "إلغاء مستند شراء"),
    ("purchases:reverse", "purchases", "عكس/إرجاع مستند شراء"),
    ("purchases:approve", "purchases", "اعتماد مستندات المشتريات"),
    ("inventory:view", "inventory", "عرض المخزون"),
    ("inventory:create", "inventory", "إنشاء حركة مخزون"),
    ("inventory:edit", "inventory", "تعديل حركة مخزون"),
    ("inventory:adjust", "inventory", "تسوية مخزون يدوية"),
    ("inventory:transfer", "inventory", "تحويل مخزون بين مخازن"),
    ("inventory:post", "inventory", "ترحيل حركة مخزون"),
    ("inventory:approve", "inventory", "اعتماد التسويات والتحويلات المخزنية"),
    ("core:documents", "core", "إدارة المستندات المرفقة"),
    ("core:workflow", "core", "إدارة سير العمل والموافقات"),
    ("core:notifications", "core", "إدارة الإشعارات"),
    ("core:manage", "core", "إدارة إعدادات النظام الأساسية"),
    ("construction:view", "construction", "عرض مراكز قيادة ومؤشرات المشروعات"),
    ("construction:manage", "construction", "إدارة بيانات ومشروعات الإنشاءات"),
    ("construction:approve", "construction", "اعتماد القياسات والتغييرات وشهادات الإنجاز"),    ("hr:view", "hr", "عرض الموارد البشرية"),
    ("hr:create", "hr", "إنشاء سجلات الموارد البشرية"),
    ("hr:edit", "hr", "تعديل سجلات الموارد البشرية"),
    ("hr:approve", "hr", "اعتماد الموارد البشرية والرواتب"),
    ("hr:payroll", "hr", "إدارة كشوف الرواتب"),
    ("hr:access", "hr", "إدارة المستخدمين والأدوار ونطاقات الوصول"),
    ("hr:documents", "hr", "إدارة مستندات الموظفين"),
    ("project:scope", "construction", "تقييد الوصول حسب المشروع والموقع"),
    ("documents:view", "documents", "عرض سجل ومستندات المشروع"),
    ("documents:create", "documents", "إنشاء وإصدار مستندات ومراسلات المشروع"),
    ("documents:edit", "documents", "تعديل حالة وبيانات المستندات"),
    ("documents:approve", "documents", "اعتماد ومراجعة المستندات"),
    ("admin:role_assign", "admin", "تعيين الأدوار الوظيفية ونطاقاتها"),
]


def ensure_default_permissions(db: Session):
    """CRITICAL FIX: the Permission table was never seeded anywhere in this
    codebase. route_permission() and _has_permission() reference ~30
    permission codes (sales:view, journal:post, etc.), but zero Permission
    rows ever existed for them to match against -- which meant
    _has_permission() returned False unconditionally for every user,
    INCLUDING admins (whose system_admin role is granted "all permission
    rows that currently exist in the Permission table", i.e. none). In
    practice this meant every permission-gated page in the entire app
    (sales, purchases, inventory, accounting, finance, enterprise...)
    returned 403 for literally everyone, including a freshly bootstrapped
    admin. This was invisible to the 42 shipped tests because none of them
    exercise the HTTP/middleware layer where route_permission is enforced --
    it only surfaced under a real TestClient HTTP request (see
    tests/test_http_regression.py). Safe/idempotent to call on every
    startup: it only inserts codes that don't already exist."""
    existing = {p.code for p in db.query(Permission.code).all()}
    created = False
    for code, _module_key, description in DEFAULT_PERMISSION_CODES:
        if code not in existing:
            db.add(Permission(code=code, description=description, is_active=True))
            created = True
    if created:
        db.commit()


_ctx = contextvars.ContextVar("erp_governance_context", default={})


logger = logging.getLogger(__name__)

def set_request_context(**values):
    current = dict(_ctx.get())
    current.update(values)
    _ctx.set(current)


def get_request_context():
    return _ctx.get()


def clear_request_context():
    _ctx.set({})


def _json_safe(value):
    if isinstance(value, Decimal): return str(value)
    if isinstance(value, (datetime.datetime, datetime.date)): return value.isoformat()
    if isinstance(value, (str, int, float, bool)) or value is None: return value
    if isinstance(value, dict): return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [_json_safe(v) for v in value]
    return str(value)


_AUDIT_REDACT_KEYS = {"password", "password_hash", "hashed_password", "secret", "secret_key", "token", "access_token", "refresh_token", "token_hash", "api_key", "private_key", "signature_hash"}

def _snapshot(obj):
    try:
        insp = __import__("sqlalchemy").inspect(obj)
        data = {}
        for attr in insp.mapper.column_attrs:
            key = attr.key
            if key.lower() in _AUDIT_REDACT_KEYS or any(x in key.lower() for x in ("password_hash", "token_hash", "private_key")):
                data[key] = "[REDACTED]"
                continue
            try:
                data[key] = _json_safe(getattr(obj, key))
            except Exception:
                logger.exception("Failed to snapshot audit attribute %s.%s", obj.__class__.__name__, key)
        return data
    except Exception:
        return {}


def _has_permission(db, user_id, code, company_id=None, branch_id=None):
    user = db.get(User, user_id)
    if not user or not user.is_active: return False
    # System administrators are the global RBAC super-role. This mirrors
    # require_module() and prevents route-level RBAC from accidentally denying
    # the administrator when a role/branch assignment is being migrated.
    if user.role == RoleEnum.admin:
        return True
    stmt = (select(Permission.id)
            .join(RolePermission, RolePermission.permission_id == Permission.id)
            .join(UserRole, UserRole.role_id == RolePermission.role_id)
            .join(Role, Role.id == UserRole.role_id)
            .where(UserRole.user_id == user_id, UserRole.is_active.is_(True),
                   Role.is_active.is_(True), Permission.code == code, Permission.is_active.is_(True)))
    if company_id is not None:
        stmt = stmt.where((UserRole.company_id == company_id) | (UserRole.company_id.is_(None)))
    if branch_id is not None:
        stmt = stmt.where((UserRole.branch_id == branch_id) | (UserRole.branch_id.is_(None)))
    return db.execute(stmt.limit(1)).first() is not None



def scope_allows(db, user_id, company_id=None, branch_id=None, project_id=None, site_id=None, write=False):
    """Optional fine-grained project/site scope. No rows means legacy unrestricted access.
    A row with NULL at a dimension is a wildcard for that dimension. Admin users bypass it.
    """
    from .hr_models import UserScope
    user=db.get(User,user_id)
    if not user or not user.is_active: return False
    if user.role == RoleEnum.admin: return True
    q=db.query(UserScope).filter(UserScope.user_id==user_id)
    rows=q.all()
    if not rows: return True
    for r in rows:
        if company_id is not None and r.company_id not in (None, company_id): continue
        if branch_id is not None and r.branch_id not in (None, branch_id): continue
        if project_id is not None and r.project_id not in (None, project_id): continue
        if site_id is not None and r.site_id not in (None, site_id): continue
        if write and not r.can_edit: continue
        if not write and not r.can_view: continue
        return True
    return False

def require_permission(code: str):
    from .auth import get_current_user
    def dependency(request: Request, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
        ctx = get_request_context()
        company_id, branch_id = ctx.get("company_id"), ctx.get("branch_id")
        if not _has_permission(db, user.id, code, company_id, branch_id):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"Missing permission: {code}")
        return user
    return dependency


def resolve_tenant(db: Session, user: User, company_id=None, branch_id=None):
    """Resolve and validate tenant scope exclusively from server-side access records.

    A client may request a company/branch context, but it can never grant itself access.
    If a user has multiple branch-only grants, a branch header is mandatory to avoid
    accidentally selecting an arbitrary branch.
    """
    requested_company = int(company_id) if company_id is not None else None
    requested_branch = int(branch_id) if branch_id is not None else None

    stmt = select(UserCompanyAccess).where(UserCompanyAccess.user_id == user.id)
    if requested_company is not None:
        stmt = stmt.where(UserCompanyAccess.company_id == requested_company)
    if requested_branch is not None:
        stmt = stmt.where(UserCompanyAccess.branch_id == requested_branch)
    accesses = db.execute(stmt.order_by(UserCompanyAccess.id)).scalars().all()

    if user.role == RoleEnum.admin and not accesses:
        # Administrators still need an explicit tenant record after Phase 4.
        raise HTTPException(403, "No company access is assigned to this user")
    if not accesses:
        # System administrators may bootstrap/repair tenant access. For an explicit
        # company request, allow an active company even if its access row is stale;
        # branch requests still require a real active branch.
        if user.role == RoleEnum.admin and requested_company is not None:
            company = db.get(Company, requested_company)
            if company and company.is_active:
                if requested_branch is None:
                    return company.id, None
                branch = db.get(Branch, requested_branch)
                if branch and branch.is_active and branch.company_id == company.id:
                    return company.id, branch.id
        raise HTTPException(403, "Company/branch access denied")

    if requested_company is not None or requested_branch is not None:
        access = accesses[0]
        resolved_company = access.company_id
        resolved_branch = access.branch_id
        if requested_branch is not None and resolved_branch != requested_branch:
            raise HTTPException(403, "Branch access denied")
    else:
        # Prefer a company-wide grant (branch NULL). Otherwise require the caller to
        # select a branch when more than one branch-only grant exists.
        company_wide = [a for a in accesses if a.branch_id is None]
        if company_wide:
            resolved_company, resolved_branch = company_wide[0].company_id, None
        elif len(accesses) == 1:
            resolved_company, resolved_branch = accesses[0].company_id, accesses[0].branch_id
        else:
            raise HTTPException(400, "Branch context is required for this user")

    company = db.get(Company, resolved_company)
    if not company or not company.is_active:
        raise HTTPException(403, "Invalid or inactive company context")
    if resolved_branch is not None:
        branch = db.get(Branch, resolved_branch)
        if not branch or not branch.is_active or branch.company_id != resolved_company:
            raise HTTPException(403, "Invalid or inactive branch context")
    return resolved_company, resolved_branch

def get_tenant_context(request: Request, db: Session = Depends(get_db)):
    user = getattr(request.state, "user", None)
    if user is None:
        raise HTTPException(401, "Authentication required")
    company_id = request.headers.get("X-Company-ID")
    branch_id = request.headers.get("X-Branch-ID")
    company_id = int(company_id) if company_id else None
    branch_id = int(branch_id) if branch_id else None
    company_id, branch_id = resolve_tenant(db, user, company_id, branch_id)
    set_request_context(user_id=user.id, company_id=company_id, branch_id=branch_id)
    return {"user": user, "company_id": company_id, "branch_id": branch_id}


def audit_write_event(session, flush_context, instances=None):
    ctx = get_request_context()
    if session.info.get("governance_audit_in_progress"): return
    if not ctx.get("request_id"): return
    records = []
    # Stamp tenant scope before audit snapshots so the recorded after-state is authoritative.
    company_id, branch_id = ctx.get("company_id"), ctx.get("branch_id")
    if company_id is not None:
        for obj in list(session.new):
            if hasattr(obj, "company_id") and getattr(obj, "company_id", None) is None:
                try:
                    setattr(obj, "company_id", company_id)
                except Exception as exc:
                    raise RuntimeError(f"Failed to stamp tenant company_id on {obj.__class__.__name__}") from exc
            # Chart-of-Accounts rows are company-wide by default. A branch-specific
            # account must be assigned explicitly by the accounting service/UI;
            # silently stamping the current branch would duplicate/split the COA.
            if (obj.__class__.__name__ != "Account" and hasattr(obj, "branch_id")
                    and getattr(obj, "branch_id", None) is None and branch_id is not None):
                try:
                    setattr(obj, "branch_id", branch_id)
                except Exception as exc:
                    raise RuntimeError(f"Failed to stamp tenant branch_id on {obj.__class__.__name__}") from exc
    for obj in list(session.new):
        if isinstance(obj, GovernanceAuditLog): continue
        records.append(("create", obj, {}, _snapshot(obj)))
    for obj in list(session.dirty):
        if isinstance(obj, GovernanceAuditLog) or not session.is_modified(obj, include_collections=False): continue
        insp = __import__('sqlalchemy').inspect(obj)
        before = {}
        for attr in insp.mapper.column_attrs:
            hist = insp.attrs[attr.key].history
            if hist.has_changes(): before[attr.key] = _json_safe(hist.deleted[0] if hist.deleted else None)
        records.append(("update", obj, before, _snapshot(obj)))
    for obj in list(session.deleted):
        if isinstance(obj, GovernanceAuditLog): continue
        records.append(("delete", obj, _snapshot(obj), {}))
    if not records: return
    session.info["governance_audit_in_progress"] = True
    try:
        for action, obj, before, after in records:
            entity_id = getattr(obj, "id", None)
            changes = {}
            for k in set(before) | set(after):
                if before.get(k) != after.get(k): changes[k] = {"before": before.get(k), "after": after.get(k)}
            session.add(GovernanceAuditLog(user_id=ctx.get("user_id"), company_id=ctx.get("company_id"), branch_id=ctx.get("branch_id"), request_id=ctx.get("request_id"), action=action, entity_type=obj.__class__.__name__, entity_id=str(entity_id) if entity_id is not None else None, ip_address=ctx.get("ip_address"), before_json=before, after_json=after, changes_json=changes))
    finally:
        session.info["governance_audit_in_progress"] = False


event.listen(Session, "before_flush", audit_write_event)

# Central row-level filtering for any mapped class exposing company_id.
@event.listens_for(Session, "do_orm_execute")
def _tenant_filter(execute_state):
    if not execute_state.is_select and not execute_state.is_update and not execute_state.is_delete:
        return
    ctx = get_request_context()
    company_id = ctx.get("company_id")
    branch_id = ctx.get("branch_id")
    if company_id is None or execute_state.execution_options.get("skip_tenant_filter"):
        return

    # Apply isolation to every mapped class carrying tenant dimensions.
    # Company-wide records (branch_id NULL) remain visible inside the company;
    # branch-scoped records are restricted to the active branch.
    for mapper in list(Base.registry.mappers):
        cls = mapper.class_
        if not hasattr(cls, "company_id"):
            continue
        # Keep tenant ids as real closure variables so SQLAlchemy's lambda SQL
        # cache tracks the current tenant instead of accidentally reusing the
        # first company/branch seen by the process. This is critical for both
        # production multi-tenant isolation and test isolation.
        if branch_id is not None and hasattr(cls, "branch_id"):
            criteria = lambda c: (c.company_id == company_id) & ((c.branch_id == branch_id) | (c.branch_id.is_(None)))
        else:
            criteria = lambda c: c.company_id == company_id
        execute_state.statement = execute_state.statement.options(
            with_loader_criteria(cls, criteria, include_aliases=True)
        )

# Audit logs are append-only. Any attempt to modify/delete them through the ORM
# is rejected before the transaction can commit.
@event.listens_for(Session, "before_flush", propagate=True)
def _protect_audit_log(session, flush_context, instances=None):
    for obj in list(session.dirty) + list(session.deleted):
        if isinstance(obj, GovernanceAuditLog):
            raise HTTPException(409, "Audit logs are immutable")


def route_permission(method: str, path: str):
    """Central endpoint-to-permission policy used by the HTTP governance layer."""
    if path.startswith("/api/v1/health") or path.startswith("/login") or path.startswith("/logout"):
        return None
    if path.startswith("/api/v1/document-controller"):
        if "/approve" in path: return "documents:approve"
        if method == "GET": return "documents:view"
        return "documents:create" if method == "POST" else "documents:edit"

    if path.startswith("/api/v1/hr"):
        if "/payroll/" in path and "/post-to-accounting" in path: return "hr:payroll"
        if "/payroll/" in path and "/allocate" in path: return "hr:payroll"
        if "/payroll" in path and method != "GET": return "hr:payroll"
        if "/roles" in path or "/permissions" in path or "/users/roles" in path or "/users/scopes" in path or "/access/" in path: return "hr:access"
        if "/approve" in path: return "hr:approve"
        if method == "GET": return "hr:view"
        return "hr:create" if method == "POST" else "hr:edit"
    if path.startswith("/api/v1/construction"):
        if path.endswith("/approve") or "/approve" in path: return "construction:approve"
        return "reports:view" if method == "GET" else "construction:manage"
    if path.startswith("/admin/organization"):
        return "admin:tenants"
    if path == "/users" or path == "/users/create" or path.startswith("/users/"):
        return "admin:permissions" if path.endswith("/permissions") else "admin:users"
    if path.startswith("/enterprise/reversals"):
        return "journal:view" if method == "GET" else "journal:reverse"
    if path.startswith("/enterprise/journal/") and path.endswith("/reverse"):
        return "journal:reverse"
    if path.startswith("/accounting/journal"):
        return "journal:view" if method == "GET" else "journal:post"
    if path.startswith("/accounting/reports") or path.startswith("/enterprise/cash-flow"):
        return "reports:view"
    if "/audit" in path:
        return "audit:view"
    if path.startswith("/sales"):
        if method == "GET": return "sales:view"
        if "/reverse" in path: return "sales:reverse"
        if "/cancel" in path: return "sales:cancel"
        return "sales:create" if method == "POST" else "sales:edit"
    if path.startswith("/purchases"):
        if method == "GET": return "purchases:view"
        if "/reverse" in path: return "purchases:reverse"
        if "/cancel" in path: return "purchases:cancel"
        return "purchases:create" if method == "POST" else "purchases:edit"
    if path.startswith("/inventory"):
        if method == "GET": return "inventory:view"
        if "/movement" in path: return "inventory:adjust"
        return "inventory:create" if method == "POST" else "inventory:edit"
    if path.startswith("/advanced-finance") or path.startswith("/finance") or path.startswith("/pro-finance"):
        if method == "GET": return "reports:view" if "/report" in path else "journal:view"
        return "journal:post"
    if path.startswith("/enterprise"):
        if method == "GET": return "reports:view"
        return "journal:post"
    if path == "/api/v1/deep-transactions/reconcile":
        return "journal:post"
    if path.startswith("/api/v1/deep-transactions/purchase-orders"):
        return "purchases:post"
    if path.startswith("/api/v1/deep-transactions/sales-invoices"):
        return "sales:reverse"
    if path.startswith("/api/v1/deep-transactions/purchase-invoices"):
        return "purchases:reverse"
    if path.startswith("/api/v1/deep-transactions"):
        return "reports:view" if method == "GET" else "reports:view"
    if path.startswith("/api/v1/transactions/sales-orders"):
        if method == "GET": return "sales:view"
        if path.endswith("/confirm") or path.endswith("/invoice"): return "sales:post"
        if path.endswith("/deliver"): return "inventory:post"
        return "sales:create"
    if path.startswith("/api/v1/transactions/sales-deliveries"):
        return "sales:post" if method != "GET" else "sales:view"
    if path.startswith("/api/v1/transactions/purchase-invoices"):
        if method == "GET": return "purchases:view"
        if path.endswith("/payments"): return "purchases:post"
        return "purchases:post"
    if path.startswith("/api/v1/transactions/sales-invoices"):
        if method == "GET": return "sales:view"
        return "sales:post"
    if path.startswith("/api/v1/core/documents"):
        return "core:documents"
    if path.startswith("/api/v1/core/workflows"):
        return "core:workflow"
    if path.startswith("/api/v1/core/notifications"):
        return "core:notifications" if method != "GET" else "reports:view"
    if path.startswith("/api/v1/core"):
        return "reports:view" if method == "GET" else "core:manage"
    if path.startswith("/api/v1"):
        return "reports:view" if method == "GET" else "admin:tenants"
    return None

def fingerprint_request(method, path, body):
    raw = json.dumps({"method": method, "path": path, "body": body}, sort_keys=True, default=str).encode()
    return hashlib.sha256(raw).hexdigest()


def new_request_id(): return uuid.uuid4().hex

# Automatically stamp tenant scope on newly-created tenant-aware records.
@event.listens_for(Session, "before_flush", propagate=True)
def _stamp_new_tenant_records(session, flush_context, instances=None):
    ctx = get_request_context()
    company_id, branch_id = ctx.get("company_id"), ctx.get("branch_id")
    if company_id is None: return

    # Defense in depth for every ORM write: client-supplied company_id/branch_id
    # values must never be able to move a record outside the authenticated tenant
    # context. This catches JSON bodies that contain an explicit company_id even
    # when an individual endpoint forgot to copy the value from get_tenant_context().
    for obj in list(session.new) + list(session.dirty):
        if isinstance(obj, GovernanceAuditLog): continue
        if hasattr(obj, "company_id"):
            obj_company = getattr(obj, "company_id", None)
            if obj_company is None:
                try:
                    setattr(obj, "company_id", company_id)
                except Exception as exc:
                    raise RuntimeError(f"Failed to stamp tenant company_id on {obj.__class__.__name__}") from exc
            elif obj_company != company_id:
                raise HTTPException(403, "Tenant boundary violation: company does not match the active context")
        if hasattr(obj, "branch_id"):
            obj_branch = getattr(obj, "branch_id", None)
            if branch_id is not None:
                if obj_branch is None:
                    # A NULL branch means company-wide and is intentionally allowed.
                    pass
                elif obj_branch != branch_id:
                    raise HTTPException(403, "Tenant boundary violation: branch does not match the active context")


def ensure_role_catalog(db: Session):
    """Idempotently seed the approved enterprise job roles and their permissions."""
    from .role_catalog import ROLE_CATALOG
    existing_permissions = {p.code: p for p in db.query(Permission).all()}
    for role_spec in ROLE_CATALOG:
        role = db.query(Role).filter(Role.code == role_spec["code"]).first()
        if not role:
            role = Role(code=role_spec["code"], name=role_spec["name"], is_system=role_spec["code"] in {"master_admin","system_admin"}, is_active=True)
            db.add(role); db.flush()
        else:
            role.name = role_spec["name"]; role.is_active = True
        for code in role_spec["permissions"]:
            perm = existing_permissions.get(code)
            if not perm:
                perm = Permission(code=code, description=code, is_active=True); db.add(perm); db.flush(); existing_permissions[code] = perm
            if not db.query(RolePermission).filter_by(role_id=role.id, permission_id=perm.id).first():
                db.add(RolePermission(role_id=role.id, permission_id=perm.id))
    db.commit()
