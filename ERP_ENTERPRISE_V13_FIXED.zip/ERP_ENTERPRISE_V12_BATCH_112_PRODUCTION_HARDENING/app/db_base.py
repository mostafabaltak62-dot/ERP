"""SQLAlchemy declarative metadata without runtime engine initialization.

Alembic imports this module to discover metadata without requiring DATABASE_URL or
other production secrets. Runtime engine/session creation stays in app.database.
"""
from sqlalchemy.orm import declarative_base

Base = declarative_base()
