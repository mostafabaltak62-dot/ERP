from .time_utils import utcnow
"""Field operations domain models for equipment, variations, requisitions and integration."""
from datetime import datetime
from sqlalchemy import Column, Integer, String, Numeric, Date, DateTime, ForeignKey, Boolean, Text, JSON, UniqueConstraint, CheckConstraint, Index
from .db_base import Base


class EquipmentLog(Base):
    __tablename__ = 'equipment_logs'
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    equipment_id = Column(Integer, ForeignKey('equipment.id', ondelete='CASCADE'), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey('projects.id', ondelete='CASCADE'), nullable=False, index=True)
    site_id = Column(Integer, ForeignKey('construction_sites.id', ondelete='SET NULL'), nullable=True, index=True)
    wbs_id = Column(Integer, ForeignKey('construction_wbs_nodes.id', ondelete='SET NULL'), nullable=True, index=True)
    cost_code_id = Column(Integer, ForeignKey('construction_cost_codes.id', ondelete='SET NULL'), nullable=True, index=True)
    work_date = Column(Date, nullable=False, index=True)
    start_reading = Column(Numeric(20, 6), nullable=False)
    end_reading = Column(Numeric(20, 6), nullable=False)
    hours = Column(Numeric(20, 6), nullable=False)
    estimated_hourly_cost = Column(Numeric(20, 6), nullable=False)
    estimated_cost = Column(Numeric(20, 6), nullable=False)
    fuel_cost = Column(Numeric(20, 6), nullable=False, default=0)
    maintenance_cost = Column(Numeric(20, 6), nullable=False, default=0)
    other_actual_cost = Column(Numeric(20, 6), nullable=False, default=0)
    actual_cost = Column(Numeric(20, 6), nullable=False)
    actual_hourly_cost = Column(Numeric(20, 6), nullable=False)
    variance_amount = Column(Numeric(20, 6), nullable=False)
    status = Column(String(30), nullable=False, default='draft')
    notes = Column(Text)
    project_cost_id = Column(Integer, ForeignKey('project_costs.id', ondelete='SET NULL'), unique=True)
    created_by_id = Column(Integer, ForeignKey('users.id', ondelete='SET NULL'))
    created_at = Column(DateTime, default=utcnow, nullable=False)
    __table_args__ = (
        CheckConstraint('end_reading >= start_reading', name='ck_equipment_log_reading_order'),
        CheckConstraint('hours > 0', name='ck_equipment_log_hours_positive'),
        CheckConstraint('estimated_hourly_cost >= 0 AND estimated_cost >= 0 AND fuel_cost >= 0 AND maintenance_cost >= 0 AND other_actual_cost >= 0 AND actual_cost >= 0', name='ck_equipment_log_costs_nonnegative'),
    )


class EquipmentCostEntry(Base):
    __tablename__ = 'equipment_cost_entries'
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    equipment_id = Column(Integer, ForeignKey('equipment.id', ondelete='CASCADE'), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey('projects.id', ondelete='CASCADE'), nullable=False, index=True)
    site_id = Column(Integer, ForeignKey('construction_sites.id', ondelete='SET NULL'))
    equipment_log_id = Column(Integer, ForeignKey('equipment_logs.id', ondelete='SET NULL'), index=True)
    source_type = Column(String(40), nullable=False)
    source_id = Column(Integer)
    entry_date = Column(Date, nullable=False)
    quantity = Column(Numeric(20, 6), nullable=True)
    unit_cost = Column(Numeric(20, 6), nullable=True)
    amount = Column(Numeric(20, 6), nullable=False)
    status = Column(String(30), nullable=False, default='posted')
    project_cost_id = Column(Integer, ForeignKey('project_costs.id', ondelete='SET NULL'), unique=True)
    description = Column(Text)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    __table_args__ = (CheckConstraint('amount >= 0', name='ck_equipment_cost_entry_amount_nonnegative'),)


class VariationAmendment(Base):
    __tablename__ = 'variation_amendments'
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    variation_id = Column(Integer, ForeignKey('construction_variations.id', ondelete='CASCADE'), nullable=False, index=True)
    amendment_no = Column(String(60), nullable=False)
    approved_amount = Column(Numeric(20, 6), nullable=False)
    time_extension_days = Column(Integer, nullable=False, default=0)
    approved_at = Column(DateTime)
    approved_by_id = Column(Integer, ForeignKey('users.id', ondelete='SET NULL'))
    status = Column(String(30), nullable=False, default='draft')
    document_id = Column(Integer, ForeignKey('project_documents.id', ondelete='SET NULL'))
    __table_args__ = (UniqueConstraint('company_id', 'amendment_no', name='uq_variation_amendment_company_no'),)


class SiteMaterialRequisition(Base):
    __tablename__ = 'site_material_requisitions'
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey('projects.id', ondelete='CASCADE'), nullable=False, index=True)
    site_id = Column(Integer, ForeignKey('construction_sites.id', ondelete='SET NULL'), nullable=True, index=True)
    requisition_no = Column(String(80), nullable=False)
    requested_by_id = Column(Integer, ForeignKey('users.id', ondelete='SET NULL'))
    required_date = Column(Date)
    purpose = Column(Text)
    status = Column(String(30), nullable=False, default='draft')
    approved_by_id = Column(Integer, ForeignKey('users.id', ondelete='SET NULL'))
    approved_at = Column(DateTime)
    fulfillment_type = Column(String(30))
    fulfillment_reference = Column(String(100))
    created_at = Column(DateTime, default=utcnow, nullable=False)
    __table_args__ = (UniqueConstraint('company_id', 'requisition_no', name='uq_site_material_requisition_company_no'),)


class SiteMaterialRequisitionLine(Base):
    __tablename__ = 'site_material_requisition_lines'
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    requisition_id = Column(Integer, ForeignKey('site_material_requisitions.id', ondelete='CASCADE'), nullable=False, index=True)
    item_id = Column(Integer, ForeignKey('items.id', ondelete='RESTRICT'), nullable=False, index=True)
    boq_line_id = Column(Integer, ForeignKey('construction_boq_lines.id', ondelete='SET NULL'), nullable=True, index=True)
    wbs_id = Column(Integer, ForeignKey('construction_wbs_nodes.id', ondelete='SET NULL'), nullable=True, index=True)
    cost_code_id = Column(Integer, ForeignKey('construction_cost_codes.id', ondelete='SET NULL'), nullable=True, index=True)
    requested_qty = Column(Numeric(20, 6), nullable=False)
    approved_qty = Column(Numeric(20, 6), nullable=True)
    fulfilled_qty = Column(Numeric(20, 6), nullable=False, default=0)
    estimated_unit_cost = Column(Numeric(20, 6), nullable=False, default=0)
    estimated_amount = Column(Numeric(20, 6), nullable=False, default=0)
    budget_qty = Column(Numeric(20, 6), nullable=True)
    budget_amount = Column(Numeric(20, 6), nullable=True)
    notes = Column(Text)
    __table_args__ = (CheckConstraint('requested_qty > 0', name='ck_site_req_qty_positive'), CheckConstraint('fulfilled_qty >= 0', name='ck_site_req_fulfilled_nonnegative'))


class OfflineSyncBatch(Base):
    __tablename__ = 'offline_sync_batches'
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    device_id = Column(String(120), nullable=False)
    batch_id = Column(String(120), nullable=False)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='SET NULL'))
    client_created_at = Column(DateTime)
    received_at = Column(DateTime, default=utcnow, nullable=False)
    status = Column(String(30), nullable=False, default='received')
    __table_args__ = (UniqueConstraint('company_id', 'device_id', 'batch_id', name='uq_offline_batch_device'),)


class OfflineSyncOperation(Base):
    __tablename__ = 'offline_sync_operations'
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    batch_id = Column(Integer, ForeignKey('offline_sync_batches.id', ondelete='CASCADE'), nullable=False, index=True)
    operation_id = Column(String(120), nullable=False)
    entity_type = Column(String(80), nullable=False)
    entity_id = Column(Integer)
    operation = Column(String(20), nullable=False)
    payload = Column(JSON, nullable=False)
    client_version = Column(Integer, nullable=False, default=1)
    server_version = Column(Integer)
    status = Column(String(30), nullable=False, default='pending')
    conflict_code = Column(String(60))
    conflict_detail = Column(Text)
    processed_at = Column(DateTime)
    __table_args__ = (UniqueConstraint('company_id', 'operation_id', name='uq_offline_operation_company'),)


class OfflineConflict(Base):
    __tablename__ = 'offline_conflicts'
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    operation_id = Column(Integer, ForeignKey('offline_sync_operations.id', ondelete='CASCADE'), nullable=False, index=True)
    entity_type = Column(String(80), nullable=False)
    entity_id = Column(Integer)
    server_version = Column(Integer)
    client_version = Column(Integer)
    resolution = Column(String(30), nullable=False, default='manual')
    resolved_by_id = Column(Integer, ForeignKey('users.id', ondelete='SET NULL'))
    resolved_at = Column(DateTime)
    detail = Column(Text)


class WebhookSubscription(Base):
    __tablename__ = 'webhook_subscriptions'
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    name = Column(String(150), nullable=False)
    endpoint_url = Column(String(500), nullable=False)
    secret = Column(String(255), nullable=False)
    event_type = Column(String(100), nullable=False, index=True)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)


class WebhookDelivery(Base):
    __tablename__ = 'webhook_deliveries'
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    subscription_id = Column(Integer, ForeignKey('webhook_subscriptions.id', ondelete='CASCADE'), nullable=False, index=True)
    event_id = Column(String(120), nullable=False)
    event_type = Column(String(100), nullable=False)
    payload = Column(JSON, nullable=False)
    status = Column(String(30), nullable=False, default='pending')
    attempts = Column(Integer, nullable=False, default=0)
    last_error = Column(Text)
    delivered_at = Column(DateTime)
    next_attempt_at = Column(DateTime)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    __table_args__ = (UniqueConstraint('subscription_id', 'event_id', name='uq_webhook_delivery_event'),)

class LicenseRegister(Base):
    __tablename__ = 'license_register'
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey('companies.id', ondelete='CASCADE'), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey('projects.id', ondelete='SET NULL'), nullable=True, index=True)
    site_id = Column(Integer, ForeignKey('construction_sites.id', ondelete='SET NULL'), nullable=True, index=True)
    equipment_id = Column(Integer, ForeignKey('equipment.id', ondelete='SET NULL'), nullable=True, index=True)
    license_type = Column(String(100), nullable=False)
    license_number = Column(String(120), nullable=False)
    issue_date = Column(Date)
    expiry_date = Column(Date, nullable=False, index=True)
    reminder_days = Column(Integer, nullable=False, default=30)
    status = Column(String(30), nullable=False, default='active')
    document_id = Column(Integer, ForeignKey('project_documents.id', ondelete='SET NULL'))
    __table_args__ = (UniqueConstraint('company_id', 'license_number', name='uq_license_company_number'), CheckConstraint('reminder_days >= 0', name='ck_license_reminder_nonnegative'))
