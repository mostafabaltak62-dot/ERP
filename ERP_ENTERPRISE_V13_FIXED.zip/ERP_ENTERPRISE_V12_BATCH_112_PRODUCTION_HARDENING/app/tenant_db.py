"""Database-level tenant context for PostgreSQL RLS.

The application authorization layer remains responsible for deciding whether a
user may select a company/branch. This module publishes the already-authorized
context to the current DB transaction so PostgreSQL RLS becomes a second,
independent isolation boundary.
"""
from sqlalchemy import event
from sqlalchemy.orm import Session
from .database import engine
from .governance import get_request_context


@event.listens_for(Session, "after_begin")
def _set_postgres_rls_context(session, transaction, connection):
    if connection.dialect.name != "postgresql":
        return
    ctx = get_request_context()
    company_id = ctx.get("company_id")
    branch_id = ctx.get("branch_id")
    user_id = ctx.get("user_id")
    # Fail closed: empty string cannot be cast to integer by policies, so use a
    # sentinel that can never be a valid positive tenant id.
    company = str(company_id) if company_id is not None else "-1"
    branch = str(branch_id) if branch_id is not None else "-1"
    user = str(user_id) if user_id is not None else "-1"
    connection.exec_driver_sql(
        "SELECT set_config('app.company_id', %s, true), "
        "set_config('app.branch_id', %s, true), "
        "set_config('app.user_id', %s, true)",
        (company, branch, user),
    )
