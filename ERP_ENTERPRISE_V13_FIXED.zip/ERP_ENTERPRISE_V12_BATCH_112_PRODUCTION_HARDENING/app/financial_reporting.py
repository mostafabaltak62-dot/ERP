# -*- coding: utf-8 -*-
"""Authoritative financial reporting and validation engine.

All financial statements are derived from POSTED journal entries only.
The engine is tenant-aware and keeps the accounting equation as an explicit invariant.
"""
from datetime import date, datetime, time, timedelta
from decimal import Decimal, ROUND_HALF_UP
from sqlalchemy import and_, func, exists
from sqlalchemy.orm import Session

from .models import Account, AccountTypeEnum, JournalEntry, JournalLine, JournalLineCostCenter, CostCenter, PeriodClosingEntry
from .enterprise_models import Budget, BudgetLine

ZERO = Decimal("0")
Q = Decimal("0.01")


def money(v) -> Decimal:
    return Decimal(str(v or 0)).quantize(Q, rounding=ROUND_HALF_UP)


def _dt_start(d: date):
    return datetime.combine(d, time.min)


def _dt_end_exclusive(d: date):
    return datetime.combine(d, time.max)


def validate_dates(from_date: date | None, to_date: date | None):
    if from_date and to_date and from_date > to_date:
        raise ValueError("تاريخ البداية يجب ألا يتجاوز تاريخ النهاية")


def posted_lines_query(db: Session, company_id: int, branch_id: int | None = None):
    q = (db.query(JournalEntry, JournalLine, Account)
         .join(JournalLine, JournalLine.entry_id == JournalEntry.id)
         .join(Account, Account.id == JournalLine.account_id)
         .filter(
             JournalEntry.company_id == company_id,
             JournalLine.company_id == company_id,
             Account.company_id == company_id,
             JournalEntry.status == "posted",
         ))
    if branch_id is not None:
        q = q.filter(JournalEntry.branch_id == branch_id, JournalLine.branch_id == branch_id)
    return q


def trial_balance(db: Session, company_id: int, from_date: date | None = None, to_date: date | None = None, branch_id: int | None = None):
    """Return opening + period activity + closing balance for every active account.

    Uses two grouped aggregate queries instead of two queries per account, avoiding
    the classic N+1 pattern on large charts of accounts.
    """
    validate_dates(from_date, to_date)
    # Financial statements must retain historically used accounts even after an
    # account is deactivated. Otherwise a valid posted transaction can disappear
    # from the P&L/Trial Balance merely because the master record was retired.
    activity_exists = exists().where(
        JournalLine.account_id == Account.id,
        JournalLine.company_id == company_id,
        JournalLine.entry_id == JournalEntry.id,
        JournalEntry.company_id == company_id,
        JournalEntry.status == "posted",
    )
    if from_date:
        activity_exists = activity_exists.where(JournalEntry.entry_date >= _dt_start(from_date))
    if to_date:
        activity_exists = activity_exists.where(JournalEntry.entry_date <= _dt_end_exclusive(to_date))
    accounts_q = db.query(Account).filter(
        Account.company_id == company_id,
        (Account.is_active.is_(True) | activity_exists),
    )
    if branch_id is not None:
        accounts_q = accounts_q.filter((Account.branch_id == branch_id) | (Account.branch_id.is_(None)))
    accounts = accounts_q.order_by(Account.code, Account.branch_id.desc()).all()
    account_ids = [a.id for a in accounts]
    if not account_ids:
        return []

    base = (db.query(JournalLine.account_id,
                     func.coalesce(func.sum(JournalLine.debit), 0).label("debit"),
                     func.coalesce(func.sum(JournalLine.credit), 0).label("credit"))
            .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
            .filter(JournalEntry.company_id == company_id,
                    JournalLine.company_id == company_id,
                    JournalEntry.status == "posted",
                    JournalLine.account_id.in_(account_ids)))
    if branch_id is not None:
        base = base.filter(JournalEntry.branch_id == branch_id, JournalLine.branch_id == branch_id)

    opening = {}
    if from_date:
        od_rows = base.filter(JournalEntry.entry_date < _dt_start(from_date)).group_by(JournalLine.account_id).all()
        opening = {aid: (money(d), money(c)) for aid, d, c in od_rows}

    period_q = base
    if from_date:
        period_q = period_q.filter(JournalEntry.entry_date >= _dt_start(from_date))
    if to_date:
        period_q = period_q.filter(JournalEntry.entry_date <= _dt_end_exclusive(to_date))
    period_rows = period_q.group_by(JournalLine.account_id).all()
    period = {aid: (money(d), money(c)) for aid, d, c in period_rows}

    rows = []
    for acc in accounts:
        od, oc = opening.get(acc.id, (ZERO, ZERO)); pd, pc = period.get(acc.id, (ZERO, ZERO))
        opening_balance = money(od - oc); movement = money(pd - pc); closing = money(opening_balance + movement)
        rows.append({
            "account_id": acc.id, "code": acc.code, "name": acc.name,
            "account_type": acc.account_type.value,
            "normal_balance": acc.normal_balance or ("debit" if acc.account_type in (AccountTypeEnum.asset, AccountTypeEnum.expense) else "credit"),
            "statement_section": acc.statement_section or acc.account_type.value,
            "opening_debit": od, "opening_credit": oc, "opening_balance": opening_balance,
            "debit": pd, "credit": pc, "movement": movement, "closing_balance": closing,
        })
    return rows


def general_ledger(db: Session, company_id: int, from_date: date, to_date: date, account_id: int | None = None, branch_id: int | None = None):
    if from_date is None or to_date is None: raise ValueError("يجب تحديد تاريخ البداية والنهاية")
    validate_dates(from_date, to_date)
    q = posted_lines_query(db, company_id, branch_id).filter(
        JournalEntry.entry_date >= _dt_start(from_date), JournalEntry.entry_date <= _dt_end_exclusive(to_date))
    if account_id is not None:
        q = q.filter(Account.id == account_id)

    # One grouped opening-balance query replaces the previous per-account query.
    opening_q = (db.query(JournalLine.account_id,
                          func.coalesce(func.sum(JournalLine.debit), 0),
                          func.coalesce(func.sum(JournalLine.credit), 0))
                 .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
                 .filter(JournalEntry.company_id == company_id,
                         JournalLine.company_id == company_id,
                         JournalEntry.status == "posted",
                         JournalEntry.entry_date < _dt_start(from_date)))
    if branch_id is not None:
        opening_q = opening_q.filter(JournalEntry.branch_id == branch_id, JournalLine.branch_id == branch_id)
    if account_id is not None:
        opening_q = opening_q.filter(JournalLine.account_id == account_id)
    opening = {aid: money(d-c) for aid, d, c in opening_q.group_by(JournalLine.account_id).all()}

    rows = []
    running = dict(opening)
    for e, line, acc in q.order_by(JournalEntry.entry_date, JournalEntry.id, JournalLine.id).all():
        debit, credit = money(line.debit), money(line.credit)
        running[acc.id] = money(running.get(acc.id, ZERO) + debit - credit)
        rows.append({"entry_id": e.id, "entry_number": e.entry_number, "date": e.entry_date.date().isoformat(),
                     "account_id": acc.id, "account_code": acc.code, "account_name": acc.name,
                     "account_active": bool(acc.is_active),
                     "description": line.description or e.description, "source_type": e.source_type, "source_id": e.source_id,
                     "debit": debit, "credit": credit, "opening_balance": opening.get(acc.id, ZERO),
                     "running_balance": running[acc.id]})
    return rows


def profit_and_loss(db: Session, company_id: int, from_date: date, to_date: date, branch_id: int | None = None):
    if from_date is None or to_date is None: raise ValueError("يجب تحديد تاريخ البداية والنهاية")
    rows = trial_balance(db, company_id, from_date, to_date, branch_id)
    revenue_lines, expense_lines = [], []
    for r in rows:
        movement = r["movement"]
        if r["account_type"] == AccountTypeEnum.revenue.value:
            amount = money(-movement)
            if amount:
                revenue_lines.append({**r, "amount": amount})
        elif r["account_type"] == AccountTypeEnum.expense.value:
            amount = money(movement)
            if amount:
                expense_lines.append({**r, "amount": amount})
    revenue_total = money(sum((r["amount"] for r in revenue_lines), ZERO))
    expense_total = money(sum((r["amount"] for r in expense_lines), ZERO))
    gross_profit = money(revenue_total - sum((r["amount"] for r in expense_lines if r["statement_section"] == "cost_of_sales"), ZERO))
    operating_expenses = money(sum((r["amount"] for r in expense_lines if r["statement_section"] != "cost_of_sales"), ZERO))
    operating_profit = money(gross_profit - operating_expenses)
    gross_margin_pct = money((gross_profit / revenue_total * Decimal("100")) if revenue_total else ZERO)
    net_margin_pct = money((operating_profit / revenue_total * Decimal("100")) if revenue_total else ZERO)
    return {
        "from_date": from_date.isoformat(), "to_date": to_date.isoformat(),
        "revenue_lines": revenue_lines, "expense_lines": expense_lines,
        "revenue_total": revenue_total, "expense_total": expense_total,
        "revenue": revenue_total, "expenses": expense_total, "expenses_total": expense_total,
        "gross_profit": gross_profit, "gross_margin_pct": gross_margin_pct,
        "operating_expenses": operating_expenses,
        "operating_profit": operating_profit, "net_profit": operating_profit,
        "net_margin_pct": net_margin_pct,
    }



def budget_vs_actual(db: Session, company_id: int, budget_id: int, branch_id: int | None = None):
    """Authoritative monthly budget-vs-actual report for an accounting budget.

    Budget lines are scoped to the selected tenant/budget. Actuals come only from
    posted journals. Account balances are normalized to each account's normal
    balance so revenue/credit-normal accounts remain positive in management
    variance reports. Cost-center budget lines use posted analytical allocations;
    project-only lines without a cost-center cannot be reliably reconciled because
    JournalLine has no project dimension, so they are explicitly flagged rather
    than silently comparing against unrelated account activity.
    """
    b = db.query(Budget).filter(Budget.id == budget_id, Budget.company_id == company_id).first()
    if not b:
        raise ValueError("الموازنة غير موجودة ضمن نطاق الشركة الحالي")
    if branch_id is not None and b.branch_id not in (None, branch_id):
        raise ValueError("الموازنة غير موجودة ضمن نطاق الفرع الحالي")

    lines_q = db.query(BudgetLine).filter(BudgetLine.budget_id == b.id, BudgetLine.company_id == company_id)
    lines = lines_q.order_by(BudgetLine.period, BudgetLine.account_id, BudgetLine.cost_center_id, BudgetLine.project_id, BudgetLine.id).all()
    if not lines:
        return {"budget": b, "rows": [], "summary": {"budget": ZERO, "actual": ZERO, "forecast": ZERO, "variance": ZERO, "forecast_variance": ZERO}, "exceptions": []}

    account_ids = sorted({x.account_id for x in lines})
    accounts = {a.id: a for a in db.query(Account).filter(Account.company_id == company_id, Account.id.in_(account_ids)).all()}
    cc_ids = sorted({x.cost_center_id for x in lines if x.cost_center_id is not None})
    centers = {c.id: c for c in db.query(CostCenter).filter(CostCenter.company_id == company_id, CostCenter.id.in_(cc_ids)).all()} if cc_ids else {}

    # One aggregate for all posted account activity, avoiding N+1 queries.
    jq = (db.query(JournalLine.account_id,
                    func.extract("month", JournalEntry.entry_date).label("period"),
                    func.coalesce(func.sum(JournalLine.debit), 0).label("debit"),
                    func.coalesce(func.sum(JournalLine.credit), 0).label("credit"))
          .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
          .filter(JournalEntry.company_id == company_id, JournalLine.company_id == company_id,
                  JournalEntry.status == "posted", JournalLine.account_id.in_(account_ids)))
    if branch_id is not None:
        jq = jq.filter(JournalEntry.branch_id == branch_id, JournalLine.branch_id == branch_id)
    start = datetime(b.fiscal_year, 1, 1)
    end = datetime(b.fiscal_year + 1, 1, 1)
    jq = jq.filter(JournalEntry.entry_date >= start, JournalEntry.entry_date < end)
    account_actual = {(aid, int(period)): (Decimal(str(debit or 0)), Decimal(str(credit or 0)))
                      for aid, period, debit, credit in jq.group_by(JournalLine.account_id, func.extract("month", JournalEntry.entry_date)).all()}

    # Cost-center allocations are a separate analytical subledger. They are
    # summed by account+cost center so a budget line cannot consume another
    # center's actuals.
    alloc_actual = {}
    if cc_ids:
        aq = (db.query(JournalLine.account_id, JournalLineCostCenter.cost_center_id,
                       func.extract("month", JournalEntry.entry_date).label("period"),
                       func.coalesce(func.sum(JournalLine.debit), 0).label("debit"),
                       func.coalesce(func.sum(JournalLine.credit), 0).label("credit"),
                       func.coalesce(func.sum(JournalLineCostCenter.amount), 0).label("allocated"))
              .join(JournalLine, JournalLine.id == JournalLineCostCenter.journal_line_id)
              .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
              .filter(JournalLineCostCenter.company_id == company_id,
                      JournalLine.company_id == company_id, JournalEntry.company_id == company_id,
                      JournalEntry.status == "posted", JournalLine.account_id.in_(account_ids),
                      JournalLineCostCenter.cost_center_id.in_(cc_ids),
                      JournalEntry.entry_date >= start, JournalEntry.entry_date < end))
        if branch_id is not None:
            aq = aq.filter(JournalEntry.branch_id == branch_id, JournalLine.branch_id == branch_id)
        for aid, ccid, period, debit, credit, allocated in aq.group_by(JournalLine.account_id, JournalLineCostCenter.cost_center_id, func.extract("month", JournalEntry.entry_date)).all():
            alloc_actual[(aid, ccid, int(period))] = (Decimal(str(debit or 0)), Decimal(str(credit or 0)), Decimal(str(allocated or 0)))

    def normalized(account, debit, credit):
        normal = account.normal_balance or ("debit" if account.account_type in (AccountTypeEnum.asset, AccountTypeEnum.expense) else "credit")
        return money((debit - credit) if normal == "debit" else (credit - debit))

    rows = []; exceptions = []
    for x in lines:
        account = accounts.get(x.account_id)
        budget = money(x.budget_amount)
        forecast = money(x.forecast_amount if x.forecast_amount is not None else x.budget_amount)
        status = "reconciled"
        actual = ZERO
        if not account:
            status = "invalid_account"; exceptions.append({"line_id": x.id, "reason": "الحساب غير موجود ضمن الشركة"})
        elif x.project_id is not None and x.cost_center_id is None:
            status = "project_dimension_unavailable"
            exceptions.append({"line_id": x.id, "reason": "لا يمكن مطابقة فعلي المشروع بدقة لأن القيد المحاسبي لا يحمل project_id"})
        elif x.cost_center_id is not None and x.cost_center_id not in centers:
            status = "invalid_cost_center"
            exceptions.append({"line_id": x.id, "reason": "مركز التكلفة غير موجود ضمن الشركة"})
        elif x.cost_center_id is not None:
            d, c, allocated = alloc_actual.get((x.account_id, x.cost_center_id, x.period), (ZERO, ZERO, ZERO))
            # Allocation amount is magnitude; direction comes from the source journal line.
            signed_alloc = allocated if d >= c else -allocated
            actual = money(signed_alloc if (account.normal_balance or ("debit" if account.account_type in (AccountTypeEnum.asset, AccountTypeEnum.expense) else "credit")) == "debit" else -signed_alloc)
            if x.project_id is not None and centers[x.cost_center_id].project_id not in (None, x.project_id):
                status = "project_cost_center_mismatch"
                actual = ZERO
                exceptions.append({"line_id": x.id, "reason": "مركز التكلفة لا ينتمي إلى المشروع المحدد في بند الموازنة"})
        else:
            d, c = account_actual.get((x.account_id, x.period), (ZERO, ZERO)); actual = normalized(account, d, c)
        variance = money(actual - budget)
        forecast_variance = money(forecast - budget)
        rows.append({"line_id": x.id, "period": x.period, "account_id": x.account_id,
                     "account_name": account.name if account else f"#{x.account_id}",
                     "account_code": account.code if account else "—",
                     "cost_center_id": x.cost_center_id,
                     "cost_center_name": centers[x.cost_center_id].name if x.cost_center_id in centers else None,
                     "project_id": x.project_id, "budget": budget, "actual": actual,
                     "forecast": forecast, "variance": variance, "forecast_variance": forecast_variance,
                     "status": status})
    # Management totals keep the full budget/forecast visible, while actual and
    # variance totals include only lines whose accounting dimension was safely
    # reconciled. This prevents an unsupported project-only line from looking like
    # a zero actual and prevents false variances from entering the KPI strip.
    reconciled = [r for r in rows if r["status"] == "reconciled"]
    summary = {
        "budget": money(sum((r["budget"] for r in rows), ZERO)),
        "actual": money(sum((r["actual"] for r in reconciled), ZERO)),
        "forecast": money(sum((r["forecast"] for r in rows), ZERO)),
        "variance": money(sum((r["variance"] for r in reconciled), ZERO)),
        "forecast_variance": money(sum((r["forecast_variance"] for r in rows), ZERO)),
    }
    summary["unreconciled_budget"] = money(sum((r["budget"] for r in rows if r["status"] != "reconciled"), ZERO))
    return {"budget": b, "rows": rows, "summary": summary, "exceptions": exceptions}


def balance_sheet(db: Session, company_id: int, as_of_date: date, branch_id: int | None = None):
    rows = trial_balance(db, company_id, None, as_of_date, branch_id)
    assets, liabilities, equity = [], [], []
    for r in rows:
        closing = r["closing_balance"]
        if r["account_type"] == AccountTypeEnum.asset.value and closing:
            assets.append({**r, "amount": closing})
        elif r["account_type"] == AccountTypeEnum.liability.value and closing:
            liabilities.append({**r, "amount": money(-closing)})
        elif r["account_type"] == AccountTypeEnum.equity.value and closing:
            equity.append({**r, "amount": money(-closing)})
    # Only profit generated since the last fiscal close is presented as current-period
    # profit. Prior closed profits are already carried in equity through the closing entry.
    last_close_q = (db.query(JournalEntry)
                    .join(PeriodClosingEntry, PeriodClosingEntry.closing_entry_id == JournalEntry.id)
                    .filter(JournalEntry.company_id == company_id,
                            JournalEntry.status == "posted",
                            JournalEntry.entry_date <= _dt_end_exclusive(as_of_date)))
    if branch_id is not None:
        last_close_q = last_close_q.filter(JournalEntry.branch_id == branch_id)
    last_close = last_close_q.order_by(JournalEntry.entry_date.desc(), JournalEntry.id.desc()).first()
    profit_start = (last_close.entry_date.date() + timedelta(days=1)) if last_close else date.min
    pnl = profit_and_loss(db, company_id, profit_start, as_of_date, branch_id)
    current_profit = pnl["net_profit"]
    asset_total = money(sum((r["amount"] for r in assets), ZERO))
    liability_total = money(sum((r["amount"] for r in liabilities), ZERO))
    equity_accounts_total = money(sum((r["amount"] for r in equity), ZERO))
    equity_total = money(equity_accounts_total + current_profit)
    difference = money(asset_total - liability_total - equity_total)
    return {
        "as_of_date": as_of_date.isoformat(), "assets": assets, "liabilities": liabilities,
        "equity": equity, "current_profit": current_profit,
        "asset_total": asset_total, "liability_total": liability_total,
        "equity_accounts_total": equity_accounts_total, "equity_total": equity_total,
        "liability_equity_total": money(liability_total + equity_total),
        "difference": difference, "balanced": difference == ZERO,
    }


def cash_flow(db: Session, company_id: int, from_date: date, to_date: date, branch_id: int | None = None):
    """Authoritative cash-flow statement from posted journal entries.

    Cash/bank accounts are identified by statement_section='cash_and_equivalents'.
    Counterpart account mappings drive operating/investing/financing classification.
    This is transaction-based classification; it does not claim to be a formal
    IAS 7 indirect-method reconciliation.
    """
    if from_date is None or to_date is None: raise ValueError("يجب تحديد تاريخ البداية والنهاية")
    validate_dates(from_date, to_date)
    cash_q = db.query(Account).filter(
        Account.company_id == company_id,
        Account.statement_section == "cash_and_equivalents",
    )
    if branch_id is not None:
        cash_q = cash_q.filter((Account.branch_id == branch_id) | (Account.branch_id.is_(None)))
    cash_accounts = cash_q.all()
    cash_ids = {a.id for a in cash_accounts}
    operating = ZERO; investing = ZERO; financing = ZERO
    opening = ZERO; closing = ZERO
    rows = []
    mapping_exceptions = []
    # Cash balance before period and at period end.
    for acc in cash_accounts:
        oq = posted_lines_query(db, company_id, branch_id).filter(Account.id == acc.id, JournalEntry.entry_date < _dt_start(from_date))
        od, oc = oq.with_entities(func.coalesce(func.sum(JournalLine.debit),0), func.coalesce(func.sum(JournalLine.credit),0)).one()
        cq = posted_lines_query(db, company_id, branch_id).filter(Account.id == acc.id, JournalEntry.entry_date <= _dt_end_exclusive(to_date))
        cd, cc = cq.with_entities(func.coalesce(func.sum(JournalLine.debit),0), func.coalesce(func.sum(JournalLine.credit),0)).one()
        opening += Decimal(str(od or 0)) - Decimal(str(oc or 0))
        closing += Decimal(str(cd or 0)) - Decimal(str(cc or 0))

    q = posted_lines_query(db, company_id, branch_id).filter(
        JournalEntry.entry_date >= _dt_start(from_date), JournalEntry.entry_date <= _dt_end_exclusive(to_date),
    )
    entries = {}
    for e, line, acc in q.order_by(JournalEntry.entry_date, JournalEntry.id, JournalLine.id).all():
        entries.setdefault(e.id, []).append((e, line, acc))
    for lines in entries.values():
        cash_lines = [(e,l,a) for e,l,a in lines if a.id in cash_ids]
        if not cash_lines:
            continue
        for e, cash_line, cash_acc in cash_lines:
            cash_delta = Decimal(str(cash_line.debit or 0)) - Decimal(str(cash_line.credit or 0))
            if cash_delta == 0:
                continue
            counterparts = [(l,a) for _,l,a in lines if a.id != cash_acc.id]
            if not counterparts:
                continue
            # Transfers between cash accounts are not cash flows.
            if all(a.id in cash_ids for _,a in counterparts):
                continue
            buckets = {"operating": ZERO, "investing": ZERO, "financing": ZERO}
            for l, a in counterparts:
                mapped = a.cash_flow_category
                if mapped not in ("operating", "investing", "financing"):
                    mapping_exceptions.append({
                        "entry_id": e.id, "entry_number": e.entry_number,
                        "account_id": a.id, "account_code": a.code, "account_name": a.name,
                        "reason": "الحساب المقابل للحركة النقدية بلا تصنيف تدفقات نقدية صالح"
                    })
                    mapped = "operating"
                buckets[mapped] = buckets.get(mapped, ZERO) + (Decimal(str(l.credit or 0)) - Decimal(str(l.debit or 0)))
            # For a cash receipt, the counterpart is credited; for a cash payment,
            # the counterpart is debited. The counterpart movement therefore already
            # carries the correct cash-flow sign.
            total = sum(buckets.values(), ZERO)
            if total == 0:
                continue
            for k, v in buckets.items():
                share = v
                if k == "operating": operating += share
                elif k == "investing": investing += share
                elif k == "financing": financing += share
            rows.append({
                "entry_id": e.id, "entry_number": e.entry_number,
                "date": e.entry_date.date().isoformat(), "description": e.description,
                "net_cash": money(cash_delta),
                "classification": (next((k for k,v in buckets.items() if v != ZERO), "operating")
                                   if sum(1 for v in buckets.values() if v != ZERO) == 1 else "mixed"),
            })
    opening, closing = money(opening), money(closing)
    net_change = money(operating + investing + financing)
    return {
        "from_date": from_date.isoformat(), "to_date": to_date.isoformat(),
        "operating": money(operating), "investing": money(investing), "financing": money(financing),
        "net_change": net_change, "opening_cash": opening, "closing_cash": closing,
        "reconciles": money(opening + net_change - closing) == ZERO, "rows": rows,
        "mapping_exceptions": mapping_exceptions,
        "mapping_complete": not mapping_exceptions,
    }


def changes_in_equity(db: Session, company_id: int, from_date: date, to_date: date, branch_id: int | None = None):
    """Authoritative statement of changes in equity.

    Closing entries are presentation mechanics, not a second equity movement or a
    second recognition of profit. They are therefore excluded from period equity
    movements and period profit, while remaining part of the opening balance for a
    later period. This keeps the statement additive across fiscal closes.
    """
    validate_dates(from_date, to_date)
    rows = trial_balance(db, company_id, from_date, to_date, branch_id)
    equity_rows = [r for r in rows if r["account_type"] == AccountTypeEnum.equity.value]

    closing_ids_q = (db.query(PeriodClosingEntry.closing_entry_id)
                     .join(JournalEntry, JournalEntry.id == PeriodClosingEntry.closing_entry_id)
                     .filter(PeriodClosingEntry.company_id == company_id,
                             JournalEntry.company_id == company_id,
                             JournalEntry.entry_date >= _dt_start(from_date),
                             JournalEntry.entry_date <= _dt_end_exclusive(to_date)))
    if branch_id is not None:
        closing_ids_q = closing_ids_q.filter(JournalEntry.branch_id == branch_id)
    closing_ids = {x[0] for x in closing_ids_q.all()}

    # Opening equity is the true signed balance immediately before the selected
    # period. Period equity movement excludes period-closing transfers.
    opening = money(sum((r["opening_balance"] * Decimal("-1") for r in equity_rows), ZERO))
    movement = ZERO
    for r in equity_rows:
        q = (db.query(func.coalesce(func.sum(JournalLine.debit), 0),
                      func.coalesce(func.sum(JournalLine.credit), 0))
             .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
             .filter(JournalLine.account_id == r["account_id"],
                     JournalLine.company_id == company_id,
                     JournalEntry.company_id == company_id,
                     JournalEntry.status == "posted",
                     JournalEntry.entry_date >= _dt_start(from_date),
                     JournalEntry.entry_date <= _dt_end_exclusive(to_date)))
        if branch_id is not None:
            q = q.filter(JournalEntry.branch_id == branch_id, JournalLine.branch_id == branch_id)
        if closing_ids:
            q = q.filter(~JournalEntry.id.in_(closing_ids))
        d, c = q.one()
        movement += money(Decimal(str(d or 0)) - Decimal(str(c or 0))) * Decimal("-1")
    movement = money(movement)

    # Profit generated in the selected period, independent of whether the period
    # was subsequently closed.
    pnl_q = (db.query(JournalLine.account_id,
                      func.coalesce(func.sum(JournalLine.debit), 0),
                      func.coalesce(func.sum(JournalLine.credit), 0))
             .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
             .join(Account, Account.id == JournalLine.account_id)
             .filter(JournalLine.company_id == company_id,
                     JournalEntry.company_id == company_id,
                     JournalEntry.status == "posted",
                     JournalEntry.entry_date >= _dt_start(from_date),
                     JournalEntry.entry_date <= _dt_end_exclusive(to_date),
                     Account.account_type.in_([AccountTypeEnum.revenue.value, AccountTypeEnum.expense.value])))
    if branch_id is not None:
        pnl_q = pnl_q.filter(JournalEntry.branch_id == branch_id, JournalLine.branch_id == branch_id)
    if closing_ids:
        pnl_q = pnl_q.filter(~JournalEntry.id.in_(closing_ids))
    profit = ZERO
    for aid, d, c in pnl_q.group_by(JournalLine.account_id).all():
        acc = db.query(Account).filter(Account.id == aid, Account.company_id == company_id).first()
        if not acc:
            continue
        net = Decimal(str(d or 0)) - Decimal(str(c or 0))
        profit += (-net if acc.account_type == AccountTypeEnum.revenue.value else -net)
    profit = money(profit)
    closing = money(opening + movement + profit)

    # Add a per-account closing amount so the statement can be audited against the
    # signed equity accounts without relying on a single opaque total.
    account_rows = []
    for r in equity_rows:
        period_movement = ZERO
        q = (db.query(func.coalesce(func.sum(JournalLine.debit), 0),
                      func.coalesce(func.sum(JournalLine.credit), 0))
             .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
             .filter(JournalLine.account_id == r["account_id"], JournalLine.company_id == company_id,
                     JournalEntry.company_id == company_id, JournalEntry.status == "posted",
                     JournalEntry.entry_date >= _dt_start(from_date), JournalEntry.entry_date <= _dt_end_exclusive(to_date)))
        if branch_id is not None:
            q = q.filter(JournalEntry.branch_id == branch_id, JournalLine.branch_id == branch_id)
        if closing_ids:
            q = q.filter(~JournalEntry.id.in_(closing_ids))
        d, c = q.one()
        period_movement = money((Decimal(str(d or 0)) - Decimal(str(c or 0))) * Decimal("-1"))
        opening_account = money(r["opening_balance"] * Decimal("-1"))
        account_rows.append({**r, "opening_equity": opening_account, "period_movement": period_movement,
                             "closing_equity": money(opening_account + period_movement)})

    return {"from_date":from_date.isoformat(),"to_date":to_date.isoformat(),
            "opening_equity":opening,"equity_movements":movement,"profit_for_period":profit,
            "closing_equity":closing,"accounts":account_rows,
            "closing_entries_excluded": len(closing_ids),
            "reconciles": closing == money(opening + movement + profit)}


def validate_financials(db: Session, company_id: int, from_date: date, to_date: date, branch_id: int | None = None):
    """Production financial integrity gate for the selected tenant/scope and period.

    The validation is deliberately independent of report presentation: it checks
    posted double-entry integrity plus the three primary statement equations.
    Draft entries are excluded from the financial statements by design.
    """
    validate_dates(from_date, to_date)
    tb = trial_balance(db, company_id, from_date, to_date, branch_id)
    debit = money(sum((r["debit"] for r in tb), ZERO))
    credit = money(sum((r["credit"] for r in tb), ZERO))
    bs = balance_sheet(db, company_id, to_date, branch_id)
    cf = cash_flow(db, company_id, from_date, to_date, branch_id)
    from .accounting_controls import journal_integrity
    integrity = journal_integrity(db, company_id, from_date, to_date, branch_id)
    checks = [
        {"code":"journal_integrity", "name":"سلامة القيود المرحلة", "ok":not integrity, "detail":f"قيود غير متوازنة: {len(integrity)}"},
        {"code":"trial_balance", "name":"ميزان المراجعة", "ok":debit == credit, "detail":f"مدين {debit} / دائن {credit}"},
        {"code":"balance_sheet", "name":"معادلة المركز المالي", "ok":bool(bs["balanced"]), "detail":f"الفرق {bs["difference"]}"},
        {"code":"cash_flow", "name":"مطابقة التدفقات النقدية", "ok":bool(cf["reconciles"]), "detail":f"افتتاحي {cf["opening_cash"]} / ختامي {cf["closing_cash"]}"},
    ]
    overall = all(x["ok"] for x in checks)
    return {
        "trial_balance_balanced": debit == credit,
        "trial_balance_debit": debit, "trial_balance_credit": credit,
        "balance_sheet_balanced": bs["balanced"], "balance_sheet_difference": bs["difference"],
        "cash_flow_reconciles": cf["reconciles"],
        "journal_integrity_ok": not integrity, "journal_exceptions": integrity,
        "checks": checks, "passed": sum(1 for x in checks if x["ok"]), "total": len(checks),
        "overall": overall,
    }
