"""Security controls: rate limiting, CSRF origin validation and request identity.

The limiter is intentionally dependency-free for local/test environments. In a
multi-worker production deployment it can use Redis when ``ERP_RATE_LIMIT_REDIS_URL``
is configured; otherwise it falls back to a bounded in-process sliding window.
"""
import os
import logging
import time
from .core_settings import redis_connection_url
from collections import defaultdict, deque
from threading import Lock

logger = logging.getLogger(__name__)

_UNSAFE = {"POST", "PUT", "PATCH", "DELETE"}
_lock = Lock()
_buckets = defaultdict(deque)
_MAX_BUCKETS = int(os.getenv("ERP_RATE_LIMIT_MAX_BUCKETS", "10000"))
_WINDOW = 60
_REDIS_URL = os.getenv("ERP_RATE_LIMIT_REDIS_URL", "").strip() or redis_connection_url(0)
_redis = None
if _REDIS_URL:
    try:
        import redis as _redis_lib
        _redis = _redis_lib.Redis.from_url(_REDIS_URL, socket_connect_timeout=1, socket_timeout=1, decode_responses=True)
    except Exception:
        _redis = None
AUTH_LIMIT = int(os.getenv("ERP_AUTH_RATE_LIMIT", "5"))
API_LIMIT = int(os.getenv("ERP_API_RATE_LIMIT", "100"))


def client_ip(request) -> str:
    """Return the peer IP; only trust forwarded headers when explicitly enabled."""
    peer = request.client.host if request.client else "unknown"
    if os.getenv("ERP_TRUST_PROXY_HEADERS", "false").lower() == "true":
        forwarded = request.headers.get("X-Forwarded-For", "").split(",", 1)[0].strip()
        if forwarded:
            return forwarded
    return peer


def _trim(q, now):
    while q and now - q[0] >= _WINDOW:
        q.popleft()


def rate_limit_check(key: str, limit: int, now: float | None = None) -> tuple[bool, int]:
    """Consume one request and return (allowed, retry_after_seconds).

    When Redis is configured, the counter is shared across workers/instances;
    otherwise a bounded in-process sliding window is used.
    """
    now = time.time() if now is None else now
    if _redis is not None:
        try:
            bucket = f"erp:rl:{key}:{int(now // _WINDOW)}"
            count = int(_redis.incr(bucket))
            if count == 1:
                _redis.expire(bucket, _WINDOW + 2)
            if count > limit:
                retry = max(1, _WINDOW - int(now % _WINDOW))
                return False, retry
            return True, 0
        except Exception:
            # Redis is an optimization for horizontal enforcement; preserve service
            # availability but emit telemetry so production monitoring detects the
            # degraded distributed rate-limit path.
            logger.exception("Redis rate-limit backend unavailable; using local fallback")
    with _lock:
        q = _buckets[key]
        _trim(q, now)
        if len(q) >= limit:
            retry = max(1, int(_WINDOW - (now - q[0])))
            return False, retry
        q.append(now)
        # Keep the fallback bounded so an internet-facing server cannot exhaust RAM.
        if len(_buckets) > _MAX_BUCKETS:
            stale = [k for k, v in _buckets.items() if not v or now - v[-1] >= _WINDOW]
            for k in stale[: max(1, len(stale) // 2)]:
                _buckets.pop(k, None)
        return True, 0


def login_rate_limit(ip: str, username: str) -> tuple[bool, int]:
    """Enforce both per-IP and per-account login limits and return retry time."""
    username_key = (username or "").strip().casefold() or "<empty>"
    ip_allowed, ip_retry = rate_limit_check(f"auth:ip:{ip}", AUTH_LIMIT)
    account_limit = int(os.getenv("ERP_AUTH_ACCOUNT_RATE_LIMIT", "12"))
    account_allowed, account_retry = rate_limit_check(f"auth:user:{username_key}", account_limit)
    return ip_allowed and account_allowed, max(ip_retry, account_retry)


def login_allowed(ip: str, username: str) -> bool:
    """Compatibility wrapper for legacy callers."""
    allowed, _ = login_rate_limit(ip, username)
    return allowed


def validate_same_origin(request) -> bool:
    """Cookie-authenticated unsafe requests must originate from this site."""
    if request.method not in _UNSAFE:
        return True
    origin = request.headers.get("origin")
    referer = request.headers.get("referer")
    if not origin and not referer:
        # Fail closed for cookie-authenticated state-changing requests.
        # This can be disabled only for controlled development/integration
        # environments where clients intentionally omit both headers.
        return os.getenv("ERP_CSRF_ALLOW_MISSING_ORIGIN", "false").lower() == "true"
    host = request.headers.get("host", "")
    scheme = request.url.scheme
    expected = f"{scheme}://{host}"
    if origin:
        return origin.rstrip("/") == expected.rstrip("/")
    return referer.startswith(expected + "/") or referer.rstrip("/") == expected.rstrip("/")
