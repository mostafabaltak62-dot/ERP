"""Serial/lot/expiry controls used by the authoritative movement engine."""
from datetime import datetime
from decimal import Decimal
from fastapi import HTTPException
from sqlalchemy.orm import Session
from .accounting import D
from .enterprise_models import InventoryTraceability
from .models import Item, StockMovement, MovementTypeEnum

IN_TYPES={MovementTypeEnum.in_, MovementTypeEnum.adjustment_in}
OUT_TYPES={MovementTypeEnum.out, MovementTypeEnum.adjustment_out}

def _clean(value):
    return str(value).strip() if value is not None and str(value).strip() else None

def _expiry(value):
    if value is None: return None
    if isinstance(value, datetime): return value
    try: return datetime.fromisoformat(str(value).replace('Z','+00:00'))
    except ValueError: raise HTTPException(422, "Invalid expiry date")

def attach_traceability(db: Session, movement: StockMovement, *, serial_numbers=None, lot_no=None, expiry_date=None):
    item=db.query(Item).filter(Item.id==movement.item_id, Item.company_id==movement.company_id).first()
    if not item: raise HTTPException(404,"Item not found")
    serials=[_clean(x) for x in (serial_numbers or []) if _clean(x)]
    lot=_clean(lot_no); expiry=_expiry(expiry_date)
    qty=D(movement.quantity)
    if item.track_serial:
        if qty != qty.to_integral_value() or len(serials) != int(qty):
            raise HTTPException(422,"Serial-tracked movement requires one unique serial for each unit")
        if len(set(serials)) != len(serials): raise HTTPException(422,"Duplicate serial number in movement")
        for serial in serials:
            if movement.movement_type in IN_TYPES:
                exists=db.query(InventoryTraceability.id).filter(InventoryTraceability.company_id==movement.company_id,InventoryTraceability.item_id==movement.item_id,InventoryTraceability.serial_no==serial).first()
                if exists: raise HTTPException(409,f"Serial already exists: {serial}")
            else:
                history=db.query(InventoryTraceability,StockMovement.movement_type).join(StockMovement,StockMovement.id==InventoryTraceability.stock_movement_id).filter(InventoryTraceability.company_id==movement.company_id,InventoryTraceability.item_id==movement.item_id,InventoryTraceability.serial_no==serial).order_by(StockMovement.operational_date.desc(),StockMovement.id.desc()).first()
                if not history or history[1] not in IN_TYPES:
                    raise HTTPException(409,f"Serial is not currently in stock: {serial}")
            db.add(InventoryTraceability(company_id=movement.company_id,item_id=movement.item_id,stock_movement_id=movement.id,serial_no=serial,lot_no=lot,expiry_date=expiry,quantity=1))
    elif serials:
        raise HTTPException(422,"Serial numbers supplied for a non-serial-tracked item")
    if item.track_expiry:
        if expiry is None or not lot: raise HTTPException(422,"Expiry-tracked movement requires lot number and expiry date")
        if movement.movement_type in IN_TYPES and expiry <= movement.operational_date: raise HTTPException(422,"Inbound expiry date must be after operational date")
        if movement.movement_type in OUT_TYPES and expiry <= movement.operational_date: raise HTTPException(409,"Cannot issue expired stock")
        if not item.track_serial:
            db.add(InventoryTraceability(company_id=movement.company_id,item_id=movement.item_id,stock_movement_id=movement.id,lot_no=lot,expiry_date=expiry,quantity=qty))
    elif lot is not None or expiry is not None:
        raise HTTPException(422,"Lot/expiry tracking is disabled for this item")
    db.flush()
