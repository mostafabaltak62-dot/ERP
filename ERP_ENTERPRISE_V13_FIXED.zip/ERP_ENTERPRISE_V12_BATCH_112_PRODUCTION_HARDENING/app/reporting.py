"""Compatibility wrapper around the authoritative accounting reporting engine."""
from datetime import date
from .financial_reporting import (
    trial_balance as _trial_balance,
    general_ledger as _general_ledger,
    profit_and_loss as _pnl,
    balance_sheet as _balance_sheet,
    cash_flow as _cash_flow,
    changes_in_equity as _changes_in_equity,
    validate_financials as _validate_financials,
)


def _serialize(v):
    if hasattr(v, "isoformat"): return v.isoformat()
    if isinstance(v, list): return [_serialize(x) for x in v]
    if isinstance(v, dict): return {k:_serialize(x) for k,x in v.items()}
    if hasattr(v, "quantize"):
        return format(v, ".6f")
    return v


def trial_balance(db, company_id, from_date=None, to_date=None, branch_id=None):
    return _serialize(_trial_balance(db, company_id, from_date, to_date, branch_id))


def general_ledger(db, company_id, from_date, to_date, account_id=None, branch_id=None):
    return _serialize(_general_ledger(db, company_id, from_date, to_date, account_id, branch_id))


def pnl(db, company_id, from_date, to_date, branch_id=None):
    return _serialize(_pnl(db, company_id, from_date, to_date, branch_id))


def balance_sheet(db, company_id, as_of_date, branch_id=None):
    r = _balance_sheet(db, company_id, as_of_date, branch_id)
    r.update({"assets": r["asset_total"], "liabilities": r["liability_total"], "equity": r["equity_total"]})
    return _serialize(r)


def cash_flow(db, company_id, from_date, to_date, branch_id=None):
    return _serialize(_cash_flow(db, company_id, from_date, to_date, branch_id))


def changes_in_equity(db, company_id, from_date, to_date, branch_id=None):
    return _serialize(_changes_in_equity(db, company_id, from_date, to_date, branch_id))


def validate_financials(db, company_id, from_date, to_date, branch_id=None):
    return _serialize(_validate_financials(db, company_id, from_date, to_date, branch_id))


def dashboard(db, company_id, from_date, to_date):
    p = _pnl(db, company_id, from_date, to_date)
    bs = _balance_sheet(db, company_id, to_date)
    cf = _cash_flow(db, company_id, from_date, to_date)
    return _serialize({
        "period":{"from":from_date.isoformat(),"to":to_date.isoformat()},
        "revenue":p["revenue_total"],"expenses":p["expense_total"],"net_profit":p["net_profit"],
        "assets":bs["asset_total"],"liabilities":bs["liability_total"],"equity":bs["equity_total"],
        "balance_sheet_balanced":bs["balanced"],"cash_flow_reconciles":cf["reconciles"],
    })
