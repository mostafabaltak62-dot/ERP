from .time_utils import utcnow
"""Phase 4 governance models: granular RBAC, tenant access, approvals, audit, and job state."""
import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, JSON, ForeignKey, Numeric, UniqueConstraint, Index
from sqlalchemy.orm import relationship
from .db_base import Base

class Permission(Base):
    __tablename__ = "permissions"
    id = Column(Integer, primary_key=True)
    code = Column(String(150), unique=True, nullable=False, index=True)
    description = Column(String(255))
    is_active = Column(Boolean, default=True, nullable=False)

class Role(Base):
    __tablename__ = "roles"
    id = Column(Integer, primary_key=True)
    code = Column(String(80), unique=True, nullable=False, index=True)
    name = Column(String(150), nullable=False)
    is_system = Column(Boolean, default=False, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)

class RolePermission(Base):
    __tablename__ = "role_permissions"
    id = Column(Integer, primary_key=True)
    role_id = Column(Integer, ForeignKey("roles.id", ondelete="CASCADE"), nullable=False)
    permission_id = Column(Integer, ForeignKey("permissions.id", ondelete="CASCADE"), nullable=False)
    __table_args__ = (UniqueConstraint("role_id", "permission_id", name="uq_role_permission"),)

class UserRole(Base):
    __tablename__ = "user_roles"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    role_id = Column(Integer, ForeignKey("roles.id", ondelete="CASCADE"), nullable=False)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=True)
    branch_id = Column(Integer, ForeignKey("branches.id", ondelete="CASCADE"), nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    __table_args__ = (UniqueConstraint("user_id", "role_id", "company_id", "branch_id", name="uq_user_role_scope"),)

class ApprovalRule(Base):
    __tablename__ = "approval_rules"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    document_type = Column(String(100), nullable=False, index=True)
    name = Column(String(180), nullable=False)
    min_amount = Column(Numeric(20, 6), nullable=True)
    max_amount = Column(Numeric(20, 6), nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    priority = Column(Integer, default=100, nullable=False)
    __table_args__ = (Index("ix_approval_rule_match", "company_id", "document_type", "is_active", "priority"),)

class ApprovalRuleStep(Base):
    __tablename__ = "approval_rule_steps"
    id = Column(Integer, primary_key=True)
    rule_id = Column(Integer, ForeignKey("approval_rules.id", ondelete="CASCADE"), nullable=False)
    sequence = Column(Integer, nullable=False)
    required_permission = Column(String(150), nullable=False)
    min_amount = Column(Numeric(20, 6), nullable=True)
    max_amount = Column(Numeric(20, 6), nullable=True)
    __table_args__ = (UniqueConstraint("rule_id", "sequence", name="uq_approval_rule_step"),)

class ApprovalRequest(Base):
    __tablename__ = "approval_requests"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id", ondelete="SET NULL"), nullable=True, index=True)
    document_type = Column(String(100), nullable=False)
    document_id = Column(Integer, nullable=False)
    rule_id = Column(Integer, ForeignKey("approval_rules.id"), nullable=False)
    status = Column(String(30), default="pending", nullable=False, index=True)
    current_sequence = Column(Integer, default=1, nullable=False)
    requested_by_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    amount = Column(Numeric(20, 6), nullable=False, default=0)
    requested_at = Column(DateTime, default=utcnow, nullable=False)
    completed_at = Column(DateTime)
    __table_args__ = (UniqueConstraint("document_type", "document_id", "rule_id", name="uq_approval_document_rule"),
                      Index("ix_approval_document", "company_id", "document_type", "document_id"))

class ApprovalAction(Base):
    __tablename__ = "approval_actions"
    id = Column(Integer, primary_key=True)
    request_id = Column(Integer, ForeignKey("approval_requests.id", ondelete="CASCADE"), nullable=False)
    sequence = Column(Integer, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    decision = Column(String(30), nullable=False)
    reason = Column(Text)
    acted_at = Column(DateTime, default=utcnow, nullable=False)

class GovernanceAuditLog(Base):
    __tablename__ = "governance_audit_logs"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id"), nullable=True, index=True)
    request_id = Column(String(80), index=True)
    action = Column(String(30), nullable=False, index=True)
    entity_type = Column(String(120), nullable=False, index=True)
    entity_id = Column(String(80))
    ip_address = Column(String(64))
    before_json = Column(JSON)
    after_json = Column(JSON)
    changes_json = Column(JSON)
    reason = Column(Text)
    created_at = Column(DateTime, default=utcnow, nullable=False, index=True)
    user = relationship("User")

class BackgroundJob(Base):
    __tablename__ = "background_jobs"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=True, index=True)
    job_type = Column(String(120), nullable=False, index=True)
    status = Column(String(30), default="queued", nullable=False, index=True)
    idempotency_key = Column(String(180), unique=True, nullable=False)
    scheduled_at = Column(DateTime, nullable=True)
    started_at = Column(DateTime)
    finished_at = Column(DateTime)
    attempts = Column(Integer, default=0, nullable=False)
    error_message = Column(Text)
    result_json = Column(JSON)


class RecurringJournalTemplate(Base):
    """A journal-entry template regenerated automatically by the scheduler.
    (The v2 package shipped a Celery task named erp.recurring_journals but
    it had no backing model or logic -- it just returned a fake "queued"
    status. This is the real implementation.)"""
    __tablename__ = "recurring_journal_templates"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True)
    name = Column(String(150), nullable=False)
    description = Column(String(255), nullable=True)
    frequency = Column(String(20), nullable=False, default="monthly")
    day_of_month = Column(Integer, nullable=True)
    lines_json = Column(JSON, nullable=False)  # [{"account_code": "...", "debit": 0, "credit": 0}]
    is_active = Column(Boolean, default=True, nullable=False)
    last_generated_at = Column(DateTime, nullable=True)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)


class AssetDepreciationRun(Base):
    """One row per depreciation POSTING for one asset in one period. Its id is
    used as JournalEntry.source_id.

    Fixes a real bug found in both source projects: the manual
    /pro-finance/assets/{id}/depreciate endpoint posted with
    source_id=asset.id, and journal_entries has a UNIQUE(source_type,
    source_id) constraint -- so the SECOND depreciation run for the same
    asset (i.e. the very next month) would always fail with 409. Using this
    per-period row's id as source_id keeps the duplicate-prevention working
    for a single period while allowing one new posting every period."""
    __tablename__ = "asset_depreciation_runs"
    __table_args__ = (UniqueConstraint("asset_id", "period_label", name="uq_asset_depreciation_period"),)
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id", ondelete="SET NULL"), nullable=True, index=True)
    asset_id = Column(Integer, ForeignKey("fixed_assets.id"), nullable=False)
    period_label = Column(String(20), nullable=False)  # e.g. "2026-08"
    amount = Column(Numeric(20, 6), nullable=False)
    journal_entry_id = Column(Integer, ForeignKey("journal_entries.id"), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)
