"""Compatibility task registration.
Canonical production tasks live in app.celery_app; this module exposes the
same callables for older deployments without duplicating business logic.
"""
def register_tasks(app):
    from .celery_app import monthly_depreciation, recurring_journals, inventory_valuation
    # Explicitly register the canonical task objects when a custom Celery app is supplied.
    app.tasks.register(monthly_depreciation)
    app.tasks.register(recurring_journals)
    app.tasks.register(inventory_valuation)
    return app
