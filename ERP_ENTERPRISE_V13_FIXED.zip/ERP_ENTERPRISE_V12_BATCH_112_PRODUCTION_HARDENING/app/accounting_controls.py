# -*- coding: utf-8 -*-
"""Accounting control/compliance layer mapped to the ERP accounting checklist.

This module does not replace the posting engine. It audits the authoritative
posted-journal source of truth and exposes actionable exceptions for the UI.
"""
from datetime import date, datetime, time
from decimal import Decimal
from sqlalchemy import func
from sqlalchemy.orm import Session

from .models import Account, AccountTypeEnum, JournalEntry, JournalLine, CostCenter, JournalLineCostCenter
from .deep_transactions import ar_aging, ap_aging, reconcile_inventory_valuation, reconcile_inventory_to_gl
from .models import BankReconciliation, FixedAsset, TaxTransaction
from .accounting import D


ZERO = Decimal("0")

def _money(v):
    return Decimal(str(v or 0)).quantize(Decimal("0.01"))

def _start(d): return datetime.combine(d, time.min)
def _end(d): return datetime.combine(d, time.max)

def orphan_accounts(db: Session, company_id: int, branch_id: int | None = None):
    """Accounts with no posted movement and no children: useful for COA hygiene."""
    accounts = db.query(Account).filter(Account.company_id == company_id, Account.is_active.is_(True)).all()
    out=[]
    for a in accounts:
        has_children = db.query(Account.id).filter(Account.company_id == company_id, Account.parent_id == a.id, Account.is_active.is_(True)).first() is not None
        lq = db.query(JournalLine.id).join(JournalEntry).filter(
            JournalLine.company_id == company_id, JournalLine.account_id == a.id,
            JournalEntry.status == "posted", JournalEntry.company_id == company_id)
        if branch_id is not None: lq=lq.filter(JournalEntry.branch_id==branch_id)
        has_lines = lq.first() is not None
        if not has_children and not has_lines:
            out.append({"id":a.id,"code":a.code,"name":a.name,"account_type":a.account_type.value})
    return out

def journal_integrity(db: Session, company_id: int, from_date: date | None = None, to_date: date | None = None, branch_id: int | None = None):
    rows=[]
    q=db.query(JournalEntry).filter(JournalEntry.company_id==company_id, JournalEntry.status=="posted")
    if from_date is not None: q=q.filter(JournalEntry.entry_date>=_start(from_date))
    if to_date is not None: q=q.filter(JournalEntry.entry_date<=_end(to_date))
    if branch_id is not None: q=q.filter(JournalEntry.branch_id==branch_id)
    entries=q.all()
    for e in entries:
        debit=_money(db.query(func.coalesce(func.sum(JournalLine.debit),0)).filter(JournalLine.entry_id==e.id).scalar())
        credit=_money(db.query(func.coalesce(func.sum(JournalLine.credit),0)).filter(JournalLine.entry_id==e.id).scalar())
        if debit != credit or debit <= 0:
            rows.append({"entry_id":e.id,"entry_number":e.entry_number,"debit":debit,"credit":credit,"status":"exception"})
    return rows

def cost_center_exceptions(db: Session, company_id: int):
    out=[]
    lines=(db.query(JournalLine).join(JournalEntry).filter(
        JournalLine.company_id==company_id, JournalEntry.company_id==company_id,
        JournalEntry.status=="posted").all())
    for line in lines:
        amount=_money(Decimal(str(line.debit or 0))-Decimal(str(line.credit or 0)))
        if amount == 0: continue
        alloc=_money(db.query(func.coalesce(func.sum(JournalLineCostCenter.amount),0)).filter(
            JournalLineCostCenter.company_id==company_id, JournalLineCostCenter.journal_line_id==line.id).scalar())
        # Only flag partially allocated lines when an allocation exists; not every
        # GL line is required to have a cost centre.
        if alloc and _money(abs(amount)-alloc) != 0:
            out.append({"journal_line_id":line.id,"entry_id":line.entry_id,"line_amount":abs(amount),"allocated":alloc,"difference":_money(abs(amount)-alloc)})
    return out

def tax_reconciliation(db: Session, company_id: int, from_date: date, to_date: date, branch_id: int | None = None):
    """Validate tax transactions and reconcile only tax records backed by posted GL entries.

    A tax row is not treated as financially valid merely because it exists: it must
    have a posted journal entry in the requested period and tenant scope.
    """
    q=db.query(TaxTransaction).filter(
        TaxTransaction.company_id==company_id,
        TaxTransaction.created_at>=_start(from_date),
        TaxTransaction.created_at<=_end(to_date))
    if branch_id is not None: q=q.filter(TaxTransaction.branch_id==branch_id)
    tx=q.all(); orphaned=[]; invalid=[]
    for x in tx:
        if x.tax_direction not in ("input", "output") or D(x.tax_amount) < 0 or D(x.taxable_amount) < 0 or not (ZERO <= D(x.rate_applied) <= Decimal("100")):
            invalid.append(x.id); continue
        if not x.journal_entry_id:
            orphaned.append(x.id); continue
        je=db.query(JournalEntry).filter(
            JournalEntry.id==x.journal_entry_id, JournalEntry.company_id==company_id,
            JournalEntry.status=="posted").first()
        if not je or je.entry_date < _start(from_date) or je.entry_date > _end(to_date) or (branch_id is not None and je.branch_id != branch_id):
            orphaned.append(x.id)
    output=_money(sum((_money(x.tax_amount) for x in tx if x.tax_direction=="output"), ZERO))
    input_tax=_money(sum((_money(x.tax_amount) for x in tx if x.tax_direction=="input"), ZERO))
    return {"output_vat":output,"input_vat":input_tax,"net_vat":_money(output-input_tax),
            "transactions":len(tx),"orphaned":orphaned,"invalid":invalid,
            "ok":not orphaned and not invalid}


def bank_control(db: Session, company_id: int, branch_id: int | None = None):
    q=db.query(BankReconciliation).filter(BankReconciliation.company_id==company_id,BankReconciliation.status=="open")
    if branch_id is not None: q=q.filter(BankReconciliation.branch_id==branch_id)
    open_count=q.with_entities(func.count(BankReconciliation.id)).scalar() or 0
    exceptions=q.filter(func.abs(BankReconciliation.difference)>Decimal("0.005")).count()
    return {"open_reconciliations":int(open_count),"exceptions":int(exceptions)}

def fixed_asset_control(db: Session, company_id: int, branch_id: int | None = None):
    q=db.query(FixedAsset).filter(FixedAsset.company_id==company_id)
    if branch_id is not None: q=q.filter(FixedAsset.branch_id==branch_id)
    assets=q.all(); exceptions=[]
    gross=ZERO; accum=ZERO
    for a in assets:
        cost=D(a.acquisition_cost); dep=D(a.accumulated_depreciation); residual=D(a.residual_value)
        gross += _money(cost); accum += _money(dep)
        if cost < 0 or residual < 0 or residual > cost or dep < 0 or dep > max(cost-residual, ZERO) or int(a.useful_life_months or 0) <= 0:
            exceptions.append(a.id)
    gross=_money(gross); accum=_money(accum)
    return {"count":len(assets),"active":sum(1 for a in assets if a.is_active),
            "gross":gross,"accumulated_depreciation":accum,"net":_money(gross-accum),
            "exceptions":exceptions,"ok":not exceptions}


def inventory_control(db: Session, company_id: int, as_of: date | None = None, branch_id: int | None = None):
    """Inventory subledger control with an explicit GL reconciliation.

    The inventory valuation is historical as-of the requested date: original
    receipt-layer value minus only cost consumptions that occurred on/before
    that date. Current ``remaining_qty`` is deliberately not used for the
    historical snapshot. Branch filtering is applied to the GL side; inventory
    cost layers are company-scoped in the current schema, so a branch-scoped
    inventory valuation is reported as consolidated and is not silently
    presented as branch-isolated.
    """
    from .models import Account, JournalLine, JournalEntry
    from .enterprise_models import InventoryCostLayer, InventoryCostConsumption
    from datetime import datetime, time
    as_of_dt = as_of or datetime.combine(date.today(), time.max)
    if isinstance(as_of_dt, date) and not isinstance(as_of_dt, datetime):
        as_of_dt = datetime.combine(as_of_dt, time.max)
    def historical_value():
        layers=db.query(InventoryCostLayer).filter(InventoryCostLayer.company_id==company_id, InventoryCostLayer.received_at<=as_of_dt).all()
        total=ZERO; by_item={}
        for layer in layers:
            original=_money(D(layer.original_qty)*D(layer.unit_cost))
            consumed=_money(db.query(func.coalesce(func.sum(InventoryCostConsumption.total_cost),0)).filter(
                InventoryCostConsumption.company_id==company_id,
                InventoryCostConsumption.layer_id==layer.id,
                InventoryCostConsumption.consumed_at<=as_of_dt).scalar() or 0)
            value=_money(original-consumed)
            total += value
            by_item[layer.item_id]=_money(by_item.get(layer.item_id,ZERO)+value)
        return _money(total), by_item
    valuation, by_item = historical_value()
    rows=reconcile_inventory_valuation(db, company_id, as_of=as_of_dt)
    for r in rows:
        r["valued_remaining"] = _money(by_item.get(r["item_id"], ZERO))
        r["difference"] = _money(r["movement_value"] - r["valued_remaining"])
        r["status"] = "reconciled" if r["difference"] == 0 else "exception"
    exceptions=[r for r in rows if r["status"]!="reconciled"]
    inv_acc=db.query(Account).filter(Account.company_id==company_id,Account.code=="1300").first()
    cogs_acc=db.query(Account).filter(Account.company_id==company_id,Account.code=="5100").first()
    def gl_balance(acc):
        if not acc: return None
        q=db.query(func.coalesce(func.sum(JournalLine.debit),0),func.coalesce(func.sum(JournalLine.credit),0)).join(JournalEntry,JournalEntry.id==JournalLine.entry_id).filter(
            JournalLine.company_id==company_id, JournalLine.account_id==acc.id,
            JournalEntry.company_id==company_id, JournalEntry.status=="posted", JournalEntry.entry_date<=as_of_dt)
        if branch_id is not None: q=q.filter(JournalEntry.branch_id==branch_id)
        d,c=q.one(); return _money(Decimal(str(d))-Decimal(str(c)))
    inventory_gl=gl_balance(inv_acc)
    cogs_gl=gl_balance(cogs_acc)
    consumed_value=_money(sum((_money(r["consumed_value"]) for r in rows),ZERO))
    inventory_difference=None if inventory_gl is None else _money(valuation-inventory_gl)
    cogs_difference=None if cogs_gl is None else _money(consumed_value-cogs_gl)
    account_exception = not inv_acc or not cogs_acc
    gl_exception = (inventory_difference not in (None, ZERO))
    status="exception" if account_exception or gl_exception or exceptions else "reconciled"
    return {"items":len(rows),"exceptions":len(exceptions),"valuation":valuation,"rows":rows,
            "as_of":as_of_dt,"inventory_gl":inventory_gl,"inventory_difference":inventory_difference,
            "consumed_cost":consumed_value,"cogs_gl":cogs_gl,"cogs_difference":cogs_difference,
            "inventory_account_code":"1300","cogs_account_code":"5100","status":status,
            "accounts_missing": [x for x,a in (("1300",inv_acc),("5100",cogs_acc)) if not a],
            "branch_id":branch_id,"inventory_scope":"company_consolidated" if branch_id is not None else "company"}

def build_accounting_control_report(db: Session, company_id: int, from_date: date, to_date: date, branch_id: int | None = None):
    integrity=journal_integrity(db,company_id,from_date,to_date,branch_id)
    ar=ar_aging(db,company_id,_end(to_date),branch_id); ap=ap_aging(db,company_id,_end(to_date),branch_id)
    ar_ap=[]
    for typ, rows, code in (("ar", ar, "1200"), ("ap", ap, "2100")):
        sub=_money(sum((_money(x["outstanding"]) for x in rows),ZERO))
        acc=db.query(Account).filter(Account.company_id==company_id,Account.code==code,Account.is_active.is_(True)).first()
        if not acc:
            ar_ap.append({"type":typ,"status":"exception","error":f"الحساب {code} غير موجود"}); continue
        glq=db.query(func.coalesce(func.sum(JournalLine.debit),0),func.coalesce(func.sum(JournalLine.credit),0)).join(JournalEntry).filter(
            JournalLine.company_id==company_id,JournalLine.account_id==acc.id,JournalEntry.company_id==company_id,JournalEntry.status=="posted",JournalEntry.entry_date<=_end(to_date))
        if branch_id is not None: glq=glq.filter(JournalEntry.branch_id==branch_id)
        d,c=glq.one()
        gl=_money(Decimal(str(d))-Decimal(str(c)))
        if typ=="ap": gl=abs(gl)
        diff=_money(sub-gl)
        ar_ap.append({"type":typ,"subledger":sub,"gl":gl,"difference":diff,"status":"reconciled" if diff==0 else "exception"})
    tax=tax_reconciliation(db,company_id,from_date,to_date,branch_id)
    inv=inventory_control(db,company_id,to_date,branch_id)
    bank=bank_control(db,company_id,branch_id)
    assets=fixed_asset_control(db,company_id,branch_id)
    orphan_rows=orphan_accounts(db,company_id,branch_id)
    cc_exceptions=cost_center_exceptions(db,company_id)
    checks=[
        ("دليل الحسابات والهيكل", all(a.company_id==company_id for a in db.query(Account).filter(Account.company_id==company_id).all()), "الحسابات ضمن الشركة الحالية."),
        ("قيد القيد المزدوج", not integrity, f"القيود غير المتوازنة: {len(integrity)}"),
        ("حسابات يتيمة", len(orphan_rows) == 0, f"حسابات بلا حركة/أبناء: {len(orphan_rows)}"),
        ("تسوية العملاء", all(x.get("status")=="reconciled" for x in ar_ap if x.get("type")=="ar") if any(x.get("type")=="ar" for x in ar_ap) else True, "AR ↔ GL"),
        ("تسوية الموردين", all(x.get("status")=="reconciled" for x in ar_ap if x.get("type")=="ap") if any(x.get("type")=="ap" for x in ar_ap) else True, "AP ↔ GL"),
        ("مخزون ↔ أستاذ عام", inv["status"]=="reconciled", f"استثناءات التقييم: {inv['exceptions']} / فرق GL: {inv['inventory_difference']}"),
        ("ضريبة القيمة المضافة", tax["ok"], f"مخرجات {tax['output_vat']} / مدخلات {tax['input_vat']} / سجلات غير مرتبطة: {len(tax['orphaned'])}"),
        ("الأصول والإهلاك", assets["ok"], f"أصول: {assets['count']} / استثناءات: {len(assets['exceptions'])}"),
        ("مراكز التكلفة", len(cc_exceptions)==0, f"توزيعات غير مكتملة: {len(cc_exceptions)}"),
        ("تسويات البنك", bank["exceptions"]==0, f"تسويات مفتوحة بها فرق: {bank['exceptions']}"),
    ]
    return {"checks":checks,"journal_exceptions":integrity,"orphans":orphan_accounts(db,company_id),
            "ar_aging":ar,"ap_aging":ap,"ar_ap_reconciliation":ar_ap,"tax":tax,
            "inventory":inv,"fixed_assets":assets,"bank":bank,"cost_center_exceptions":cc_exceptions,"branch_id":branch_id,
            "cost_center_exceptions":cost_center_exceptions(db,company_id),
            "passed":sum(1 for _,ok,_ in checks if ok),"total":len(checks)}
