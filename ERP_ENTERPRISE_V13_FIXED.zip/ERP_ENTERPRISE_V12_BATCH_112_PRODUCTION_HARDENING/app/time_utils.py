"""Time helpers used by the ERP domain and persistence layers."""

from datetime import datetime, timezone


def utcnow() -> datetime:
    """Return current UTC as a naive datetime for existing UTC DB columns."""
    return datetime.now(timezone.utc).replace(tzinfo=None)
