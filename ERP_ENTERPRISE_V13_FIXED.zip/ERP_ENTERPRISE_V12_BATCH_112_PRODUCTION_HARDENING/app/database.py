# -*- coding: utf-8 -*-
"""Synchronous SQLAlchemy runtime database configuration.

The application currently uses synchronous SQLAlchemy. Pooling is configured for
PostgreSQL/Neon and SQLite is retained only for local development/tests.
"""
from __future__ import annotations

from sqlalchemy import create_engine, event
from sqlalchemy.engine import make_url
from sqlalchemy.orm import sessionmaker

from .core_settings import runtime_settings, validate_runtime_config
from .db_base import Base

_cfg = validate_runtime_config(require_database=True)
_settings = runtime_settings()
DATABASE_URL = _cfg["DATABASE_URL"]

if DATABASE_URL.startswith("postgresql://"):
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+psycopg://", 1)

url = make_url(DATABASE_URL)
is_sqlite = url.get_backend_name() == "sqlite"
is_postgres = url.get_backend_name() == "postgresql"

if _settings.ERP_ENV.lower() == "production" and not is_postgres:
    raise RuntimeError("Production runtime requires PostgreSQL")

connect_args: dict = {"check_same_thread": False} if is_sqlite else {}
if is_postgres and _settings.ERP_ENV.lower() == "production":
    # psycopg/libpq honors sslmode in the URL. Refuse explicit disablement in
    # core_settings and require TLS for managed/external production databases.
    query = {k.lower(): str(v).lower() for k, v in url.query.items()}
    if query.get("sslmode") == "disable":
        raise RuntimeError("Production PostgreSQL TLS cannot be disabled")

engine_kwargs = {
    "connect_args": connect_args,
    "pool_pre_ping": True,
    "future": True,
}
if not is_sqlite:
    engine_kwargs.update({
        "pool_size": _settings.ERP_DB_POOL_SIZE,
        "max_overflow": _settings.ERP_DB_MAX_OVERFLOW,
        "pool_timeout": _settings.ERP_DB_POOL_TIMEOUT,
        "pool_recycle": _settings.ERP_DB_POOL_RECYCLE,
    })

engine = create_engine(DATABASE_URL, **engine_kwargs)

if is_sqlite:
    @event.listens_for(engine, "connect")
    def _enable_sqlite_foreign_keys(dbapi_connection, _connection_record):
        cursor = dbapi_connection.cursor()
        try:
            cursor.execute("PRAGMA foreign_keys=ON")
        finally:
            cursor.close()

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    expire_on_commit=False,
    bind=engine,
)


def get_db():
    """FastAPI dependency: one database session per request with rollback safety."""
    db = SessionLocal()
    try:
        yield db
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
