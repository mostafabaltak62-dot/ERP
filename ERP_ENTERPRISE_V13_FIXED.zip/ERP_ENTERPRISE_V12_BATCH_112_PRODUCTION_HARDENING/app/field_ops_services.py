from .time_utils import utcnow
"""Business services for field operations and integration boundaries."""
from datetime import datetime
from decimal import Decimal
import hashlib, hmac, json, uuid
import httpx
from sqlalchemy import func
from sqlalchemy.orm import Session
from .enterprise_models import Equipment, FuelTransaction, MaintenanceRecord, Project, ProjectCost, Contract
from .construction_models import ConstructionSite, WBSNode, ConstructionCostCode, BOQLine, ConstructionVariation, ConstructionCostBudgetLine
from .models import Item
from .field_ops_models import EquipmentLog, EquipmentCostEntry, VariationAmendment, SiteMaterialRequisition, SiteMaterialRequisitionLine, OfflineSyncBatch, OfflineSyncOperation, OfflineConflict, WebhookSubscription, WebhookDelivery, LicenseRegister
from .warehouse_models import Warehouse
from .models import StockMovement, MovementTypeEnum, Item
from .construction_models import SiteMaterialIssue


def D(value):
    return Decimal(str(value or 0))


def q(value):
    return D(value).quantize(Decimal('0.000001'))


class FieldOpsError(ValueError):
    pass

class BudgetExceeded(FieldOpsError):
    pass

class SyncConflict(FieldOpsError):
    pass


def _project(db, company_id, project_id):
    row = db.query(Project).filter_by(id=project_id, company_id=company_id).one_or_none()
    if not row:
        raise FieldOpsError('Project not found')
    return row


def _equipment(db, company_id, equipment_id):
    row = db.query(Equipment).filter_by(id=equipment_id, company_id=company_id, is_active=True).one_or_none()
    if not row:
        raise FieldOpsError('Equipment not found')
    return row


def create_equipment_log(db: Session, company_id, project_id, equipment_id, work_date, start_reading, end_reading, site_id=None, wbs_id=None, cost_code_id=None, user_id=None, notes=None):
    _project(db, company_id, project_id)
    equipment = _equipment(db, company_id, equipment_id)
    start, end = D(start_reading), D(end_reading)
    if end < start:
        raise FieldOpsError('Equipment meter reading cannot move backwards')
    hours = end - start
    if hours <= 0:
        raise FieldOpsError('Equipment log must contain positive working hours')
    estimated_hourly = D(equipment.hourly_rate)
    estimated_cost = q(hours * estimated_hourly)
    log = EquipmentLog(company_id=company_id, equipment_id=equipment_id, project_id=project_id, site_id=site_id, wbs_id=wbs_id, cost_code_id=cost_code_id, work_date=work_date, start_reading=start, end_reading=end, hours=hours, estimated_hourly_cost=estimated_hourly, estimated_cost=estimated_cost, actual_cost=estimated_cost, actual_hourly_cost=estimated_hourly, variance_amount=0, created_by_id=user_id, notes=notes)
    db.add(log)
    db.flush()
    _refresh_equipment_log(db, log)
    return log


def add_equipment_cost(db: Session, company_id, equipment_id, project_id, source_type, amount, entry_date, site_id=None, equipment_log_id=None, quantity=None, unit_cost=None, source_id=None, description=None):
    _project(db, company_id, project_id)
    _equipment(db, company_id, equipment_id)
    amount = q(amount)
    if amount < 0:
        raise FieldOpsError('Equipment cost cannot be negative')
    if source_type not in {'fuel', 'maintenance', 'other'}:
        raise FieldOpsError('Unsupported equipment cost source')
    row = EquipmentCostEntry(company_id=company_id, equipment_id=equipment_id, project_id=project_id, site_id=site_id, equipment_log_id=equipment_log_id, source_type=source_type, source_id=source_id, entry_date=entry_date, quantity=quantity, unit_cost=unit_cost, amount=amount, description=description)
    db.add(row)
    db.flush()
    if equipment_log_id:
        log = db.query(EquipmentLog).filter_by(id=equipment_log_id, company_id=company_id).with_for_update().one_or_none()
        if not log:
            raise FieldOpsError('Equipment log not found')
        _refresh_equipment_log(db, log)
    else:
        project_cost = ProjectCost(company_id=company_id, project_id=project_id, cost_type='equipment', source_type=f'equipment_{source_type}', source_id=row.id, amount=amount, cost_date=datetime.combine(entry_date, datetime.min.time()), description=description or f'Equipment {source_type} cost')
        db.add(project_cost)
        db.flush()
        row.project_cost_id = project_cost.id
        enqueue_budget_alert_if_needed(db, company_id, project_id, {'source_type': f'equipment_{source_type}', 'source_id': row.id})
    return row


def _refresh_equipment_log(db, log):
    fuel = D(db.query(func.coalesce(func.sum(EquipmentCostEntry.amount), 0)).filter_by(company_id=log.company_id, equipment_log_id=log.id, source_type='fuel').scalar())
    maintenance = D(db.query(func.coalesce(func.sum(EquipmentCostEntry.amount), 0)).filter_by(company_id=log.company_id, equipment_log_id=log.id, source_type='maintenance').scalar())
    other = D(db.query(func.coalesce(func.sum(EquipmentCostEntry.amount), 0)).filter_by(company_id=log.company_id, equipment_log_id=log.id, source_type='other').scalar())
    actual = q(D(log.estimated_cost) + fuel + maintenance + other)
    log.fuel_cost, log.maintenance_cost, log.other_actual_cost = q(fuel), q(maintenance), q(other)
    log.actual_cost = actual
    log.actual_hourly_cost = q(actual / D(log.hours)) if D(log.hours) else Decimal('0')
    log.variance_amount = q(actual - D(log.estimated_cost))
    return log


def post_equipment_log(db, company_id, log_id):
    log = db.query(EquipmentLog).filter_by(id=log_id, company_id=company_id).with_for_update().one_or_none()
    if not log:
        raise FieldOpsError('Equipment log not found')
    if log.status == 'posted':
        return log
    _refresh_equipment_log(db, log)
    existing = db.query(ProjectCost).filter_by(company_id=company_id, project_id=log.project_id, source_type='equipment_log', source_id=log.id).one_or_none()
    if not existing:
        existing = ProjectCost(company_id=company_id, project_id=log.project_id, cost_type='equipment', source_type='equipment_log', source_id=log.id, amount=log.actual_cost, cost_date=datetime.combine(log.work_date, datetime.min.time()), description=f'Equipment {log.equipment_id} site log')
        db.add(existing)
        db.flush()
    log.project_cost_id = existing.id
    log.status = 'posted'
    enqueue_budget_alert_if_needed(db, company_id, log.project_id, {'source_type': 'equipment_log', 'source_id': log.id})
    return log


def allocate_existing_fuel_transaction(db, company_id, transaction_id, project_id, site_id=None, equipment_log_id=None):
    tx = db.query(FuelTransaction).filter_by(id=transaction_id, company_id=company_id).one_or_none()
    if not tx or not tx.equipment_id:
        raise FieldOpsError('Fuel transaction not found or has no equipment')
    return add_equipment_cost(db, company_id, tx.equipment_id, project_id, 'fuel', D(tx.total_cost), tx.transaction_date.date(), site_id=site_id, equipment_log_id=equipment_log_id, quantity=tx.quantity, unit_cost=tx.unit_cost, source_id=tx.id, description=f'Fuel transaction {tx.id}')


def allocate_existing_maintenance_record(db, company_id, maintenance_id, project_id, site_id=None, equipment_log_id=None):
    record = db.query(MaintenanceRecord).filter_by(id=maintenance_id, company_id=company_id).one_or_none()
    if not record:
        raise FieldOpsError('Maintenance record not found')
    return add_equipment_cost(db, company_id, record.equipment_id, project_id, 'maintenance', D(record.cost), record.maintenance_date, site_id=site_id, equipment_log_id=equipment_log_id, source_id=record.id, description=f'Maintenance record {record.id}')


def approve_variation_amendment(db, company_id, variation_id, amendment_no, user_id, approved_amount=None, time_extension_days=None, document_id=None):
    variation = db.query(ConstructionVariation).filter_by(id=variation_id, company_id=company_id).with_for_update().one_or_none()
    if not variation:
        raise FieldOpsError('Variation not found')
    if variation.status == 'approved':
        return variation
    amount = q(variation.amount if approved_amount is None else approved_amount)
    days = int(time_extension_days if time_extension_days is not None else 0)
    if db.query(VariationAmendment).filter_by(company_id=company_id, amendment_no=amendment_no).first():
        raise FieldOpsError('Amendment number already exists')
    project = _project(db, company_id, variation.project_id)
    amendment = VariationAmendment(company_id=company_id, variation_id=variation.id, amendment_no=amendment_no, approved_amount=amount, time_extension_days=days, approved_at=utcnow(), approved_by_id=user_id, status='approved', document_id=document_id)
    db.add(amendment)
    if variation.contract_id:
        contract = db.query(Contract).filter_by(id=variation.contract_id, company_id=company_id, project_id=variation.project_id).with_for_update().one_or_none()
        if not contract:
            raise FieldOpsError('Variation contract not found')
        contract.value = q(D(contract.value) + amount)
    project.budget = q(D(project.budget) + amount)
    variation.status = 'approved'
    variation.approved_at = utcnow()
    variation.approved_by_id = user_id
    variation.financial_status = 'approved'
    variation.schedule_status = 'approved' if days >= 0 else 'pending'
    variation.approved_financial_amount = amount
    variation.approved_time_extension_days = days
    variation.budget_applied_at = utcnow()
    variation.amendment_number = amendment_no
    db.flush()
    return variation


def create_material_requisition(db, company_id, project_id, requisition_no, lines, requested_by_id, site_id=None, required_date=None, purpose=None):
    _project(db, company_id, project_id)
    if db.query(SiteMaterialRequisition).filter_by(company_id=company_id, requisition_no=requisition_no).first():
        raise FieldOpsError('Material requisition number already exists')
    req = SiteMaterialRequisition(company_id=company_id, project_id=project_id, site_id=site_id, requisition_no=requisition_no, requested_by_id=requested_by_id, required_date=required_date, purpose=purpose)
    db.add(req)
    db.flush()
    for line in lines:
        item = db.query(Item).filter_by(id=line['item_id'], company_id=company_id).one_or_none()
        if not item:
            raise FieldOpsError('Material item not found')
        qty = D(line['requested_qty'])
        if qty <= 0:
            raise FieldOpsError('Requested material quantity must be positive')
        budget_qty = line.get('budget_qty')
        budget_amount = line.get('budget_amount')
        if line.get('boq_line_id'):
            boq = db.query(BOQLine).filter_by(id=line['boq_line_id'], company_id=company_id, project_id=project_id).one_or_none()
            if not boq:
                raise FieldOpsError('BOQ line not found')
            if budget_qty is None:
                budget_qty = boq.contract_qty
            if budget_amount is None:
                budget_amount = D(boq.contract_qty) * D(boq.contract_rate)
        if budget_qty is not None:
            already = D(db.query(func.coalesce(func.sum(SiteMaterialRequisitionLine.requested_qty), 0)).join(SiteMaterialRequisition, SiteMaterialRequisition.id == SiteMaterialRequisitionLine.requisition_id).filter(SiteMaterialRequisition.company_id == company_id, SiteMaterialRequisition.project_id == project_id, SiteMaterialRequisitionLine.item_id == line['item_id'], SiteMaterialRequisitionLine.status != 'rejected' if hasattr(SiteMaterialRequisitionLine,'status') else True).scalar())
            if already + qty > D(budget_qty):
                raise BudgetExceeded(f'Material quantity exceeds approved budget by {q(already + qty - D(budget_qty))}')
        unit_cost = D(line.get('estimated_unit_cost', 0))
        row = SiteMaterialRequisitionLine(company_id=company_id, requisition_id=req.id, item_id=line['item_id'], boq_line_id=line.get('boq_line_id'), wbs_id=line.get('wbs_id'), cost_code_id=line.get('cost_code_id'), requested_qty=qty, estimated_unit_cost=unit_cost, estimated_amount=q(qty * unit_cost), budget_qty=budget_qty, budget_amount=budget_amount, notes=line.get('notes'))
        db.add(row)
    db.flush()
    return req


def approve_material_requisition(db, company_id, requisition_id, user_id):
    req = db.query(SiteMaterialRequisition).filter_by(id=requisition_id, company_id=company_id).with_for_update().one_or_none()
    if not req:
        raise FieldOpsError('Material requisition not found')
    if req.status != 'draft':
        raise FieldOpsError('Material requisition is not draft')
    for line in db.query(SiteMaterialRequisitionLine).filter_by(requisition_id=req.id, company_id=company_id).with_for_update().all():
        line.approved_qty = line.requested_qty
    req.status, req.approved_by_id, req.approved_at = 'approved', user_id, utcnow()
    db.flush()
    return req


def fulfill_material_requisition(db, company_id, requisition_id, fulfillment_type, reference):
    req = db.query(SiteMaterialRequisition).filter_by(id=requisition_id, company_id=company_id).with_for_update().one_or_none()
    if not req:
        raise FieldOpsError('Material requisition not found')
    if req.status != 'approved':
        raise FieldOpsError('Material requisition must be approved before fulfillment')
    if fulfillment_type not in {'stock_issue', 'purchase_request'}:
        raise FieldOpsError('Unsupported fulfillment type')
    req.status = 'fulfilled' if fulfillment_type == 'stock_issue' else 'purchase_requested'
    req.fulfillment_type, req.fulfillment_reference = fulfillment_type, reference
    for line in db.query(SiteMaterialRequisitionLine).filter_by(requisition_id=req.id, company_id=company_id):
        line.fulfilled_qty = line.approved_qty or line.requested_qty if fulfillment_type == 'stock_issue' else line.fulfilled_qty
    db.flush()
    return req


def submit_offline_batch(db, company_id, device_id, batch_id, user_id, operations, client_created_at=None):
    batch = db.query(OfflineSyncBatch).filter_by(company_id=company_id, device_id=device_id, batch_id=batch_id).one_or_none()
    if batch:
        return batch
    batch = OfflineSyncBatch(company_id=company_id, device_id=device_id, batch_id=batch_id, user_id=user_id, client_created_at=client_created_at)
    db.add(batch)
    db.flush()
    for op in operations:
        operation_id = op['operation_id']
        if db.query(OfflineSyncOperation).filter_by(company_id=company_id, operation_id=operation_id).first():
            continue
        row = OfflineSyncOperation(company_id=company_id, batch_id=batch.id, operation_id=operation_id, entity_type=op['entity_type'], entity_id=op.get('entity_id'), operation=op['operation'], payload=op.get('payload', {}), client_version=int(op.get('client_version', 1)))
        db.add(row)
    db.flush()
    return batch


def process_offline_batch(db, company_id, batch_id):
    batch = db.query(OfflineSyncBatch).filter_by(id=batch_id, company_id=company_id).with_for_update().one_or_none()
    if not batch:
        raise FieldOpsError('Offline batch not found')
    operations = db.query(OfflineSyncOperation).filter_by(batch_id=batch.id, company_id=company_id).all()
    conflicts = []
    for op in operations:
        if op.status == 'applied':
            continue
        if op.entity_id is not None and op.client_version < 1:
            op.status = 'conflict'; op.conflict_code = 'INVALID_VERSION'; op.conflict_detail = 'Client version must be positive'
        elif op.operation not in {'create', 'update', 'delete'}:
            op.status = 'conflict'; op.conflict_code = 'INVALID_OPERATION'; op.conflict_detail = 'Unsupported offline operation'
        else:
            op.status = 'accepted'; op.processed_at = utcnow()
        if op.status == 'conflict':
            conflict = OfflineConflict(company_id=company_id, operation_id=op.id, entity_type=op.entity_type, entity_id=op.entity_id, client_version=op.client_version, resolution='manual', detail=op.conflict_detail)
            db.add(conflict); conflicts.append(conflict)
    batch.status = 'conflict' if conflicts else 'processed'
    db.flush()
    return batch, conflicts


def resolve_offline_conflict(db, company_id, conflict_id, resolution, user_id):
    conflict = db.query(OfflineConflict).filter_by(id=conflict_id, company_id=company_id).with_for_update().one_or_none()
    if not conflict:
        raise FieldOpsError('Offline conflict not found')
    if resolution not in {'accept_server', 'accept_client', 'manual'}:
        raise FieldOpsError('Unsupported conflict resolution')
    conflict.resolution = resolution
    conflict.resolved_by_id = user_id
    conflict.resolved_at = utcnow()
    op = db.query(OfflineSyncOperation).filter_by(id=conflict.operation_id, company_id=company_id).one_or_none()
    if op:
        op.status = 'accepted' if resolution == 'accept_client' else 'resolved'
        op.processed_at = utcnow()
    db.flush()
    return conflict

def create_webhook_subscription(db, company_id, name, endpoint_url, secret, event_type):
    row = WebhookSubscription(company_id=company_id, name=name, endpoint_url=endpoint_url, secret=secret, event_type=event_type)
    db.add(row); db.flush(); return row


def enqueue_webhook_event(db, company_id, event_type, payload):
    event_id = str(uuid.uuid4())
    rows = db.query(WebhookSubscription).filter_by(company_id=company_id, event_type=event_type, is_active=True).all()
    for sub in rows:
        db.add(WebhookDelivery(company_id=company_id, subscription_id=sub.id, event_id=event_id, event_type=event_type, payload=payload))
    db.flush()
    return event_id, len(rows)


def webhook_signature(secret, payload):
    body = json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


def enqueue_budget_alert_if_needed(db, company_id, project_id, event_payload=None):
    project = _project(db, company_id, project_id)
    budget = D(project.budget)
    actual = D(db.query(func.coalesce(func.sum(ProjectCost.amount), 0)).filter_by(company_id=company_id, project_id=project_id).scalar())
    if budget > 0 and actual > budget:
        payload = {'project_id': project_id, 'budget': str(q(budget)), 'actual_cost': str(q(actual)), 'variance': str(q(actual - budget))}
        if event_payload:
            payload.update(event_payload)
        return enqueue_webhook_event(db, company_id, 'project.budget.exceeded', payload)
    return None, 0


def create_license(db, company_id, license_type, license_number, expiry_date, reminder_days=30, project_id=None, site_id=None, equipment_id=None, issue_date=None, document_id=None):
    if reminder_days < 0:
        raise FieldOpsError('Reminder days cannot be negative')
    if db.query(LicenseRegister).filter_by(company_id=company_id, license_number=license_number).first():
        raise FieldOpsError('License number already exists')
    row = LicenseRegister(company_id=company_id, project_id=project_id, site_id=site_id, equipment_id=equipment_id, license_type=license_type, license_number=license_number, issue_date=issue_date, expiry_date=expiry_date, reminder_days=reminder_days, document_id=document_id)
    db.add(row)
    db.flush()
    return row


def evaluate_license_alerts(db, company_id, as_of_date):
    rows = db.query(LicenseRegister).filter(LicenseRegister.company_id == company_id, LicenseRegister.status == 'active').all()
    queued = []
    for row in rows:
        days_left = (row.expiry_date - as_of_date).days
        if days_left < 0:
            event = enqueue_webhook_event(db, company_id, 'license.expired', {'license_id': row.id, 'license_number': row.license_number, 'expiry_date': row.expiry_date.isoformat(), 'days_overdue': abs(days_left)})
            queued.append((row.id, 'expired', event[0]))
        elif days_left <= row.reminder_days:
            event = enqueue_webhook_event(db, company_id, 'license.expiring', {'license_id': row.id, 'license_number': row.license_number, 'expiry_date': row.expiry_date.isoformat(), 'days_left': days_left})
            queued.append((row.id, 'expiring', event[0]))
    db.flush()
    return queued


def dispatch_webhook_delivery(db, company_id, delivery_id):
    delivery = db.query(WebhookDelivery).filter_by(id=delivery_id, company_id=company_id).one_or_none()
    if not delivery:
        raise FieldOpsError('Webhook delivery not found')
    subscription = db.query(WebhookSubscription).filter_by(id=delivery.subscription_id, company_id=company_id, is_active=True).one_or_none()
    if not subscription:
        raise FieldOpsError('Webhook subscription not found')
    body = json.dumps(delivery.payload, sort_keys=True, separators=(',', ':'))
    signature = webhook_signature(subscription.secret, delivery.payload)
    delivery.attempts += 1
    try:
        response = httpx.post(subscription.endpoint_url, content=body, headers={'Content-Type': 'application/json', 'X-ERP-Event': delivery.event_type, 'X-ERP-Signature': signature, 'X-ERP-Event-ID': delivery.event_id}, timeout=5.0, follow_redirects=False)
        if 200 <= response.status_code < 300:
            delivery.status = 'delivered'; delivery.delivered_at = utcnow(); delivery.last_error = None
        else:
            delivery.status = 'failed'; delivery.last_error = f'HTTP {response.status_code}'
    except Exception as exc:
        delivery.status = 'failed'; delivery.last_error = str(exc)[:500]
    db.flush()
    return delivery


def issue_material_requisition_from_warehouse(db, company_id, requisition_id, warehouse_id, issued_by_id, issue_date=None):
    """Issue approved site requisition quantities from one warehouse atomically."""
    from datetime import date
    from .enterprise_models import ProjectCost
    req = db.query(SiteMaterialRequisition).filter_by(id=requisition_id, company_id=company_id).with_for_update().one_or_none()
    if not req:
        raise FieldOpsError("Material requisition not found")
    if req.status != "approved":
        raise FieldOpsError("Material requisition must be approved before stock issue")
    wh = db.query(Warehouse).filter_by(id=warehouse_id, company_id=company_id, is_active=True).first()
    if not wh:
        raise FieldOpsError("Warehouse not found or inactive")
    if wh.project_id is not None and wh.project_id != req.project_id:
        raise FieldOpsError("Warehouse is assigned to another project")
    site = req.site_id
    rows = db.query(SiteMaterialRequisitionLine).filter_by(requisition_id=req.id, company_id=company_id).with_for_update().all()
    if not rows:
        raise FieldOpsError("Material requisition has no lines")
    issued = []
    issue_date = issue_date or date.today()
    for line in rows:
        approved = D(line.approved_qty or line.requested_qty)
        fulfilled = D(line.fulfilled_qty or 0)
        qty = approved - fulfilled
        if qty <= 0:
            continue
        inbound = D(db.query(func.coalesce(func.sum(StockMovement.quantity), 0)).filter(
            StockMovement.company_id == company_id, StockMovement.item_id == line.item_id,
            StockMovement.warehouse_id == wh.id,
            StockMovement.movement_type.in_([MovementTypeEnum.in_, MovementTypeEnum.adjustment_in])).scalar() or 0)
        outbound = D(db.query(func.coalesce(func.sum(StockMovement.quantity), 0)).filter(
            StockMovement.company_id == company_id, StockMovement.item_id == line.item_id,
            StockMovement.warehouse_id == wh.id,
            StockMovement.movement_type.in_([MovementTypeEnum.out, MovementTypeEnum.adjustment_out])).scalar() or 0)
        available = inbound - outbound
        if available < qty:
            raise FieldOpsError(f"Insufficient stock in warehouse for item {line.item_id}: available {available}, required {qty}")
        item = db.query(Item).filter_by(id=line.item_id, company_id=company_id, is_active=True).first()
        if not item:
            raise FieldOpsError("Material item not found or inactive")
        # Weighted average of the selected warehouse's remaining movements.
        ins = db.query(StockMovement).filter(
            StockMovement.company_id == company_id, StockMovement.item_id == line.item_id,
            StockMovement.warehouse_id == wh.id,
            StockMovement.movement_type.in_([MovementTypeEnum.in_, MovementTypeEnum.adjustment_in])).all()
        total_qty = sum((D(x.quantity) for x in ins), Decimal("0"))
        total_value = sum((D(x.quantity) * D(x.unit_cost) for x in ins), Decimal("0"))
        avg_cost = q(total_value / total_qty) if total_qty else q(item.purchase_price or 0)
        issue = SiteMaterialIssue(company_id=company_id, project_id=req.project_id, site_id=req.site_id, item_id=line.item_id,
            warehouse_id=wh.id, requisition_id=req.id, requisition_line_id=line.id, boq_line_id=line.boq_line_id, issued_by_id=issued_by_id,
            quantity=qty, unit_cost=avg_cost, total_cost=q(qty * avg_cost), issue_date=issue_date,
            reference=req.requisition_no, status="posted")
        db.add(issue); db.flush()
        movement = StockMovement(company_id=company_id, item_id=line.item_id, warehouse_id=wh.id,
            movement_type=MovementTypeEnum.out, quantity=qty, unit_cost=avg_cost, total_cost=issue.total_cost,
            note=f"Site requisition {req.requisition_no}", created_by_id=issued_by_id, source_type="site_requisition", source_id=req.id, operational_date=issue_date)
        db.add(movement); db.flush()
        db.add(ProjectCost(company_id=company_id, project_id=req.project_id, cost_type="material",
            source_type="site_material_issue", source_id=issue.id, amount=issue.total_cost,
            cost_date=utcnow(), description=f"Material issue {req.requisition_no}"))
        line.fulfilled_qty = fulfilled + qty
        issued.append(issue)
    if not issued:
        raise FieldOpsError("All requested quantities are already fulfilled")
    req.status = "fulfilled" if all(D(x.fulfilled_qty or 0) >= D(x.approved_qty or x.requested_qty) for x in rows) else "partially_fulfilled"
    req.fulfillment_type = "stock_issue"
    req.fulfillment_reference = wh.code
    db.flush()
    return issued


def _site_issued_available(db, company_id, project_id, site_id, item_id):
    """Material physically available at site.

    A site cannot consume material merely because it was issued from the warehouse;
    it must first be received at the site.  This preserves the real workflow:
    issue -> receipt -> consumption/waste/return.
    """
    from .site_material_flow_models import SiteMaterialReceipt, SiteMaterialConsumption, SiteMaterialAdjustment
    received = D(db.query(func.coalesce(func.sum(SiteMaterialReceipt.quantity), 0)).filter(
        SiteMaterialReceipt.company_id == company_id, SiteMaterialReceipt.project_id == project_id,
        SiteMaterialReceipt.site_id == site_id, SiteMaterialReceipt.item_id == item_id,
        SiteMaterialReceipt.status == 'posted').scalar() or 0)
    returned = D(db.query(func.coalesce(func.sum(SiteMaterialAdjustment.quantity), 0)).filter(
        SiteMaterialAdjustment.company_id == company_id, SiteMaterialAdjustment.project_id == project_id,
        SiteMaterialAdjustment.site_id == site_id, SiteMaterialAdjustment.item_id == item_id,
        SiteMaterialAdjustment.adjustment_type == 'return', SiteMaterialAdjustment.status == 'posted').scalar() or 0)
    consumed = D(db.query(func.coalesce(func.sum(SiteMaterialConsumption.quantity), 0)).filter(
        SiteMaterialConsumption.company_id == company_id, SiteMaterialConsumption.project_id == project_id,
        SiteMaterialConsumption.site_id == site_id, SiteMaterialConsumption.item_id == item_id,
        SiteMaterialConsumption.status == 'posted').scalar() or 0)
    wasted = D(db.query(func.coalesce(func.sum(SiteMaterialAdjustment.quantity), 0)).filter(
        SiteMaterialAdjustment.company_id == company_id, SiteMaterialAdjustment.project_id == project_id,
        SiteMaterialAdjustment.site_id == site_id, SiteMaterialAdjustment.item_id == item_id,
        SiteMaterialAdjustment.adjustment_type == 'waste', SiteMaterialAdjustment.status == 'posted').scalar() or 0)
    return received - returned - consumed - wasted


def _site_material_unit_cost(db, company_id, project_id, site_id, item_id):
    """Use the latest posted receipt cost; fall back to the latest warehouse issue."""
    from .site_material_flow_models import SiteMaterialReceipt
    receipt = db.query(SiteMaterialReceipt).filter_by(
        company_id=company_id, project_id=project_id, site_id=site_id,
        item_id=item_id, status='posted').order_by(
        SiteMaterialReceipt.receipt_date.desc(), SiteMaterialReceipt.id.desc()).first()
    if receipt:
        return D(receipt.unit_cost)
    issue = db.query(SiteMaterialIssue).filter_by(
        company_id=company_id, project_id=project_id, site_id=site_id,
        item_id=item_id, status='posted').order_by(
        SiteMaterialIssue.issue_date.desc(), SiteMaterialIssue.id.desc()).first()
    return D(issue.unit_cost) if issue else D(0)

def receive_material_at_site(db, company_id, issue_id, quantity, received_by_id, receipt_date=None, reference=None):
    from datetime import date
    from .site_material_flow_models import SiteMaterialReceipt
    qty = D(quantity)
    if qty <= 0: raise FieldOpsError('Receipt quantity must be greater than zero')
    issue = db.query(SiteMaterialIssue).filter_by(id=issue_id, company_id=company_id, status='posted').with_for_update().one_or_none()
    if not issue: raise FieldOpsError('Posted material issue not found')
    received = D(db.query(func.coalesce(func.sum(SiteMaterialReceipt.quantity), 0)).filter(SiteMaterialReceipt.company_id == company_id, SiteMaterialReceipt.issue_id == issue.id, SiteMaterialReceipt.status == 'posted').scalar() or 0)
    if received + qty > D(issue.quantity): raise FieldOpsError('Receipt exceeds the issued quantity')
    row = SiteMaterialReceipt(company_id=company_id, project_id=issue.project_id, site_id=issue.site_id, issue_id=issue.id, item_id=issue.item_id, quantity=qty, unit_cost=issue.unit_cost, total_cost=q(qty*D(issue.unit_cost)), receipt_date=receipt_date or date.today(), received_by_id=received_by_id, reference=reference or issue.reference, status='posted')
    db.add(row); db.flush(); return row


def consume_site_material(db, company_id, project_id, site_id, item_id, quantity, consumed_by_id, consumption_date=None, cost_code_id=None, boq_line_id=None, reference=None, receipt_id=None):
    from datetime import date
    from .site_material_flow_models import SiteMaterialConsumption
    qty = D(quantity)
    if qty <= 0: raise FieldOpsError('Consumption quantity must be greater than zero')
    available = _site_issued_available(db, company_id, project_id, site_id, item_id)
    if available < qty: raise FieldOpsError(f'Insufficient material available at site: available {available}, required {qty}')
    unit_cost = _site_material_unit_cost(db, company_id, project_id, site_id, item_id)
    row = SiteMaterialConsumption(company_id=company_id, project_id=project_id, site_id=site_id, item_id=item_id, receipt_id=receipt_id, quantity=qty, unit_cost=unit_cost, total_cost=q(qty*unit_cost), consumption_date=consumption_date or date.today(), consumed_by_id=consumed_by_id, cost_code_id=cost_code_id, boq_line_id=boq_line_id, reference=reference, status='posted')
    db.add(row); db.flush()
    from .enterprise_models import ProjectCost
    db.add(ProjectCost(company_id=company_id, project_id=project_id, cost_type='material_consumption', source_type='site_material_consumption', source_id=row.id, amount=row.total_cost, cost_date=utcnow(), description=f'Site material consumption {reference or row.id}'))
    return row


def adjust_site_material(db, company_id, project_id, site_id, item_id, adjustment_type, quantity, created_by_id, reason, warehouse_id=None, adjustment_date=None, reference=None):
    from datetime import date
    from .site_material_flow_models import SiteMaterialAdjustment
    qty = D(quantity)
    if adjustment_type not in ('waste','return'): raise FieldOpsError('Adjustment type must be waste or return')
    if qty <= 0: raise FieldOpsError('Adjustment quantity must be greater than zero')
    available = _site_issued_available(db, company_id, project_id, site_id, item_id)
    if available < qty: raise FieldOpsError(f'Insufficient material available at site: available {available}, required {qty}')
    unit_cost = _site_material_unit_cost(db, company_id, project_id, site_id, item_id)
    if adjustment_type == 'return':
        if not warehouse_id: raise FieldOpsError('Return requires a destination warehouse')
        wh = db.query(Warehouse).filter_by(id=warehouse_id, company_id=company_id, is_active=True).first()
        if not wh or (wh.project_id is not None and wh.project_id != project_id): raise FieldOpsError('Invalid destination warehouse for project')
        db.add(StockMovement(company_id=company_id, item_id=item_id, warehouse_id=warehouse_id, movement_type=MovementTypeEnum.in_, quantity=qty, unit_cost=unit_cost, total_cost=q(qty*unit_cost), note=f'Site material return {reference or project_id}', created_by_id=created_by_id, source_type="site_material_return", source_id=project_id, operational_date=issue_date))
    row = SiteMaterialAdjustment(company_id=company_id, project_id=project_id, site_id=site_id, item_id=item_id, warehouse_id=warehouse_id, adjustment_type=adjustment_type, quantity=qty, unit_cost=unit_cost, total_cost=q(qty*unit_cost), adjustment_date=adjustment_date or date.today(), reason=reason.strip(), created_by_id=created_by_id, reference=reference, status='posted')
    db.add(row); db.flush()
    from .enterprise_models import ProjectCost
    if adjustment_type == 'return':
        db.add(ProjectCost(company_id=company_id, project_id=project_id, cost_type='material_return', source_type='site_material_return', source_id=row.id, amount=q(-qty*unit_cost), cost_date=utcnow(), description=f'Material return {reference or ""}'.strip()))
    else:
        db.add(ProjectCost(company_id=company_id, project_id=project_id, cost_type='material_waste', source_type='site_material_waste', source_id=row.id, amount=row.total_cost, cost_date=utcnow(), description=f'Site material waste {reference or row.id}'))
    return row
