import logging
# -*- coding: utf-8 -*-
from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment
from reportlab.lib.pagesizes import A4, landscape
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.units import mm
from fastapi.responses import StreamingResponse
from pathlib import Path

logger = logging.getLogger(__name__)

try:
    import arabic_reshaper
    from bidi.algorithm import get_display
except Exception:
    arabic_reshaper = None
    get_display = None

FONT_PATH = "/usr/share/fonts/truetype/noto/NotoSansArabicUI-Regular.ttf"
BOLD_PATH = "/usr/share/fonts/truetype/noto/NotoSansArabicUI-Bold.ttf"
try:
    if Path(FONT_PATH).exists(): pdfmetrics.registerFont(TTFont("ERPArabic", FONT_PATH))
    if Path(BOLD_PATH).exists(): pdfmetrics.registerFont(TTFont("ERPArabicBold", BOLD_PATH))
except Exception:
    logger.exception("Failed to register optional ERP PDF fonts")


def ar(text):
    text = "" if text is None else str(text)
    if arabic_reshaper and get_display:
        return get_display(arabic_reshaper.reshape(text))
    return text


def _excel_safe_value(value):
    """Keep user-controlled strings as literal Excel text, never formulas.

    Excel treats values beginning with =, +, -, @, or control characters as
    potentially executable formulas/commands. Prefixing those strings with a
    single quote preserves the displayed value while disabling formula parsing.
    """
    if value is None:
        return ""
    if not isinstance(value, str):
        return value
    text = value
    stripped = text.lstrip()
    if stripped.startswith(("=", "+", "-", "@")) or "\t" in text or "\r" in text or "\n" in text:
        return "'" + text
    return text


def excel_response(title, headers, rows, filename):
    wb = Workbook(); ws = wb.active; ws.title = title[:31]
    ws.sheet_view.rightToLeft = True
    ws.append(headers)
    for c in ws[1]:
        c.font = Font(bold=True); c.alignment = Alignment(horizontal="right")
    for row in rows: ws.append([_excel_safe_value(v) for v in row])
    for col in ws.columns:
        max_len = min(max(len(str(c.value or "")) for c in col) + 2, 45)
        ws.column_dimensions[col[0].column_letter].width = max_len
    out = BytesIO(); wb.save(out); out.seek(0)
    return StreamingResponse(out, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition": f'attachment; filename="{filename}"'})


def pdf_response(title, headers, rows, filename):
    out = BytesIO(); c = canvas.Canvas(out, pagesize=landscape(A4)); w, h = landscape(A4)
    font = "ERPArabic" if "ERPArabic" in pdfmetrics.getRegisteredFontNames() else "Helvetica"
    bold = "ERPArabicBold" if "ERPArabicBold" in pdfmetrics.getRegisteredFontNames() else font
    c.setFont(bold, 16); c.drawRightString(w-15*mm, h-15*mm, ar(title))
    y = h-28*mm; c.setFont(bold, 8)
    widths = [w/max(len(headers),1)] * len(headers)
    for i, head in enumerate(headers):
        x = w-15*mm-sum(widths[:i]); c.drawRightString(x, y, ar(head))
    y -= 7*mm; c.setFont(font, 7)
    for row in rows:
        if y < 15*mm:
            c.showPage(); y = h-15*mm; c.setFont(font,7)
        for i, val in enumerate(row):
            x = w-15*mm-sum(widths[:i]); c.drawRightString(x, y, ar(val))
        y -= 6*mm
    c.save(); out.seek(0)
    return StreamingResponse(out, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="{filename}"'})
