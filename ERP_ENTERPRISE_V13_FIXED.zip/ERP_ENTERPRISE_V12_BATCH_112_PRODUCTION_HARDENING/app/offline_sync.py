"""Deterministic offline-first conflict policy for mobile mutations."""
from dataclasses import dataclass
from enum import Enum

class ConflictPolicy(str, Enum):
    IDEMPOTENT = "idempotent"
    SERVER_WINS = "server_wins"
    CLIENT_WINS = "client_wins"
    MANUAL = "manual"

@dataclass(frozen=True)
class SyncDecision:
    action: str
    reason: str

MUTATION_POLICIES = {
    "journal_entry": ConflictPolicy.MANUAL,
    "sales_invoice": ConflictPolicy.MANUAL,
    "site_material_issue": ConflictPolicy.MANUAL,
    "site_material_consumption": ConflictPolicy.MANUAL,
    "stock_movement": ConflictPolicy.MANUAL,
    "document": ConflictPolicy.SERVER_WINS,
    "progress_update": ConflictPolicy.MANUAL,
}

def decide(entity_type: str, *, operation_id_seen: bool, client_version: int, server_version: int | None,
           entity_exists: bool) -> SyncDecision:
    if operation_id_seen:
        return SyncDecision("ignore_duplicate", "operation_id already processed")
    if client_version < 1:
        return SyncDecision("reject", "client_version must be positive")
    policy = MUTATION_POLICIES.get(entity_type, ConflictPolicy.MANUAL)
    if entity_exists and server_version is not None and client_version != server_version:
        if policy == ConflictPolicy.SERVER_WINS:
            return SyncDecision("accept_server", "server version changed")
        if policy == ConflictPolicy.CLIENT_WINS:
            return SyncDecision("accept_client", "explicit client-wins policy")
        return SyncDecision("manual_conflict", "version mismatch on non-mergeable financial/stock data")
    return SyncDecision("apply", "new operation or matching version")
