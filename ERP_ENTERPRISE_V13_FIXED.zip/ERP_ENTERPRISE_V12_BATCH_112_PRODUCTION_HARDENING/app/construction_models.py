from .time_utils import utcnow
"""Construction ERP domain models built on the reusable ERP Core."""
from datetime import datetime, date
from sqlalchemy import Column, Integer, String, Numeric, Date, DateTime, ForeignKey, Boolean, Text, UniqueConstraint, CheckConstraint, Index
from .db_base import Base

class ConstructionCostCode(Base):
    __tablename__ = 'construction_cost_codes'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    code=Column(String(60), nullable=False)
    name=Column(String(180), nullable=False)
    category=Column(String(40), nullable=False)  # material/labor/equipment/subcontract/overhead/other
    parent_id=Column(Integer, ForeignKey('construction_cost_codes.id'))
    is_active=Column(Boolean, default=True, nullable=False)
    __table_args__=(UniqueConstraint('company_id','code',name='uq_construction_cost_code'),)

class WBSNode(Base):
    __tablename__ = 'construction_wbs_nodes'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    parent_id=Column(Integer, ForeignKey('construction_wbs_nodes.id'))
    code=Column(String(60), nullable=False)
    name=Column(String(180), nullable=False)
    level=Column(Integer, default=1, nullable=False)
    budget_amount=Column(Numeric(20,6), default=0, nullable=False)
    is_active=Column(Boolean, default=True, nullable=False)
    __table_args__=(UniqueConstraint('project_id','code',name='uq_wbs_project_code'),)

class BOQRevision(Base):
    __tablename__ = 'construction_boq_revisions'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    revision_no=Column(Integer, nullable=False)
    status=Column(String(30), default='draft', nullable=False)
    effective_date=Column(Date, nullable=False)
    reason=Column(Text)
    created_by_id=Column(Integer, ForeignKey('users.id'))
    created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint('project_id','revision_no',name='uq_boq_revision_project_no'),)

class BOQLine(Base):
    __tablename__ = 'construction_boq_lines'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    revision_id=Column(Integer, ForeignKey('construction_boq_revisions.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    boq_item_id=Column(Integer, ForeignKey('boq_items.id'), nullable=True)
    wbs_id=Column(Integer, ForeignKey('construction_wbs_nodes.id'))
    cost_code_id=Column(Integer, ForeignKey('construction_cost_codes.id'))
    item_code=Column(String(60), nullable=False)
    description=Column(Text, nullable=False)
    unit=Column(String(30), nullable=False)
    contract_qty=Column(Numeric(20,6), nullable=False)
    contract_rate=Column(Numeric(20,6), nullable=False)
    __table_args__=(CheckConstraint('contract_qty >= 0','ck_boq_qty_nonnegative'), CheckConstraint('contract_rate >= 0','ck_boq_rate_nonnegative'))

class BOQExecution(Base):
    __tablename__ = 'construction_boq_executions'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    boq_line_id=Column(Integer, ForeignKey('construction_boq_lines.id'), nullable=False, index=True)
    measurement_id=Column(Integer, ForeignKey('construction_measurements.id'))
    quantity=Column(Numeric(20,6), nullable=False)
    execution_date=Column(Date, nullable=False)
    source_type=Column(String(60))
    source_id=Column(Integer)
    __table_args__=(CheckConstraint('quantity >= 0','ck_boq_execution_qty_nonnegative'),)

class ConstructionMeasurement(Base):
    __tablename__ = 'construction_measurements'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    measurement_no=Column(String(60), nullable=False)
    measurement_date=Column(Date, nullable=False)
    status=Column(String(30), default='draft', nullable=False)
    notes=Column(Text)
    created_by_id=Column(Integer, ForeignKey('users.id'))
    __table_args__=(UniqueConstraint('company_id','measurement_no',name='uq_measurement_company_no'),)

class ConstructionMeasurementLine(Base):
    __tablename__ = 'construction_measurement_lines'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    measurement_id=Column(Integer, ForeignKey('construction_measurements.id'), nullable=False, index=True)
    boq_line_id=Column(Integer, ForeignKey('construction_boq_lines.id'), nullable=False)
    current_qty=Column(Numeric(20,6), nullable=False)
    cumulative_qty=Column(Numeric(20,6), nullable=False)
    amount=Column(Numeric(20,6), nullable=False)
    __table_args__=(CheckConstraint('current_qty >= 0','ck_measurement_current_nonnegative'), CheckConstraint('cumulative_qty >= 0','ck_measurement_cumulative_nonnegative'))

class ConstructionVariation(Base):
    __tablename__ = 'construction_variations'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    contract_id=Column(Integer, ForeignKey('contracts.id'))
    variation_no=Column(String(60), nullable=False)
    description=Column(Text, nullable=False)
    amount=Column(Numeric(20,6), nullable=False, default=0)
    status=Column(String(30), default='draft', nullable=False)
    approved_at=Column(DateTime)
    approved_by_id=Column(Integer, ForeignKey('users.id'))
    financial_status=Column(String(30), nullable=False, default='pending')
    schedule_status=Column(String(30), nullable=False, default='pending')
    approved_financial_amount=Column(Numeric(20,6), nullable=True)
    approved_time_extension_days=Column(Integer, nullable=True)
    amendment_number=Column(String(60), nullable=True)
    budget_applied_at=Column(DateTime, nullable=True)
    __table_args__=(UniqueConstraint('company_id','variation_no',name='uq_variation_company_no'),)

class ConstructionAdvance(Base):
    __tablename__ = 'construction_advances'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    contract_id=Column(Integer, ForeignKey('contracts.id'), nullable=False)
    direction=Column(String(20), nullable=False)  # received/payable
    amount=Column(Numeric(20,6), nullable=False)
    recovered_amount=Column(Numeric(20,6), default=0, nullable=False)
    advance_date=Column(Date, nullable=False)
    status=Column(String(30), default='open', nullable=False)
    reference=Column(String(100))
    journal_entry_id=Column(Integer, ForeignKey('journal_entries.id'))
    __table_args__=(CheckConstraint('amount > 0','ck_advance_positive'), CheckConstraint('recovered_amount >= 0 AND recovered_amount <= amount','ck_advance_recovery_bounds'))

class ConstructionProgressCertificateLine(Base):
    __tablename__ = 'construction_progress_certificate_lines'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    certificate_id=Column(Integer, ForeignKey('progress_certificates.id'), nullable=False, index=True)
    boq_line_id=Column(Integer, ForeignKey('construction_boq_lines.id'), nullable=False)
    current_qty=Column(Numeric(20,6), nullable=False)
    cumulative_qty=Column(Numeric(20,6), nullable=False)
    gross_amount=Column(Numeric(20,6), nullable=False)
    retention_amount=Column(Numeric(20,6), default=0, nullable=False)
    advance_recovery=Column(Numeric(20,6), default=0, nullable=False)
    net_amount=Column(Numeric(20,6), nullable=False)

class SubcontractorProgress(Base):
    __tablename__ = 'subcontractor_progress'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    contract_id=Column(Integer, ForeignKey('contracts.id'), nullable=False)
    measurement_id=Column(Integer, ForeignKey('subcontractor_measurements.id'))
    certificate_no=Column(String(60), nullable=False)
    gross_amount=Column(Numeric(20,6), nullable=False)
    retention_amount=Column(Numeric(20,6), default=0, nullable=False)
    advance_recovery=Column(Numeric(20,6), default=0, nullable=False)
    deductions=Column(Numeric(20,6), default=0, nullable=False)
    net_amount=Column(Numeric(20,6), nullable=False)
    status=Column(String(30), default='draft', nullable=False)
    certificate_date=Column(Date, nullable=False)
    approved_at=Column(DateTime)
    approved_by_id=Column(Integer, ForeignKey('users.id'))
    journal_entry_id=Column(Integer, ForeignKey('journal_entries.id'))
    __table_args__=(UniqueConstraint('company_id','certificate_no',name='uq_subcontractor_certificate_no'),)

# Phase 6.1 — Construction site operations and field cost control
class ConstructionSite(Base):
    __tablename__='construction_sites'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    code=Column(String(60), nullable=False); name=Column(String(180), nullable=False)
    location=Column(String(250)); manager_id=Column(Integer, ForeignKey('users.id'))
    status=Column(String(30), nullable=False, default='active')
    __table_args__=(UniqueConstraint('company_id','code',name='uq_construction_site_company_code'),)

class SiteMaterialIssue(Base):
    __tablename__='site_material_issues'
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True); site_id=Column(Integer, ForeignKey('construction_sites.id'), nullable=False)
    item_id=Column(Integer, ForeignKey('items.id'), nullable=False); warehouse_id=Column(Integer, ForeignKey('warehouses.id', ondelete='SET NULL'), nullable=True, index=True)
    requisition_id=Column(Integer, ForeignKey('site_material_requisitions.id', ondelete='SET NULL'), nullable=True, index=True)
    requisition_line_id=Column(Integer, ForeignKey('site_material_requisition_lines.id', ondelete='SET NULL'), nullable=True, index=True); boq_line_id=Column(Integer, ForeignKey('construction_boq_lines.id', ondelete='SET NULL'), nullable=True, index=True)
    issued_by_id=Column(Integer, ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    quantity=Column(Numeric(20,6), nullable=False)
    unit_cost=Column(Numeric(20,6), nullable=False); total_cost=Column(Numeric(20,6), nullable=False)
    issue_date=Column(Date, nullable=False); reference=Column(String(100)); status=Column(String(30), nullable=False, default='posted')
    __table_args__=(CheckConstraint('quantity > 0','ck_site_material_qty_positive'),CheckConstraint('unit_cost >= 0','ck_site_material_unit_cost_nonnegative'))

class EquipmentUsage(Base):
    __tablename__='construction_equipment_usage'
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True); equipment_id=Column(Integer, ForeignKey('equipment.id'), nullable=False, index=True)
    site_id=Column(Integer, ForeignKey('construction_sites.id')); usage_date=Column(Date, nullable=False)
    start_reading=Column(Numeric(20,6), nullable=False); end_reading=Column(Numeric(20,6), nullable=False); hours=Column(Numeric(20,6), nullable=False)
    rate_per_hour=Column(Numeric(20,6), nullable=False); total_cost=Column(Numeric(20,6), nullable=False)
    __table_args__=(CheckConstraint('end_reading >= start_reading','ck_equipment_reading_order'),CheckConstraint('hours >= 0','ck_equipment_hours_nonnegative'))

class ConstructionLaborEntry(Base):
    __tablename__='construction_labor_entries'
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True); site_id=Column(Integer, ForeignKey('construction_sites.id'))
    employee_id=Column(Integer, ForeignKey('employees.id'), nullable=False); work_date=Column(Date, nullable=False)
    regular_hours=Column(Numeric(20,6), nullable=False, default=0); overtime_hours=Column(Numeric(20,6), nullable=False, default=0)
    regular_rate=Column(Numeric(20,6), nullable=False, default=0); overtime_rate=Column(Numeric(20,6), nullable=False, default=0); total_cost=Column(Numeric(20,6), nullable=False, default=0)
    __table_args__=(CheckConstraint('regular_hours >= 0 AND overtime_hours >= 0','ck_labor_hours_nonnegative'),)

class SubcontractorBOQLine(Base):
    __tablename__='subcontractor_boq_lines'
    id=Column(Integer, primary_key=True); company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True); contract_id=Column(Integer, ForeignKey('contracts.id'), nullable=False)
    cost_code_id=Column(Integer, ForeignKey('construction_cost_codes.id')); item_code=Column(String(60), nullable=False); description=Column(Text, nullable=False)
    unit=Column(String(30), nullable=False); contract_qty=Column(Numeric(20,6), nullable=False); contract_rate=Column(Numeric(20,6), nullable=False)
    __table_args__=(UniqueConstraint('contract_id','item_code',name='uq_subcontractor_boq_contract_item'),CheckConstraint('contract_qty >= 0','ck_sub_boq_qty_nonnegative'),CheckConstraint('contract_rate >= 0','ck_sub_boq_rate_nonnegative'))


# Phase 6.3 — Construction Cost Control & Subcontractor Management
class ConstructionCostBudgetLine(Base):
    __tablename__='construction_cost_budget_lines'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    cost_code_id=Column(Integer, ForeignKey('construction_cost_codes.id'))
    wbs_id=Column(Integer, ForeignKey('construction_wbs_nodes.id'))
    boq_line_id=Column(Integer, ForeignKey('construction_boq_lines.id'))
    description=Column(String(255), nullable=False)
    budget_amount=Column(Numeric(20,6), nullable=False, default=0)
    budget_date=Column(Date)
    status=Column(String(30), nullable=False, default='active')
    __table_args__=(CheckConstraint('budget_amount >= 0','ck_cost_budget_nonnegative'),)

class ConstructionCommitment(Base):
    __tablename__='construction_commitments'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    contract_id=Column(Integer, ForeignKey('contracts.id'))
    cost_code_id=Column(Integer, ForeignKey('construction_cost_codes.id'))
    wbs_id=Column(Integer, ForeignKey('construction_wbs_nodes.id'))
    subcontractor_boq_line_id=Column(Integer, ForeignKey('subcontractor_boq_lines.id'))
    source_type=Column(String(50), nullable=False)
    source_id=Column(Integer)
    commitment_date=Column(Date, nullable=False)
    description=Column(String(255), nullable=False)
    committed_amount=Column(Numeric(20,6), nullable=False)
    released_amount=Column(Numeric(20,6), nullable=False, default=0)
    status=Column(String(30), nullable=False, default='open')
    __table_args__=(CheckConstraint('committed_amount >= 0','ck_commitment_nonnegative'),
                    CheckConstraint('released_amount >= 0 AND released_amount <= committed_amount','ck_commitment_release_bounds'))

class SubcontractorMeasurement(Base):
    __tablename__='subcontractor_measurements'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    contract_id=Column(Integer, ForeignKey('contracts.id'), nullable=False)
    measurement_no=Column(String(60), nullable=False)
    measurement_date=Column(Date, nullable=False)
    status=Column(String(30), nullable=False, default='draft')
    notes=Column(Text)
    created_by_id=Column(Integer, ForeignKey('users.id'))
    __table_args__=(UniqueConstraint('company_id','measurement_no',name='uq_sub_measurement_company_no'),)

class SubcontractorMeasurementLine(Base):
    __tablename__='subcontractor_measurement_lines'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    measurement_id=Column(Integer, ForeignKey('subcontractor_measurements.id'), nullable=False, index=True)
    subcontractor_boq_line_id=Column(Integer, ForeignKey('subcontractor_boq_lines.id'), nullable=False)
    current_qty=Column(Numeric(20,6), nullable=False)
    cumulative_qty=Column(Numeric(20,6), nullable=False)
    amount=Column(Numeric(20,6), nullable=False)
    __table_args__=(CheckConstraint('current_qty >= 0','ck_sub_measure_current_nonnegative'),
                    CheckConstraint('cumulative_qty >= 0','ck_sub_measure_cumulative_nonnegative'))

class SubcontractorProgressLine(Base):
    __tablename__='subcontractor_progress_lines'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    progress_id=Column(Integer, ForeignKey('subcontractor_progress.id'), nullable=False, index=True)
    subcontractor_boq_line_id=Column(Integer, ForeignKey('subcontractor_boq_lines.id'), nullable=False)
    current_qty=Column(Numeric(20,6), nullable=False)
    cumulative_qty=Column(Numeric(20,6), nullable=False)
    gross_amount=Column(Numeric(20,6), nullable=False)

class ConstructionCostForecast(Base):
    __tablename__='construction_cost_forecasts'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    cost_code_id=Column(Integer, ForeignKey('construction_cost_codes.id'))
    wbs_id=Column(Integer, ForeignKey('construction_wbs_nodes.id'))
    forecast_date=Column(Date, nullable=False)
    description=Column(String(255), nullable=False)
    etc_amount=Column(Numeric(20,6), nullable=False)
    status=Column(String(30), nullable=False, default='active')
    created_by_id=Column(Integer, ForeignKey('users.id'))
    __table_args__=(CheckConstraint('etc_amount >= 0','ck_forecast_etc_nonnegative'),)


# Patch 54 — Enterprise Cost Control Governance
class ConstructionCostControlSnapshot(Base):
    __tablename__='construction_cost_control_snapshots'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    status_date=Column(Date, nullable=False)
    budget=Column(Numeric(20,6), nullable=False, default=0)
    committed=Column(Numeric(20,6), nullable=False, default=0)
    actual=Column(Numeric(20,6), nullable=False, default=0)
    etc=Column(Numeric(20,6), nullable=False, default=0)
    eac=Column(Numeric(20,6), nullable=False, default=0)
    variance=Column(Numeric(20,6), nullable=False, default=0)
    cpi=Column(Numeric(20,8))
    eac_method=Column(String(30), nullable=False, default='manual_etc')
    status=Column(String(30), nullable=False, default='draft')
    created_by_id=Column(Integer, ForeignKey('users.id'))
    approved_by_id=Column(Integer, ForeignKey('users.id'))
    approved_at=Column(DateTime)
    __table_args__=(UniqueConstraint('company_id','project_id','status_date',name='uq_cost_snapshot_company_project_date'),
                    CheckConstraint('budget >= 0 AND committed >= 0 AND actual >= 0 AND etc >= 0 AND eac >= 0','ck_cost_snapshot_nonnegative'))


# Patch 55 — Cost Control Engine: revisions, time-phasing, forecast versions and variance governance
class ConstructionCostBudgetRevision(Base):
    __tablename__='construction_cost_budget_revisions'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    revision_no=Column(Integer, nullable=False)
    revision_date=Column(Date, nullable=False)
    reason=Column(String(500), nullable=False)
    status=Column(String(30), nullable=False, default='draft')
    created_by_id=Column(Integer, ForeignKey('users.id'))
    approved_by_id=Column(Integer, ForeignKey('users.id'))
    approved_at=Column(DateTime)
    __table_args__=(UniqueConstraint('company_id','project_id','revision_no',name='uq_cost_budget_revision_no'),)

class ConstructionCostBudgetRevisionLine(Base):
    __tablename__='construction_cost_budget_revision_lines'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    revision_id=Column(Integer, ForeignKey('construction_cost_budget_revisions.id', ondelete='CASCADE'), nullable=False, index=True)
    cost_code_id=Column(Integer, ForeignKey('construction_cost_codes.id'))
    wbs_id=Column(Integer, ForeignKey('construction_wbs_nodes.id'))
    period_date=Column(Date, nullable=False)
    delta_amount=Column(Numeric(20,6), nullable=False)
    __table_args__=(CheckConstraint('delta_amount <> 0','ck_budget_revision_delta_nonzero'),)

class ConstructionTimePhasedCost(Base):
    __tablename__='construction_time_phased_costs'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    cost_code_id=Column(Integer, ForeignKey('construction_cost_codes.id'))
    wbs_id=Column(Integer, ForeignKey('construction_wbs_nodes.id'))
    period_date=Column(Date, nullable=False)
    budget_amount=Column(Numeric(20,6), nullable=False, default=0)
    commitment_amount=Column(Numeric(20,6), nullable=False, default=0)
    actual_amount=Column(Numeric(20,6), nullable=False, default=0)
    __table_args__=(UniqueConstraint('company_id','project_id','cost_code_id','wbs_id','period_date',name='uq_time_phased_cost_scope'),
                    CheckConstraint('budget_amount >= 0 AND commitment_amount >= 0 AND actual_amount >= 0','ck_time_phased_cost_nonnegative'))

class ConstructionCostForecastVersion(Base):
    __tablename__='construction_cost_forecast_versions'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    version_no=Column(Integer, nullable=False)
    status_date=Column(Date, nullable=False)
    method=Column(String(30), nullable=False, default='manual')
    status=Column(String(30), nullable=False, default='draft')
    total_etc=Column(Numeric(20,6), nullable=False, default=0)
    total_eac=Column(Numeric(20,6), nullable=False, default=0)
    created_by_id=Column(Integer, ForeignKey('users.id'))
    approved_by_id=Column(Integer, ForeignKey('users.id'))
    approved_at=Column(DateTime)
    __table_args__=(UniqueConstraint('company_id','project_id','version_no',name='uq_cost_forecast_version_no'),
                    CheckConstraint('total_etc >= 0 AND total_eac >= 0','ck_forecast_version_nonnegative'))

class ConstructionCostForecastVersionLine(Base):
    __tablename__='construction_cost_forecast_version_lines'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    version_id=Column(Integer, ForeignKey('construction_cost_forecast_versions.id', ondelete='CASCADE'), nullable=False, index=True)
    cost_code_id=Column(Integer, ForeignKey('construction_cost_codes.id'))
    wbs_id=Column(Integer, ForeignKey('construction_wbs_nodes.id'))
    etc_amount=Column(Numeric(20,6), nullable=False)
    eac_amount=Column(Numeric(20,6), nullable=False)
    __table_args__=(CheckConstraint('etc_amount >= 0 AND eac_amount >= 0','ck_forecast_version_line_nonnegative'),)

# Patch 56 — Authoritative budget, reconciliation, alerts, cash-flow and profitability linkage
class ConstructionAuthoritativeBudgetLine(Base):
    __tablename__='construction_authoritative_budget_lines'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    cost_code_id=Column(Integer, ForeignKey('construction_cost_codes.id'))
    wbs_id=Column(Integer, ForeignKey('construction_wbs_nodes.id'))
    period_date=Column(Date, nullable=False)
    base_amount=Column(Numeric(20,6), nullable=False, default=0)
    revision_amount=Column(Numeric(20,6), nullable=False, default=0)
    approved_budget=Column(Numeric(20,6), nullable=False, default=0)
    last_revision_id=Column(Integer, ForeignKey('construction_cost_budget_revisions.id'))
    updated_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint('company_id','project_id','cost_code_id','wbs_id','period_date',name='uq_authoritative_budget_scope'),
                    CheckConstraint('base_amount >= 0 AND approved_budget >= 0','ck_authoritative_budget_nonnegative'))

class ConstructionCostReconciliation(Base):
    __tablename__='construction_cost_reconciliations'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    status_date=Column(Date, nullable=False)
    budget_amount=Column(Numeric(20,6), nullable=False, default=0)
    commitment_amount=Column(Numeric(20,6), nullable=False, default=0)
    actual_amount=Column(Numeric(20,6), nullable=False, default=0)
    open_commitment_amount=Column(Numeric(20,6), nullable=False, default=0)
    unreconciled_amount=Column(Numeric(20,6), nullable=False, default=0)
    status=Column(String(30), nullable=False, default='balanced')
    created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint('company_id','project_id','status_date',name='uq_cost_reconciliation_project_date'),
                    CheckConstraint('budget_amount >= 0 AND commitment_amount >= 0 AND actual_amount >= 0 AND open_commitment_amount >= 0','ck_reconciliation_nonnegative'))

class ConstructionCostAlert(Base):
    __tablename__='construction_cost_alerts'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    status_date=Column(Date, nullable=False)
    alert_type=Column(String(60), nullable=False)
    severity=Column(String(20), nullable=False)
    metric=Column(String(60), nullable=False)
    threshold=Column(Numeric(20,8))
    actual_value=Column(Numeric(20,8))
    message=Column(Text, nullable=False)
    status=Column(String(20), nullable=False, default='open')
    acknowledged_by_id=Column(Integer, ForeignKey('users.id'))
    acknowledged_at=Column(DateTime)
    resolved_by_id=Column(Integer, ForeignKey('users.id'))
    resolved_at=Column(DateTime)
    created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint('company_id','project_id','status_date','alert_type','metric',name='uq_cost_alert_scope'),)

class ConstructionCostCashFlowSnapshot(Base):
    __tablename__='construction_cost_cash_flow_snapshots'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    status_date=Column(Date, nullable=False)
    actual_inflow=Column(Numeric(20,6), nullable=False, default=0)
    actual_outflow=Column(Numeric(20,6), nullable=False, default=0)
    committed_outflow=Column(Numeric(20,6), nullable=False, default=0)
    forecast_inflow=Column(Numeric(20,6), nullable=False, default=0)
    forecast_outflow=Column(Numeric(20,6), nullable=False, default=0)
    forecast_net=Column(Numeric(20,6), nullable=False, default=0)
    created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint('company_id','project_id','status_date',name='uq_cost_cashflow_project_date'),)

class ConstructionCostVariance(Base):
    __tablename__='construction_cost_variances'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    status_date=Column(Date, nullable=False)
    budget=Column(Numeric(20,6), nullable=False, default=0)
    committed=Column(Numeric(20,6), nullable=False, default=0)
    actual=Column(Numeric(20,6), nullable=False, default=0)
    etc=Column(Numeric(20,6), nullable=False, default=0)
    eac=Column(Numeric(20,6), nullable=False, default=0)
    variance=Column(Numeric(20,6), nullable=False, default=0)
    variance_pct=Column(Numeric(20,8), nullable=False, default=0)
    status=Column(String(30), nullable=False)
    __table_args__=(UniqueConstraint('company_id','project_id','status_date',name='uq_cost_variance_project_date'),)

# Phase 6.4 — Construction Planning, EVM & Advanced Forecasting
class ConstructionActivity(Base):
    __tablename__='construction_activities'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    wbs_id=Column(Integer, ForeignKey('construction_wbs_nodes.id'), index=True)
    boq_line_id=Column(Integer, ForeignKey('construction_boq_lines.id'), index=True)
    code=Column(String(80), nullable=False)
    name=Column(String(255), nullable=False)
    planned_start=Column(Date, nullable=False)
    planned_finish=Column(Date, nullable=False)
    budget_amount=Column(Numeric(20,6), nullable=False, default=0)
    status=Column(String(30), nullable=False, default='planned')
    actual_start=Column(Date)
    actual_finish=Column(Date)
    calendar_id=Column(Integer, ForeignKey('construction_schedule_calendars.id'), index=True)
    __table_args__=(UniqueConstraint('project_id','code',name='uq_construction_activity_project_code'), CheckConstraint('budget_amount >= 0','ck_activity_budget_nonnegative'))

class ConstructionScheduleCalendar(Base):
    __tablename__='construction_schedule_calendars'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    name=Column(String(120), nullable=False)
    workdays_mask=Column(String(7), nullable=False, default='1111100')  # Mon..Sun
    holidays=Column(Text)  # ISO dates separated by commas
    is_default=Column(Boolean, nullable=False, default=False)
    __table_args__=(UniqueConstraint('project_id','name',name='uq_schedule_calendar_project_name'),)


class ConstructionActivityDependency(Base):
    __tablename__='construction_activity_dependencies'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    predecessor_id=Column(Integer, ForeignKey('construction_activities.id'), nullable=False, index=True)
    successor_id=Column(Integer, ForeignKey('construction_activities.id'), nullable=False, index=True)
    dependency_type=Column(String(2), nullable=False, default='FS')
    lag_days=Column(Integer, nullable=False, default=0)
    __table_args__=(UniqueConstraint('project_id','predecessor_id','successor_id',name='uq_activity_dependency'),
                    CheckConstraint("dependency_type IN ('FS','SS','FF','SF')", 'ck_dependency_type'),
                    CheckConstraint('predecessor_id <> successor_id','ck_dependency_not_self'))


class ConstructionScheduleBaseline(Base):
    __tablename__='construction_schedule_baselines'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    baseline_no=Column(Integer, nullable=False)
    baseline_date=Column(Date, nullable=False)
    status=Column(String(30), nullable=False, default='draft')
    approved_by_id=Column(Integer, ForeignKey('users.id'))
    approved_at=Column(DateTime)
    __table_args__=(UniqueConstraint('project_id','baseline_no',name='uq_schedule_baseline_project_no'),)

class ConstructionActivityBaseline(Base):
    __tablename__='construction_activity_baselines'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    baseline_id=Column(Integer, ForeignKey('construction_schedule_baselines.id'), nullable=False, index=True)
    activity_id=Column(Integer, ForeignKey('construction_activities.id'), nullable=False, index=True)
    planned_start=Column(Date, nullable=False)
    planned_finish=Column(Date, nullable=False)
    budget_amount=Column(Numeric(20,6), nullable=False)
    __table_args__=(CheckConstraint('budget_amount >= 0','ck_activity_baseline_budget_nonnegative'), UniqueConstraint('baseline_id','activity_id',name='uq_activity_baseline_activity'))

class ConstructionProgressPeriod(Base):
    __tablename__='construction_progress_periods'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    status_date=Column(Date, nullable=False)
    baseline_id=Column(Integer, ForeignKey('construction_schedule_baselines.id'))
    status=Column(String(30), nullable=False, default='open')
    approved_by_id=Column(Integer, ForeignKey('users.id'))
    approved_at=Column(DateTime)
    __table_args__=(UniqueConstraint('project_id','status_date',name='uq_progress_period_project_date'),)

class ConstructionActivityProgress(Base):
    __tablename__='construction_activity_progress'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    period_id=Column(Integer, ForeignKey('construction_progress_periods.id'), nullable=False, index=True)
    activity_id=Column(Integer, ForeignKey('construction_activities.id'), nullable=False, index=True)
    earned_percent=Column(Numeric(10,6), nullable=False, default=0)
    earned_value=Column(Numeric(20,6), nullable=False, default=0)
    notes=Column(Text)
    __table_args__=(CheckConstraint('earned_percent >= 0 AND earned_percent <= 100','ck_activity_progress_percent_bounds'), CheckConstraint('earned_value >= 0','ck_activity_progress_ev_nonnegative'), UniqueConstraint('period_id','activity_id',name='uq_activity_progress_period_activity'))

class ConstructionTimePhasedBudget(Base):
    __tablename__='construction_time_phased_budgets'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    baseline_id=Column(Integer, ForeignKey('construction_schedule_baselines.id'), index=True)
    activity_id=Column(Integer, ForeignKey('construction_activities.id'), index=True)
    period_date=Column(Date, nullable=False)
    planned_value=Column(Numeric(20,6), nullable=False)
    __table_args__=(CheckConstraint('planned_value >= 0','ck_time_phased_pv_nonnegative'),)

class ConstructionEVMForecast(Base):
    __tablename__='construction_evm_forecasts'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    status_date=Column(Date, nullable=False)
    method=Column(String(40), nullable=False)
    eac_amount=Column(Numeric(20,6), nullable=False)
    approved=Column(Boolean, nullable=False, default=False)
    created_by_id=Column(Integer, ForeignKey('users.id'))
    created_at=Column(DateTime, default=utcnow, nullable=False)
    notes=Column(Text)

class ConstructionEVMSnapshot(Base):
    __tablename__='construction_evm_snapshots'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    status_date=Column(Date, nullable=False)
    baseline_id=Column(Integer, ForeignKey('construction_schedule_baselines.id'))
    pv=Column(Numeric(20,6), nullable=False)
    ev=Column(Numeric(20,6), nullable=False)
    ac=Column(Numeric(20,6), nullable=False)
    bac=Column(Numeric(20,6), nullable=False)
    cpi=Column(Numeric(20,8), nullable=False)
    spi=Column(Numeric(20,8), nullable=False)
    cv=Column(Numeric(20,6), nullable=False)
    sv=Column(Numeric(20,6), nullable=False)
    eac=Column(Numeric(20,6), nullable=False)
    etc=Column(Numeric(20,6), nullable=False)
    vac=Column(Numeric(20,6), nullable=False)
    tcpi_bac=Column(Numeric(20,8), nullable=False)
    tcpi_eac=Column(Numeric(20,8), nullable=False)
    __table_args__=(UniqueConstraint('project_id','status_date',name='uq_evm_snapshot_project_date'),)

# Phase 6.4.1 — EVM cost allocation and performance roll-up


class ConstructionScheduleDelayEvent(Base):
    __tablename__='construction_schedule_delay_events'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    activity_id=Column(Integer, ForeignKey('construction_activities.id'), nullable=True, index=True)
    event_no=Column(String(60), nullable=False)
    event_date=Column(Date, nullable=False)
    cause=Column(String(120), nullable=False)
    description=Column(Text, nullable=False)
    excusable=Column(Boolean, nullable=False, default=False)
    compensable=Column(Boolean, nullable=False, default=False)
    claimed_days=Column(Integer, nullable=False, default=0)
    approved_days=Column(Integer, nullable=False, default=0)
    status=Column(String(30), nullable=False, default='open')
    created_by_id=Column(Integer, ForeignKey('users.id'))
    created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint('project_id','event_no',name='uq_schedule_delay_project_no'),
                    CheckConstraint('claimed_days >= 0','ck_schedule_delay_claimed_nonnegative'),
                    CheckConstraint('approved_days >= 0 AND approved_days <= claimed_days','ck_schedule_delay_approved_bounds'))

class ConstructionTimeImpactAnalysis(Base):
    __tablename__='construction_time_impact_analyses'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    delay_event_id=Column(Integer, ForeignKey('construction_schedule_delay_events.id'), nullable=False, index=True)
    baseline_id=Column(Integer, ForeignKey('construction_schedule_baselines.id'), nullable=True, index=True)
    status_date=Column(Date, nullable=False)
    impacted_activity_id=Column(Integer, ForeignKey('construction_activities.id'), nullable=True, index=True)
    baseline_project_finish=Column(Date, nullable=True)
    current_project_finish=Column(Date, nullable=True)
    impacted_project_finish=Column(Date, nullable=True)
    calculated_impact_days=Column(Integer, nullable=False, default=0)
    critical_path_impact=Column(Boolean, nullable=False, default=False)
    analysis_method=Column(String(40), nullable=False, default='fragnet')
    status=Column(String(30), nullable=False, default='draft')
    approved_by_id=Column(Integer, ForeignKey('users.id'))
    approved_at=Column(DateTime)
    notes=Column(Text)
    created_by_id=Column(Integer, ForeignKey('users.id'))
    created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint('project_id','delay_event_id',name='uq_tia_project_delay_event'),
                    CheckConstraint('calculated_impact_days >= 0','ck_tia_impact_days_nonnegative'))


class ConstructionRecoveryScheduleLink(Base):
    __tablename__='construction_recovery_schedule_links'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    recovery_plan_id=Column(Integer, ForeignKey('construction_recovery_plans.id'), nullable=False, index=True)
    activity_id=Column(Integer, ForeignKey('construction_activities.id'), nullable=False, index=True)
    target_start=Column(Date, nullable=True)
    target_finish=Column(Date, nullable=True)
    target_progress=Column(Numeric(10,6), nullable=False, default=100)
    acceleration_factor=Column(Numeric(12,6), nullable=False, default=1)
    notes=Column(Text)
    created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint('recovery_plan_id','activity_id',name='uq_recovery_schedule_plan_activity'),
                    CheckConstraint('target_progress >= 0 AND target_progress <= 100','ck_recovery_schedule_target_progress'),
                    CheckConstraint('acceleration_factor > 0','ck_recovery_schedule_acceleration_positive'))

class ConstructionEOTClaim(Base):
    __tablename__='construction_eot_claims'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    claim_no=Column(String(60), nullable=False)
    delay_event_id=Column(Integer, ForeignKey('construction_schedule_delay_events.id'), nullable=True, index=True)
    tia_id=Column(Integer, ForeignKey('construction_time_impact_analyses.id'), nullable=True, index=True)
    claimed_days=Column(Integer, nullable=False, default=0)
    approved_days=Column(Integer, nullable=False, default=0)
    status=Column(String(30), nullable=False, default='draft')
    submitted_at=Column(DateTime)
    approved_by_id=Column(Integer, ForeignKey('users.id'))
    approved_at=Column(DateTime)
    notes=Column(Text)
    created_by_id=Column(Integer, ForeignKey('users.id'))
    created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint('project_id','claim_no',name='uq_eot_claim_project_no'),
                    CheckConstraint('claimed_days >= 0 AND approved_days >= 0 AND approved_days <= claimed_days','ck_eot_claim_days_bounds'))

class ConstructionScheduleUpdateLine(Base):
    __tablename__='construction_schedule_update_lines'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    period_id=Column(Integer, ForeignKey('construction_schedule_update_periods.id'), nullable=False, index=True)
    activity_id=Column(Integer, ForeignKey('construction_activities.id'), nullable=False, index=True)
    actual_start=Column(Date)
    actual_finish=Column(Date)
    progress_percent=Column(Numeric(10,6), nullable=False, default=0)
    finish_variance_days=Column(Integer, nullable=False, default=0)
    created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint('period_id','activity_id',name='uq_schedule_update_period_activity'),
                    CheckConstraint('progress_percent >= 0 AND progress_percent <= 100','ck_schedule_update_progress_bounds'))

class ConstructionScheduleResource(Base):
    __tablename__='construction_schedule_resources'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    activity_id=Column(Integer, ForeignKey('construction_activities.id'), nullable=False, index=True)
    resource_type=Column(String(30), nullable=False)
    resource_name=Column(String(180), nullable=False)
    planned_units=Column(Numeric(20,6), nullable=False, default=0)
    actual_units=Column(Numeric(20,6), nullable=False, default=0)
    unit_cost=Column(Numeric(20,6), nullable=False, default=0)
    __table_args__=(UniqueConstraint('project_id','activity_id','resource_type','resource_name',name='uq_schedule_resource_activity_name'),
                    CheckConstraint('planned_units >= 0 AND actual_units >= 0 AND unit_cost >= 0','ck_schedule_resource_nonnegative'))


class ConstructionEVMCostAllocation(Base):
    __tablename__='construction_evm_cost_allocations'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    project_cost_id=Column(Integer, ForeignKey('project_costs.id'), nullable=False, index=True)
    wbs_id=Column(Integer, ForeignKey('construction_wbs_nodes.id'), index=True)
    boq_line_id=Column(Integer, ForeignKey('construction_boq_lines.id'), index=True)
    cost_code_id=Column(Integer, ForeignKey('construction_cost_codes.id'), index=True)
    allocated_amount=Column(Numeric(20,6), nullable=False)
    created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(CheckConstraint('allocated_amount >= 0','ck_evm_allocated_amount_nonnegative'),)

# Phase 6.4.2 — Performance alerts and forecast governance
class ConstructionPerformanceAlert(Base):
    __tablename__='construction_performance_alerts'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    snapshot_id=Column(Integer, ForeignKey('construction_evm_snapshots.id'), nullable=True, index=True)
    status_date=Column(Date, nullable=False)
    alert_type=Column(String(40), nullable=False)
    metric=Column(String(30), nullable=False)
    severity=Column(String(20), nullable=False)
    threshold=Column(Numeric(20,8), nullable=False)
    actual_value=Column(Numeric(20,8), nullable=False)
    status=Column(String(30), nullable=False, default='open')
    message=Column(Text, nullable=False)
    acknowledged_by_id=Column(Integer, ForeignKey('users.id'))
    acknowledged_at=Column(DateTime)
    corrective_action=Column(Text)
    resolved_by_id=Column(Integer, ForeignKey('users.id'))
    resolved_at=Column(DateTime)
    created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint('project_id','status_date','alert_type','metric',name='uq_perf_alert_project_date_type_metric'),)


# Phase 6.4.3 — Recovery planning and forecast approval governance
class ConstructionRecoveryPlan(Base):
    __tablename__='construction_recovery_plans'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    alert_id=Column(Integer, ForeignKey('construction_performance_alerts.id'), nullable=True, index=True)
    plan_no=Column(String(60), nullable=False)
    title=Column(String(255), nullable=False)
    owner_id=Column(Integer, ForeignKey('users.id'), nullable=True)
    target_date=Column(Date, nullable=False)
    target_cpi=Column(Numeric(20,8), nullable=True)
    target_spi=Column(Numeric(20,8), nullable=True)
    target_eac=Column(Numeric(20,6), nullable=True)
    status=Column(String(30), nullable=False, default='draft')
    approved_by_id=Column(Integer, ForeignKey('users.id'), nullable=True)
    approved_at=Column(DateTime)
    closed_by_id=Column(Integer, ForeignKey('users.id'), nullable=True)
    closed_at=Column(DateTime)
    notes=Column(Text)
    created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint('project_id','plan_no',name='uq_recovery_plan_project_no'),)

class ConstructionRecoveryAction(Base):
    __tablename__='construction_recovery_actions'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    plan_id=Column(Integer, ForeignKey('construction_recovery_plans.id'), nullable=False, index=True)
    action_no=Column(String(60), nullable=False)
    description=Column(Text, nullable=False)
    owner_id=Column(Integer, ForeignKey('users.id'), nullable=True)
    due_date=Column(Date, nullable=False)
    status=Column(String(30), nullable=False, default='open')
    completion_percent=Column(Numeric(10,6), nullable=False, default=0)
    completed_at=Column(DateTime)
    evidence=Column(Text)
    created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint('plan_id','action_no',name='uq_recovery_action_plan_no'), CheckConstraint('completion_percent >= 0 AND completion_percent <= 100','ck_recovery_action_completion_bounds'))

class ConstructionScheduleUpdatePeriod(Base):
    __tablename__='construction_schedule_update_periods'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    status_date=Column(Date, nullable=False)
    baseline_id=Column(Integer, ForeignKey('construction_schedule_baselines.id'), nullable=True, index=True)
    status=Column(String(30), nullable=False, default='open')
    approved_by_id=Column(Integer, ForeignKey('users.id'), nullable=True)
    approved_at=Column(DateTime)
    locked_by_id=Column(Integer, ForeignKey('users.id'), nullable=True)
    locked_at=Column(DateTime)
    created_at=Column(DateTime, default=utcnow, nullable=False)
    __table_args__=(UniqueConstraint('project_id','status_date',name='uq_schedule_update_period_project_date'),)

class ConstructionScheduleResourcePeriod(Base):
    __tablename__='construction_schedule_resource_periods'
    id=Column(Integer, primary_key=True)
    company_id=Column(Integer, ForeignKey('companies.id'), nullable=False, index=True)
    project_id=Column(Integer, ForeignKey('projects.id'), nullable=False, index=True)
    activity_id=Column(Integer, ForeignKey('construction_activities.id'), nullable=False, index=True)
    resource_id=Column(Integer, ForeignKey('construction_schedule_resources.id'), nullable=False, index=True)
    period_date=Column(Date, nullable=False)
    planned_units=Column(Numeric(20,6), nullable=False, default=0)
    actual_units=Column(Numeric(20,6), nullable=False, default=0)
    planned_cost=Column(Numeric(20,6), nullable=False, default=0)
    actual_cost=Column(Numeric(20,6), nullable=False, default=0)
    __table_args__=(UniqueConstraint('project_id','resource_id','period_date',name='uq_schedule_resource_period'),
                    CheckConstraint('planned_units >= 0 AND actual_units >= 0 AND planned_cost >= 0 AND actual_cost >= 0','ck_schedule_resource_period_nonnegative'))
