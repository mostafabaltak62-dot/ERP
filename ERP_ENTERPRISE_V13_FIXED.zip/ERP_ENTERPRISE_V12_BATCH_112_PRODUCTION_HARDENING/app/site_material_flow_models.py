"""Project-site material receiving, consumption, waste and return ledger."""
from sqlalchemy import Column, Integer, String, Numeric, Date, DateTime, ForeignKey, CheckConstraint, UniqueConstraint
from .db_base import Base
from .time_utils import utcnow

class SiteMaterialReceipt(Base):
    __tablename__ = "site_material_receipts"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True)
    site_id = Column(Integer, ForeignKey("construction_sites.id", ondelete="SET NULL"), nullable=True, index=True)
    issue_id = Column(Integer, ForeignKey("site_material_issues.id", ondelete="SET NULL"), nullable=True, index=True)
    item_id = Column(Integer, ForeignKey("items.id", ondelete="RESTRICT"), nullable=False, index=True)
    quantity = Column(Numeric(20,6), nullable=False)
    unit_cost = Column(Numeric(20,6), nullable=False, default=0)
    total_cost = Column(Numeric(20,6), nullable=False, default=0)
    receipt_date = Column(Date, nullable=False)
    received_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    reference = Column(String(100))
    status = Column(String(30), nullable=False, default="posted")
    created_at = Column(DateTime, default=utcnow, nullable=False)
    __table_args__ = (CheckConstraint("quantity > 0", name="ck_site_receipt_qty_positive"), CheckConstraint("unit_cost >= 0", name="ck_site_receipt_cost_nonnegative"))

class SiteMaterialConsumption(Base):
    __tablename__ = "site_material_consumptions"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True)
    site_id = Column(Integer, ForeignKey("construction_sites.id", ondelete="SET NULL"), nullable=True, index=True)
    item_id = Column(Integer, ForeignKey("items.id", ondelete="RESTRICT"), nullable=False, index=True)
    receipt_id = Column(Integer, ForeignKey("site_material_receipts.id", ondelete="SET NULL"), nullable=True, index=True)
    quantity = Column(Numeric(20,6), nullable=False)
    unit_cost = Column(Numeric(20,6), nullable=False, default=0)
    total_cost = Column(Numeric(20,6), nullable=False, default=0)
    consumption_date = Column(Date, nullable=False)
    consumed_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    cost_code_id = Column(Integer, ForeignKey("construction_cost_codes.id", ondelete="SET NULL"))
    boq_line_id = Column(Integer, ForeignKey("construction_boq_lines.id", ondelete="SET NULL"))
    reference = Column(String(100))
    status = Column(String(30), nullable=False, default="posted")
    __table_args__ = (CheckConstraint("quantity > 0", name="ck_site_consumption_qty_positive"), CheckConstraint("unit_cost >= 0", name="ck_site_consumption_cost_nonnegative"))

class SiteMaterialAdjustment(Base):
    __tablename__ = "site_material_adjustments"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True)
    site_id = Column(Integer, ForeignKey("construction_sites.id", ondelete="SET NULL"), nullable=True, index=True)
    item_id = Column(Integer, ForeignKey("items.id", ondelete="RESTRICT"), nullable=False, index=True)
    warehouse_id = Column(Integer, ForeignKey("warehouses.id", ondelete="SET NULL"), nullable=True, index=True)
    adjustment_type = Column(String(20), nullable=False)  # waste | return
    quantity = Column(Numeric(20,6), nullable=False)
    unit_cost = Column(Numeric(20,6), nullable=False, default=0)
    total_cost = Column(Numeric(20,6), nullable=False, default=0)
    adjustment_date = Column(Date, nullable=False)
    reason = Column(String(255), nullable=False)
    created_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    reference = Column(String(100))
    status = Column(String(30), nullable=False, default="posted")
    __table_args__ = (CheckConstraint("quantity > 0", name="ck_site_adjustment_qty_positive"), CheckConstraint("adjustment_type in ('waste','return')", name="ck_site_adjustment_type"))
