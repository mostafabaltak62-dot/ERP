from .time_utils import utcnow
"""Enterprise Plus completeness layer: HR, workforce, service, quality and controlled signing."""
import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Date, Numeric, ForeignKey, Text, JSON, UniqueConstraint, CheckConstraint, Index
from .db_base import Base

class WorkSchedule(Base):
    __tablename__='work_schedules'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True)
    code=Column(String(40),nullable=False); name=Column(String(150),nullable=False); daily_hours=Column(Numeric(8,2),nullable=False,default=8); weekly_hours=Column(Numeric(8,2),nullable=False,default=48); timezone=Column(String(64),default='Africa/Cairo'); is_active=Column(Boolean,default=True,nullable=False)
    __table_args__=(UniqueConstraint('company_id','code',name='uq_work_schedule_company_code'),CheckConstraint('daily_hours > 0','ck_work_schedule_daily_hours'),CheckConstraint('weekly_hours > 0','ck_work_schedule_weekly_hours'))
class WorkScheduleDay(Base):
    __tablename__='work_schedule_days'
    id=Column(Integer,primary_key=True); schedule_id=Column(Integer,ForeignKey('work_schedules.id',ondelete='CASCADE'),nullable=False,index=True); weekday=Column(Integer,nullable=False); start_time=Column(String(5),nullable=False); end_time=Column(String(5),nullable=False); break_hours=Column(Numeric(8,2),default=0,nullable=False); is_working=Column(Boolean,default=True,nullable=False)
    __table_args__=(UniqueConstraint('schedule_id','weekday',name='uq_work_schedule_day'),)
class OvertimeRule(Base):
    __tablename__='overtime_rules'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); code=Column(String(40),nullable=False); name=Column(String(150),nullable=False); weekday_multiplier=Column(Numeric(8,4),default=1.25,nullable=False); weekend_multiplier=Column(Numeric(8,4),default=1.50,nullable=False); holiday_multiplier=Column(Numeric(8,4),default=2.00,nullable=False); max_daily_hours=Column(Numeric(8,2),default=4,nullable=False); approval_required=Column(Boolean,default=True,nullable=False); is_active=Column(Boolean,default=True,nullable=False)
    __table_args__=(UniqueConstraint('company_id','code',name='uq_ot_rule_company_code'),)
class EmployeeContract(Base):
    __tablename__='employee_contracts'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); employee_id=Column(Integer,ForeignKey('employees.id',ondelete='CASCADE'),nullable=False,index=True); contract_no=Column(String(80),nullable=False); contract_type=Column(String(50),default='full_time'); start_date=Column(Date,nullable=False); end_date=Column(Date); salary=Column(Numeric(20,6),default=0,nullable=False); schedule_id=Column(Integer,ForeignKey('work_schedules.id',ondelete='SET NULL')); overtime_rule_id=Column(Integer,ForeignKey('overtime_rules.id',ondelete='SET NULL')); status=Column(String(30),default='draft',nullable=False); terms=Column(Text); signed_document_id=Column(Integer,ForeignKey('project_documents.id',ondelete='SET NULL')); created_at=Column(DateTime,default=utcnow,nullable=False)
    __table_args__=(UniqueConstraint('company_id','contract_no',name='uq_employee_contract_company_no'),)
class AttendanceEvent(Base):
    __tablename__='attendance_events'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); employee_id=Column(Integer,ForeignKey('employees.id',ondelete='CASCADE'),nullable=False,index=True); event_at=Column(DateTime,nullable=False); event_type=Column(String(20),nullable=False); method=Column(String(30),default='manual'); device_id=Column(String(100)); ip_address=Column(String(64)); latitude=Column(Numeric(10,7)); longitude=Column(Numeric(10,7)); project_id=Column(Integer,ForeignKey('projects.id',ondelete='SET NULL')); site_id=Column(Integer,ForeignKey('construction_sites.id',ondelete='SET NULL')); notes=Column(Text)
    __table_args__=(Index('ix_attendance_event_employee_time','employee_id','event_at'),)
class OnboardingCase(Base):
    __tablename__='onboarding_cases'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); employee_id=Column(Integer,ForeignKey('employees.id',ondelete='CASCADE'),nullable=False,index=True); status=Column(String(30),default='open',nullable=False); start_date=Column(Date); target_date=Column(Date); owner_user_id=Column(Integer,ForeignKey('users.id',ondelete='SET NULL')); notes=Column(Text)
class OnboardingTask(Base):
    __tablename__='onboarding_tasks'
    id=Column(Integer,primary_key=True); case_id=Column(Integer,ForeignKey('onboarding_cases.id',ondelete='CASCADE'),nullable=False,index=True); title=Column(String(180),nullable=False); sequence=Column(Integer,default=1,nullable=False); required=Column(Boolean,default=True,nullable=False); status=Column(String(30),default='pending',nullable=False); due_date=Column(Date); completed_at=Column(DateTime); completed_by_id=Column(Integer,ForeignKey('users.id',ondelete='SET NULL'))
class RecruitmentJob(Base):
    __tablename__='recruitment_jobs'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); code=Column(String(50),nullable=False); title=Column(String(180),nullable=False); department_id=Column(Integer,ForeignKey('departments.id',ondelete='SET NULL')); project_id=Column(Integer,ForeignKey('projects.id',ondelete='SET NULL')); openings=Column(Integer,default=1,nullable=False); status=Column(String(30),default='open',nullable=False); description=Column(Text)
    __table_args__=(UniqueConstraint('company_id','code',name='uq_recruitment_job_company_code'),)
class RecruitmentCandidate(Base):
    __tablename__='recruitment_candidates'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); job_id=Column(Integer,ForeignKey('recruitment_jobs.id',ondelete='CASCADE'),nullable=False,index=True); name=Column(String(180),nullable=False); email=Column(String(150)); phone=Column(String(50)); stage=Column(String(40),default='new',nullable=False); score=Column(Numeric(8,2)); notes=Column(Text); created_at=Column(DateTime,default=utcnow,nullable=False)
class EmployeeLifecycleCase(Base):
    __tablename__='employee_lifecycle_cases'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); employee_id=Column(Integer,ForeignKey('employees.id',ondelete='CASCADE'),nullable=False,index=True); case_type=Column(String(30),nullable=False); status=Column(String(30),default='open',nullable=False); effective_date=Column(Date); reason=Column(Text); owner_user_id=Column(Integer,ForeignKey('users.id',ondelete='SET NULL')); clearance_json=Column(JSON)
class ExpenseClaim(Base):
    __tablename__='expense_claims'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); employee_id=Column(Integer,ForeignKey('employees.id',ondelete='CASCADE'),nullable=False,index=True); project_id=Column(Integer,ForeignKey('projects.id',ondelete='SET NULL')); expense_date=Column(Date,nullable=False); category=Column(String(80),nullable=False); description=Column(Text); amount=Column(Numeric(20,6),nullable=False); currency_code=Column(String(3),default='EGP',nullable=False); status=Column(String(30),default='draft',nullable=False); receipt_document_id=Column(Integer,ForeignKey('project_documents.id',ondelete='SET NULL')); approved_by_id=Column(Integer,ForeignKey('users.id',ondelete='SET NULL')); approved_at=Column(DateTime); posted_project_cost_id=Column(Integer,ForeignKey('project_costs.id',ondelete='SET NULL')); created_at=Column(DateTime,default=utcnow,nullable=False)
class ProjectTimesheet(Base):
    __tablename__='project_timesheets'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); employee_id=Column(Integer,ForeignKey('employees.id',ondelete='CASCADE'),nullable=False,index=True); project_id=Column(Integer,ForeignKey('projects.id',ondelete='CASCADE'),nullable=False,index=True); site_id=Column(Integer,ForeignKey('construction_sites.id',ondelete='SET NULL')); wbs_id=Column(Integer,ForeignKey('construction_wbs_nodes.id',ondelete='SET NULL')); cost_code_id=Column(Integer,ForeignKey('construction_cost_codes.id',ondelete='SET NULL')); work_date=Column(Date,nullable=False); hours=Column(Numeric(8,2),nullable=False); description=Column(Text); status=Column(String(30),default='draft',nullable=False); approved_by_id=Column(Integer,ForeignKey('users.id',ondelete='SET NULL')); approved_at=Column(DateTime); project_cost_id=Column(Integer,ForeignKey('project_costs.id',ondelete='SET NULL'))
    __table_args__=(CheckConstraint('hours >= 0','ck_timesheet_hours_nonnegative'),UniqueConstraint('employee_id','project_id','work_date','wbs_id','cost_code_id',name='uq_timesheet_allocation_day'))
class ProjectTask(Base):
    __tablename__='project_tasks'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); project_id=Column(Integer,ForeignKey('projects.id',ondelete='CASCADE'),nullable=False,index=True); parent_id=Column(Integer,ForeignKey('project_tasks.id',ondelete='SET NULL')); wbs_id=Column(Integer,ForeignKey('construction_wbs_nodes.id',ondelete='SET NULL')); code=Column(String(60),nullable=False); title=Column(String(220),nullable=False); planned_start=Column(Date); planned_end=Column(Date); actual_start=Column(Date); actual_end=Column(Date); progress=Column(Numeric(8,2),default=0,nullable=False); assigned_user_id=Column(Integer,ForeignKey('users.id',ondelete='SET NULL')); status=Column(String(30),default='todo',nullable=False); priority=Column(String(20),default='normal',nullable=False); estimated_hours=Column(Numeric(10,2),default=0,nullable=False)
    __table_args__=(UniqueConstraint('project_id','code',name='uq_project_task_code'),CheckConstraint('progress >= 0 AND progress <= 100','ck_project_task_progress'))
class QualityInspection(Base):
    __tablename__='quality_inspections'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); project_id=Column(Integer,ForeignKey('projects.id',ondelete='CASCADE'),nullable=False,index=True); site_id=Column(Integer,ForeignKey('construction_sites.id',ondelete='SET NULL')); boq_line_id=Column(Integer,ForeignKey('construction_boq_lines.id',ondelete='SET NULL')); inspection_no=Column(String(80),nullable=False); inspection_type=Column(String(80),nullable=False); inspection_date=Column(Date,nullable=False); inspector_id=Column(Integer,ForeignKey('users.id',ondelete='SET NULL')); result=Column(String(40),default='pending',nullable=False); comments=Column(Text); document_id=Column(Integer,ForeignKey('project_documents.id',ondelete='SET NULL')); closed_at=Column(DateTime)
    __table_args__=(UniqueConstraint('company_id','inspection_no',name='uq_quality_inspection_company_no'),)
class QualityDefect(Base):
    __tablename__='quality_defects'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); inspection_id=Column(Integer,ForeignKey('quality_inspections.id',ondelete='CASCADE'),nullable=False,index=True); defect_no=Column(String(80),nullable=False); severity=Column(String(30),default='minor',nullable=False); description=Column(Text,nullable=False); corrective_action=Column(Text); responsible_user_id=Column(Integer,ForeignKey('users.id',ondelete='SET NULL')); due_date=Column(Date); status=Column(String(30),default='open',nullable=False); closed_at=Column(DateTime)
class MaintenancePlan(Base):
    __tablename__='maintenance_plans'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); equipment_id=Column(Integer,ForeignKey('equipment.id',ondelete='CASCADE'),nullable=False,index=True); code=Column(String(60),nullable=False); interval_days=Column(Integer); interval_hours=Column(Numeric(10,2)); last_service_date=Column(Date); next_due_date=Column(Date); status=Column(String(30),default='active',nullable=False)
class MaintenanceWorkOrder(Base):
    __tablename__='maintenance_work_orders'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); equipment_id=Column(Integer,ForeignKey('equipment.id',ondelete='CASCADE'),nullable=False,index=True); plan_id=Column(Integer,ForeignKey('maintenance_plans.id',ondelete='SET NULL')); project_id=Column(Integer,ForeignKey('projects.id',ondelete='SET NULL')); work_order_no=Column(String(80),nullable=False); work_type=Column(String(40),default='preventive'); scheduled_date=Column(Date); completed_date=Column(Date); status=Column(String(30),default='open',nullable=False); estimated_cost=Column(Numeric(20,6),default=0,nullable=False); actual_cost=Column(Numeric(20,6),default=0,nullable=False); notes=Column(Text)
    __table_args__=(UniqueConstraint('company_id','work_order_no',name='uq_maintenance_wo_company_no'),)
class FieldServiceVisit(Base):
    __tablename__='field_service_visits'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); project_id=Column(Integer,ForeignKey('projects.id',ondelete='CASCADE'),nullable=False,index=True); site_id=Column(Integer,ForeignKey('construction_sites.id',ondelete='SET NULL')); assigned_user_id=Column(Integer,ForeignKey('users.id',ondelete='SET NULL')); visit_no=Column(String(80),nullable=False); scheduled_at=Column(DateTime); check_in=Column(DateTime); check_out=Column(DateTime); status=Column(String(30),default='scheduled',nullable=False); summary=Column(Text); customer_signoff_document_id=Column(Integer,ForeignKey('project_documents.id',ondelete='SET NULL'))
    __table_args__=(UniqueConstraint('company_id','visit_no',name='uq_field_visit_company_no'),)
class DocumentTemplate(Base):
    __tablename__='document_templates'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); code=Column(String(60),nullable=False); name=Column(String(180),nullable=False); document_type=Column(String(60),nullable=False); body=Column(Text); version=Column(Integer,default=1,nullable=False); is_active=Column(Boolean,default=True,nullable=False)
    __table_args__=(UniqueConstraint('company_id','code',name='uq_document_template_company_code'),)
class SignatureRequest(Base):
    __tablename__='signature_requests'
    id=Column(Integer,primary_key=True); company_id=Column(Integer,ForeignKey('companies.id',ondelete='CASCADE'),nullable=False,index=True); project_id=Column(Integer,ForeignKey('projects.id',ondelete='SET NULL')); document_id=Column(Integer,ForeignKey('project_documents.id',ondelete='CASCADE'),nullable=False,index=True); title=Column(String(220),nullable=False); status=Column(String(30),default='pending',nullable=False); requested_by_id=Column(Integer,ForeignKey('users.id',ondelete='SET NULL')); expires_at=Column(DateTime); completed_at=Column(DateTime); certificate_hash=Column(String(64))
class SignatureSigner(Base):
    __tablename__='signature_signers'
    id=Column(Integer,primary_key=True); request_id=Column(Integer,ForeignKey('signature_requests.id',ondelete='CASCADE'),nullable=False,index=True); signer_order=Column(Integer,nullable=False); user_id=Column(Integer,ForeignKey('users.id',ondelete='SET NULL')); signer_name=Column(String(180),nullable=False); signer_email=Column(String(180)); status=Column(String(30),default='pending',nullable=False); signed_at=Column(DateTime); signature_hash=Column(String(64)); decline_reason=Column(Text)
    __table_args__=(UniqueConstraint('request_id','signer_order',name='uq_signature_signer_order'),)
