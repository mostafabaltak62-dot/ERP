from .time_utils import utcnow
"""Enterprise Construction Document Controller.

Central register for controlled project documents, submittals, drawings, material
submissions, letters, minutes, inspections, handovers and their revisions,
transmittals and approvals. Files are stored outside the database; the database
stores immutable metadata and SHA-256 checksums.
"""
import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Date, ForeignKey, Numeric, Text, UniqueConstraint, CheckConstraint, Index
from .db_base import Base

class ProjectDocument(Base):
    __tablename__ = "project_documents"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True)
    contract_id = Column(Integer, ForeignKey("contracts.id", ondelete="SET NULL"), nullable=True, index=True)
    site_id = Column(Integer, ForeignKey("construction_sites.id", ondelete="SET NULL"), nullable=True, index=True)
    wbs_id = Column(Integer, ForeignKey("construction_wbs_nodes.id", ondelete="SET NULL"), nullable=True, index=True)
    boq_line_id = Column(Integer, ForeignKey("construction_boq_lines.id", ondelete="SET NULL"), nullable=True, index=True)
    cost_code_id = Column(Integer, ForeignKey("construction_cost_codes.id", ondelete="SET NULL"), nullable=True, index=True)
    item_id = Column(Integer, ForeignKey("items.id", ondelete="SET NULL"), nullable=True, index=True)
    equipment_id = Column(Integer, ForeignKey("equipment.id", ondelete="SET NULL"), nullable=True, index=True)
    purchase_order_id = Column(Integer, ForeignKey("purchase_orders.id", ondelete="SET NULL"), nullable=True, index=True)
    measurement_id = Column(Integer, ForeignKey("construction_measurements.id", ondelete="SET NULL"), nullable=True, index=True)
    progress_certificate_id = Column(Integer, ForeignKey("progress_certificates.id", ondelete="SET NULL"), nullable=True, index=True)
    subcontractor_progress_id = Column(Integer, ForeignKey("subcontractor_progress.id", ondelete="SET NULL"), nullable=True, index=True)
    site_material_issue_id = Column(Integer, ForeignKey("site_material_issues.id", ondelete="SET NULL"), nullable=True, index=True)
    equipment_usage_id = Column(Integer, ForeignKey("construction_equipment_usage.id", ondelete="SET NULL"), nullable=True, index=True)
    labor_entry_id = Column(Integer, ForeignKey("construction_labor_entries.id", ondelete="SET NULL"), nullable=True, index=True)
    daily_labor_entry_id = Column(Integer, ForeignKey("daily_labor_entries.id", ondelete="SET NULL"), nullable=True, index=True)
    document_no = Column(String(80), nullable=False)
    title = Column(String(255), nullable=False)
    document_type = Column(String(50), nullable=False, index=True)
    discipline = Column(String(80))
    status = Column(String(40), nullable=False, default="draft", index=True)
    priority = Column(String(20), nullable=False, default="normal")
    external_reference = Column(String(120))
    issue_date = Column(Date)
    due_date = Column(Date)
    confidentiality = Column(String(30), nullable=False, default="internal")
    description = Column(Text)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, nullable=False, default=utcnow)
    updated_at = Column(DateTime, nullable=False, default=utcnow, onupdate=utcnow)
    current_revision_no = Column(Integer, nullable=False, default=0)
    __table_args__ = (
        UniqueConstraint("company_id", "document_no", name="uq_project_document_company_no"),
        Index("ix_project_document_project_type_status", "project_id", "document_type", "status"),
    )

class ProjectDocumentRevision(Base):
    __tablename__ = "project_document_revisions"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    document_id = Column(Integer, ForeignKey("project_documents.id", ondelete="CASCADE"), nullable=False, index=True)
    revision_no = Column(Integer, nullable=False)
    revision_code = Column(String(30), nullable=False)
    file_name = Column(String(255), nullable=False)
    stored_path = Column(String(1000), nullable=False)
    mime_type = Column(String(150), nullable=False)
    file_size = Column(Integer, nullable=False)
    sha256 = Column(String(64), nullable=False, index=True)
    change_description = Column(Text)
    status = Column(String(40), nullable=False, default="draft")
    uploaded_by_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    uploaded_at = Column(DateTime, nullable=False, default=utcnow)
    supersedes_revision_id = Column(Integer, ForeignKey("project_document_revisions.id", ondelete="SET NULL"))
    is_current = Column(Boolean, nullable=False, default=True)
    __table_args__ = (
        UniqueConstraint("document_id", "revision_no", name="uq_project_document_revision_no"),
        UniqueConstraint("document_id", "revision_code", name="uq_project_document_revision_code"),
    )

class DocumentTransmittal(Base):
    __tablename__ = "document_transmittals"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True)
    transmittal_no = Column(String(80), nullable=False)
    recipient = Column(String(255), nullable=False)
    recipient_role = Column(String(150))
    subject = Column(String(255), nullable=False)
    purpose = Column(String(80), nullable=False, default="for_review")
    status = Column(String(40), nullable=False, default="issued")
    issue_date = Column(Date, nullable=False)
    response_due_date = Column(Date)
    response_date = Column(Date)
    received_at = Column(DateTime)
    receipt_acknowledged_at = Column(DateTime)
    receipt_acknowledged_by_id = Column(Integer, ForeignKey("users.id"))
    notes = Column(Text)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, nullable=False, default=utcnow)
    __table_args__ = (UniqueConstraint("company_id", "transmittal_no", name="uq_document_transmittal_company_no"),)

class DocumentTransmittalLine(Base):
    __tablename__ = "document_transmittal_lines"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    transmittal_id = Column(Integer, ForeignKey("document_transmittals.id", ondelete="CASCADE"), nullable=False, index=True)
    document_id = Column(Integer, ForeignKey("project_documents.id", ondelete="CASCADE"), nullable=False, index=True)
    revision_id = Column(Integer, ForeignKey("project_document_revisions.id", ondelete="RESTRICT"), nullable=False, index=True)
    action = Column(String(50), nullable=False, default="review")
    remarks = Column(Text)
    __table_args__ = (UniqueConstraint("transmittal_id", "document_id", "revision_id", name="uq_transmittal_document_revision"),)

class DocumentApproval(Base):
    __tablename__ = "document_approvals"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    document_id = Column(Integer, ForeignKey("project_documents.id", ondelete="CASCADE"), nullable=False, index=True)
    revision_id = Column(Integer, ForeignKey("project_document_revisions.id", ondelete="CASCADE"), nullable=False, index=True)
    approver_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    decision = Column(String(40), nullable=False)
    comments = Column(Text)
    approved_at = Column(DateTime, nullable=False, default=utcnow)
    __table_args__ = (Index("ix_document_approval_doc_revision", "document_id", "revision_id"),)

class DocumentDistribution(Base):
    __tablename__ = "document_distributions"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    document_id = Column(Integer, ForeignKey("project_documents.id", ondelete="CASCADE"), nullable=False, index=True)
    revision_id = Column(Integer, ForeignKey("project_document_revisions.id", ondelete="CASCADE"), nullable=False, index=True)
    recipient = Column(String(255), nullable=False)
    recipient_role = Column(String(150))
    distribution_method = Column(String(40), nullable=False, default="system")
    distributed_at = Column(DateTime, nullable=False, default=utcnow)
    acknowledged_at = Column(DateTime)
    notes = Column(Text)

class DocumentReviewAssignment(Base):
    __tablename__ = "document_review_assignments"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    document_id = Column(Integer, ForeignKey("project_documents.id", ondelete="CASCADE"), nullable=False, index=True)
    revision_id = Column(Integer, ForeignKey("project_document_revisions.id", ondelete="CASCADE"), nullable=False, index=True)
    reviewer_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    reviewer_role = Column(String(120))
    due_date = Column(Date)
    status = Column(String(30), nullable=False, default="pending", index=True)
    comments = Column(Text)
    reviewed_at = Column(DateTime)
    assigned_by_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, nullable=False, default=utcnow)
    __table_args__ = (UniqueConstraint("revision_id", "reviewer_id", name="uq_document_review_assignment"),)

class DocumentReviewComment(Base):
    __tablename__ = "document_review_comments"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    document_id = Column(Integer, ForeignKey("project_documents.id", ondelete="CASCADE"), nullable=False, index=True)
    revision_id = Column(Integer, ForeignKey("project_document_revisions.id", ondelete="CASCADE"), nullable=False, index=True)
    author_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    comment_text = Column(Text, nullable=False)
    status = Column(String(30), nullable=False, default="open")
    created_at = Column(DateTime, nullable=False, default=utcnow)
    resolved_at = Column(DateTime)
    resolved_by_id = Column(Integer, ForeignKey("users.id"))
