"""Tenant-safe Celery task helpers."""
from contextlib import contextmanager
from .governance import set_request_context, clear_request_context

@contextmanager
def tenant_task_context(company_id, branch_id=None, user_id=None, request_id=None):
    if company_id is None:
        raise ValueError("company_id is required for tenant-sensitive background jobs")
    set_request_context(user_id=user_id, company_id=int(company_id), branch_id=int(branch_id) if branch_id is not None else None,
                        request_id=request_id or f"celery:{company_id}", ip_address=None)
    try:
        yield
    finally:
        clear_request_context()
