# -*- coding: utf-8 -*-
"""Commercial completion layer: procurement sourcing, credit control and policy configuration."""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Date, Numeric, ForeignKey, Text, UniqueConstraint, Index, CheckConstraint
from .db_base import Base
from .time_utils import utcnow

class CustomerCreditPolicy(Base):
    __tablename__ = "customer_credit_policies"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    customer_id = Column(Integer, ForeignKey("customers.id", ondelete="CASCADE"), nullable=False, index=True)
    credit_limit = Column(Numeric(20,6), nullable=False, default=0)
    payment_terms_days = Column(Integer, nullable=False, default=0)
    block_on_overlimit = Column(Boolean, nullable=False, default=True)
    warning_percent = Column(Numeric(9,6), nullable=False, default=80)
    is_active = Column(Boolean, nullable=False, default=True)
    updated_at = Column(DateTime, nullable=False, default=utcnow, onupdate=utcnow)
    __table_args__ = (UniqueConstraint("company_id","customer_id",name="uq_customer_credit_policy"), CheckConstraint("credit_limit >= 0", name="ck_credit_limit_nonnegative"))

class SupplierCreditPolicy(Base):
    __tablename__ = "supplier_credit_policies"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    supplier_id = Column(Integer, ForeignKey("suppliers.id", ondelete="CASCADE"), nullable=False, index=True)
    credit_limit = Column(Numeric(20,6), nullable=False, default=0)
    payment_terms_days = Column(Integer, nullable=False, default=0)
    updated_at = Column(DateTime, nullable=False, default=utcnow, onupdate=utcnow)
    __table_args__ = (UniqueConstraint("company_id","supplier_id",name="uq_supplier_credit_policy"), CheckConstraint("credit_limit >= 0", name="ck_supplier_credit_limit_nonnegative"))

class InventoryPolicy(Base):
    __tablename__ = "inventory_policies"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    warehouse_id = Column(Integer, ForeignKey("warehouses.id", ondelete="CASCADE"), nullable=True, index=True)
    costing_method = Column(String(30), nullable=False, default="weighted_average")
    allow_negative_stock = Column(Boolean, nullable=False, default=False)
    reorder_point = Column(Numeric(20,6), nullable=False, default=0)
    reorder_quantity = Column(Numeric(20,6), nullable=False, default=0)
    __table_args__ = (UniqueConstraint("company_id","warehouse_id",name="uq_inventory_policy_scope"),)

class BudgetControlPolicy(Base):
    __tablename__ = "budget_control_policies"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=True, index=True)
    tolerance_percent = Column(Numeric(9,6), nullable=False, default=0)
    block_over_budget = Column(Boolean, nullable=False, default=True)
    warning_percent = Column(Numeric(9,6), nullable=False, default=80)
    is_active = Column(Boolean, nullable=False, default=True)
    __table_args__ = (UniqueConstraint("company_id","project_id",name="uq_budget_policy_scope"),)

class ProcurementRequest(Base):
    __tablename__ = "procurement_requests"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id", ondelete="SET NULL"), nullable=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="SET NULL"), nullable=True, index=True)
    request_number = Column(String(40), nullable=False, index=True)
    requested_by_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    request_date = Column(DateTime, nullable=False, default=utcnow)
    status = Column(String(30), nullable=False, default="draft", index=True)
    priority = Column(String(20), nullable=False, default="normal")
    justification = Column(Text)
    created_at = Column(DateTime, nullable=False, default=utcnow)
    __table_args__ = (UniqueConstraint("company_id","request_number",name="uq_proc_request_number"),
                      CheckConstraint("status IN ('draft','submitted','rfq','closed','cancelled')", name="ck_proc_request_status"),
                      CheckConstraint("priority IN ('normal','high','urgent')", name="ck_proc_request_priority"),)

class ProcurementRequestLine(Base):
    __tablename__ = "procurement_request_lines"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    request_id = Column(Integer, ForeignKey("procurement_requests.id", ondelete="CASCADE"), nullable=False, index=True)
    item_id = Column(Integer, ForeignKey("items.id"), nullable=False)
    quantity = Column(Numeric(20,6), nullable=False)
    requested_date = Column(Date)
    specification = Column(Text)
    __table_args__ = (UniqueConstraint("company_id","request_id","item_id",name="uq_proc_request_line_item"),
                      CheckConstraint("quantity > 0", name="ck_proc_request_line_positive_qty"),)

class RFQ(Base):
    __tablename__ = "rfqs"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    branch_id = Column(Integer, ForeignKey("branches.id", ondelete="SET NULL"), nullable=True, index=True)
    request_id = Column(Integer, ForeignKey("procurement_requests.id", ondelete="SET NULL"), nullable=True, index=True)
    rfq_number = Column(String(40), nullable=False, index=True)
    issue_date = Column(DateTime, nullable=False, default=utcnow)
    due_date = Column(DateTime)
    status = Column(String(30), nullable=False, default="draft")
    notes = Column(Text)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    __table_args__ = (UniqueConstraint("company_id","rfq_number",name="uq_rfq_number"),
                      CheckConstraint("status IN ('draft','issued','open','closed','cancelled')", name="ck_rfq_status"),
                      CheckConstraint("due_date IS NULL OR due_date >= issue_date", name="ck_rfq_due_after_issue"),)

class RFQSupplier(Base):
    __tablename__ = "rfq_suppliers"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    rfq_id = Column(Integer, ForeignKey("rfqs.id", ondelete="CASCADE"), nullable=False, index=True)
    supplier_id = Column(Integer, ForeignKey("suppliers.id", ondelete="CASCADE"), nullable=False, index=True)
    status = Column(String(30), nullable=False, default="invited")
    __table_args__ = (UniqueConstraint("rfq_id","supplier_id",name="uq_rfq_supplier"),)

class RFQQuote(Base):
    __tablename__ = "rfq_quotes"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    rfq_id = Column(Integer, ForeignKey("rfqs.id", ondelete="CASCADE"), nullable=False, index=True)
    supplier_id = Column(Integer, ForeignKey("suppliers.id", ondelete="CASCADE"), nullable=False, index=True)
    quote_number = Column(String(60))
    quote_date = Column(DateTime, nullable=False, default=utcnow)
    valid_until = Column(Date)
    delivery_days = Column(Integer, nullable=True)
    payment_terms_days = Column(Integer, nullable=True)
    status = Column(String(30), nullable=False, default="received")
    notes = Column(Text)
    total_amount = Column(Numeric(20,6), nullable=False, default=0)

class RFQQuoteLine(Base):
    __tablename__ = "rfq_quote_lines"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    quote_id = Column(Integer, ForeignKey("rfq_quotes.id", ondelete="CASCADE"), nullable=False, index=True)
    item_id = Column(Integer, ForeignKey("items.id"), nullable=False)
    quantity = Column(Numeric(20,6), nullable=False)
    unit_price = Column(Numeric(20,6), nullable=False)
    tax_rate_id = Column(Integer, ForeignKey("tax_rates.id"), nullable=True)
    line_total = Column(Numeric(20,6), nullable=False)

class CommercialEvent(Base):
    __tablename__ = "commercial_events"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    entity_type = Column(String(80), nullable=False)
    entity_id = Column(Integer, nullable=False)
    event_type = Column(String(80), nullable=False)
    message = Column(Text)
    created_by_id = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, nullable=False, default=utcnow, index=True)
    __table_args__ = (Index("ix_commercial_event_entity","company_id","entity_type","entity_id","created_at"),)
