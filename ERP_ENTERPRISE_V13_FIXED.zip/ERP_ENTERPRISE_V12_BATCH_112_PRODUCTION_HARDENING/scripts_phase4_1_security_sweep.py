"""Static security inventory for Phase 4.1.

Reports FastAPI routes and whether they are covered by the central permission
mapper. It does not rewrite routes blindly.
"""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ROUTERS = ROOT / "app" / "routers"

for path in sorted(ROUTERS.glob("*.py")):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            decorators = [ast.unparse(d) for d in node.decorator_list]
            route = [d for d in decorators if ".get(" in d or ".post(" in d or ".put(" in d or ".patch(" in d or ".delete(" in d]
            if route:
                has_perm = any("require_permission" in d for d in decorators)
                print(f"{path.name}:{node.lineno}: {'PERMISSION' if has_perm else 'CENTRAL-MAPPER'} :: {route[0]}")
