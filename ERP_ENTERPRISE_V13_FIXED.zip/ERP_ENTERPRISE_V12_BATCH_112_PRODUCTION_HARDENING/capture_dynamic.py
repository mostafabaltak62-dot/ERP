import requests,re
from pathlib import Path
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:8000'; OUT=Path('/mnt/data/ERP_V10_PAGE_SCREENSHOTS'); OUT.mkdir(exist_ok=True)
urls=[
'/advanced-finance/customer/1','/advanced-finance/supplier/1','/inventory/1','/inventory/1/edit','/hr/employees/1',
'/projects/command-center?project_id=1','/projects/command-center/certificates?project_id=1','/projects/command-center/documents?project_id=1',
'/site-operations?project_id=1','/site-operations/daily-labor?project_id=1','/site-operations/equipment?project_id=1','/site-operations/material-requisitions?project_id=1','/site-operations/cost-control?project_id=1','/site-operations/project-cost-control?project_id=1','/site-operations/material-flow?project_id=1',
'/planning-costs/planning?project_id=1','/planning-costs/costs?project_id=1',
'/finance/party/customer/1','/finance/party/supplier/1'
]
s=requests.Session(); s.post(BASE+'/login',data={'username':'admin','password':'Admin12345678!'},allow_redirects=False); headers={'X-Company-ID':'1','X-Branch-ID':'1'}
def inline(html):
 soup=BeautifulSoup(html,'html.parser')
 for link in list(soup.find_all('link',href=True)):
  h=link['href']
  if h.startswith('/static/'):
   rr=requests.get(BASE+h)
   if rr.ok:
    st=soup.new_tag('style'); st.string=rr.text; link.replace_with(st)
 return str(soup)
start=len(list(OUT.glob('*.png')))+1
with sync_playwright() as p:
 b=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium',args=['--no-sandbox']); page=b.new_page(viewport={'width':1440,'height':1000},java_script_enabled=False)
 for n,u in enumerate(urls,start):
  try:
   r=s.get(BASE+u,headers=headers,timeout=10,allow_redirects=True); ct=r.headers.get('content-type','')
   if r.status_code==200 and 'text/html' in ct:
    page.set_content(inline(r.text),wait_until='domcontentloaded'); fn=f'{n:03d}_dynamic_{re.sub("[^A-Za-z0-9]+","_",u.strip("/"))[:90]}.png'; page.screenshot(path=str(OUT/fn),full_page=True); print('OK',u,fn)
   else: print('SKIP',u,r.status_code,ct)
  except Exception as e: print('ERR',u,e)
 b.close()
