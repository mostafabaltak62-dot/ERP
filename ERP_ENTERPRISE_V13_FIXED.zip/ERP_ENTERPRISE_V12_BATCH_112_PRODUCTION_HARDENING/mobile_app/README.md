# ERP Enterprise Mobile

Flutter mobile foundation for the ERP V8 backend. Android and iOS share one Dart codebase.

## Architecture
- `core/` API client, secure session, local SQLite queue, theme.
- `features/` authentication, executive dashboard, field operations, documents, approvals.
- API calls target `/api/v1` only; no Jinja HTML is used by the mobile app.

## Run
`flutter pub get`

`flutter run --dart-define=ERP_API_URL=https://erp.example.com`

Android emulator default: `http://10.0.2.2:8000`

## Security
- Bearer JWT in `flutter_secure_storage`.
- Tenant selected through `X-Company-ID`; server validates access and sets PostgreSQL RLS context.
- Never trust tenant identifiers from the client as authorization; the backend remains authoritative.

## Offline
SQLite stores pending operations with idempotency keys. A sync worker should submit batches to `/api/v1/field-operations/offline/batches` when connectivity returns. Photos should be staged in app-private storage and uploaded after the corresponding document/revision is created.
