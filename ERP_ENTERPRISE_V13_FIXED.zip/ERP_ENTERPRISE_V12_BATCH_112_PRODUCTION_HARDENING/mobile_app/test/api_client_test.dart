import 'package:flutter_test/flutter_test.dart';
import 'package:erp_mobile/core/api_client.dart';
void main(){test('tenant headers are generated for API calls',(){final api=ApiClient('http://localhost');api.token='t';api.companyId=7;api.branchId=3;expect(api.headers['Authorization'],'Bearer t');expect(api.headers['X-Company-ID'],'7');expect(api.headers['X-Branch-ID'],'3');});}
