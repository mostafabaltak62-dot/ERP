# Mobile Architecture

## API boundary
The app communicates only with `/api/v1/mobile/*`, `/api/v1/health`, and `/api/v1/notifications` exposed by the ERP API layer. It never renders or consumes Jinja HTML.

## Authentication
Mobile login uses `POST /api/v1/mobile/auth/login`. The server validates the user and requested tenant using server-side `UserCompanyAccess`, then returns a short-lived JWT. Subsequent calls send `Authorization: Bearer` plus `X-Company-ID` and optional `X-Branch-ID`.

## Data protection
Tokens live in OS-backed secure storage. Offline records contain business payloads only; credentials are never placed in SQLite.

## Offline contract
Every queued mutation has a unique `operation_id`. Batches are sent to the backend offline sync endpoint when connectivity returns. The server remains authoritative for conflict resolution and tenant access.

## Modules
1. Executive dashboard
2. Field labor / daily workers
3. Material requisitions
4. Document capture and review
5. Approvals and notifications
6. Offline synchronization
