import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiException implements Exception {
  final int status;
  final String message;
  ApiException(this.status, this.message);
  @override
  String toString() => message;
}

class ApiClient {
  final String baseUrl;
  String? token;
  int? companyId;
  int? branchId;
  ApiClient(this.baseUrl);

  Map<String,String> get headers => {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    if (token != null) 'Authorization': 'Bearer $token',
    if (companyId != null) 'X-Company-ID': '$companyId',
    if (branchId != null) 'X-Branch-ID': '$branchId',
  };

  Future<dynamic> get(String path, {Map<String,String>? query}) async {
    final uri = Uri.parse('$baseUrl$path').replace(queryParameters: query);
    final r = await http.get(uri, headers: headers);
    return _decode(r);
  }

  Future<dynamic> post(String path, Map<String,dynamic> body) async {
    final r = await http.post(Uri.parse('$baseUrl$path'), headers: headers, body: jsonEncode(body));
    return _decode(r);
  }

  Future<dynamic> _decode(http.Response r) async {
    dynamic body;
    try { body = jsonDecode(r.body); } catch (_) { body = r.body; }
    if (r.statusCode < 200 || r.statusCode >= 300) {
      final msg = body is Map && body['detail'] != null ? body['detail'].toString() : 'Request failed (${r.statusCode})';
      throw ApiException(r.statusCode, msg);
    }
    return body;
  }
}
