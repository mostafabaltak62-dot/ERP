import 'dart:convert';
import 'package:uuid/uuid.dart';
import 'api_client.dart';
import 'local_store.dart';

/// Offline-first mutation queue.
/// Financial, stock and site mutations are never silently merged: the server
/// remains authoritative and a version mismatch becomes a manual conflict.
class SyncManager {
  final ApiClient api;
  final LocalStore store;
  final _uuid = const Uuid();
  SyncManager(this.api, this.store);

  Future<void> enqueue(String entityType, String operation, Map<String, dynamic> payload, int clientVersion) async {
    final id = _uuid.v4();
    await store.queue(id, entityType, operation, {
      ...payload,
      'client_version': clientVersion,
    });
  }

  Future<List<Map<String, dynamic>>> flush() async {
    final pending = await store.pending();
    final conflicts = <Map<String, dynamic>>[];
    for (final row in pending) {
      final payload = jsonDecode(row['payload'] as String) as Map<String, dynamic>;
      try {
        final result = await api.post('/api/v1/field-ops/offline-sync', {
          'operation_id': row['operation_id'],
          'entity_type': row['entity_type'],
          'operation': row['operation'],
          'entity_id': payload['entity_id'],
          'client_version': payload['client_version'] ?? 1,
          'payload': payload,
        });
        if (result is Map && result['status'] == 'conflict') {
          conflicts.add({'operation_id': row['operation_id'], 'result': result});
        } else {
          await store.markDone(row['id'] as int);
        }
      } on ApiException catch (e) {
        if (e.status == 409) {
          conflicts.add({'operation_id': row['operation_id'], 'error': e.message});
        }
        // transient failures stay pending for retry with the same operation_id
      }
    }
    return conflicts;
  }
}
