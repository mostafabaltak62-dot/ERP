import 'dart:convert';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class LocalStore {
  Database? _db;
  Future<Database> get db async => _db ??= await openDatabase(join(await getDatabasesPath(), 'erp_mobile.db'), version: 1, onCreate: (db, _) async {
    await db.execute('CREATE TABLE sync_queue(id INTEGER PRIMARY KEY AUTOINCREMENT, operation_id TEXT UNIQUE, entity_type TEXT, operation TEXT, payload TEXT, created_at TEXT, status TEXT DEFAULT "pending")');
    await db.execute('CREATE TABLE cache(key TEXT PRIMARY KEY, value TEXT, updated_at TEXT)');
  });

  Future<void> queue(String operationId, String entityType, String operation, Map<String,dynamic> payload) async {
    final d = await db;
    await d.insert('sync_queue', {'operation_id':operationId,'entity_type':entityType,'operation':operation,'payload':jsonEncode(payload),'created_at':DateTime.now().toUtc().toIso8601String(),'status':'pending'}, conflictAlgorithm: ConflictAlgorithm.ignore);
  }

  Future<List<Map<String,Object?>>> pending() async => (await db).query('sync_queue', where:'status=?', whereArgs:['pending'], orderBy:'id');
  Future<void> markDone(int id) async => (await db).update('sync_queue', {'status':'sent'}, where:'id=?', whereArgs:[id]);
  Future<void> cache(String key, dynamic value) async => (await db).insert('cache', {'key':key,'value':jsonEncode(value),'updated_at':DateTime.now().toUtc().toIso8601String()}, conflictAlgorithm: ConflictAlgorithm.replace);
  Future<dynamic> readCache(String key) async { final rows=await (await db).query('cache',where:'key=?',whereArgs:[key]); return rows.isEmpty?null:jsonDecode(rows.first['value'] as String); }
}
