import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'api_client.dart';

class Session extends ChangeNotifier {
  final FlutterSecureStorage storage = const FlutterSecureStorage();
  final ApiClient api;
  bool ready = false;
  bool authenticated = false;
  String? username;
  Session(this.api);

  Future<void> restore() async {
    api.token = await storage.read(key: 'access_token');
    final company = await storage.read(key: 'company_id');
    final branch = await storage.read(key: 'branch_id');
    api.companyId = company == null ? null : int.tryParse(company);
    api.branchId = branch == null ? null : int.tryParse(branch);
    authenticated = api.token != null;
    ready = true;
    notifyListeners();
  }

  Future<void> signIn(String user, String password, int company) async {
    final result = await api.post('/api/v1/mobile/auth/login', {'username': user, 'password': password, 'company_id': company});
    api.token = result['access_token'];
    api.companyId = company;
    username = result['user']['username'];
    await storage.write(key: 'access_token', value: api.token);
    await storage.write(key: 'company_id', value: '$company');
    authenticated = true;
    notifyListeners();
  }

  Future<void> signOut() async {
    await storage.delete(key: 'access_token');
    await storage.delete(key: 'company_id');
    await storage.delete(key: 'branch_id');
    api.token = null; api.companyId = null; api.branchId = null;
    authenticated = false;
    notifyListeners();
  }
}
