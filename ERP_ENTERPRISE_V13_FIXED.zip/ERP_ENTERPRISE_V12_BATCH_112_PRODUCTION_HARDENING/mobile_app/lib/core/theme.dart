import 'package:flutter/material.dart';
class AppTheme {
  static ThemeData get light => ThemeData(useMaterial3:true, colorSchemeSeed:const Color(0xFF0B5CAD), scaffoldBackgroundColor:const Color(0xFFF4F6F8), fontFamily:'Arial', inputDecorationTheme:const InputDecorationTheme(border:OutlineInputBorder(), filled:true, fillColor:Colors.white));
}
