import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/api_client.dart';
class DocumentsScreen extends StatelessWidget { final ApiClient api; const DocumentsScreen({super.key,required this.api});
  Future<void> capture(BuildContext c) async { final x=await ImagePicker().pickImage(source:ImageSource.camera,imageQuality:80); if(x!=null&&c.mounted) ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text('تم التقاط ${x.name} — جاهز للرفع'))); }
  @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Document Controller',style:TextStyle(fontSize:26,fontWeight:FontWeight.w800)),const SizedBox(height:16),FilledButton.icon(onPressed:()=>capture(c),icon:const Icon(Icons.camera_alt),label:const Text('تصوير ورفع مستند')),const SizedBox(height:12),_doc('SIR','طلبات فحص الأعمال'),_doc('MIR','طلبات فحص المواد'),_doc('MT','Material Transmittals'),_doc('DOC','Document Submittals'),_doc('LETTER','خطابات المشروع'),_doc('HANDOVER','محاضر الاستلام والتسليم')]);
  Widget _doc(String code,String name)=>Card(child:ListTile(leading:const Icon(Icons.description_outlined),title:Text(name),subtitle:Text(code),trailing:const Icon(Icons.chevron_right)));
}
