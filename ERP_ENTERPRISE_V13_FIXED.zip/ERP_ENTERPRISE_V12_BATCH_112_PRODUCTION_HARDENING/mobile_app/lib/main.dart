import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/api_client.dart';
import 'core/session.dart';
import 'core/local_store.dart';
import 'core/theme.dart';
import 'features/auth/login_screen.dart';
import 'features/dashboard/dashboard_screen.dart';
import 'features/field_ops/field_ops_screen.dart';
import 'features/documents/documents_screen.dart';

void main(){
  const apiUrl = String.fromEnvironment('ERP_API_URL', defaultValue: '');
  assert(apiUrl.isNotEmpty, 'ERP_API_URL must be supplied');
  if (apiUrl.isEmpty || (!apiUrl.startsWith('https://') && !apiUrl.startsWith('http://10.0.2.2:'))) {
    throw StateError('ERP_API_URL must be provided; production builds require HTTPS');
  }
  final api=ApiClient(apiUrl);
  final session=Session(api);
  runApp(ChangeNotifierProvider.value(value:session,child:ErpApp(api:api,store:LocalStore())));
}
class ErpApp extends StatefulWidget{final ApiClient api;final LocalStore store;const ErpApp({super.key,required this.api,required this.store});@override State<ErpApp> createState()=>_ErpAppState();}
class _ErpAppState extends State<ErpApp>{int index=0;late Session session;@override void initState(){super.initState();session=Provider.of<Session>(context,listen:false);session.restore();}
 @override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,theme:AppTheme.light,home:!session.ready?const Scaffold(body:Center(child:CircularProgressIndicator())):(!session.authenticated?LoginScreen(session:session):_home()));
 Widget _home()=>Scaffold(appBar:AppBar(title:const Text('ERP Enterprise'),actions:[IconButton(onPressed:session.signOut,icon:const Icon(Icons.logout))]),body:[DashboardScreen(api:widget.api),FieldOpsScreen(api:widget.api,store:widget.store),DocumentsScreen(api:widget.api),const Center(child:Text('Approvals & Notifications'))][index],bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),destinations:const[NavigationDestination(icon:Icon(Icons.dashboard_outlined),label:'الرئيسية'),NavigationDestination(icon:Icon(Icons.engineering_outlined),label:'الموقع'),NavigationDestination(icon:Icon(Icons.folder_outlined),label:'المستندات'),NavigationDestination(icon:Icon(Icons.approval_outlined),label:'الموافقات')]),);
}
