# Offline Sync Strategy

1. Every mutation gets a UUID `operation_id` and is stored locally before network transmission.
2. The server is authoritative; duplicate `operation_id` values are idempotently ignored.
3. Each mutation carries `client_version`.
4. Financial journals, invoices, stock movements and site material movements are **non-mergeable**. Version mismatch becomes a manual conflict; no automatic last-write-wins.
5. Reference/document updates may use server-wins where safe.
6. On reconnect, operations are sent in FIFO order. A transient 5xx/network failure keeps the same operation pending; a 409 becomes a conflict record.
7. Tenant headers are generated from the authenticated session and never treated as permission grants by the backend.
8. Access/refresh tokens are kept in secure storage; logout clears local credentials.
