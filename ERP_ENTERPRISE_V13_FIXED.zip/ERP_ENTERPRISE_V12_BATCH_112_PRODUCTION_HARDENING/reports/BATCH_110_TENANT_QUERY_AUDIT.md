# Tenant & ORM Static Audit
Direct Session.get calls: 35
Files containing query() calls: 46
Explicit tenant-filter bypasses: 1

## Direct Session.get review queue
- app/auth.py:105 -> User
- app/models.py:981 -> JournalEntry
- app/models.py:998 -> JournalEntry
- app/workflows.py:21 -> User
- app/governance.py:139 -> User
- app/governance.py:165 -> User
- app/governance.py:243 -> Company
- app/governance.py:247 -> Branch
- app/governance.py:217 -> Company
- app/governance.py:221 -> Branch
- app/routers/organization_admin_router.py:25 -> Company
- app/routers/organization_admin_router.py:210 -> User
- app/routers/admin_security_router.py:42 -> User
- app/routers/admin_security_router.py:76 -> User
- app/routers/admin_security_router.py:96 -> User
- app/routers/admin_security_router.py:105 -> User
- app/routers/admin_security_router.py:116 -> PasswordResetRequest
- app/routers/admin_security_router.py:202 -> User
- app/routers/admin_security_router.py:228 -> UserRole
- app/routers/admin_security_router.py:230 -> Role
- app/routers/admin_security_router.py:283 -> User
- app/routers/admin_security_router.py:206 -> Company
- app/routers/admin_security_router.py:209 -> Branch
- app/routers/auth_router.py:83 -> Company
- app/routers/auth_router.py:274 -> User
- app/routers/auth_router.py:309 -> User
- app/routers/auth_router.py:355 -> User
- app/routers/auth_router.py:396 -> User
- app/routers/auth_router.py:408 -> User
- app/routers/auth_router.py:254 -> User
- app/routers/auth_router.py:278 -> User
- app/routers/auth_router.py:413 -> Branch
- app/routers/auth_router.py:417 -> Project
- app/routers/auth_router.py:422 -> ConstructionSite
- app/routers/auth_router.py:425 -> Project

## Query hotspots
- app/construction_services.py: 218 query() calls
- app/routers/site_operations_router.py: 82 query() calls
- app/routers/commercial_workspace_router.py: 66 query() calls
- app/field_ops_services.py: 49 query() calls
- app/routers/commercial_completion_router.py: 44 query() calls
- app/routers/auth_router.py: 41 query() calls
- app/routers/hr_router.py: 40 query() calls
- app/routers/planning_costs_router.py: 38 query() calls
- app/routers/advanced_finance_router.py: 36 query() calls
- app/deep_transactions.py: 33 query() calls
- app/routers/command_center_router.py: 33 query() calls
- app/routers/pro_ledger_router.py: 31 query() calls
- app/routers/enterprise_plus_router.py: 31 query() calls
- app/routers/accounting_router.py: 29 query() calls
- app/routers/sales_router.py: 28 query() calls
- app/routers/finance_router.py: 28 query() calls
- app/routers/purchases_router.py: 28 query() calls
- app/routers/document_controller_router.py: 26 query() calls
- app/routers/hr_ui_router.py: 24 query() calls
- app/routers/admin_security_router.py: 22 query() calls
- app/core_services.py: 21 query() calls
- app/routers/organization_admin_router.py: 21 query() calls
- app/accounting_controls.py: 20 query() calls
- app/routers/financial_reporting_ui.py: 19 query() calls
- app/accounting.py: 18 query() calls

## Explicit bypasses
- app/accounting.py:37 -> db.query(SequenceCounter).execution_options(skip_tenant_filter=True)
