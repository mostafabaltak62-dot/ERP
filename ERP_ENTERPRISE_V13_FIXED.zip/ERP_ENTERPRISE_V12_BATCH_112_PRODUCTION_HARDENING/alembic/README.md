# Database migrations

Production databases must be upgraded with Alembic instead of `Base.metadata.create_all()`.

Examples:

```bash
alembic upgrade head
alembic downgrade -1
alembic revision --autogenerate -m "describe change"
```

Set `DATABASE_URL` in the environment before running migrations.
