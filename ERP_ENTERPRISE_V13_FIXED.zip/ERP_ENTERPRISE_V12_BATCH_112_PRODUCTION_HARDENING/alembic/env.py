from logging.config import fileConfig
import os
from dotenv import load_dotenv

load_dotenv(override=False)
from sqlalchemy import engine_from_config, pool
from alembic import context

from app.db_base import Base

# Import model modules only.  Alembic metadata discovery must not import
# runtime services that initialize database engines or require production secrets.
from app import account_security  # noqa: F401
from app import governance_models  # noqa: F401
from app import construction_models  # noqa: F401
from app import models  # noqa: F401
from app import document_models  # noqa: F401
from app import site_material_flow_models  # noqa: F401
from app import hr_models  # noqa: F401
from app import site_operations_center_models  # noqa: F401
from app import enterprise_models  # noqa: F401
from app import construction_document_forms_models  # noqa: F401
from app import field_ops_models  # noqa: F401
from app import commercial_completion_models  # noqa: F401
from app import enterprise_plus_models  # noqa: F401
from app import warehouse_models  # noqa: F401

config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

url = os.getenv("DATABASE_URL") or os.getenv("ERP_DATABASE_URL") or config.get_main_option("sqlalchemy.url")
config.set_main_option("sqlalchemy.url", url.replace('%', '%%'))
target_metadata = Base.metadata


def run_migrations_offline():
    context.configure(url=url, target_metadata=target_metadata, literal_binds=True,
                      dialect_opts={"paramstyle": "named"}, compare_type=True,
                      compare_server_default=True)
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online():
    connectable = engine_from_config(config.get_section(config.config_ini_section),
                                     prefix="sqlalchemy.", poolclass=pool.NullPool)
    with connectable.connect() as connection:
        if url.startswith("sqlite"):
            connection.exec_driver_sql("PRAGMA foreign_keys=ON")
        context.configure(connection=connection, target_metadata=target_metadata,
                          compare_type=True, compare_server_default=True,
                          transactional_ddl=False)
        context.run_migrations()
        # SQLite uses non-transactional DDL; explicitly commit Alembic's
        # version-table update so a successful migration is durable.
        connection.commit()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
