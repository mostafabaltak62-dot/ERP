"""Phase 6.9 — Enterprise completeness suite.

Adds the missing enterprise capabilities identified in the Odoo comparison while
keeping the construction-specific core as the differentiator: workforce rules,
contracts/lifecycle, recruitment/onboarding, expenses, project timesheets/tasks,
quality, maintenance, field service, document templates and controlled signatures.
"""
from typing import Sequence, Union
from alembic import op
from app.db_base import Base
from app import enterprise_plus_models  # noqa: F401

revision: str = 'a66a79eb1cf4'
down_revision: Union[str, Sequence[str], None] = '2c3d4e5f6a71'
branch_labels = None
depends_on = None

TABLES = [
    'work_schedules','work_schedule_days','overtime_rules','employee_contracts',
    'attendance_events','onboarding_cases','onboarding_tasks','recruitment_jobs',
    'recruitment_candidates','employee_lifecycle_cases','expense_claims',
    'project_timesheets','project_tasks','quality_inspections','quality_defects',
    'maintenance_plans','maintenance_work_orders','field_service_visits',
    'document_templates','signature_requests','signature_signers'
]

def upgrade() -> None:
    bind = op.get_bind()
    for name in TABLES:
        table = Base.metadata.tables[name]
        table.create(bind=bind, checkfirst=True)

def downgrade() -> None:
    bind = op.get_bind()
    for name in reversed(TABLES):
        table = Base.metadata.tables[name]
        table.drop(bind=bind, checkfirst=True)
