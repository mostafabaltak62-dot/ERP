"""Patch 54 cost control governance snapshots
Revision ID: p54_cost_control_governance
Revises: p52_resource_periods_schedule_updates
"""
from alembic import op
import sqlalchemy as sa
revision='p54_cost_control_governance'; down_revision='p52_recovery_eot_schedule_updates'; branch_labels=None; depends_on=None

def upgrade():
    op.create_table('construction_cost_control_snapshots',
        sa.Column('id',sa.Integer(),primary_key=True), sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False,index=True),
        sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False,index=True), sa.Column('status_date',sa.Date(),nullable=False),
        sa.Column('budget',sa.Numeric(20,6),nullable=False,server_default='0'), sa.Column('committed',sa.Numeric(20,6),nullable=False,server_default='0'),
        sa.Column('actual',sa.Numeric(20,6),nullable=False,server_default='0'), sa.Column('etc',sa.Numeric(20,6),nullable=False,server_default='0'),
        sa.Column('eac',sa.Numeric(20,6),nullable=False,server_default='0'), sa.Column('variance',sa.Numeric(20,6),nullable=False,server_default='0'),
        sa.Column('cpi',sa.Numeric(20,8)), sa.Column('eac_method',sa.String(30),nullable=False,server_default='manual_etc'),
        sa.Column('status',sa.String(30),nullable=False,server_default='draft'), sa.Column('created_by_id',sa.Integer(),sa.ForeignKey('users.id')),
        sa.Column('approved_by_id',sa.Integer(),sa.ForeignKey('users.id')), sa.Column('approved_at',sa.DateTime()),
        sa.UniqueConstraint('company_id','project_id','status_date',name='uq_cost_snapshot_company_project_date'),
        sa.CheckConstraint('budget >= 0 AND committed >= 0 AND actual >= 0 AND etc >= 0 AND eac >= 0','ck_cost_snapshot_nonnegative'))

def downgrade(): op.drop_table('construction_cost_control_snapshots')
