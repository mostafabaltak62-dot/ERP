"""Enterprise inventory valuation engine.

Adds explicit cost layers/consumptions and per-item valuation policy so COGS
is derived from FIFO or weighted-average costing rather than item.purchase_price.
"""
from alembic import op
import sqlalchemy as sa

revision = "7f8e9d0a1b22"
down_revision = "6d2f8e1a9c77"
branch_labels = None
depends_on = None


def _rls(bind, tables):
    if bind.dialect.name != "postgresql": return
    for table in tables:
        q='"'+table+'"'; policy=f"tenant_isolation_{table}"
        op.execute(f"ALTER TABLE {q} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {q} FORCE ROW LEVEL SECURITY")
        op.execute(f"DROP POLICY IF EXISTS {policy} ON {q}")
        expr="company_id = NULLIF(current_setting('app.company_id', true), '')::integer"
        op.execute(f"CREATE POLICY {policy} ON {q} USING ({expr}) WITH CHECK ({expr})")


def upgrade():
    op.create_table("inventory_valuation_policies",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id"), nullable=False),
        sa.Column("item_id", sa.Integer(), sa.ForeignKey("items.id"), nullable=False),
        sa.Column("method", sa.String(20), nullable=False, server_default="weighted_average"),
        sa.Column("allow_negative", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("effective_from", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("company_id","item_id",name="uq_inventory_policy_company_item"),
    )
    op.create_index("ix_inventory_valuation_policies_company_id","inventory_valuation_policies",["company_id"])
    op.create_index("ix_inventory_valuation_policies_item_id","inventory_valuation_policies",["item_id"])

    op.create_table("inventory_cost_layers",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id"), nullable=False),
        sa.Column("item_id", sa.Integer(), sa.ForeignKey("items.id"), nullable=False),
        sa.Column("source_type", sa.String(50), nullable=False),
        sa.Column("source_id", sa.Integer(), nullable=False),
        sa.Column("received_at", sa.DateTime(), nullable=False),
        sa.Column("original_qty", sa.Numeric(20,6), nullable=False),
        sa.Column("remaining_qty", sa.Numeric(20,6), nullable=False),
        sa.Column("unit_cost", sa.Numeric(20,6), nullable=False),
        sa.Column("total_cost", sa.Numeric(20,6), nullable=False),
        sa.CheckConstraint("original_qty >= 0", name="ck_inventory_layer_original_qty"),
        sa.CheckConstraint("remaining_qty >= 0", name="ck_inventory_layer_remaining_qty"),
    )
    op.create_index("ix_inventory_cost_layers_company_id","inventory_cost_layers",["company_id"])
    op.create_index("ix_inventory_cost_layers_item_id","inventory_cost_layers",["item_id"])
    op.create_index("ix_inventory_layers_fifo","inventory_cost_layers",["company_id","item_id","received_at","id"])

    op.create_table("inventory_cost_consumptions",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id"), nullable=False),
        sa.Column("item_id", sa.Integer(), sa.ForeignKey("items.id"), nullable=False),
        sa.Column("layer_id", sa.Integer(), sa.ForeignKey("inventory_cost_layers.id"), nullable=False),
        sa.Column("source_type", sa.String(50), nullable=False),
        sa.Column("source_id", sa.Integer(), nullable=False),
        sa.Column("quantity", sa.Numeric(20,6), nullable=False),
        sa.Column("unit_cost", sa.Numeric(20,6), nullable=False),
        sa.Column("total_cost", sa.Numeric(20,6), nullable=False),
        sa.Column("consumed_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("company_id","layer_id","source_type","source_id",name="uq_inventory_consumption_source"),
    )
    op.create_index("ix_inventory_cost_consumptions_company_id","inventory_cost_consumptions",["company_id"])
    op.create_index("ix_inventory_cost_consumptions_item_id","inventory_cost_consumptions",["item_id"])
    op.create_index("ix_inventory_cost_consumptions_layer_id","inventory_cost_consumptions",["layer_id"])

    op.create_table("inventory_valuation_runs",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id"), nullable=False),
        sa.Column("run_date", sa.DateTime(), nullable=False),
        sa.Column("status", sa.String(20), nullable=False, server_default="completed"),
        sa.Column("total_quantity", sa.Numeric(20,6), nullable=False, server_default="0"),
        sa.Column("total_value", sa.Numeric(20,6), nullable=False, server_default="0"),
        sa.Column("method", sa.String(20), nullable=False),
        sa.Column("created_by_id", sa.Integer(), sa.ForeignKey("users.id")),
    )
    op.create_index("ix_inventory_valuation_runs_company_id","inventory_valuation_runs",["company_id"])
    _rls(op.get_bind(), ["inventory_valuation_policies","inventory_cost_layers","inventory_cost_consumptions","inventory_valuation_runs"])


def downgrade():
    bind=op.get_bind()
    if bind.dialect.name == "postgresql":
        for table in ["inventory_valuation_policies","inventory_cost_layers","inventory_cost_consumptions","inventory_valuation_runs"]:
            q='"'+table+'"'; policy=f"tenant_isolation_{table}"
            op.execute(f"DROP POLICY IF EXISTS {policy} ON {q}")
            op.execute(f"ALTER TABLE {q} NO FORCE ROW LEVEL SECURITY")
            op.execute(f"ALTER TABLE {q} DISABLE ROW LEVEL SECURITY")
    op.drop_table("inventory_valuation_runs")
    op.drop_table("inventory_cost_consumptions")
    op.drop_table("inventory_cost_layers")
    op.drop_table("inventory_valuation_policies")
