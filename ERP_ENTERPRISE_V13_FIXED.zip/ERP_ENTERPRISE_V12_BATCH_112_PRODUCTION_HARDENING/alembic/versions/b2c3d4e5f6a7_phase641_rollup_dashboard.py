"""phase 6.4.1 evm rollup dashboard and cost allocation
Revision ID: b2c3d4e5f6a7
Revises: a1b2c3d4e5f6
"""
from alembic import op
import sqlalchemy as sa
revision='b2c3d4e5f6a7'; down_revision='a1b2c3d4e5f6'; branch_labels=None; depends_on=None

def upgrade():
    op.create_table('construction_evm_cost_allocations',
      sa.Column('id',sa.Integer(),primary_key=True),
      sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),
      sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),
      sa.Column('project_cost_id',sa.Integer(),sa.ForeignKey('project_costs.id'),nullable=False),
      sa.Column('wbs_id',sa.Integer(),sa.ForeignKey('construction_wbs_nodes.id')),
      sa.Column('boq_line_id',sa.Integer(),sa.ForeignKey('construction_boq_lines.id')),
      sa.Column('cost_code_id',sa.Integer(),sa.ForeignKey('construction_cost_codes.id')),
      sa.Column('allocated_amount',sa.Numeric(20,6),nullable=False),
      sa.Column('created_at',sa.DateTime(),nullable=False,server_default=sa.func.now()),
      sa.CheckConstraint('allocated_amount >= 0',name='ck_evm_allocated_amount_nonnegative'))
    for c in ['company_id','project_id','project_cost_id','wbs_id','boq_line_id','cost_code_id']:
        op.create_index('ix_evm_alloc_'+c,'construction_evm_cost_allocations',[c])

def downgrade():
    op.drop_table('construction_evm_cost_allocations')
