"""phase 6.4.2 performance alerts and forecast governance
Revision ID: c3d4e5f6a7b8
Revises: b2c3d4e5f6a7
"""
from alembic import op
import sqlalchemy as sa
revision='c3d4e5f6a7b8'; down_revision='b2c3d4e5f6a7'; branch_labels=None; depends_on=None

def upgrade():
    op.create_table('construction_performance_alerts',
      sa.Column('id',sa.Integer(),primary_key=True),
      sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),
      sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),
      sa.Column('snapshot_id',sa.Integer(),sa.ForeignKey('construction_evm_snapshots.id')),
      sa.Column('status_date',sa.Date(),nullable=False),
      sa.Column('alert_type',sa.String(40),nullable=False),
      sa.Column('metric',sa.String(30),nullable=False),
      sa.Column('severity',sa.String(20),nullable=False),
      sa.Column('threshold',sa.Numeric(20,8),nullable=False),
      sa.Column('actual_value',sa.Numeric(20,8),nullable=False),
      sa.Column('status',sa.String(30),nullable=False,server_default='open'),
      sa.Column('message',sa.Text(),nullable=False),
      sa.Column('acknowledged_by_id',sa.Integer(),sa.ForeignKey('users.id')),
      sa.Column('acknowledged_at',sa.DateTime()),
      sa.Column('corrective_action',sa.Text()),
      sa.Column('resolved_by_id',sa.Integer(),sa.ForeignKey('users.id')),
      sa.Column('resolved_at',sa.DateTime()),
      sa.Column('created_at',sa.DateTime(),nullable=False,server_default=sa.func.now()),
      sa.UniqueConstraint('project_id','status_date','alert_type','metric',name='uq_perf_alert_project_date_type_metric'))
    for c in ['company_id','project_id','snapshot_id']:
        op.create_index('ix_perf_alert_'+c,'construction_performance_alerts',[c])

def downgrade():
    op.drop_table('construction_performance_alerts')
