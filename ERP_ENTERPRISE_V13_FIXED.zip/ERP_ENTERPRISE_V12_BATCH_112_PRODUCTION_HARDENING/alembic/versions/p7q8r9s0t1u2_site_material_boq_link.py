"""Link site material issues directly to BOQ lines (SQLite/PostgreSQL safe)."""
from alembic import op
import sqlalchemy as sa

revision = "p7q8r9s0t1u2"
down_revision = "o6p7q8r9s0t1"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("site_material_issues", sa.Column("boq_line_id", sa.Integer(), nullable=True))
    # SQLite cannot ALTER TABLE to add a foreign key; batch mode transparently
    # rebuilds the table while PostgreSQL performs the native ALTER.
    with op.batch_alter_table("site_material_issues", recreate="auto") as batch:
        batch.create_foreign_key(
            "fk_site_material_issue_boq_line",
            "construction_boq_lines",
            ["boq_line_id"], ["id"], ondelete="SET NULL"
        )
        batch.create_index("ix_site_material_issues_boq_line_id", ["boq_line_id"])

    bind = op.get_bind()
    if bind.dialect.name == "sqlite":
        op.execute(sa.text("""
            UPDATE site_material_issues
            SET boq_line_id = (
                SELECT r.boq_line_id
                FROM site_material_requisition_lines r
                WHERE r.id = site_material_issues.requisition_line_id
            )
            WHERE EXISTS (
                SELECT 1 FROM site_material_requisition_lines r2
                WHERE r2.id = site_material_issues.requisition_line_id
                  AND r2.boq_line_id IS NOT NULL
            )
        """))
    else:
        op.execute(sa.text("""
            UPDATE site_material_issues
            SET boq_line_id = r.boq_line_id
            FROM site_material_requisition_lines r
            WHERE site_material_issues.requisition_line_id = r.id
              AND r.boq_line_id IS NOT NULL
        """))


def downgrade():
    with op.batch_alter_table("site_material_issues", recreate="auto") as batch:
        batch.drop_index("ix_site_material_issues_boq_line_id")
        batch.drop_constraint("fk_site_material_issue_boq_line", type_="foreignkey")
        batch.drop_column("boq_line_id")
