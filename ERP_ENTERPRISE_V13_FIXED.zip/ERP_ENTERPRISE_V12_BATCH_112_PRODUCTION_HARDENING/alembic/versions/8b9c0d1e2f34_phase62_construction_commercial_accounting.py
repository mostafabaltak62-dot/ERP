"""phase62 construction commercial accounting integration
Revision ID: 8b9c0d1e2f34
Revises: 7a8b9c0d1e23
"""
from alembic import op
import sqlalchemy as sa
revision='8b9c0d1e2f34'; down_revision='7a8b9c0d1e23'; branch_labels=None; depends_on=None

def upgrade():
    with op.batch_alter_table('progress_certificates', schema=None) as b:
        b.add_column(sa.Column('contract_id', sa.Integer(), nullable=True))
        b.add_column(sa.Column('approved_at', sa.DateTime(), nullable=True))
        b.add_column(sa.Column('approved_by_id', sa.Integer(), nullable=True))
        b.add_column(sa.Column('journal_entry_id', sa.Integer(), nullable=True))
        b.create_foreign_key('fk_progress_cert_contract','contracts',['contract_id'],['id'])
        b.create_foreign_key('fk_progress_cert_approved_by','users',['approved_by_id'],['id'])
        b.create_foreign_key('fk_progress_cert_journal','journal_entries',['journal_entry_id'],['id'])
        b.create_index('ix_progress_certificates_contract_id',['contract_id'])
    with op.batch_alter_table('construction_advances', schema=None) as b:
        b.add_column(sa.Column('journal_entry_id', sa.Integer(), nullable=True))
        b.create_foreign_key('fk_construction_advance_journal','journal_entries',['journal_entry_id'],['id'])
    with op.batch_alter_table('subcontractor_progress', schema=None) as b:
        b.add_column(sa.Column('approved_at', sa.DateTime(), nullable=True))
        b.add_column(sa.Column('approved_by_id', sa.Integer(), nullable=True))
        b.add_column(sa.Column('journal_entry_id', sa.Integer(), nullable=True))
        b.create_foreign_key('fk_sub_progress_approved_by','users',['approved_by_id'],['id'])
        b.create_foreign_key('fk_sub_progress_journal','journal_entries',['journal_entry_id'],['id'])

def downgrade():
    with op.batch_alter_table('subcontractor_progress', schema=None) as b:
        b.drop_constraint('fk_sub_progress_journal', type_='foreignkey'); b.drop_constraint('fk_sub_progress_approved_by', type_='foreignkey')
        b.drop_column('journal_entry_id'); b.drop_column('approved_by_id'); b.drop_column('approved_at')
    with op.batch_alter_table('construction_advances', schema=None) as b:
        b.drop_constraint('fk_construction_advance_journal', type_='foreignkey'); b.drop_column('journal_entry_id')
    with op.batch_alter_table('progress_certificates', schema=None) as b:
        b.drop_index('ix_progress_certificates_contract_id')
        b.drop_constraint('fk_progress_cert_journal', type_='foreignkey'); b.drop_constraint('fk_progress_cert_approved_by', type_='foreignkey'); b.drop_constraint('fk_progress_cert_contract', type_='foreignkey')
        b.drop_column('journal_entry_id'); b.drop_column('approved_by_id'); b.drop_column('approved_at'); b.drop_column('contract_id')
