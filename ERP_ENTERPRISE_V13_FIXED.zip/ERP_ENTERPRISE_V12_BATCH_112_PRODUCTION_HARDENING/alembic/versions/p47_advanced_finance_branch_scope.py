"""Patch 48: branch scope for advanced finance masters and postings."""
from alembic import op
import sqlalchemy as sa

revision = "p47_adv_fin_branch"
down_revision = "x10p45_p2p_hardening"
branch_labels = None
depends_on = None

TABLES = [
    "cost_centers", "tax_rates", "accrual_entries", "withholding_tax_rates",
    "withholding_tax_transactions", "fixed_assets", "fixed_asset_disposals",
    "asset_depreciation_runs",
]

def _drop_unique_if_present(batch, table, expected_name):
    bind = op.get_bind()
    names = {x.get("name") for x in sa.inspect(bind).get_unique_constraints(table)}
    if expected_name in names:
        batch.drop_constraint(expected_name, type_="unique")
    # The baseline SQLite schema used a unique index rather than a named
    # constraint for some legacy codes. Drop it as well when present.
    index_names = {x.get("name") for x in sa.inspect(bind).get_indexes(table)}
    legacy_index = {"cost_centers":"ix_cost_centers_code"}.get(table)
    if legacy_index in index_names:
        batch.drop_index(legacy_index)


def upgrade():
    for table in TABLES:
        with op.batch_alter_table(table) as batch:
            batch.add_column(sa.Column("branch_id", sa.Integer(), nullable=True))
            batch.create_index(f"ix_{table}_branch_id", ["branch_id"])
            batch.create_foreign_key(f"fk_{table}_branch_id", "branches", ["branch_id"], ["id"], ondelete="SET NULL")
    # Legacy global codes become scoped by company + branch. NULL branch is the
    # company-wide namespace and remains intentionally separate from branch rows.
    with op.batch_alter_table("cost_centers") as batch:
        _drop_unique_if_present(batch, "cost_centers", "cost_centers_code_key")
        batch.create_unique_constraint("uq_cost_center_company_branch_code", ["company_id", "branch_id", "code"])
    with op.batch_alter_table("tax_rates") as batch:
        _drop_unique_if_present(batch, "tax_rates", "tax_rates_code_key")
        batch.create_unique_constraint("uq_tax_rate_company_branch_code", ["company_id", "branch_id", "code"])
    with op.batch_alter_table("fixed_assets") as batch:
        _drop_unique_if_present(batch, "fixed_assets", "fixed_assets_asset_code_key")
        batch.create_unique_constraint("uq_fixed_asset_company_branch_code", ["company_id", "branch_id", "asset_code"])
    with op.batch_alter_table("withholding_tax_rates") as batch:
        _drop_unique_if_present(batch, "withholding_tax_rates", "uq_wht_company_code")
        batch.create_unique_constraint("uq_wht_company_branch_code", ["company_id", "branch_id", "code"])

def downgrade():
    for table, name in [("cost_centers","uq_cost_center_company_branch_code"),("tax_rates","uq_tax_rate_company_branch_code"),("fixed_assets","uq_fixed_asset_company_branch_code"),("withholding_tax_rates","uq_wht_company_branch_code")]:
        with op.batch_alter_table(table) as batch:
            batch.drop_constraint(name, type_="unique")
    with op.batch_alter_table("cost_centers") as batch: batch.create_unique_constraint("cost_centers_code_key", ["code"])
    with op.batch_alter_table("tax_rates") as batch: batch.create_unique_constraint("tax_rates_code_key", ["code"])
    with op.batch_alter_table("fixed_assets") as batch: batch.create_unique_constraint("fixed_assets_asset_code_key", ["asset_code"])
    with op.batch_alter_table("withholding_tax_rates") as batch: batch.create_unique_constraint("uq_wht_company_code", ["company_id","code"])
    for table in reversed(TABLES):
        with op.batch_alter_table(table) as batch:
            batch.drop_constraint(f"fk_{table}_branch_id", type_="foreignkey")
            batch.drop_index(f"ix_{table}_branch_id")
            batch.drop_column("branch_id")
