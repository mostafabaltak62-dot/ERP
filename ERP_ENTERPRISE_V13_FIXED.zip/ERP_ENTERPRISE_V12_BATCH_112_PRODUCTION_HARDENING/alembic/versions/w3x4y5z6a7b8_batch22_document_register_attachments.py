"""Batch 22 official form attachments and register integration."""
from alembic import op
import sqlalchemy as sa
revision='w3x4y5z6a7b8'
down_revision='v2w3x4y5z6b8'
branch_labels=None
depends_on=None

def upgrade():
    op.create_table('construction_document_form_attachments',
        sa.Column('id',sa.Integer(),primary_key=True),
        sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id',ondelete='CASCADE'),nullable=False),
        sa.Column('form_id',sa.Integer(),sa.ForeignKey('construction_document_forms.id',ondelete='CASCADE'),nullable=False),
        sa.Column('file_name',sa.String(255),nullable=False),
        sa.Column('stored_path',sa.String(1000),nullable=False),
        sa.Column('mime_type',sa.String(150),nullable=False),
        sa.Column('file_size',sa.Integer(),nullable=False),
        sa.Column('sha256',sa.String(64),nullable=False),
        sa.Column('attachment_type',sa.String(50),nullable=False,server_default='supporting_document'),
        sa.Column('description',sa.Text()),
        sa.Column('uploaded_by_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False),
        sa.Column('uploaded_at',sa.DateTime(),nullable=False),
    )
    op.create_index('ix_construction_document_form_attachment_company','construction_document_form_attachments',['company_id'])
    op.create_index('ix_construction_document_form_attachment_form','construction_document_form_attachments',['form_id'])
    op.create_index('ix_construction_document_form_attachment_sha','construction_document_form_attachments',['sha256'])

def downgrade():
    op.drop_index('ix_construction_document_form_attachment_sha',table_name='construction_document_form_attachments')
    op.drop_index('ix_construction_document_form_attachment_form',table_name='construction_document_form_attachments')
    op.drop_index('ix_construction_document_form_attachment_company',table_name='construction_document_form_attachments')
    op.drop_table('construction_document_form_attachments')
