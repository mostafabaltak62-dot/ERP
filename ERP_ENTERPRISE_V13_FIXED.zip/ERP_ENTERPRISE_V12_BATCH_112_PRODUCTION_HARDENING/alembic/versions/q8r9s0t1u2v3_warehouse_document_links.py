"""Complete warehouse links used by ERP document models."""
from alembic import op
import sqlalchemy as sa

revision = "q8r9s0t1u2v3"
down_revision = "p7q8r9s0t1u2"
branch_labels = None
depends_on = None

TABLES = ("journal_entries", "purchase_orders", "sale_invoices")


def upgrade():
    for table in TABLES:
        with op.batch_alter_table(table, recreate="auto") as batch:
            batch.add_column(sa.Column("warehouse_id", sa.Integer(), nullable=True))
            batch.create_index(f"ix_{table}_warehouse_id", ["warehouse_id"])
            batch.create_foreign_key(
                f"fk_{table}_warehouse_id", "warehouses", ["warehouse_id"], ["id"], ondelete="SET NULL"
            )


def downgrade():
    for table in reversed(TABLES):
        with op.batch_alter_table(table, recreate="auto") as batch:
            batch.drop_constraint(f"fk_{table}_warehouse_id", type="foreignkey")
            batch.drop_index(f"ix_{table}_warehouse_id")
            batch.drop_column("warehouse_id")
