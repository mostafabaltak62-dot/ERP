"""Database-enforced accounting immutability and positive stock quantities."""
from alembic import op
import sqlalchemy as sa

revision = "t1u2v3w4x5y6"
down_revision = "s0t1u2v3w4x5"
branch_labels = None
depends_on = None


def upgrade():
    bind = op.get_bind()
    insp = sa.inspect(bind)
    cols = {c["name"] for c in insp.get_columns("stock_movements")}
    # CHECK is harmless on existing positive data; reject non-positive movement rows.
    if "quantity" in cols:
        if bind.dialect.name == "sqlite":
            with op.batch_alter_table("stock_movements") as batch:
                batch.create_check_constraint("ck_stock_movement_positive_qty", "quantity > 0")
        else:
            op.create_check_constraint("ck_stock_movement_positive_qty", "stock_movements", "quantity > 0")

    if bind.dialect.name == "postgresql":
        op.execute(sa.text("""
        CREATE OR REPLACE FUNCTION prevent_posted_journal_mutation()
        RETURNS trigger AS $$
        BEGIN
          IF TG_OP = 'DELETE' THEN
            IF OLD.status = 'posted' THEN
              RAISE EXCEPTION 'Posted journal entries are immutable; use a reversal entry';
            END IF;
            RETURN OLD;
          END IF;
          IF OLD.status = 'posted' THEN
            RAISE EXCEPTION 'Posted journal entries are immutable; use a reversal entry';
          END IF;
          RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
        """))
        op.execute(sa.text("DROP TRIGGER IF EXISTS trg_journal_entries_immutable ON journal_entries"))
        op.execute(sa.text("""
        CREATE TRIGGER trg_journal_entries_immutable
        BEFORE UPDATE OR DELETE ON journal_entries
        FOR EACH ROW EXECUTE FUNCTION prevent_posted_journal_mutation();
        """))

        op.execute(sa.text("""
        CREATE OR REPLACE FUNCTION prevent_posted_journal_line_mutation()
        RETURNS trigger AS $$
        DECLARE st text;
        BEGIN
          SELECT status INTO st FROM journal_entries WHERE id = COALESCE(OLD.entry_id, NEW.entry_id) FOR UPDATE;
          IF st = 'posted' THEN
            RAISE EXCEPTION 'Lines of posted journal entries are immutable; use a reversal entry';
          END IF;
          IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
          RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
        """))
        op.execute(sa.text("DROP TRIGGER IF EXISTS trg_journal_lines_immutable ON journal_lines"))
        op.execute(sa.text("""
        CREATE TRIGGER trg_journal_lines_immutable
        BEFORE INSERT OR UPDATE OR DELETE ON journal_lines
        FOR EACH ROW EXECUTE FUNCTION prevent_posted_journal_line_mutation();
        """))


def downgrade():
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        op.execute(sa.text("DROP TRIGGER IF EXISTS trg_journal_lines_immutable ON journal_lines"))
        op.execute(sa.text("DROP TRIGGER IF EXISTS trg_journal_entries_immutable ON journal_entries"))
        op.execute(sa.text("DROP FUNCTION IF EXISTS prevent_posted_journal_line_mutation()"))
        op.execute(sa.text("DROP FUNCTION IF EXISTS prevent_posted_journal_mutation()"))
    if bind.dialect.name == "sqlite":
        with op.batch_alter_table("stock_movements") as batch:
            batch.drop_constraint("ck_stock_movement_positive_qty", type_="check")
    else:
        op.drop_constraint("ck_stock_movement_positive_qty", "stock_movements", type_="check")
