"""Patch 73 — Tax administration and historical tax integrity."""
from alembic import op
import sqlalchemy as sa

revision = "p73_tax_governance"
down_revision = "g7h8i9j0k1l2"
branch_labels = None
depends_on = None

def upgrade():
    bind = op.get_bind()
    insp = sa.inspect(bind)
    cols = {c["name"] for c in insp.get_columns("tax_transactions")}
    with op.batch_alter_table("tax_transactions") as b:
        if "branch_id" not in cols:
            b.add_column(sa.Column("branch_id", sa.Integer(), nullable=True))
            b.create_foreign_key("fk_tax_transactions_branch", "branches", ["branch_id"], ["id"], ondelete="SET NULL")
            b.create_index("ix_tax_transactions_branch_id", ["branch_id"])
        if "rate_applied" not in cols:
            b.add_column(sa.Column("rate_applied", sa.Numeric(12,6), nullable=False, server_default="0"))
        if "tax_code_snapshot" not in cols:
            b.add_column(sa.Column("tax_code_snapshot", sa.String(30), nullable=True))
        if "tax_name_snapshot" not in cols:
            b.add_column(sa.Column("tax_name_snapshot", sa.String(100), nullable=True))
        if "tax_account_code_snapshot" not in cols:
            b.add_column(sa.Column("tax_account_code_snapshot", sa.String(30), nullable=True))
        # Backfill immutable reporting values from the current master for legacy rows.
    op.execute(sa.text("""UPDATE tax_transactions SET branch_id=(SELECT j.branch_id FROM journal_entries j WHERE j.id=tax_transactions.journal_entry_id) WHERE branch_id IS NULL AND journal_entry_id IS NOT NULL"""))
    op.execute(sa.text("""UPDATE tax_transactions SET rate_applied=COALESCE((SELECT rate FROM tax_rates r WHERE r.id=tax_transactions.tax_rate_id),0), tax_code_snapshot=(SELECT code FROM tax_rates r WHERE r.id=tax_transactions.tax_rate_id), tax_name_snapshot=(SELECT name FROM tax_rates r WHERE r.id=tax_transactions.tax_rate_id), tax_account_code_snapshot=(SELECT tax_account_code FROM tax_rates r WHERE r.id=tax_transactions.tax_rate_id) WHERE tax_code_snapshot IS NULL"""))
    # SQLite cannot reliably add named CHECK constraints to an existing table; the
    # application validates these invariants and new schemas receive them from metadata.

def downgrade():
    with op.batch_alter_table("tax_transactions") as b:
        for name in ("tax_account_code_snapshot","tax_name_snapshot","tax_code_snapshot","rate_applied","branch_id"):
            try: b.drop_column(name)
            except Exception: pass
