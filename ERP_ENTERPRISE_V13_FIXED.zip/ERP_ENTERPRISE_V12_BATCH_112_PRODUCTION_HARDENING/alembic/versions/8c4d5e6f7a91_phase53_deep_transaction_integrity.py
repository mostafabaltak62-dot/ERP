"""phase 5.3 deep transaction integrity

Revision ID: 8c4d5e6f7a91
Revises: 7f8e9d0a1b22
"""
from alembic import op
import sqlalchemy as sa

revision = "8c4d5e6f7a91"
down_revision = "7f8e9d0a1b22"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table("purchase_receipt_lines",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id"), nullable=False),
        sa.Column("receipt_id", sa.Integer(), sa.ForeignKey("purchase_receipts.id", ondelete="CASCADE"), nullable=False),
        sa.Column("po_line_id", sa.Integer(), sa.ForeignKey("purchase_order_lines.id"), nullable=False),
        sa.Column("item_id", sa.Integer(), sa.ForeignKey("items.id"), nullable=False),
        sa.Column("quantity", sa.Numeric(20,6), nullable=False),
        sa.Column("unit_cost", sa.Numeric(20,6), nullable=False),
        sa.UniqueConstraint("company_id","receipt_id","po_line_id",name="uq_receipt_line"))
    op.create_index("ix_receipt_lines_company", "purchase_receipt_lines", ["company_id","receipt_id"])
    op.create_table("purchase_match_lines",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id"), nullable=False),
        sa.Column("purchase_invoice_id", sa.Integer(), sa.ForeignKey("purchase_invoices.id", ondelete="CASCADE"), nullable=False),
        sa.Column("purchase_invoice_line_id", sa.Integer(), sa.ForeignKey("purchase_invoice_lines.id"), nullable=False),
        sa.Column("po_line_id", sa.Integer(), sa.ForeignKey("purchase_order_lines.id"), nullable=False),
        sa.Column("receipt_line_id", sa.Integer(), sa.ForeignKey("purchase_receipt_lines.id"), nullable=False),
        sa.Column("matched_quantity", sa.Numeric(20,6), nullable=False),
        sa.Column("matched_amount", sa.Numeric(20,6), nullable=False),
        sa.Column("status", sa.String(20), nullable=False, server_default="matched"),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("company_id","purchase_invoice_line_id","receipt_line_id",name="uq_purchase_match_line"))
    op.create_index("ix_purchase_match_company_invoice", "purchase_match_lines", ["company_id","purchase_invoice_id"])
    for table, number_constraint in (("sales_returns","uq_sales_return_number"),("purchase_returns","uq_purchase_return_number")):
        op.create_table(table,
            sa.Column("id",sa.Integer(),primary_key=True), sa.Column("company_id",sa.Integer(),sa.ForeignKey("companies.id"),nullable=False),
            sa.Column("return_number",sa.String(40),nullable=False),
            sa.Column("sale_invoice_id" if table=="sales_returns" else "purchase_invoice_id",sa.Integer(),sa.ForeignKey("sale_invoices.id" if table=="sales_returns" else "purchase_invoices.id"),nullable=False),
            sa.Column("customer_id" if table=="sales_returns" else "supplier_id",sa.Integer(),sa.ForeignKey("customers.id" if table=="sales_returns" else "suppliers.id"),nullable=False),
            sa.Column("return_date",sa.DateTime(),nullable=False), sa.Column("status",sa.String(20),nullable=False,server_default="posted"),
            sa.Column("subtotal",sa.Numeric(20,6),nullable=False,server_default="0"), sa.Column("tax_amount",sa.Numeric(20,6),nullable=False,server_default="0"),
            sa.Column("total_amount",sa.Numeric(20,6),nullable=False,server_default="0"),
            *([sa.Column("cogs_reversal",sa.Numeric(20,6),nullable=False,server_default="0")] if table=="sales_returns" else []),
            sa.Column("created_by_id",sa.Integer(),sa.ForeignKey("users.id")),
            sa.UniqueConstraint("company_id","return_number",name=number_constraint))
        op.create_index(f"ix_{table}_company",table,["company_id","return_number"])
    op.create_table("sales_return_lines",
        sa.Column("id",sa.Integer(),primary_key=True),sa.Column("company_id",sa.Integer(),sa.ForeignKey("companies.id"),nullable=False),
        sa.Column("return_id",sa.Integer(),sa.ForeignKey("sales_returns.id",ondelete="CASCADE"),nullable=False),sa.Column("invoice_line_id",sa.Integer(),sa.ForeignKey("sale_invoice_lines.id"),nullable=False),
        sa.Column("item_id",sa.Integer(),sa.ForeignKey("items.id"),nullable=False),sa.Column("quantity",sa.Numeric(20,6),nullable=False),sa.Column("unit_price",sa.Numeric(20,6),nullable=False),sa.Column("unit_cost",sa.Numeric(20,6),nullable=False,server_default="0"),sa.Column("line_total",sa.Numeric(20,6),nullable=False),sa.Column("cost_total",sa.Numeric(20,6),nullable=False,server_default="0"))
    op.create_index("ix_sales_return_lines_company","sales_return_lines",["company_id","return_id"])
    op.create_table("purchase_return_lines",
        sa.Column("id",sa.Integer(),primary_key=True),sa.Column("company_id",sa.Integer(),sa.ForeignKey("companies.id"),nullable=False),
        sa.Column("return_id",sa.Integer(),sa.ForeignKey("purchase_returns.id",ondelete="CASCADE"),nullable=False),sa.Column("invoice_line_id",sa.Integer(),sa.ForeignKey("purchase_invoice_lines.id"),nullable=False),
        sa.Column("item_id",sa.Integer(),sa.ForeignKey("items.id"),nullable=False),sa.Column("quantity",sa.Numeric(20,6),nullable=False),sa.Column("unit_price",sa.Numeric(20,6),nullable=False),sa.Column("line_total",sa.Numeric(20,6),nullable=False))
    op.create_index("ix_purchase_return_lines_company","purchase_return_lines",["company_id","return_id"])
    op.create_table("subledger_reconciliations",
        sa.Column("id",sa.Integer(),primary_key=True),sa.Column("company_id",sa.Integer(),sa.ForeignKey("companies.id"),nullable=False),sa.Column("as_of_date",sa.DateTime(),nullable=False),
        sa.Column("subledger_type",sa.String(20),nullable=False),sa.Column("subledger_total",sa.Numeric(20,6),nullable=False),sa.Column("gl_total",sa.Numeric(20,6),nullable=False),sa.Column("difference",sa.Numeric(20,6),nullable=False),sa.Column("status",sa.String(20),nullable=False),sa.Column("created_by_id",sa.Integer(),sa.ForeignKey("users.id")),sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_reconciliation_company_date","subledger_reconciliations",["company_id","subledger_type","as_of_date"])

    # New tenant-aware tables are protected by PostgreSQL native RLS as well.
    if op.get_bind().dialect.name == "postgresql":
        for table in ("purchase_receipt_lines", "purchase_match_lines", "sales_returns", "sales_return_lines", "purchase_returns", "purchase_return_lines", "subledger_reconciliations"):
            op.execute(sa.text(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY"))
            op.execute(sa.text(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY"))
            op.execute(sa.text(f"DROP POLICY IF EXISTS {table}_tenant_isolation ON {table}"))
            op.execute(sa.text(f"CREATE POLICY {table}_tenant_isolation ON {table} USING (company_id = NULLIF(current_setting('app.company_id', true), '')::integer) WITH CHECK (company_id = NULLIF(current_setting('app.company_id', true), '')::integer)"))


def downgrade():
    for t in ("subledger_reconciliations","purchase_return_lines","sales_return_lines","purchase_returns","sales_returns","purchase_match_lines","purchase_receipt_lines"):
        op.drop_table(t)
