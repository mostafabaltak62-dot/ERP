"""Batch 27 enterprise item master
Revision ID: z6a7b8c9d0e1
Revises: y5z6a7b8c9d0
"""
from alembic import op
import sqlalchemy as sa
revision='z6a7b8c9d0e1'; down_revision='y5z6a7b8c9d0'; branch_labels=None; depends_on=None
cols=[
sa.Column('name_en',sa.String(150)),sa.Column('short_name',sa.String(80)),sa.Column('description',sa.Text()),sa.Column('item_group',sa.String(80)),sa.Column('brand',sa.String(80)),sa.Column('manufacturer',sa.String(120)),sa.Column('model',sa.String(80)),sa.Column('country_of_origin',sa.String(80)),sa.Column('purchase_unit',sa.String(30)),sa.Column('issue_unit',sa.String(30)),sa.Column('conversion_factor',sa.Numeric(20,6),server_default='1',nullable=False),sa.Column('max_stock',sa.Numeric(20,6),server_default='0',nullable=False),sa.Column('reorder_level',sa.Numeric(20,6),server_default='0',nullable=False),sa.Column('safety_stock',sa.Numeric(20,6),server_default='0',nullable=False),sa.Column('lead_time_days',sa.Integer(),server_default='0',nullable=False),sa.Column('allow_negative_stock',sa.Boolean(),server_default=sa.false(),nullable=False),sa.Column('inspection_required',sa.Boolean(),server_default=sa.false(),nullable=False),sa.Column('mir_required',sa.Boolean(),server_default=sa.false(),nullable=False),sa.Column('certificate_required',sa.Boolean(),server_default=sa.false(),nullable=False),sa.Column('standard_cost',sa.Numeric(20,6),server_default='0',nullable=False),sa.Column('lifecycle_status',sa.String(30),server_default='active',nullable=False)]
def upgrade():
    for c in cols: op.add_column('items',c)
def downgrade():
    for c in reversed(cols): op.drop_column('items',c.name)
