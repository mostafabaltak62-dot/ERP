"""Add site material receiving consumption waste and returns ledger."""
from alembic import op
import sqlalchemy as sa
revision = "o6p7q8r9s0t1"
down_revision = "n5o6p7q8r9s0"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table("site_material_receipts",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id", ondelete="CASCADE"), nullable=False),
        sa.Column("project_id", sa.Integer(), sa.ForeignKey("projects.id", ondelete="CASCADE"), nullable=False),
        sa.Column("site_id", sa.Integer(), sa.ForeignKey("construction_sites.id", ondelete="SET NULL")),
        sa.Column("issue_id", sa.Integer(), sa.ForeignKey("site_material_issues.id", ondelete="SET NULL")),
        sa.Column("item_id", sa.Integer(), sa.ForeignKey("items.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("quantity", sa.Numeric(20,6), nullable=False), sa.Column("unit_cost", sa.Numeric(20,6), nullable=False, server_default="0"), sa.Column("total_cost", sa.Numeric(20,6), nullable=False, server_default="0"),
        sa.Column("receipt_date", sa.Date(), nullable=False), sa.Column("received_by_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="SET NULL")), sa.Column("reference", sa.String(100)), sa.Column("status", sa.String(30), nullable=False, server_default="posted"), sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.CheckConstraint("quantity > 0", name="ck_site_receipt_qty_positive"), sa.CheckConstraint("unit_cost >= 0", name="ck_site_receipt_cost_nonnegative"))
    op.create_index("ix_site_material_receipts_company_id", "site_material_receipts", ["company_id"]); op.create_index("ix_site_material_receipts_project_id", "site_material_receipts", ["project_id"]); op.create_index("ix_site_material_receipts_item_id", "site_material_receipts", ["item_id"])
    op.create_table("site_material_consumptions",
        sa.Column("id", sa.Integer(), primary_key=True), sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id", ondelete="CASCADE"), nullable=False), sa.Column("project_id", sa.Integer(), sa.ForeignKey("projects.id", ondelete="CASCADE"), nullable=False), sa.Column("site_id", sa.Integer(), sa.ForeignKey("construction_sites.id", ondelete="SET NULL")), sa.Column("item_id", sa.Integer(), sa.ForeignKey("items.id", ondelete="RESTRICT"), nullable=False), sa.Column("receipt_id", sa.Integer(), sa.ForeignKey("site_material_receipts.id", ondelete="SET NULL")), sa.Column("quantity", sa.Numeric(20,6), nullable=False), sa.Column("unit_cost", sa.Numeric(20,6), nullable=False, server_default="0"), sa.Column("total_cost", sa.Numeric(20,6), nullable=False, server_default="0"), sa.Column("consumption_date", sa.Date(), nullable=False), sa.Column("consumed_by_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="SET NULL")), sa.Column("cost_code_id", sa.Integer(), sa.ForeignKey("construction_cost_codes.id", ondelete="SET NULL")), sa.Column("boq_line_id", sa.Integer(), sa.ForeignKey("construction_boq_lines.id", ondelete="SET NULL")), sa.Column("reference", sa.String(100)), sa.Column("status", sa.String(30), nullable=False, server_default="posted"), sa.CheckConstraint("quantity > 0", name="ck_site_consumption_qty_positive"), sa.CheckConstraint("unit_cost >= 0", name="ck_site_consumption_cost_nonnegative"))
    op.create_index("ix_site_material_consumptions_company_id", "site_material_consumptions", ["company_id"]); op.create_index("ix_site_material_consumptions_project_id", "site_material_consumptions", ["project_id"]); op.create_index("ix_site_material_consumptions_item_id", "site_material_consumptions", ["item_id"])
    op.create_table("site_material_adjustments",
        sa.Column("id", sa.Integer(), primary_key=True), sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id", ondelete="CASCADE"), nullable=False), sa.Column("project_id", sa.Integer(), sa.ForeignKey("projects.id", ondelete="CASCADE"), nullable=False), sa.Column("site_id", sa.Integer(), sa.ForeignKey("construction_sites.id", ondelete="SET NULL")), sa.Column("item_id", sa.Integer(), sa.ForeignKey("items.id", ondelete="RESTRICT"), nullable=False), sa.Column("warehouse_id", sa.Integer(), sa.ForeignKey("warehouses.id", ondelete="SET NULL")), sa.Column("adjustment_type", sa.String(20), nullable=False), sa.Column("quantity", sa.Numeric(20,6), nullable=False), sa.Column("unit_cost", sa.Numeric(20,6), nullable=False, server_default="0"), sa.Column("total_cost", sa.Numeric(20,6), nullable=False, server_default="0"), sa.Column("adjustment_date", sa.Date(), nullable=False), sa.Column("reason", sa.String(255), nullable=False), sa.Column("created_by_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="SET NULL")), sa.Column("reference", sa.String(100)), sa.Column("status", sa.String(30), nullable=False, server_default="posted"), sa.CheckConstraint("quantity > 0", name="ck_site_adjustment_qty_positive"), sa.CheckConstraint("adjustment_type in ('waste','return')", name="ck_site_adjustment_type"))
    op.create_index("ix_site_material_adjustments_company_id", "site_material_adjustments", ["company_id"]); op.create_index("ix_site_material_adjustments_project_id", "site_material_adjustments", ["project_id"]); op.create_index("ix_site_material_adjustments_item_id", "site_material_adjustments", ["item_id"])

def downgrade():
    op.drop_table("site_material_adjustments"); op.drop_table("site_material_consumptions"); op.drop_table("site_material_receipts")
