"""Patch 49: enterprise planning and scheduling engine."""
from alembic import op
import sqlalchemy as sa
revision='p48_planning_sched_engine'; down_revision='p47_adv_fin_branch'; branch_labels=None; depends_on=None

def upgrade():
    op.create_table('construction_schedule_calendars',
      sa.Column('id',sa.Integer(),primary_key=True), sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False), sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),
      sa.Column('name',sa.String(120),nullable=False), sa.Column('workdays_mask',sa.String(7),nullable=False,server_default='1111100'), sa.Column('holidays',sa.Text()), sa.Column('is_default',sa.Boolean(),nullable=False,server_default=sa.false()), sa.UniqueConstraint('project_id','name',name='uq_schedule_calendar_project_name'))
    op.create_index('ix_construction_schedule_calendars_company_id','construction_schedule_calendars',['company_id']); op.create_index('ix_construction_schedule_calendars_project_id','construction_schedule_calendars',['project_id'])
    op.create_table('construction_activity_dependencies',
      sa.Column('id',sa.Integer(),primary_key=True), sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False), sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),
      sa.Column('predecessor_id',sa.Integer(),sa.ForeignKey('construction_activities.id'),nullable=False), sa.Column('successor_id',sa.Integer(),sa.ForeignKey('construction_activities.id'),nullable=False), sa.Column('dependency_type',sa.String(2),nullable=False,server_default='FS'), sa.Column('lag_days',sa.Integer(),nullable=False,server_default='0'),
      sa.UniqueConstraint('project_id','predecessor_id','successor_id',name='uq_activity_dependency'), sa.CheckConstraint("dependency_type IN ('FS','SS','FF','SF')",name='ck_dependency_type'), sa.CheckConstraint('predecessor_id <> successor_id',name='ck_dependency_not_self'))
    for n,c in [('company_id','company_id'),('project_id','project_id'),('predecessor_id','predecessor_id'),('successor_id','successor_id')]: op.create_index(f'ix_construction_activity_dependencies_{n}', 'construction_activity_dependencies',[c])
    with op.batch_alter_table('construction_activities') as b:
        b.add_column(sa.Column('actual_start',sa.Date(),nullable=True)); b.add_column(sa.Column('actual_finish',sa.Date(),nullable=True)); b.add_column(sa.Column('calendar_id',sa.Integer(),nullable=True)); b.create_index('ix_construction_activities_calendar_id',['calendar_id']); b.create_foreign_key('fk_construction_activities_calendar_id','construction_schedule_calendars',['calendar_id'],['id'],ondelete='SET NULL')

def downgrade():
    with op.batch_alter_table('construction_activities') as b:
        b.drop_constraint('fk_construction_activities_calendar_id',type_='foreignkey'); b.drop_index('ix_construction_activities_calendar_id'); b.drop_column('calendar_id'); b.drop_column('actual_finish'); b.drop_column('actual_start')
    op.drop_table('construction_activity_dependencies'); op.drop_table('construction_schedule_calendars')
