"""Patch 64 — inventory & item master governance hardening."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import inspect

revision = 'p64_inventory_items_governance'
down_revision = 'p63_accounting_period_governance'
branch_labels = None
depends_on = None


def upgrade():
    # Batch mode keeps the migration safe for SQLite while remaining valid on PostgreSQL.
    bind = op.get_bind()
    inspector = inspect(bind)
    unique_indexes = {x['name'] for x in inspector.get_indexes('items') if x.get('unique')}
    unique_constraints = {x.get('name') for x in inspector.get_unique_constraints('items') if x.get('name')}
    with op.batch_alter_table('items', recreate='auto') as batch:
        if 'items_code_key' in unique_constraints:
            batch.drop_constraint('items_code_key', type_='unique')
        elif 'ix_items_code' in unique_indexes:
            batch.drop_index('ix_items_code')
        batch.create_unique_constraint('uq_item_company_code', ['company_id', 'code'])
        batch.create_unique_constraint('uq_item_company_barcode', ['company_id', 'barcode'])
        batch.create_check_constraint('ck_item_purchase_price_nonnegative', 'purchase_price >= 0')
        batch.create_check_constraint('ck_item_sale_price_nonnegative', 'sale_price >= 0')
        batch.create_check_constraint('ck_item_standard_cost_nonnegative', 'standard_cost >= 0')
        batch.create_check_constraint('ck_item_min_stock_nonnegative', 'min_stock >= 0')
        batch.create_check_constraint('ck_item_max_stock_nonnegative', 'max_stock >= 0')
        batch.create_check_constraint('ck_item_reorder_level_nonnegative', 'reorder_level >= 0')
        batch.create_check_constraint('ck_item_safety_stock_nonnegative', 'safety_stock >= 0')
        batch.create_check_constraint('ck_item_reorder_qty_nonnegative', 'reorder_qty >= 0')
        batch.create_check_constraint('ck_item_conversion_factor_positive', 'conversion_factor > 0')
        batch.create_check_constraint('ck_item_tax_rate_range', 'tax_rate >= 0 AND tax_rate <= 100')
        batch.create_index('ix_items_company_name', ['company_id', 'name'])
        batch.create_index('ix_items_company_category', ['company_id', 'category'])


def downgrade():
    with op.batch_alter_table('items', recreate='auto') as batch:
        batch.drop_index('ix_items_company_category')
        batch.drop_index('ix_items_company_name')
        for name in [
            'ck_item_tax_rate_range','ck_item_conversion_factor_positive','ck_item_reorder_qty_nonnegative',
            'ck_item_safety_stock_nonnegative','ck_item_reorder_level_nonnegative','ck_item_max_stock_nonnegative',
            'ck_item_min_stock_nonnegative','ck_item_standard_cost_nonnegative','ck_item_sale_price_nonnegative',
            'ck_item_purchase_price_nonnegative']:
            batch.drop_constraint(name, type_='check')
        batch.drop_constraint('uq_item_company_barcode', type_='unique')
        batch.drop_constraint('uq_item_company_code', type_='unique')
        batch.create_unique_constraint('items_code_key', ['code'])
