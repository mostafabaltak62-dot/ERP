"""scope workflow instance identity to company tenant

Revision ID: s0t1u2v3w4x5
Revises: r9s0t1u2v3w4
"""
from alembic import op

revision = "s0t1u2v3w4x5"
down_revision = "r9s0t1u2v3w4"
branch_labels = None
depends_on = None


def upgrade():
    # A workflow document identifier is only unique inside its tenant.
    # The previous global constraint caused valid documents in two companies
    # to collide even though workflow instances carry company_id.
    with op.batch_alter_table("workflow_instances") as batch:
        batch.drop_constraint("uq_workflow_document", type_="unique")
        batch.create_unique_constraint(
            "uq_workflow_company_document",
            ["company_id", "document_type", "document_id"],
        )


def downgrade():
    with op.batch_alter_table("workflow_instances") as batch:
        batch.drop_constraint("uq_workflow_company_document", type_="unique")
        batch.create_unique_constraint("uq_workflow_document", ["document_type", "document_id"])
