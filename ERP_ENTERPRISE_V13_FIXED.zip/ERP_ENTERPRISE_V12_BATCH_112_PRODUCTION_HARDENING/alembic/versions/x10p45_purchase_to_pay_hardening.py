"""Patch 45 — Purchase-to-Pay hardening: multiple GRNs and cumulative matching."""
from alembic import op
import sqlalchemy as sa

revision = "x10p45_p2p_hardening"
down_revision = "w11x22y33z44"
branch_labels = None
depends_on = None

def upgrade():
    bind=op.get_bind(); dialect=bind.dialect.name
    # Add a durable GRN number first.
    with op.batch_alter_table("purchase_receipts") as batch:
        batch.add_column(sa.Column("receipt_number", sa.String(40), nullable=True))
    bind.execute(sa.text("UPDATE purchase_receipts SET receipt_number = 'GRN-' || id WHERE receipt_number IS NULL"))
    with op.batch_alter_table("purchase_receipts") as batch:
        batch.alter_column("receipt_number", existing_type=sa.String(40), nullable=False)
        batch.create_unique_constraint("uq_purchase_receipts_receipt_number", ["receipt_number"])
        batch.create_index("ix_purchase_receipts_company_po", ["company_id","po_id"], unique=False)
    # Remove legacy unique(po_id), which blocked multiple GRNs. SQLite requires table recreation.
    if dialect == "sqlite":
        cols=bind.execute(sa.text("PRAGMA table_info(purchase_receipts)")).fetchall()
        fk=bind.execute(sa.text("PRAGMA foreign_key_list(purchase_receipts)")).fetchall()
        # Alembic batch recreation with an explicit copy table is safest for the unnamed legacy unique.
        op.create_table("_purchase_receipts_p45",
            sa.Column("id",sa.Integer(),primary_key=True), sa.Column("company_id",sa.Integer(),nullable=True),
            sa.Column("receipt_number",sa.String(40),nullable=False), sa.Column("po_id",sa.Integer(),nullable=False),
            sa.Column("receipt_date",sa.DateTime(),nullable=True), sa.Column("warehouse_id",sa.Integer(),nullable=True),
            sa.Column("created_by_id",sa.Integer(),nullable=True),
            sa.ForeignKeyConstraint(["po_id"],["purchase_orders.id"]), sa.ForeignKeyConstraint(["company_id"],["companies.id"]),
            sa.ForeignKeyConstraint(["warehouse_id"],["warehouses.id"]), sa.ForeignKeyConstraint(["created_by_id"],["users.id"]))
        bind.execute(sa.text("INSERT INTO _purchase_receipts_p45 (id,company_id,receipt_number,po_id,receipt_date,warehouse_id,created_by_id) SELECT id,company_id,receipt_number,po_id,receipt_date,warehouse_id,created_by_id FROM purchase_receipts"))
        op.drop_table("purchase_receipts")
        op.rename_table("_purchase_receipts_p45","purchase_receipts")
        op.create_index("ix_purchase_receipts_id","purchase_receipts",["id"],unique=False)
        op.create_index("ix_purchase_receipts_company_id","purchase_receipts",["company_id"],unique=False)
        op.create_index("ix_purchase_receipts_receipt_number","purchase_receipts",["receipt_number"],unique=True)
        op.create_index("ix_purchase_receipts_po_id","purchase_receipts",["po_id"],unique=False)
        op.create_index("ix_purchase_receipts_warehouse_id","purchase_receipts",["warehouse_id"],unique=False)
        op.create_index("ix_purchase_receipts_company_po","purchase_receipts",["company_id","po_id"],unique=False)
    else:
        # PostgreSQL/other named-constraint environments: find and drop the unique constraint on po_id.
        if dialect == "postgresql":
            row=bind.execute(sa.text("SELECT conname FROM pg_constraint c JOIN pg_class t ON t.oid=c.conrelid WHERE t.relname='purchase_receipts' AND c.contype='u' AND pg_get_constraintdef(c.oid) LIKE '%(po_id)%'" )).first()
            if row: bind.execute(sa.text(f'ALTER TABLE purchase_receipts DROP CONSTRAINT "{row[0]}"'))
    with op.batch_alter_table("purchase_match_lines") as batch:
        batch.create_index("ix_purchase_match_company_po_line",["company_id","po_line_id"],unique=False)
        batch.create_index("ix_purchase_match_company_receipt_line",["company_id","receipt_line_id"],unique=False)
    with op.batch_alter_table("purchase_invoice_lines") as batch:
        batch.create_index("ix_purchase_invoice_lines_company_po_line",["company_id","po_line_id"],unique=False)

def downgrade():
    raise RuntimeError("Patch 45 downgrade is intentionally blocked because reverting to single-GRN semantics can destroy valid partial-receipt history.")
