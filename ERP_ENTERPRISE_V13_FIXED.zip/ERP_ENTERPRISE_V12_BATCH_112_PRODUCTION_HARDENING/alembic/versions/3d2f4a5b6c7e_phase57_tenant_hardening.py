"""Phase 5.7 tenant hardening for merged governance fixes.

Adds company scope to asset depreciation runs and applies native PostgreSQL
RLS to the two new governance tables introduced by the merge.
"""
from alembic import op
import sqlalchemy as sa

revision = "3d2f4a5b6c7e"
down_revision = "2e9accc33d79"
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table("asset_depreciation_runs") as batch:
        batch.add_column(sa.Column("company_id", sa.Integer(), nullable=True))
        batch.create_index("ix_asset_depreciation_runs_company_id", ["company_id"], unique=False)
        batch.create_foreign_key("fk_asset_depreciation_runs_company", "companies", ["company_id"], ["id"])
    # Backfill from the authoritative fixed asset tenant.
    bind = op.get_bind()
    bind.execute(sa.text("UPDATE asset_depreciation_runs SET company_id = (SELECT company_id FROM fixed_assets WHERE fixed_assets.id = asset_depreciation_runs.asset_id) WHERE company_id IS NULL"))
    with op.batch_alter_table("asset_depreciation_runs") as batch:
        batch.alter_column("company_id", nullable=False)

    if bind.dialect.name == "postgresql":
        for table in ("asset_depreciation_runs", "recurring_journal_templates"):
            quoted = '"' + table + '"'
            policy = f"tenant_isolation_{table}"
            expr = "company_id = NULLIF(current_setting('app.company_id', true), '')::integer"
            op.execute(f"ALTER TABLE {quoted} ENABLE ROW LEVEL SECURITY")
            op.execute(f"ALTER TABLE {quoted} FORCE ROW LEVEL SECURITY")
            op.execute(f"DROP POLICY IF EXISTS {policy} ON {quoted}")
            op.execute(f"CREATE POLICY {policy} ON {quoted} USING ({expr}) WITH CHECK ({expr})")


def downgrade():
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        for table in ("asset_depreciation_runs", "recurring_journal_templates"):
            quoted = '"' + table + '"'
            policy = f"tenant_isolation_{table}"
            op.execute(f"DROP POLICY IF EXISTS {policy} ON {quoted}")
            op.execute(f"ALTER TABLE {quoted} NO FORCE ROW LEVEL SECURITY")
            op.execute(f"ALTER TABLE {quoted} DISABLE ROW LEVEL SECURITY")
    with op.batch_alter_table("asset_depreciation_runs") as batch:
        batch.drop_constraint("fk_asset_depreciation_runs_company", type_="foreignkey")
        batch.drop_index("ix_asset_depreciation_runs_company_id")
        batch.drop_column("company_id")
