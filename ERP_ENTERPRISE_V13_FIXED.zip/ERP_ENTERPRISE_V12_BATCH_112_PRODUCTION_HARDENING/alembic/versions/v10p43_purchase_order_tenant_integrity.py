"""Patch 43 — Purchase Order tenant and input integrity hardening."""
from alembic import op
import sqlalchemy as sa

revision = "v10p43po_tenant"
down_revision = "u1v2w3x4y5z6"
branch_labels = None
depends_on = None


def upgrade():
    bind = op.get_bind()
    # Backfill legacy PO lines from their parent order before enforcing NOT NULL.
    bind.execute(sa.text("""
        UPDATE purchase_order_lines
        SET company_id = (SELECT company_id FROM purchase_orders po WHERE po.id = purchase_order_lines.po_id)
        WHERE company_id IS NULL
    """))
    # Fail closed if historical corruption prevents safe enforcement.
    remaining = bind.execute(sa.text("SELECT COUNT(*) FROM purchase_order_lines WHERE company_id IS NULL")).scalar()
    if remaining:
        raise RuntimeError(f"Cannot enforce purchase_order_lines.company_id NOT NULL; {remaining} rows remain unmapped")
    with op.batch_alter_table("purchase_order_lines") as batch:
        batch.alter_column("company_id", existing_type=sa.Integer(), nullable=False)


def downgrade():
    with op.batch_alter_table("purchase_order_lines") as batch:
        batch.alter_column("company_id", existing_type=sa.Integer(), nullable=True)
