"""phase63 construction cost control and subcontractor management
Revision ID: 9c0d1e2f3a45
Revises: 8b9c0d1e2f34
"""
from alembic import op
import sqlalchemy as sa
revision='9c0d1e2f3a45'; down_revision='8b9c0d1e2f34'; branch_labels=None; depends_on=None

def upgrade():
    op.create_table('construction_cost_budget_lines',
        sa.Column('id',sa.Integer(),primary_key=True),
        sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),
        sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),
        sa.Column('cost_code_id',sa.Integer(),sa.ForeignKey('construction_cost_codes.id')),
        sa.Column('wbs_id',sa.Integer(),sa.ForeignKey('construction_wbs_nodes.id')),
        sa.Column('boq_line_id',sa.Integer(),sa.ForeignKey('construction_boq_lines.id')),
        sa.Column('description',sa.String(255),nullable=False),
        sa.Column('budget_amount',sa.Numeric(20,6),nullable=False,server_default='0'),
        sa.Column('budget_date',sa.Date()),
        sa.Column('status',sa.String(30),nullable=False,server_default='active'),
        sa.CheckConstraint('budget_amount >= 0',name='ck_cost_budget_nonnegative'))
    op.create_index('ix_construction_cost_budget_lines_company_id','construction_cost_budget_lines',['company_id'])
    op.create_index('ix_construction_cost_budget_lines_project_id','construction_cost_budget_lines',['project_id'])

    op.create_table('construction_commitments',
        sa.Column('id',sa.Integer(),primary_key=True),
        sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),
        sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),
        sa.Column('contract_id',sa.Integer(),sa.ForeignKey('contracts.id')),
        sa.Column('cost_code_id',sa.Integer(),sa.ForeignKey('construction_cost_codes.id')),
        sa.Column('wbs_id',sa.Integer(),sa.ForeignKey('construction_wbs_nodes.id')),
        sa.Column('subcontractor_boq_line_id',sa.Integer(),sa.ForeignKey('subcontractor_boq_lines.id')),
        sa.Column('source_type',sa.String(50),nullable=False),
        sa.Column('source_id',sa.Integer()),
        sa.Column('commitment_date',sa.Date(),nullable=False),
        sa.Column('description',sa.String(255),nullable=False),
        sa.Column('committed_amount',sa.Numeric(20,6),nullable=False),
        sa.Column('released_amount',sa.Numeric(20,6),nullable=False,server_default='0'),
        sa.Column('status',sa.String(30),nullable=False,server_default='open'),
        sa.CheckConstraint('committed_amount >= 0',name='ck_commitment_nonnegative'),
        sa.CheckConstraint('released_amount >= 0 AND released_amount <= committed_amount',name='ck_commitment_release_bounds'))
    op.create_index('ix_construction_commitments_company_id','construction_commitments',['company_id'])
    op.create_index('ix_construction_commitments_project_id','construction_commitments',['project_id'])

    op.create_table('subcontractor_measurements',
        sa.Column('id',sa.Integer(),primary_key=True),
        sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),
        sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),
        sa.Column('contract_id',sa.Integer(),sa.ForeignKey('contracts.id'),nullable=False),
        sa.Column('measurement_no',sa.String(60),nullable=False),
        sa.Column('measurement_date',sa.Date(),nullable=False),
        sa.Column('status',sa.String(30),nullable=False,server_default='draft'),
        sa.Column('notes',sa.Text()),
        sa.Column('created_by_id',sa.Integer(),sa.ForeignKey('users.id')),
        sa.UniqueConstraint('company_id','measurement_no',name='uq_sub_measurement_company_no'))
    op.create_index('ix_subcontractor_measurements_company_id','subcontractor_measurements',['company_id'])
    op.create_index('ix_subcontractor_measurements_project_id','subcontractor_measurements',['project_id'])

    op.create_table('subcontractor_measurement_lines',
        sa.Column('id',sa.Integer(),primary_key=True),
        sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),
        sa.Column('measurement_id',sa.Integer(),sa.ForeignKey('subcontractor_measurements.id'),nullable=False),
        sa.Column('subcontractor_boq_line_id',sa.Integer(),sa.ForeignKey('subcontractor_boq_lines.id'),nullable=False),
        sa.Column('current_qty',sa.Numeric(20,6),nullable=False),
        sa.Column('cumulative_qty',sa.Numeric(20,6),nullable=False),
        sa.Column('amount',sa.Numeric(20,6),nullable=False),
        sa.CheckConstraint('current_qty >= 0',name='ck_sub_measure_current_nonnegative'),
        sa.CheckConstraint('cumulative_qty >= 0',name='ck_sub_measure_cumulative_nonnegative'))
    op.create_index('ix_subcontractor_measurement_lines_company_id','subcontractor_measurement_lines',['company_id'])
    op.create_index('ix_subcontractor_measurement_lines_measurement_id','subcontractor_measurement_lines',['measurement_id'])

    op.create_table('subcontractor_progress_lines',
        sa.Column('id',sa.Integer(),primary_key=True),
        sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),
        sa.Column('progress_id',sa.Integer(),sa.ForeignKey('subcontractor_progress.id'),nullable=False),
        sa.Column('subcontractor_boq_line_id',sa.Integer(),sa.ForeignKey('subcontractor_boq_lines.id'),nullable=False),
        sa.Column('current_qty',sa.Numeric(20,6),nullable=False),
        sa.Column('cumulative_qty',sa.Numeric(20,6),nullable=False),
        sa.Column('gross_amount',sa.Numeric(20,6),nullable=False))
    op.create_index('ix_subcontractor_progress_lines_company_id','subcontractor_progress_lines',['company_id'])
    op.create_index('ix_subcontractor_progress_lines_progress_id','subcontractor_progress_lines',['progress_id'])

    op.create_table('construction_cost_forecasts',
        sa.Column('id',sa.Integer(),primary_key=True),
        sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),
        sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),
        sa.Column('cost_code_id',sa.Integer(),sa.ForeignKey('construction_cost_codes.id')),
        sa.Column('wbs_id',sa.Integer(),sa.ForeignKey('construction_wbs_nodes.id')),
        sa.Column('forecast_date',sa.Date(),nullable=False),
        sa.Column('description',sa.String(255),nullable=False),
        sa.Column('etc_amount',sa.Numeric(20,6),nullable=False),
        sa.Column('status',sa.String(30),nullable=False,server_default='active'),
        sa.Column('created_by_id',sa.Integer(),sa.ForeignKey('users.id')),
        sa.CheckConstraint('etc_amount >= 0',name='ck_forecast_etc_nonnegative'))
    op.create_index('ix_construction_cost_forecasts_company_id','construction_cost_forecasts',['company_id'])
    op.create_index('ix_construction_cost_forecasts_project_id','construction_cost_forecasts',['project_id'])

    with op.batch_alter_table('subcontractor_progress', schema=None) as b:
        b.add_column(sa.Column('measurement_id',sa.Integer(),nullable=True))
        b.create_foreign_key('fk_sub_progress_measurement','subcontractor_measurements',['measurement_id'],['id'])
        b.create_index('ix_sub_progress_measurement_id',['measurement_id'])

def downgrade():
    with op.batch_alter_table('subcontractor_progress', schema=None) as b:
        b.drop_index('ix_sub_progress_measurement_id')
        b.drop_constraint('fk_sub_progress_measurement',type_='foreignkey')
        b.drop_column('measurement_id')
    for t in ['construction_cost_forecasts','subcontractor_progress_lines','subcontractor_measurement_lines','subcontractor_measurements','construction_commitments','construction_cost_budget_lines']:
        op.drop_table(t)
