"""Batch 39 — Purchase Returns Control Center
Revision ID: a7b8c9d0e139
Revises: z6a7b8c9d0e1
"""
from alembic import op
import sqlalchemy as sa

revision = 'a7b8c9d0e139'
down_revision = 'z6a7b8c9d0e1'
branch_labels = None
depends_on = None

def upgrade():
    with op.batch_alter_table('purchase_returns', recreate='auto') as batch:
        batch.add_column(sa.Column('warehouse_id', sa.Integer(), nullable=True))
        batch.create_foreign_key('fk_purchase_returns_warehouse', 'warehouses', ['warehouse_id'], ['id'], ondelete='SET NULL')
        batch.add_column(sa.Column('reason', sa.String(length=80), nullable=True))
        batch.add_column(sa.Column('notes', sa.String(length=500), nullable=True))
        batch.add_column(sa.Column('posted_at', sa.DateTime(), nullable=True))
        batch.add_column(sa.Column('cancelled_at', sa.DateTime(), nullable=True))
        batch.add_column(sa.Column('cancelled_by_id', sa.Integer(), nullable=True))
        batch.create_foreign_key('fk_purchase_returns_cancelled_by', 'users', ['cancelled_by_id'], ['id'])
    op.create_index('ix_purchase_returns_warehouse_id', 'purchase_returns', ['warehouse_id'])
    with op.batch_alter_table('purchase_return_lines', recreate='auto') as batch:
        batch.add_column(sa.Column('return_reason', sa.String(length=120), nullable=True))
        batch.add_column(sa.Column('condition', sa.String(length=40), nullable=True))
        batch.add_column(sa.Column('notes', sa.String(length=500), nullable=True))

def downgrade():
    op.drop_column('purchase_return_lines', 'notes')
    op.drop_column('purchase_return_lines', 'condition')
    op.drop_column('purchase_return_lines', 'return_reason')
    op.drop_index('ix_purchase_returns_warehouse_id', table_name='purchase_returns')
    op.drop_column('purchase_returns', 'cancelled_by_id')
    op.drop_column('purchase_returns', 'cancelled_at')
    op.drop_column('purchase_returns', 'posted_at')
    op.drop_column('purchase_returns', 'notes')
    op.drop_column('purchase_returns', 'reason')
    op.drop_column('purchase_returns', 'warehouse_id')
