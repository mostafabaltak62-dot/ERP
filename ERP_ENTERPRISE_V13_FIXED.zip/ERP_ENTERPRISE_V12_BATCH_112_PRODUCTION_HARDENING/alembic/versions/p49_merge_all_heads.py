"""Merge existing migration branches after planning scheduling hardening."""
revision='p49_merge_all_heads'
down_revision=('a7b8c9d0e128','a7b8c9d0e129','b8c9d0e1f240','d5e6f7a8b9c0','p48_planning_sched_engine')
branch_labels=None
depends_on=None

def upgrade():
    pass

def downgrade():
    pass
