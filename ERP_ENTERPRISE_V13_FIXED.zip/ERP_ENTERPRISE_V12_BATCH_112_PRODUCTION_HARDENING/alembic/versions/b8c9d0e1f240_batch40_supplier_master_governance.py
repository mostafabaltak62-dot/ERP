"""Batch 40 supplier master governance
Revision ID: b8c9d0e1f240
Revises: a7b8c9d0e1f2
"""
from alembic import op
import sqlalchemy as sa
revision='b8c9d0e1f240'; down_revision='a7b8c9d0e139'; branch_labels=None; depends_on=None

def upgrade():
    cols=[
      sa.Column('legal_name',sa.String(200),nullable=True), sa.Column('supplier_type',sa.String(40),server_default='company',nullable=False),
      sa.Column('contact_person',sa.String(120),nullable=True), sa.Column('tax_number',sa.String(80),nullable=True),
      sa.Column('registration_number',sa.String(80),nullable=True), sa.Column('country',sa.String(80),nullable=True),
      sa.Column('city',sa.String(80),nullable=True), sa.Column('postal_code',sa.String(30),nullable=True),
      sa.Column('payment_terms_days',sa.Integer(),server_default='0',nullable=False), sa.Column('preferred_payment_method',sa.String(40),nullable=True),
      sa.Column('currency_code',sa.String(10),server_default='EGP',nullable=False), sa.Column('credit_limit',sa.Numeric(20,2),server_default='0',nullable=False),
      sa.Column('bank_name',sa.String(120),nullable=True), sa.Column('bank_account_name',sa.String(150),nullable=True),
      sa.Column('bank_account_number',sa.String(80),nullable=True), sa.Column('iban',sa.String(80),nullable=True), sa.Column('swift_code',sa.String(30),nullable=True),
      sa.Column('blocked_reason',sa.String(255),nullable=True)]
    for c in cols: op.add_column('suppliers',c)
    op.create_index('ix_suppliers_tax_number','suppliers',['tax_number'])
    op.create_index('ix_suppliers_registration_number','suppliers',['registration_number'])

def downgrade():
    op.drop_index('ix_suppliers_registration_number',table_name='suppliers'); op.drop_index('ix_suppliers_tax_number',table_name='suppliers')
    for name in ['blocked_reason','swift_code','iban','bank_account_number','bank_account_name','bank_name','credit_limit','currency_code','preferred_payment_method','payment_terms_days','postal_code','city','country','registration_number','tax_number','contact_person','supplier_type','legal_name']:
        op.drop_column('suppliers',name)
