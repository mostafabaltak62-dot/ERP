"""Merge tax governance and procurement hardening migration heads."""
from alembic import op

revision = "p74_merge_tax_procurement"
down_revision = ("p70_procurement_supply_hardening", "p73_tax_governance")
branch_labels = None
depends_on = None

def upgrade():
    pass

def downgrade():
    pass
