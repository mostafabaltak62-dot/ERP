"""phase 6.4.3 recovery planning and corrective action governance
Revision ID: d4e5f6a7b8c9
Revises: c3d4e5f6a7b8
"""
from alembic import op
import sqlalchemy as sa
revision='d4e5f6a7b8c9'; down_revision='c3d4e5f6a7b8'; branch_labels=None; depends_on=None

def upgrade():
    op.create_table('construction_recovery_plans',
      sa.Column('id',sa.Integer(),primary_key=True),
      sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),
      sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),
      sa.Column('alert_id',sa.Integer(),sa.ForeignKey('construction_performance_alerts.id')),
      sa.Column('plan_no',sa.String(60),nullable=False),
      sa.Column('title',sa.String(255),nullable=False),
      sa.Column('owner_id',sa.Integer(),sa.ForeignKey('users.id')),
      sa.Column('target_date',sa.Date(),nullable=False),
      sa.Column('target_cpi',sa.Numeric(20,8)),
      sa.Column('target_spi',sa.Numeric(20,8)),
      sa.Column('target_eac',sa.Numeric(20,6)),
      sa.Column('status',sa.String(30),nullable=False,server_default='draft'),
      sa.Column('approved_by_id',sa.Integer(),sa.ForeignKey('users.id')),
      sa.Column('approved_at',sa.DateTime()),
      sa.Column('closed_by_id',sa.Integer(),sa.ForeignKey('users.id')),
      sa.Column('closed_at',sa.DateTime()),
      sa.Column('notes',sa.Text()),
      sa.Column('created_at',sa.DateTime(),nullable=False,server_default=sa.func.now()),
      sa.UniqueConstraint('project_id','plan_no',name='uq_recovery_plan_project_no'))
    for c in ['company_id','project_id','alert_id']:
        op.create_index('ix_recovery_plan_'+c,'construction_recovery_plans',[c])
    op.create_table('construction_recovery_actions',
      sa.Column('id',sa.Integer(),primary_key=True),
      sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),
      sa.Column('plan_id',sa.Integer(),sa.ForeignKey('construction_recovery_plans.id'),nullable=False),
      sa.Column('action_no',sa.String(60),nullable=False),
      sa.Column('description',sa.Text(),nullable=False),
      sa.Column('owner_id',sa.Integer(),sa.ForeignKey('users.id')),
      sa.Column('due_date',sa.Date(),nullable=False),
      sa.Column('status',sa.String(30),nullable=False,server_default='open'),
      sa.Column('completion_percent',sa.Numeric(10,6),nullable=False,server_default='0'),
      sa.Column('completed_at',sa.DateTime()),
      sa.Column('evidence',sa.Text()),
      sa.Column('created_at',sa.DateTime(),nullable=False,server_default=sa.func.now()),
      sa.UniqueConstraint('plan_id','action_no',name='uq_recovery_action_plan_no'),
      sa.CheckConstraint('completion_percent >= 0 AND completion_percent <= 100',name='ck_recovery_action_completion_bounds'))
    for c in ['company_id','plan_id']:
        op.create_index('ix_recovery_action_'+c,'construction_recovery_actions',[c])

def downgrade():
    op.drop_table('construction_recovery_actions')
    op.drop_table('construction_recovery_plans')
