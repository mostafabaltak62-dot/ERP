"""Patch 62 — bank reconciliation governance and account linkage"""
from alembic import op
import sqlalchemy as sa
revision='p62_bank_reconciliation_governance'
down_revision='p58_warehouse_management_hardening'
branch_labels=None
depends_on=None

def upgrade():
    with op.batch_alter_table('bank_reconciliations', recreate='auto') as batch:
        batch.add_column(sa.Column('bank_account_id', sa.Integer(), nullable=True))
        batch.create_foreign_key('fk_bank_reconciliations_bank_account_id','accounts',['bank_account_id'],['id'])
    op.create_index('ix_bank_reconciliations_account_date','bank_reconciliations',['company_id','bank_account_id','statement_date'])

def downgrade():
    op.drop_index('ix_bank_reconciliations_account_date', table_name='bank_reconciliations')
    op.drop_constraint('fk_bank_reconciliations_bank_account_id','bank_reconciliations',type_='foreignkey')
    op.drop_column('bank_reconciliations','bank_account_id')
