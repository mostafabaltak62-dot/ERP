"""Phase 7.0 — field operations, commercial variations, site requisitions and integration."""
from typing import Sequence, Union
from alembic import op
from sqlalchemy import Column, Integer, String, Numeric, DateTime
from app.db_base import Base
from app import field_ops_models  # noqa: F401

revision: str = 'b7c8d9e0f1a2'
down_revision: Union[str, Sequence[str], None] = 'a66a79eb1cf4'
branch_labels = None
depends_on = None

NEW_TABLES = [
    'equipment_logs','equipment_cost_entries','variation_amendments',
    'site_material_requisitions','site_material_requisition_lines',
    'offline_sync_batches','offline_sync_operations','offline_conflicts',
    'webhook_subscriptions','webhook_deliveries','license_register'
]

def upgrade() -> None:
    bind = op.get_bind()
    for name in NEW_TABLES:
        Base.metadata.tables[name].create(bind=bind, checkfirst=True)
    existing = {c['name'] for c in bind.exec_driver_sql('PRAGMA table_info(construction_variations)').mappings()} if bind.dialect.name == 'sqlite' else {c.name for c in bind.dialect.get_columns(bind, 'construction_variations')}
    additions = [
        ('financial_status', String(30), 'pending'),
        ('schedule_status', String(30), 'pending'),
        ('approved_financial_amount', Numeric(20,6), None),
        ('approved_time_extension_days', Integer(), None),
        ('amendment_number', String(60), None),
        ('budget_applied_at', DateTime(), None),
    ]
    for name, typ, default in additions:
        if name not in existing:
            op.add_column('construction_variations', Column(name, typ, nullable=False if default is not None else True, server_default=default))

def downgrade() -> None:
    bind = op.get_bind()
    for name in ['budget_applied_at','amendment_number','approved_time_extension_days','approved_financial_amount','schedule_status','financial_status']:
        try: op.drop_column('construction_variations', name)
        except Exception: pass
    for name in reversed(NEW_TABLES):
        Base.metadata.tables[name].drop(bind=bind, checkfirst=True)
