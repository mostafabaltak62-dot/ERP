"""Patch 67 — audit log hardening and tenant-scoped query performance."""
from alembic import op
import sqlalchemy as sa
revision='p67_audit_log_hardening'
down_revision='p66_inventory_traceability_reconciliation'
branch_labels=None
depends_on=None

def upgrade():
    op.create_index('ix_governance_audit_logs_company_created', 'governance_audit_logs', ['company_id','created_at','id'], unique=False)
    op.create_index('ix_governance_audit_logs_company_entity', 'governance_audit_logs', ['company_id','entity_type','entity_id'], unique=False)
    op.create_index('ix_governance_audit_logs_company_action', 'governance_audit_logs', ['company_id','action','created_at'], unique=False)

def downgrade():
    op.drop_index('ix_governance_audit_logs_company_action', table_name='governance_audit_logs')
    op.drop_index('ix_governance_audit_logs_company_entity', table_name='governance_audit_logs')
    op.drop_index('ix_governance_audit_logs_company_created', table_name='governance_audit_logs')
