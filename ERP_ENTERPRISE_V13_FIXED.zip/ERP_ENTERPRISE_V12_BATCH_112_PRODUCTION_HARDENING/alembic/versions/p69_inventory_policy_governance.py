"""Patch 69 — inventory policy and valuation governance."""
from alembic import op
import sqlalchemy as sa

revision = 'p69_inventory_policy_governance'
down_revision = 'p67_audit_log_hardening'
branch_labels = None
depends_on = None


def upgrade():
    # The warehouse policy table already permits warehouse_id=NULL; this row is
    # the single company-wide default used to seed item-level valuation policy.
    op.create_index(
        'uq_inventory_policy_company_default',
        'inventory_policies',
        ['company_id'],
        unique=True,
        sqlite_where=sa.text('warehouse_id IS NULL'),
        postgresql_where=sa.text('warehouse_id IS NULL'),
    )
    with op.batch_alter_table('inventory_policies', recreate='auto') as batch:
        batch.create_check_constraint(
            'ck_inventory_policy_costing_method',
            "costing_method IN ('fifo','weighted_average','standard')",
        )
        batch.create_check_constraint(
            'ck_inventory_policy_reorder_point_nonnegative',
            'reorder_point >= 0',
        )
        batch.create_check_constraint(
            'ck_inventory_policy_reorder_quantity_nonnegative',
            'reorder_quantity >= 0',
        )


def downgrade():
    with op.batch_alter_table('inventory_policies', recreate='auto') as batch:
        batch.drop_constraint('ck_inventory_policy_reorder_quantity_nonnegative', type_='check')
        batch.drop_constraint('ck_inventory_policy_reorder_point_nonnegative', type_='check')
        batch.drop_constraint('ck_inventory_policy_costing_method', type_='check')
    op.drop_index('uq_inventory_policy_company_default', table_name='inventory_policies')
