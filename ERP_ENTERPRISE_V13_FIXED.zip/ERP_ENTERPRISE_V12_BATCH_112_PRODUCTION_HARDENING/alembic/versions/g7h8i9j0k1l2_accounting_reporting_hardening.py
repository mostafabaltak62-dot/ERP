"""Accounting reporting hardening and chart-of-accounts presentation metadata.

Revision ID: g7h8i9j0k1l2
Revises: b8c9d0e1f2a3
"""
from alembic import op
import sqlalchemy as sa

revision = "g7h8i9j0k1l2"
down_revision = "b8c9d0e1f2a3"
branch_labels = None
depends_on = None


def upgrade():
    # SQLite cannot ALTER constraints in-place. Batch mode also lets us convert
    # the old globally-unique account-code index into a normal index.
    with op.batch_alter_table("accounts", recreate="auto") as batch:
        try:
            batch.drop_index("ix_accounts_code")
        except Exception:
            pass
        batch.add_column(sa.Column("parent_id", sa.Integer(), nullable=True))
        batch.add_column(sa.Column("normal_balance", sa.String(length=10), nullable=True))
        batch.add_column(sa.Column("statement_section", sa.String(length=50), nullable=True))
        batch.add_column(sa.Column("cash_flow_category", sa.String(length=20), nullable=True))
        batch.create_index("ix_accounts_parent_id", ["parent_id"], unique=False)
        batch.create_foreign_key("fk_accounts_parent_id", "accounts", ["parent_id"], ["id"])
    op.create_index("ix_accounts_code", "accounts", ["code"], unique=False)


def downgrade():
    with op.batch_alter_table("accounts", recreate="auto") as batch:
        try:
            batch.drop_index("ix_accounts_code")
        except Exception:
            pass
        batch.drop_constraint("fk_accounts_parent_id", type_="foreignkey")
        try:
            batch.drop_index("ix_accounts_parent_id")
        except Exception:
            pass
        batch.drop_column("cash_flow_category")
        batch.drop_column("statement_section")
        batch.drop_column("normal_balance")
        batch.drop_column("parent_id")
    op.create_index("ix_accounts_code", "accounts", ["code"], unique=True)
