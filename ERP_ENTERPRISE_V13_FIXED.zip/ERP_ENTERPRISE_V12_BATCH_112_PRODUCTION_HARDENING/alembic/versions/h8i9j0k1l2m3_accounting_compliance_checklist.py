"""Accounting compliance checklist extensions.

Revision ID: h8i9j0k1l2m3
Revises: g7h8i9j0k1l2
"""
from alembic import op
import sqlalchemy as sa

revision = "h8i9j0k1l2m3"
down_revision = "g7h8i9j0k1l2"
branch_labels = None
depends_on = None

def upgrade():
    bind = op.get_bind()
    insp = sa.inspect(bind)
    tables = set(insp.get_table_names())

    if "bank_reconciliation_items" not in tables:
        op.create_table(
            "bank_reconciliation_items",
            sa.Column("id", sa.Integer(), primary_key=True),
            sa.Column("company_id", sa.Integer(), nullable=True),
            sa.Column("reconciliation_id", sa.Integer(), sa.ForeignKey("bank_reconciliations.id"), nullable=False),
            sa.Column("transaction_date", sa.DateTime(), nullable=False),
            sa.Column("reference", sa.String(100), nullable=True),
            sa.Column("description", sa.String(255), nullable=True),
            sa.Column("amount", sa.Numeric(20,6), nullable=False),
            sa.Column("direction", sa.String(10), nullable=False),
            sa.Column("matched_journal_line_id", sa.Integer(), sa.ForeignKey("journal_lines.id"), nullable=True),
            sa.Column("status", sa.String(20), nullable=False, server_default="unmatched"),
            sa.Column("created_at", sa.DateTime(), nullable=False),
        )
        op.create_index("ix_bank_reconciliation_items_company_id", "bank_reconciliation_items", ["company_id"])
        op.create_index("ix_bank_reconciliation_items_reconciliation_id", "bank_reconciliation_items", ["reconciliation_id"])

    if "withholding_tax_rates" not in tables:
        op.create_table(
            "withholding_tax_rates",
            sa.Column("id", sa.Integer(), primary_key=True),
            sa.Column("company_id", sa.Integer(), nullable=True),
            sa.Column("code", sa.String(30), nullable=False),
            sa.Column("name", sa.String(120), nullable=False),
            sa.Column("rate", sa.Numeric(12,6), nullable=False, server_default="0"),
            sa.Column("tax_account_code", sa.String(30), nullable=False, server_default="2230"),
            sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
            sa.UniqueConstraint("company_id", "code", name="uq_wht_company_code"),
        )
        op.create_index("ix_withholding_tax_rates_company_id", "withholding_tax_rates", ["company_id"])

    if "withholding_tax_transactions" not in tables:
        op.create_table(
            "withholding_tax_transactions",
            sa.Column("id", sa.Integer(), primary_key=True),
            sa.Column("company_id", sa.Integer(), nullable=True),
            sa.Column("rate_id", sa.Integer(), sa.ForeignKey("withholding_tax_rates.id"), nullable=False),
            sa.Column("source_type", sa.String(50), nullable=False),
            sa.Column("source_id", sa.Integer(), nullable=False),
            sa.Column("taxable_amount", sa.Numeric(20,6), nullable=False),
            sa.Column("tax_amount", sa.Numeric(20,6), nullable=False),
            sa.Column("journal_entry_id", sa.Integer(), sa.ForeignKey("journal_entries.id"), nullable=True),
            sa.Column("created_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
            sa.Column("created_at", sa.DateTime(), nullable=False),
        )
        op.create_index("ix_withholding_tax_transactions_company_id", "withholding_tax_transactions", ["company_id"])

    if "fixed_asset_disposals" not in tables:
        op.create_table(
            "fixed_asset_disposals",
            sa.Column("id", sa.Integer(), primary_key=True),
            sa.Column("company_id", sa.Integer(), nullable=True),
            sa.Column("asset_id", sa.Integer(), sa.ForeignKey("fixed_assets.id"), nullable=False, unique=True),
            sa.Column("disposal_date", sa.DateTime(), nullable=False),
            sa.Column("proceeds", sa.Numeric(20,6), nullable=False, server_default="0"),
            sa.Column("net_book_value", sa.Numeric(20,6), nullable=False),
            sa.Column("gain_loss", sa.Numeric(20,6), nullable=False, server_default="0"),
            sa.Column("journal_entry_id", sa.Integer(), sa.ForeignKey("journal_entries.id"), nullable=False),
            sa.Column("created_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
            sa.Column("created_at", sa.DateTime(), nullable=False),
        )
        op.create_index("ix_fixed_asset_disposals_company_id", "fixed_asset_disposals", ["company_id"])

    # SQLite-safe additions: only add columns when absent.
    tax_cols = {c["name"] for c in sa.inspect(bind).get_columns("tax_rates")}
    if "tax_direction" not in tax_cols:
        op.add_column("tax_rates", sa.Column("tax_direction", sa.String(20), nullable=False, server_default="output"))

    for table, column, coltype in [
        ("cost_centers", "project_id", sa.Integer()),
        ("journal_line_cost_centers", "allocation_percent", sa.Numeric(9,6)),
    ]:
        cols = {c["name"] for c in sa.inspect(bind).get_columns(table)}
        if column not in cols:
            op.add_column(table, sa.Column(column, coltype, nullable=True))
            if table == "cost_centers":
                op.create_index("ix_cost_centers_project_id", table, [column])

def downgrade():
    # Deliberately conservative: dropping accounting history structures is not
    # safe for a production ERP rollback. Use a database backup and controlled
    # migration rollback procedure if required.
    pass
