"""Phase 6.8 — Daily labor (sarky) and overtime/payable control"""
from alembic import op
import sqlalchemy as sa
revision='2c3d4e5f6a71'; down_revision='1b2c3d4e5f60'; branch_labels=None; depends_on=None

def upgrade():
    op.create_table('daily_workers',
        sa.Column('id',sa.Integer(),primary_key=True),sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id',ondelete='CASCADE'),nullable=False),
        sa.Column('worker_code',sa.String(60),nullable=False),sa.Column('name',sa.String(180),nullable=False),sa.Column('national_id',sa.String(100)),sa.Column('phone',sa.String(50)),sa.Column('trade',sa.String(100)),
        sa.Column('worker_type',sa.String(50),nullable=False,server_default='daily'),sa.Column('daily_rate',sa.Numeric(20,6),nullable=False,server_default='0'),sa.Column('overtime_rate',sa.Numeric(20,6),nullable=False,server_default='0'),sa.Column('normal_hours',sa.Numeric(10,2),nullable=False,server_default='8'),sa.Column('status',sa.String(30),nullable=False,server_default='active'),sa.Column('created_at',sa.DateTime(),nullable=False),
        sa.UniqueConstraint('company_id','worker_code',name='uq_daily_worker_company_code'),sa.CheckConstraint('daily_rate >= 0','ck_daily_worker_daily_rate'),sa.CheckConstraint('overtime_rate >= 0','ck_daily_worker_ot_rate'),sa.CheckConstraint('normal_hours > 0','ck_daily_worker_normal_hours'))
    for c in ['company_id','worker_code','status']: op.create_index('ix_daily_workers_'+c,'daily_workers',[c])
    op.create_table('daily_labor_entries',
        sa.Column('id',sa.Integer(),primary_key=True),sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id',ondelete='CASCADE'),nullable=False),sa.Column('worker_id',sa.Integer(),sa.ForeignKey('daily_workers.id',ondelete='CASCADE'),nullable=False),
        sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id',ondelete='CASCADE'),nullable=False),sa.Column('site_id',sa.Integer(),sa.ForeignKey('construction_sites.id',ondelete='SET NULL')),sa.Column('wbs_id',sa.Integer(),sa.ForeignKey('construction_wbs_nodes.id',ondelete='SET NULL')),sa.Column('cost_code_id',sa.Integer(),sa.ForeignKey('construction_cost_codes.id',ondelete='SET NULL')),sa.Column('boq_line_id',sa.Integer(),sa.ForeignKey('construction_boq_lines.id',ondelete='SET NULL')),sa.Column('work_date',sa.Date(),nullable=False),sa.Column('check_in',sa.DateTime()),sa.Column('check_out',sa.DateTime()),
        sa.Column('regular_hours',sa.Numeric(10,2),nullable=False,server_default='0'),sa.Column('overtime_hours',sa.Numeric(10,2),nullable=False,server_default='0'),sa.Column('daily_rate',sa.Numeric(20,6),nullable=False,server_default='0'),sa.Column('overtime_rate',sa.Numeric(20,6),nullable=False,server_default='0'),sa.Column('regular_amount',sa.Numeric(20,6),nullable=False,server_default='0'),sa.Column('overtime_amount',sa.Numeric(20,6),nullable=False,server_default='0'),sa.Column('other_amount',sa.Numeric(20,6),nullable=False,server_default='0'),sa.Column('deduction_amount',sa.Numeric(20,6),nullable=False,server_default='0'),sa.Column('net_amount',sa.Numeric(20,6),nullable=False,server_default='0'),
        sa.Column('status',sa.String(30),nullable=False,server_default='draft'),sa.Column('approved_by_id',sa.Integer(),sa.ForeignKey('users.id',ondelete='SET NULL')),sa.Column('approved_at',sa.DateTime()),sa.Column('project_cost_id',sa.Integer(),sa.ForeignKey('project_costs.id',ondelete='SET NULL'),unique=True),sa.Column('notes',sa.Text()),
        sa.UniqueConstraint('worker_id','project_id','work_date',name='uq_daily_labor_worker_project_date'),sa.CheckConstraint('regular_hours >= 0 AND overtime_hours >= 0','ck_daily_labor_hours_nonnegative'),sa.CheckConstraint('daily_rate >= 0 AND overtime_rate >= 0','ck_daily_labor_rates_nonnegative'),sa.CheckConstraint('other_amount >= 0 AND deduction_amount >= 0','ck_daily_labor_adjustments_nonnegative'))
    for c in ['company_id','worker_id','project_id','site_id','wbs_id','cost_code_id','boq_line_id','work_date']: op.create_index('ix_daily_labor_entries_'+c,'daily_labor_entries',[c])
    with op.batch_alter_table('project_documents', schema=None) as batch:
        batch.add_column(sa.Column('daily_labor_entry_id', sa.Integer(), nullable=True))
        batch.create_foreign_key('fk_project_documents_daily_labor_entry','daily_labor_entries',['daily_labor_entry_id'],['id'],ondelete='SET NULL')
        batch.create_index('ix_project_documents_daily_labor_entry_id',['daily_labor_entry_id'])
    op.create_table('daily_labor_settlements',
        sa.Column('id',sa.Integer(),primary_key=True),sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id',ondelete='CASCADE'),nullable=False),sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id',ondelete='CASCADE')),sa.Column('period_start',sa.Date(),nullable=False),sa.Column('period_end',sa.Date(),nullable=False),sa.Column('status',sa.String(30),nullable=False,server_default='draft'),sa.Column('gross_amount',sa.Numeric(20,6),nullable=False,server_default='0'),sa.Column('deductions',sa.Numeric(20,6),nullable=False,server_default='0'),sa.Column('net_amount',sa.Numeric(20,6),nullable=False,server_default='0'),sa.Column('approved_by_id',sa.Integer(),sa.ForeignKey('users.id',ondelete='SET NULL')),sa.Column('approved_at',sa.DateTime()),sa.CheckConstraint('period_end >= period_start','ck_daily_labor_settlement_dates'))
    for c in ['company_id','project_id','period_start','period_end']: op.create_index('ix_daily_labor_settlements_'+c,'daily_labor_settlements',[c])

def downgrade():
    with op.batch_alter_table('project_documents', schema=None) as batch:
        batch.drop_index('ix_project_documents_daily_labor_entry_id')
        batch.drop_constraint('fk_project_documents_daily_labor_entry', type_='foreignkey')
        batch.drop_column('daily_labor_entry_id')
    op.drop_table('daily_labor_settlements')
    op.drop_table('daily_labor_entries')
    op.drop_table('daily_workers')
