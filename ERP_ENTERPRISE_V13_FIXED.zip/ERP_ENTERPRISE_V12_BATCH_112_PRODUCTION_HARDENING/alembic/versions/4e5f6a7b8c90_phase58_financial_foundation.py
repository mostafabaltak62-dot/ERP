from alembic import op
import sqlalchemy as sa

revision = "4e5f6a7b8c90"
down_revision = "3d2f4a5b6c7e"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table("budgets",
        sa.Column("id",sa.Integer(),primary_key=True),
        sa.Column("company_id",sa.Integer(),sa.ForeignKey("companies.id"),nullable=False,index=True),
        sa.Column("branch_id",sa.Integer(),sa.ForeignKey("branches.id"),nullable=True,index=True),
        sa.Column("code",sa.String(50),nullable=False),sa.Column("name",sa.String(180),nullable=False),
        sa.Column("fiscal_year",sa.Integer(),nullable=False),sa.Column("scenario",sa.String(30),nullable=False),
        sa.Column("status",sa.String(30),nullable=False),sa.Column("currency_id",sa.Integer(),sa.ForeignKey("currencies.id")),
        sa.UniqueConstraint("company_id","code","scenario",name="uq_budget_company_code_scenario"))
    op.create_table("budget_lines",
        sa.Column("id",sa.Integer(),primary_key=True),
        sa.Column("company_id",sa.Integer(),sa.ForeignKey("companies.id"),nullable=False,index=True),
        sa.Column("budget_id",sa.Integer(),sa.ForeignKey("budgets.id"),nullable=False,index=True),
        sa.Column("account_id",sa.Integer(),sa.ForeignKey("accounts.id"),nullable=False),
        sa.Column("cost_center_id",sa.Integer(),sa.ForeignKey("cost_centers.id")),
        sa.Column("project_id",sa.Integer(),sa.ForeignKey("projects.id")),
        sa.Column("period",sa.Integer(),nullable=False),sa.Column("budget_amount",sa.Numeric(20,6),nullable=False),
        sa.Column("forecast_amount",sa.Numeric(20,6)),
        sa.UniqueConstraint("budget_id","account_id","cost_center_id","project_id","period",name="uq_budget_line"))
    op.create_table("project_forecasts",
        sa.Column("id",sa.Integer(),primary_key=True),
        sa.Column("company_id",sa.Integer(),sa.ForeignKey("companies.id"),nullable=False,index=True),
        sa.Column("project_id",sa.Integer(),sa.ForeignKey("projects.id"),nullable=False,index=True),
        sa.Column("as_of_date",sa.Date(),nullable=False),sa.Column("budget_cost",sa.Numeric(20,6),nullable=False),
        sa.Column("committed_cost",sa.Numeric(20,6),nullable=False),sa.Column("actual_cost",sa.Numeric(20,6),nullable=False),
        sa.Column("forecast_final_cost",sa.Numeric(20,6),nullable=False),sa.Column("forecast_revenue",sa.Numeric(20,6),nullable=False),
        sa.Column("forecast_profit",sa.Numeric(20,6),nullable=False),
        sa.UniqueConstraint("project_id","as_of_date",name="uq_project_forecast_date"))

    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        for table in ("budgets", "budget_lines", "project_forecasts"):
            quoted = '"' + table + '"'
            policy = f"tenant_isolation_{table}"
            expr = "company_id = NULLIF(current_setting('app.company_id', true), '')::integer"
            op.execute(f"ALTER TABLE {quoted} ENABLE ROW LEVEL SECURITY")
            op.execute(f"ALTER TABLE {quoted} FORCE ROW LEVEL SECURITY")
            op.execute(f"DROP POLICY IF EXISTS {policy} ON {quoted}")
            op.execute(f"CREATE POLICY {policy} ON {quoted} USING ({expr}) WITH CHECK ({expr})")

def downgrade():
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        for table in ("budgets", "budget_lines", "project_forecasts"):
            quoted = '"' + table + '"'
            policy = f"tenant_isolation_{table}"
            op.execute(f"DROP POLICY IF EXISTS {policy} ON {quoted}")
            op.execute(f"ALTER TABLE {quoted} NO FORCE ROW LEVEL SECURITY")
            op.execute(f"ALTER TABLE {quoted} DISABLE ROW LEVEL SECURITY")
    op.drop_table("project_forecasts"); op.drop_table("budget_lines"); op.drop_table("budgets")
