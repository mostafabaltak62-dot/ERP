"""Batch 28 Employee Profile 360
Revision ID: a7b8c9d0e128
Revises: z6a7b8c9d0e1
"""
from alembic import op
import sqlalchemy as sa
revision="a7b8c9d0e128"
down_revision="z6a7b8c9d0e1"
branch_labels=None
depends_on=None
def upgrade():
    op.create_table("employee_timeline_events",sa.Column("id",sa.Integer,primary_key=True),sa.Column("company_id",sa.Integer,sa.ForeignKey("companies.id",ondelete="CASCADE"),nullable=False),sa.Column("employee_id",sa.Integer,sa.ForeignKey("employees.id",ondelete="CASCADE"),nullable=False),sa.Column("event_type",sa.String(60),nullable=False),sa.Column("title",sa.String(200),nullable=False),sa.Column("event_date",sa.Date,nullable=False),sa.Column("description",sa.Text),sa.Column("reference_type",sa.String(80)),sa.Column("reference_id",sa.Integer),sa.Column("created_by_id",sa.Integer,sa.ForeignKey("users.id",ondelete="SET NULL")),sa.Column("created_at",sa.DateTime,nullable=False))
    op.create_index("ix_employee_timeline_company_employee", "employee_timeline_events", ["company_id","employee_id"])
def downgrade():
    op.drop_index("ix_employee_timeline_company_employee",table_name="employee_timeline_events")
    op.drop_table("employee_timeline_events")
