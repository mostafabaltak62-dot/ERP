"""Phase 6.6 — HR/Project/Accounting integration hardening.

Adds explicit payroll allocation method metadata and the authoritative journal
link from a payroll run to its accounting posting.
"""
from alembic import op
import sqlalchemy as sa

revision = '0a1b2c3d4e5f'
down_revision = 'f6a7b8c9d0e1'
branch_labels = None
depends_on = None

def upgrade():
    op.add_column('approval_requests', sa.Column('amount', sa.Numeric(20, 6), nullable=False, server_default='0'))
    op.add_column('payroll_allocations', sa.Column('allocation_method', sa.String(length=40), nullable=False, server_default='project_assignment'))
    op.add_column('payroll_runs', sa.Column('journal_entry_id', sa.Integer(), nullable=True))
    op.create_index('ix_payroll_runs_journal_entry_id', 'payroll_runs', ['journal_entry_id'], unique=False)
    with op.batch_alter_table('payroll_runs') as batch:
        batch.create_foreign_key('fk_payroll_runs_journal_entry', 'journal_entries', ['journal_entry_id'], ['id'], ondelete='SET NULL')

def downgrade():
    op.drop_column('approval_requests', 'amount')
    with op.batch_alter_table('payroll_runs') as batch:
        batch.drop_constraint('fk_payroll_runs_journal_entry', type_='foreignkey')
    op.drop_index('ix_payroll_runs_journal_entry_id', table_name='payroll_runs')
    op.drop_column('payroll_runs', 'journal_entry_id')
    op.drop_column('payroll_allocations', 'allocation_method')
