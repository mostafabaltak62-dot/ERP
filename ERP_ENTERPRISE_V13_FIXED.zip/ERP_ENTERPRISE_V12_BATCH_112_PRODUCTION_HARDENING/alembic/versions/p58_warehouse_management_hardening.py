"""Patch 58 — warehouse management hardening
Revision ID: p58_warehouse_management_hardening
Revises: p56_cost_control_authoritative_linkage
"""
from alembic import op
import sqlalchemy as sa
revision='p58_warehouse_management_hardening'; down_revision='p56_cost_control_authoritative_linkage'; branch_labels=None; depends_on=None

def upgrade():
    op.create_index('ix_warehouses_company_branch_active','warehouses',['company_id','branch_id','is_active'])
    op.create_index('ix_warehouses_company_project','warehouses',['company_id','project_id'])

def downgrade():
    op.drop_index('ix_warehouses_company_project', table_name='warehouses')
    op.drop_index('ix_warehouses_company_branch_active', table_name='warehouses')
