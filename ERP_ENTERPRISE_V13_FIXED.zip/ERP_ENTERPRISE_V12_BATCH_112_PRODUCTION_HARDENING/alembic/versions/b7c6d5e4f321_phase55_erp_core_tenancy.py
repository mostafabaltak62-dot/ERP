"""Phase 5.5 ERP Core: complete tenant dimensions and core permissions."""
from alembic import op
import sqlalchemy as sa

revision = "b7c6d5e4f321"
down_revision = "9e7f6a5b4c32"
branch_labels = None
depends_on = None

TABLES = {
    "workflow_steps": ("workflow_definitions", "workflow_id"),
    "workflow_instances": ("workflow_definitions", "workflow_id"),
    "workflow_actions": ("workflow_instances", "instance_id"),
    "dimension_values": ("analytical_dimensions", "dimension_id"),
    "project_phases": ("projects", "project_id"),
    "project_costs": ("projects", "project_id"),
    "contract_milestones": ("contracts", "contract_id"),
    "boq_items": ("projects", "project_id"),
    "progress_certificates": ("projects", "project_id"),
    "attendance_records": ("employees", "employee_id"),
    "leave_requests": ("employees", "employee_id"),
    "payroll_lines": ("payroll_runs", "payroll_run_id"),
    "bom_lines": ("boms", "bom_id"),
    "fuel_transactions": ("equipment", "equipment_id"),
    "maintenance_records": ("equipment", "equipment_id"),
}

PERMISSIONS = [
    ("core:manage", "Manage ERP Core master data"),
    ("core:branches", "Manage branches"),
    ("core:departments", "Manage departments"),
    ("core:dimensions", "Manage analytical dimensions"),
    ("core:projects", "Manage projects"),
    ("core:contracts", "Manage contracts"),
    ("core:search", "Use global ERP search"),
]


def upgrade():
    bind = op.get_bind()
    insp = sa.inspect(bind)

    for table, (parent, fk_col) in TABLES.items():
        cols = {c["name"] for c in insp.get_columns(table)}
        if "company_id" in cols:
            continue
        with op.batch_alter_table(table, recreate="auto") as batch:
            batch.add_column(sa.Column("company_id", sa.Integer(), nullable=True))
            batch.create_index(f"ix_{table}_company_id", ["company_id"])
        # Backfill from authoritative parent company.
        op.execute(sa.text(f"UPDATE {table} SET company_id = (SELECT company_id FROM {parent} p WHERE p.id = {table}.{fk_col}) WHERE company_id IS NULL"))
        with op.batch_alter_table(table, recreate="auto") as batch:
            batch.alter_column("company_id", existing_type=sa.Integer(), nullable=False)
            batch.create_foreign_key(f"fk_{table}_company_id", "companies", ["company_id"], ["id"])

    # User-scoped records need an explicit tenant. Use the user's first authorized
    # company for legacy rows; current requests can never create rows without context.
    for table in ("notifications", "idempotency_keys"):
        cols = {c["name"] for c in insp.get_columns(table)}
        if "company_id" not in cols:
            with op.batch_alter_table(table, recreate="auto") as batch:
                batch.add_column(sa.Column("company_id", sa.Integer(), nullable=True))
                batch.create_index(f"ix_{table}_company_id", ["company_id"])
            op.execute(sa.text(f"UPDATE {table} SET company_id = (SELECT company_id FROM user_company_access a WHERE a.user_id = {table}.user_id ORDER BY a.id LIMIT 1) WHERE company_id IS NULL"))
            op.execute(sa.text(f"UPDATE {table} SET company_id = (SELECT id FROM companies ORDER BY id LIMIT 1) WHERE company_id IS NULL"))
            with op.batch_alter_table(table, recreate="auto") as batch:
                batch.alter_column("company_id", existing_type=sa.Integer(), nullable=False)
                batch.create_foreign_key(f"fk_{table}_company_id", "companies", ["company_id"], ["id"])

    # Existing unique idempotency scope must include company to avoid collisions
    # for the same user/endpoint/key across companies.
    with op.batch_alter_table("idempotency_keys", recreate="auto") as batch:
        batch.drop_constraint("uq_idempotency_request", type_="unique")
        batch.create_unique_constraint("uq_idempotency_company_request", ["company_id", "key", "user_id", "endpoint"])

    # Add core permissions. Startup attaches all active permissions to system_admin.
    perm_table = sa.table("permissions", sa.column("code", sa.String), sa.column("description", sa.String), sa.column("is_active", sa.Boolean))
    for code, description in PERMISSIONS:
        op.execute(sa.text("INSERT INTO permissions(code, description, is_active) SELECT :c, :d, TRUE WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE code=:c)").bindparams(c=code, d=description))

    # Native PostgreSQL RLS for the newly tenant-aware child tables.
    if bind.dialect.name == "postgresql":
        for table in list(TABLES) + ["notifications", "idempotency_keys"]:
            policy = f"tenant_isolation_{table}"
            q = '"' + table.replace('"', '""') + '"'
            op.execute(f"ALTER TABLE {q} ENABLE ROW LEVEL SECURITY")
            op.execute(f"ALTER TABLE {q} FORCE ROW LEVEL SECURITY")
            op.execute(f"DROP POLICY IF EXISTS {policy} ON {q}")
            expr = "company_id = NULLIF(current_setting('app.company_id', true), '')::integer"
            op.execute(f"CREATE POLICY {policy} ON {q} USING ({expr}) WITH CHECK ({expr})")


def downgrade():
    bind = op.get_bind()
    for table in ("idempotency_keys", "notifications") + tuple(TABLES.keys()):
        if bind.dialect.name == "postgresql":
            q='"'+table.replace('"','""')+'"'; op.execute(f"DROP POLICY IF EXISTS tenant_isolation_{table} ON {q}"); op.execute(f"ALTER TABLE {q} NO FORCE ROW LEVEL SECURITY"); op.execute(f"ALTER TABLE {q} DISABLE ROW LEVEL SECURITY")
        if table == "idempotency_keys":
            with op.batch_alter_table(table, recreate="auto") as batch:
                batch.drop_constraint("uq_idempotency_company_request", type_="unique")
                batch.create_unique_constraint("uq_idempotency_request", ["key", "user_id", "endpoint"])
        with op.batch_alter_table(table, recreate="auto") as batch:
            batch.drop_constraint(f"fk_{table}_company_id", type_="foreignkey")
            batch.drop_index(f"ix_{table}_company_id")
            batch.drop_column("company_id")
    # Core permission rows are safe to leave for compatibility with roles.
