"""Patch 63 — accounting period creation governance"""
from alembic import op
import sqlalchemy as sa

revision='p63_accounting_period_governance'
down_revision='p62_bank_reconciliation_governance'
branch_labels=None
depends_on=None

def upgrade():
    with op.batch_alter_table('accounting_periods', recreate='auto') as batch:
        batch.drop_constraint('uq_accounting_period_name', type_='unique')
        batch.create_unique_constraint('uq_accounting_period_scope_name', ['company_id','branch_id','name'])
    op.create_index('ix_accounting_period_scope_dates', 'accounting_periods', ['company_id','branch_id','start_date','end_date'])

def downgrade():
    op.drop_index('ix_accounting_period_scope_dates', table_name='accounting_periods')
    op.drop_constraint('uq_accounting_period_scope_name', 'accounting_periods', type_='unique')
    op.create_unique_constraint('uq_accounting_period_name', 'accounting_periods', ['name'])
