"""Patch 77 — bank statement reconciliation integrity hardening.

This merge closes the remaining Alembic branches and protects the core invariant
that one posted GL line can be reconciled against at most one bank statement line.
"""
from alembic import op
from sqlalchemy import inspect, text

revision = "p77_bank_statement_reconciliation_hardening"
down_revision = (
    "a7b8c9d0e129",
    "d5e6f7a8b9c0",
    "c9d8e7f6a5b4",
    "2c3d4e5f6a71",
    "p74_merge_tax_procurement",
    "b8c9d0e1f240",
    "t1u2v3w4x5y6",
)
branch_labels = None
depends_on = None


def upgrade():
    bind = op.get_bind()
    inspector = inspect(bind)
    tables = set(inspector.get_table_names())
    if "bank_reconciliation_items" not in tables:
        return

    # Do not silently repair financially ambiguous historical data. If a line was
    # already matched more than once, the operator must resolve it before upgrade.
    dupes = bind.execute(text("""
        SELECT matched_journal_line_id
        FROM bank_reconciliation_items
        WHERE matched_journal_line_id IS NOT NULL
          AND status = 'matched'
        GROUP BY matched_journal_line_id
        HAVING COUNT(*) > 1
        LIMIT 1
    """)).fetchone()
    if dupes:
        raise RuntimeError(
            "Bank reconciliation migration blocked: a journal line is matched by "
            "multiple bank statement items. Resolve duplicate matches first."
        )

    existing = {idx.get("name") for idx in inspector.get_indexes("bank_reconciliation_items")}
    if "uq_bank_reconciliation_items_matched_journal_line" not in existing:
        op.create_index(
            "uq_bank_reconciliation_items_matched_journal_line",
            "bank_reconciliation_items",
            ["matched_journal_line_id"],
            unique=True,
        )

    if "ix_bank_reconciliation_items_company_status" not in existing:
        op.create_index(
            "ix_bank_reconciliation_items_company_status",
            "bank_reconciliation_items",
            ["company_id", "status"],
            unique=False,
        )


def downgrade():
    bind = op.get_bind()
    inspector = inspect(bind)
    existing = {idx.get("name") for idx in inspector.get_indexes("bank_reconciliation_items")}
    if "ix_bank_reconciliation_items_company_status" in existing:
        op.drop_index("ix_bank_reconciliation_items_company_status", table_name="bank_reconciliation_items")
    if "uq_bank_reconciliation_items_matched_journal_line" in existing:
        op.drop_index("uq_bank_reconciliation_items_matched_journal_line", table_name="bank_reconciliation_items")
