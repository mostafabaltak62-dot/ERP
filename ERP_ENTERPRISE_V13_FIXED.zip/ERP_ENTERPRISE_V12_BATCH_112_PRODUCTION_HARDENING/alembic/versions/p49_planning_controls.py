"""Patch 50: planning controls, delay events and resource loading."""
from alembic import op
import sqlalchemy as sa
revision='p49_planning_controls'; down_revision='p48_planning_sched_engine'; branch_labels=None; depends_on=None

def upgrade():
    op.create_table('construction_schedule_delay_events',
      sa.Column('id',sa.Integer(),primary_key=True),sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),sa.Column('activity_id',sa.Integer(),sa.ForeignKey('construction_activities.id'),nullable=True),sa.Column('event_no',sa.String(60),nullable=False),sa.Column('event_date',sa.Date(),nullable=False),sa.Column('cause',sa.String(120),nullable=False),sa.Column('description',sa.Text(),nullable=False),sa.Column('excusable',sa.Boolean(),nullable=False,server_default=sa.false()),sa.Column('compensable',sa.Boolean(),nullable=False,server_default=sa.false()),sa.Column('claimed_days',sa.Integer(),nullable=False,server_default='0'),sa.Column('approved_days',sa.Integer(),nullable=False,server_default='0'),sa.Column('status',sa.String(30),nullable=False,server_default='open'),sa.Column('created_by_id',sa.Integer(),sa.ForeignKey('users.id')),sa.Column('created_at',sa.DateTime(),nullable=False),sa.UniqueConstraint('project_id','event_no',name='uq_schedule_delay_project_no'),sa.CheckConstraint('claimed_days >= 0',name='ck_schedule_delay_claimed_nonnegative'),sa.CheckConstraint('approved_days >= 0 AND approved_days <= claimed_days',name='ck_schedule_delay_approved_bounds'))
    for n in ('company_id','project_id','activity_id'): op.create_index('ix_construction_schedule_delay_events_'+n,'construction_schedule_delay_events',[n])
    op.create_table('construction_schedule_resources',
      sa.Column('id',sa.Integer(),primary_key=True),sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),sa.Column('activity_id',sa.Integer(),sa.ForeignKey('construction_activities.id'),nullable=False),sa.Column('resource_type',sa.String(30),nullable=False),sa.Column('resource_name',sa.String(180),nullable=False),sa.Column('planned_units',sa.Numeric(20,6),nullable=False,server_default='0'),sa.Column('actual_units',sa.Numeric(20,6),nullable=False,server_default='0'),sa.Column('unit_cost',sa.Numeric(20,6),nullable=False,server_default='0'),sa.UniqueConstraint('project_id','activity_id','resource_type','resource_name',name='uq_schedule_resource_activity_name'),sa.CheckConstraint('planned_units >= 0 AND actual_units >= 0 AND unit_cost >= 0',name='ck_schedule_resource_nonnegative'))
    for n in ('company_id','project_id','activity_id'): op.create_index('ix_construction_schedule_resources_'+n,'construction_schedule_resources',[n])

def downgrade():
    op.drop_table('construction_schedule_resources'); op.drop_table('construction_schedule_delay_events')
