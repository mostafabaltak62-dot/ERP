"""Batch 26 Site Operations Center"""
from alembic import op
import sqlalchemy as sa

revision = "y5z6a7b8c9d0"
down_revision = "x4y5z6a7b8c9"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "site_location_nodes",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("company_id", sa.Integer, sa.ForeignKey("companies.id"), nullable=False),
        sa.Column("project_id", sa.Integer, sa.ForeignKey("projects.id"), nullable=False),
        sa.Column("parent_id", sa.Integer, sa.ForeignKey("site_location_nodes.id")),
        sa.Column("code", sa.String(60), nullable=False),
        sa.Column("name", sa.String(180), nullable=False),
        sa.Column("node_type", sa.String(30), nullable=False),
        sa.Column("status", sa.String(30), nullable=False, server_default="active"),
        sa.Column("created_at", sa.DateTime, nullable=False),
    )
    with op.batch_alter_table("site_location_nodes", recreate="auto") as batch:
        batch.create_unique_constraint("uq_site_location_project_code", ["project_id", "code"])

    op.create_table(
        "daily_site_reports",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("company_id", sa.Integer, sa.ForeignKey("companies.id"), nullable=False),
        sa.Column("project_id", sa.Integer, sa.ForeignKey("projects.id"), nullable=False),
        sa.Column("report_date", sa.Date, nullable=False),
        sa.Column("weather", sa.String(80)),
        sa.Column("status", sa.String(30), nullable=False, server_default="draft"),
        sa.Column("work_summary", sa.Text),
        sa.Column("constraints", sa.Text),
        sa.Column("tomorrow_plan", sa.Text),
        sa.Column("notes", sa.Text),
        sa.Column("prepared_by_id", sa.Integer, sa.ForeignKey("users.id")),
        sa.Column("approved_by_id", sa.Integer, sa.ForeignKey("users.id")),
        sa.Column("approved_at", sa.DateTime),
        sa.Column("created_at", sa.DateTime, nullable=False),
    )
    with op.batch_alter_table("daily_site_reports", recreate="auto") as batch:
        batch.create_unique_constraint("uq_daily_site_report_project_date", ["company_id", "project_id", "report_date"])

    op.create_table(
        "site_diary_entries",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("company_id", sa.Integer, sa.ForeignKey("companies.id"), nullable=False),
        sa.Column("project_id", sa.Integer, sa.ForeignKey("projects.id"), nullable=False),
        sa.Column("event_date", sa.Date, nullable=False),
        sa.Column("event_type", sa.String(40), nullable=False),
        sa.Column("title", sa.String(200), nullable=False),
        sa.Column("details", sa.Text),
        sa.Column("location_node_id", sa.Integer, sa.ForeignKey("site_location_nodes.id")),
        sa.Column("created_by_id", sa.Integer, sa.ForeignKey("users.id")),
        sa.Column("created_at", sa.DateTime, nullable=False),
    )

    op.create_table(
        "site_issues",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("company_id", sa.Integer, sa.ForeignKey("companies.id"), nullable=False),
        sa.Column("project_id", sa.Integer, sa.ForeignKey("projects.id"), nullable=False),
        sa.Column("issue_no", sa.String(60), nullable=False),
        sa.Column("title", sa.String(200), nullable=False),
        sa.Column("description", sa.Text),
        sa.Column("severity", sa.String(20), nullable=False),
        sa.Column("status", sa.String(30), nullable=False),
        sa.Column("due_date", sa.Date),
        sa.Column("location_node_id", sa.Integer, sa.ForeignKey("site_location_nodes.id")),
        sa.Column("assigned_to_id", sa.Integer, sa.ForeignKey("users.id")),
        sa.Column("created_by_id", sa.Integer, sa.ForeignKey("users.id")),
        sa.Column("resolved_at", sa.DateTime),
        sa.Column("created_at", sa.DateTime, nullable=False),
    )
    with op.batch_alter_table("site_issues", recreate="auto") as batch:
        batch.create_unique_constraint("uq_site_issue_no", ["company_id", "project_id", "issue_no"])

    op.create_table(
        "site_operations_plans",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("company_id", sa.Integer, sa.ForeignKey("companies.id"), nullable=False),
        sa.Column("project_id", sa.Integer, sa.ForeignKey("projects.id"), nullable=False),
        sa.Column("plan_date", sa.Date, nullable=False),
        sa.Column("title", sa.String(200), nullable=False),
        sa.Column("description", sa.Text),
        sa.Column("responsible_id", sa.Integer, sa.ForeignKey("users.id")),
        sa.Column("location_node_id", sa.Integer, sa.ForeignKey("site_location_nodes.id")),
        sa.Column("status", sa.String(30), nullable=False),
        sa.Column("created_by_id", sa.Integer, sa.ForeignKey("users.id")),
        sa.Column("created_at", sa.DateTime, nullable=False),
    )

    op.create_table(
        "site_progress_entries",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("company_id", sa.Integer, sa.ForeignKey("companies.id"), nullable=False),
        sa.Column("project_id", sa.Integer, sa.ForeignKey("projects.id"), nullable=False),
        sa.Column("progress_date", sa.Date, nullable=False),
        sa.Column("wbs_node_id", sa.Integer, sa.ForeignKey("construction_wbs_nodes.id")),
        sa.Column("boq_line_id", sa.Integer, sa.ForeignKey("construction_boq_lines.id")),
        sa.Column("location_node_id", sa.Integer, sa.ForeignKey("site_location_nodes.id")),
        sa.Column("planned_qty", sa.Numeric(20, 6), nullable=False, server_default="0"),
        sa.Column("actual_qty", sa.Numeric(20, 6), nullable=False, server_default="0"),
        sa.Column("notes", sa.Text),
        sa.Column("created_by_id", sa.Integer, sa.ForeignKey("users.id")),
        sa.Column("created_at", sa.DateTime, nullable=False),
    )


def downgrade():
    for table in [
        "site_progress_entries",
        "site_operations_plans",
        "site_issues",
        "site_diary_entries",
        "daily_site_reports",
        "site_location_nodes",
    ]:
        op.drop_table(table)
