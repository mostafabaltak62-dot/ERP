"""admin account management and dual approval password recovery"""
from alembic import op
import sqlalchemy as sa
revision='k2l3m4n5o6p7'; down_revision='j1k2l3m4n5o6'; branch_labels=None; depends_on=None

def upgrade():
    op.add_column('users', sa.Column('phone', sa.String(length=30), nullable=True))
    op.create_index('ix_users_phone', 'users', ['phone'], unique=True)
    op.create_table('password_reset_requests',
        sa.Column('id', sa.Integer(), primary_key=True), sa.Column('user_id', sa.Integer(), sa.ForeignKey('users.id', ondelete='CASCADE'), nullable=False),
        sa.Column('request_token_hash', sa.String(64), nullable=False), sa.Column('otp_hash', sa.String(64), nullable=False), sa.Column('otp_attempts', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('otp_expires_at', sa.DateTime(), nullable=False), sa.Column('expires_at', sa.DateTime(), nullable=False), sa.Column('delivery_channel', sa.String(10), nullable=False), sa.Column('delivery_target', sa.String(255), nullable=False),
        sa.Column('admin_approved_by', sa.Integer(), sa.ForeignKey('users.id'), nullable=True), sa.Column('admin_approved_at', sa.DateTime(), nullable=True),
        sa.Column('senior_approved_by', sa.Integer(), sa.ForeignKey('users.id'), nullable=True), sa.Column('senior_approved_at', sa.DateTime(), nullable=True),
        sa.Column('verified_at', sa.DateTime(), nullable=True), sa.Column('completed_at', sa.DateTime(), nullable=True), sa.Column('revoked_at', sa.DateTime(), nullable=True), sa.Column('created_at', sa.DateTime(), nullable=False))
    op.create_index('ix_password_reset_requests_user_id','password_reset_requests',['user_id'])
    op.create_index('ix_password_reset_requests_request_token_hash','password_reset_requests',['request_token_hash'],unique=True)
    op.create_index('ix_password_reset_requests_expires_at','password_reset_requests',['expires_at'])

def downgrade():
    op.drop_index('ix_password_reset_requests_expires_at', table_name='password_reset_requests'); op.drop_index('ix_password_reset_requests_request_token_hash', table_name='password_reset_requests'); op.drop_index('ix_password_reset_requests_user_id', table_name='password_reset_requests'); op.drop_table('password_reset_requests'); op.drop_index('ix_users_phone', table_name='users'); op.drop_column('users','phone')
