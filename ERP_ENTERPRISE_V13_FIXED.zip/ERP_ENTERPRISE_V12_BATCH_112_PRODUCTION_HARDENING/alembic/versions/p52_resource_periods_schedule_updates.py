"""Patch 52: schedule update governance and time-phased resource loading."""
from alembic import op
import sqlalchemy as sa
revision='p52_resource_periods_schedule_updates'; down_revision='p51_time_impact_schedule_health'; branch_labels=None; depends_on=None

def upgrade():
    op.create_table('construction_schedule_update_periods',
      sa.Column('id',sa.Integer(),primary_key=True),sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),sa.Column('status_date',sa.Date(),nullable=False),sa.Column('baseline_id',sa.Integer(),sa.ForeignKey('construction_schedule_baselines.id')),sa.Column('status',sa.String(30),nullable=False,server_default='open'),sa.Column('approved_by_id',sa.Integer(),sa.ForeignKey('users.id')),sa.Column('approved_at',sa.DateTime()),sa.Column('locked_by_id',sa.Integer(),sa.ForeignKey('users.id')),sa.Column('locked_at',sa.DateTime()),sa.Column('created_at',sa.DateTime(),nullable=False),sa.UniqueConstraint('project_id','status_date',name='uq_schedule_update_period_project_date'))
    for n in ('company_id','project_id','baseline_id'): op.create_index('ix_schedule_update_periods_'+n,'construction_schedule_update_periods',[n])
    op.create_table('construction_schedule_resource_periods',
      sa.Column('id',sa.Integer(),primary_key=True),sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),sa.Column('activity_id',sa.Integer(),sa.ForeignKey('construction_activities.id'),nullable=False),sa.Column('resource_id',sa.Integer(),sa.ForeignKey('construction_schedule_resources.id'),nullable=False),sa.Column('period_date',sa.Date(),nullable=False),sa.Column('planned_units',sa.Numeric(20,6),nullable=False,server_default='0'),sa.Column('actual_units',sa.Numeric(20,6),nullable=False,server_default='0'),sa.Column('planned_cost',sa.Numeric(20,6),nullable=False,server_default='0'),sa.Column('actual_cost',sa.Numeric(20,6),nullable=False,server_default='0'),sa.UniqueConstraint('project_id','resource_id','period_date',name='uq_schedule_resource_period'),sa.CheckConstraint('planned_units >= 0 AND actual_units >= 0 AND planned_cost >= 0 AND actual_cost >= 0',name='ck_schedule_resource_period_nonnegative'))
    for n in ('company_id','project_id','activity_id','resource_id'): op.create_index('ix_schedule_resource_periods_'+n,'construction_schedule_resource_periods',[n])

def downgrade():
    op.drop_table('construction_schedule_resource_periods'); op.drop_table('construction_schedule_update_periods')
