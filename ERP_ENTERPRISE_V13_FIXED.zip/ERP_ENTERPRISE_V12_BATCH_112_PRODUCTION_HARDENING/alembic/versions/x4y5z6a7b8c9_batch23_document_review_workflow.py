"""batch23 document review workflow"""
from alembic import op
import sqlalchemy as sa
revision='x4y5z6a7b8c9'
down_revision='w3x4y5z6a7b8'
branch_labels=None
depends_on=None

def upgrade():
    op.create_table('document_review_assignments',
        sa.Column('id',sa.Integer(),primary_key=True),sa.Column('company_id',sa.Integer(),nullable=False),sa.Column('document_id',sa.Integer(),nullable=False),sa.Column('revision_id',sa.Integer(),nullable=False),sa.Column('reviewer_id',sa.Integer(),nullable=False),sa.Column('reviewer_role',sa.String(length=120)),sa.Column('due_date',sa.Date()),sa.Column('status',sa.String(length=30),nullable=False,server_default='pending'),sa.Column('comments',sa.Text()),sa.Column('reviewed_at',sa.DateTime()),sa.Column('assigned_by_id',sa.Integer(),nullable=False),sa.Column('created_at',sa.DateTime(),nullable=False),sa.UniqueConstraint('revision_id','reviewer_id',name='uq_document_review_assignment'))
    op.create_index('ix_document_review_assignments_company_id','document_review_assignments',['company_id'])
    op.create_index('ix_document_review_assignments_document_id','document_review_assignments',['document_id'])
    op.create_table('document_review_comments',
        sa.Column('id',sa.Integer(),primary_key=True),sa.Column('company_id',sa.Integer(),nullable=False),sa.Column('document_id',sa.Integer(),nullable=False),sa.Column('revision_id',sa.Integer(),nullable=False),sa.Column('author_id',sa.Integer(),nullable=False),sa.Column('comment_text',sa.Text(),nullable=False),sa.Column('status',sa.String(length=30),nullable=False,server_default='open'),sa.Column('created_at',sa.DateTime(),nullable=False),sa.Column('resolved_at',sa.DateTime()),sa.Column('resolved_by_id',sa.Integer()))
    op.create_index('ix_document_review_comments_company_id','document_review_comments',['company_id'])
    op.create_index('ix_document_review_comments_document_id','document_review_comments',['document_id'])
def downgrade():
    op.drop_table('document_review_comments'); op.drop_table('document_review_assignments')
