"""Batch 25: controlled copies and revision register
Revision ID: d5e6f7a8b9c0
Revises: c2d3e4f5a6b7
"""
from alembic import op
import sqlalchemy as sa
revision='d5e6f7a8b9c0'
down_revision='c2d3e4f5a6b7'
branch_labels=None
depends_on=None

def upgrade():
    op.create_table('document_revision_register',sa.Column('id',sa.Integer(),primary_key=True),sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id',ondelete='CASCADE'),nullable=False),sa.Column('document_id',sa.Integer(),sa.ForeignKey('project_documents.id',ondelete='CASCADE'),nullable=False),sa.Column('revision_no',sa.Integer(),nullable=False),sa.Column('revision_reason',sa.Text()),sa.Column('supersedes_revision_id',sa.Integer(),sa.ForeignKey('document_revision_register.id')),sa.Column('issued_by_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False),sa.Column('issued_at',sa.DateTime(),nullable=False),sa.Column('is_current',sa.Boolean(),nullable=False,server_default=sa.true()),sa.Column('status',sa.String(length=30),nullable=False,server_default='issued'),sa.UniqueConstraint('company_id','document_id','revision_no',name='uq_document_revision_no'))
    op.create_index('ix_document_revision_register_company_id','document_revision_register',['company_id']);op.create_index('ix_document_revision_register_document_id','document_revision_register',['document_id'])
    op.create_table('controlled_document_copies',sa.Column('id',sa.Integer(),primary_key=True),sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id',ondelete='CASCADE'),nullable=False),sa.Column('document_id',sa.Integer(),sa.ForeignKey('project_documents.id',ondelete='CASCADE'),nullable=False),sa.Column('revision_no',sa.Integer(),nullable=False,server_default='0'),sa.Column('copy_no',sa.String(length=80),nullable=False),sa.Column('holder_user_id',sa.Integer(),sa.ForeignKey('users.id')),sa.Column('holder_name',sa.String(length=160)),sa.Column('issued_at',sa.DateTime(),nullable=False),sa.Column('acknowledged_at',sa.DateTime()),sa.Column('recalled_at',sa.DateTime()),sa.Column('status',sa.String(length=30),nullable=False,server_default='active'),sa.UniqueConstraint('company_id','document_id','copy_no',name='uq_controlled_copy_document_no'))
    op.create_index('ix_controlled_document_copies_company_id','controlled_document_copies',['company_id']);op.create_index('ix_controlled_document_copies_document_id','controlled_document_copies',['document_id'])

def downgrade():
    op.drop_table('controlled_document_copies');op.drop_table('document_revision_register')
