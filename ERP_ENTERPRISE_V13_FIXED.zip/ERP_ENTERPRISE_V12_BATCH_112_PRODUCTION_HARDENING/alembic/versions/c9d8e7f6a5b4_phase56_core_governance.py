"""Phase 5.6 ERP Core governance: documents, workflows and notifications."""
from alembic import op
import sqlalchemy as sa

revision = "c9d8e7f6a5b4"
down_revision = "b7c6d5e4f321"
branch_labels = None
depends_on = None

PERMISSIONS = [
    ("core:documents", "Manage ERP document attachments"),
    ("core:workflow", "Manage and execute ERP workflows"),
    ("core:notifications", "Send ERP notifications"),
]

def upgrade():
    bind = op.get_bind()
    perm = sa.table("permissions", sa.column("code", sa.String), sa.column("description", sa.String), sa.column("is_active", sa.Boolean))
    for code, desc in PERMISSIONS:
        op.execute(sa.text("INSERT INTO permissions(code, description, is_active) SELECT :c,:d,TRUE WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE code=:c)").bindparams(c=code,d=desc))
    insp=sa.inspect(bind)
    # Strengthen attachment tenancy/indexing and workflow lookup without changing public API.
    if "document_attachments" in insp.get_table_names():
        cols={c["name"] for c in insp.get_columns("document_attachments")}
        if "company_id" in cols:
            try: op.create_index("ix_attachment_entity_tenant", "document_attachments", ["company_id","entity_type","entity_id","version"])
            except Exception: pass
    if "workflow_definitions" in insp.get_table_names():
        try: op.create_index("ix_workflow_company_type", "workflow_definitions", ["company_id","document_type","is_active"])
        except Exception: pass
    if bind.dialect.name == "postgresql":
        for table in ("document_attachments","workflow_definitions","workflow_steps","workflow_instances","workflow_actions"):
            if table in insp.get_table_names() and "company_id" in {c["name"] for c in insp.get_columns(table)}:
                q='"'+table+'"'; policy=f"tenant_isolation_{table}"
                op.execute(f"ALTER TABLE {q} ENABLE ROW LEVEL SECURITY")
                op.execute(f"ALTER TABLE {q} FORCE ROW LEVEL SECURITY")
                op.execute(f"DROP POLICY IF EXISTS {policy} ON {q}")
                expr="company_id = NULLIF(current_setting('app.company_id', true), '')::integer"
                op.execute(f"CREATE POLICY {policy} ON {q} USING ({expr}) WITH CHECK ({expr})")

def downgrade():
    bind=op.get_bind(); insp=sa.inspect(bind)
    for table in ("document_attachments","workflow_definitions"):
        try: op.drop_index("ix_attachment_entity_tenant" if table=="document_attachments" else "ix_workflow_company_type", table_name=table)
        except Exception: pass
    if bind.dialect.name == "postgresql":
        for table in ("document_attachments","workflow_steps","workflow_instances","workflow_actions"):
            if table in insp.get_table_names():
                q='"'+table+'"'; op.execute(f"DROP POLICY IF EXISTS tenant_isolation_{table} ON {q}")
