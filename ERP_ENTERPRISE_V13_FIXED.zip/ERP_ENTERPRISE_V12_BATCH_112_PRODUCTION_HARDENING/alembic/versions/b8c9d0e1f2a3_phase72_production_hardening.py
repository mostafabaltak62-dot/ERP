"""Phase 7.2 production hardening.

Adds the indexes used by high-volume construction queries, closes PostgreSQL
RLS coverage for company-scoped tables introduced after Phase 4.1, and creates
PostgreSQL reporting materialized views for project-cost and current-EVM reads.
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import inspect, text

revision = "b8c9d0e1f2a3"
down_revision = "b7c8d9e0f1a2"
branch_labels = None
depends_on = None

INDEXES = {
    "project_costs": [("ix_project_costs_company_project_date", ["company_id", "project_id", "cost_date"])],
    "construction_evm_snapshots": [("ix_evm_snapshots_company_project_date", ["company_id", "project_id", "status_date"])],
    "construction_performance_alerts": [("ix_perf_alerts_company_project_status", ["company_id", "project_id", "status"])],
    "project_documents": [("ix_project_documents_company_project_type_status", ["company_id", "project_id", "document_type", "status"])],
    "project_document_revisions": [("ix_document_revisions_company_document_current", ["company_id", "document_id", "is_current"])],
    "daily_labor_entries": [("ix_daily_labor_company_project_date", ["company_id", "project_id", "work_date"])],
    "equipment_logs": [("ix_equipment_logs_company_project_date", ["company_id", "project_id", "work_date"])],
    "site_material_requisitions": [("ix_material_requisitions_company_project_status", ["company_id", "project_id", "status"])],
    "variation_orders": [("ix_variation_orders_company_project_status", ["company_id", "project_id", "status"])],
    "project_timesheets": [("ix_project_timesheets_company_project_date", ["company_id", "project_id", "work_date"])],
    "attendance_records": [("ix_attendance_company_employee_date", ["company_id", "employee_id", "work_date"])],
}


def _quote(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def _apply_indexes(bind) -> None:
    insp = inspect(bind)
    tables = set(insp.get_table_names())
    for table, definitions in INDEXES.items():
        if table not in tables:
            continue
        existing = {idx["name"] for idx in insp.get_indexes(table)}
        columns = {c["name"] for c in insp.get_columns(table)}
        for name, cols in definitions:
            if name in existing or not set(cols).issubset(columns):
                continue
            op.create_index(name, table, cols)


def _apply_postgres_rls(bind) -> None:
    if bind.dialect.name != "postgresql":
        return

    rows = bind.execute(text("""
        SELECT c.relname, EXISTS (
            SELECT 1 FROM pg_attribute a
            WHERE a.attrelid = c.oid AND a.attname = 'branch_id' AND NOT a.attisdropped
        ) AS has_branch
        FROM pg_class c
        JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE c.relkind = 'r' AND n.nspname = current_schema()
          AND EXISTS (
            SELECT 1 FROM pg_attribute a
            WHERE a.attrelid = c.oid AND a.attname = 'company_id' AND NOT a.attisdropped
          )
    """)).mappings().all()

    for row in rows:
        table = row["relname"]
        quoted = _quote(table)
        policies = bind.execute(
            text("SELECT policyname FROM pg_policies WHERE schemaname = current_schema() AND tablename = :table"),
            {"table": table},
        ).scalars().all()
        for policy in policies:
            if policy.startswith("tenant_isolation_") or policy.endswith("_tenant_isolation"):
                bind.execute(text(f"DROP POLICY IF EXISTS {_quote(policy)} ON {quoted}"))

        bind.execute(text(f"ALTER TABLE {quoted} ENABLE ROW LEVEL SECURITY"))
        bind.execute(text(f"ALTER TABLE {quoted} FORCE ROW LEVEL SECURITY"))
        if row["has_branch"]:
            expression = (
                "company_id = NULLIF(current_setting('app.company_id', true), '')::integer "
                "AND (branch_id IS NULL OR "
                "(NULLIF(current_setting('app.branch_id', true), '') IS NOT NULL "
                "AND branch_id = NULLIF(current_setting('app.branch_id', true), '')::integer))"
            )
        else:
            expression = "company_id = NULLIF(current_setting('app.company_id', true), '')::integer"
        policy = f"tenant_isolation_{table}"
        bind.execute(text(
            f"CREATE POLICY {_quote(policy)} ON {quoted} USING ({expression}) WITH CHECK ({expression})"
        ))


def _create_reporting_views(bind) -> None:
    if bind.dialect.name != "postgresql":
        return
    bind.execute(text("DROP MATERIALIZED VIEW IF EXISTS mv_project_cost_summary"))
    bind.execute(text("""
        CREATE MATERIALIZED VIEW mv_project_cost_summary AS
        SELECT company_id, project_id,
               SUM(amount) AS actual_cost,
               COUNT(*) AS cost_entries,
               MIN(cost_date) AS first_cost_date,
               MAX(cost_date) AS last_cost_date
        FROM project_costs
        GROUP BY company_id, project_id
    """))
    bind.execute(text("CREATE UNIQUE INDEX ux_mv_project_cost_summary ON mv_project_cost_summary(company_id, project_id)"))

    bind.execute(text("DROP MATERIALIZED VIEW IF EXISTS mv_project_evm_current"))
    bind.execute(text("""
        CREATE MATERIALIZED VIEW mv_project_evm_current AS
        SELECT DISTINCT ON (company_id, project_id)
               company_id, project_id, status_date, pv, ev, ac, bac,
               cpi, spi, cv, sv, eac, etc, vac, tcpi_bac, tcpi_eac
        FROM construction_evm_snapshots
        ORDER BY company_id, project_id, status_date DESC, id DESC
    """))
    bind.execute(text("CREATE UNIQUE INDEX ux_mv_project_evm_current ON mv_project_evm_current(company_id, project_id)"))


def upgrade() -> None:
    bind = op.get_bind()
    _apply_indexes(bind)
    _apply_postgres_rls(bind)
    _create_reporting_views(bind)


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        bind.execute(text("DROP MATERIALIZED VIEW IF EXISTS mv_project_evm_current"))
        bind.execute(text("DROP MATERIALIZED VIEW IF EXISTS mv_project_cost_summary"))
        insp = inspect(bind)
        for table in [r["relname"] for r in bind.execute(text("SELECT relname FROM pg_class WHERE relkind='r' AND relnamespace=current_schema()::regnamespace"))]:
            policies = bind.execute(
                text("SELECT policyname FROM pg_policies WHERE schemaname=current_schema() AND tablename=:table"),
                {"table": table},
            ).scalars().all()
            for policy in policies:
                if policy.startswith("tenant_isolation_"):
                    bind.execute(text(f"DROP POLICY IF EXISTS {_quote(policy)} ON {_quote(table)}"))
    for table, definitions in INDEXES.items():
        for name, _ in definitions:
            try:
                op.drop_index(name, table_name=table)
            except Exception:
                pass
