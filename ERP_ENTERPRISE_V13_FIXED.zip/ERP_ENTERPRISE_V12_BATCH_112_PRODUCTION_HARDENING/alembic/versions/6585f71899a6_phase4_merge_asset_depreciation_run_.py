"""phase4 merge: asset depreciation run tracking (fixes repeat-depreciation bug)

Revision ID: 6585f71899a6
Revises: c9d8e7f6a5b4
Create Date: 2026-08-24 22:15:30.818880
"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa


revision: str = '6585f71899a6'
down_revision: Union[str, Sequence[str], None] = 'c9d8e7f6a5b4'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table('asset_depreciation_runs',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('asset_id', sa.Integer(), nullable=False),
    sa.Column('period_label', sa.String(length=20), nullable=False),
    sa.Column('amount', sa.Numeric(precision=20, scale=6), nullable=False),
    sa.Column('journal_entry_id', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(), nullable=False),
    sa.ForeignKeyConstraint(['asset_id'], ['fixed_assets.id'], ),
    sa.ForeignKeyConstraint(['journal_entry_id'], ['journal_entries.id'], ),
    sa.PrimaryKeyConstraint('id'),
    sa.UniqueConstraint('asset_id', 'period_label', name='uq_asset_depreciation_period')
    )


def downgrade() -> None:
    op.drop_table('asset_depreciation_runs')
