"""close pre-existing financial foreign-key model/migration drift"""
from alembic import op

revision='m4n5o6p7q8r9'
down_revision='l3m4n5o6p7q8'
branch_labels=None
depends_on=None

FIXES = [
    ('bank_reconciliation_items', 'fk_bri_company_id', 'company_id', 'companies'),
    ('cost_centers', 'fk_cost_centers_project_id', 'project_id', 'projects'),
    ('fixed_asset_disposals', 'fk_fad_company_id', 'company_id', 'companies'),
    ('withholding_tax_rates', 'fk_wtr_company_id', 'company_id', 'companies'),
    ('withholding_tax_transactions', 'fk_wtt_company_id', 'company_id', 'companies'),
]

def upgrade():
    for table, name, column, ref_table in FIXES:
        with op.batch_alter_table(table, schema=None) as batch:
            batch.create_foreign_key(name, ref_table, [column], ['id'])

def downgrade():
    for table, name, column, ref_table in reversed(FIXES):
        with op.batch_alter_table(table, schema=None) as batch:
            batch.drop_constraint(name, type_='foreignkey')
