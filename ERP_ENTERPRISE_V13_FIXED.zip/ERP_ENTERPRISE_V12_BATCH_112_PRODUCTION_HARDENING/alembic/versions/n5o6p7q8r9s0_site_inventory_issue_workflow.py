"""Add warehouse-scoped site material issue workflow."""
from alembic import op
import sqlalchemy as sa

revision = "n5o6p7q8r9s0"
down_revision = "m4n5o6p7q8r9"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "warehouses",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id", ondelete="CASCADE"), nullable=False),
        sa.Column("branch_id", sa.Integer(), sa.ForeignKey("branches.id", ondelete="SET NULL"), nullable=True),
        sa.Column("code", sa.String(60), nullable=False),
        sa.Column("name", sa.String(180), nullable=False),
        sa.Column("warehouse_type", sa.String(30), nullable=False, server_default="branch"),
        sa.Column("project_id", sa.Integer(), sa.ForeignKey("projects.id", ondelete="SET NULL"), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.UniqueConstraint("company_id", "code", name="uq_warehouse_company_code"),
    )
    op.create_index("ix_warehouses_company_id", "warehouses", ["company_id"])
    op.create_index("ix_warehouses_branch_id", "warehouses", ["branch_id"])
    op.create_index("ix_warehouses_project_id", "warehouses", ["project_id"])
    with op.batch_alter_table("stock_movements") as b:
        b.add_column(sa.Column("warehouse_id", sa.Integer(), nullable=True))
        b.create_index("ix_stock_movements_warehouse_id", ["warehouse_id"])
        b.create_foreign_key("fk_stock_movements_warehouse", "warehouses", ["warehouse_id"], ["id"], ondelete="SET NULL")
    with op.batch_alter_table("site_material_issues") as b:
        b.add_column(sa.Column("warehouse_id", sa.Integer(), nullable=True))
        b.add_column(sa.Column("requisition_id", sa.Integer(), nullable=True))
        b.add_column(sa.Column("requisition_line_id", sa.Integer(), nullable=True))
        b.add_column(sa.Column("issued_by_id", sa.Integer(), nullable=True))
        b.create_index("ix_site_material_issues_warehouse_id", ["warehouse_id"])
        b.create_index("ix_site_material_issues_requisition_id", ["requisition_id"])
        b.create_index("ix_site_material_issues_requisition_line_id", ["requisition_line_id"])
        b.create_foreign_key("fk_site_issue_warehouse", "warehouses", ["warehouse_id"], ["id"], ondelete="SET NULL")
        b.create_foreign_key("fk_site_issue_requisition", "site_material_requisitions", ["requisition_id"], ["id"], ondelete="SET NULL")
        b.create_foreign_key("fk_site_issue_requisition_line", "site_material_requisition_lines", ["requisition_line_id"], ["id"], ondelete="SET NULL")
        b.create_foreign_key("fk_site_issue_issued_by", "users", ["issued_by_id"], ["id"], ondelete="SET NULL")

def downgrade():
    with op.batch_alter_table("site_material_issues") as b:
        for name in ["fk_site_issue_issued_by", "fk_site_issue_requisition_line", "fk_site_issue_requisition", "fk_site_issue_warehouse"]:
            b.drop_constraint(name, type="foreignkey")
        for name in ["ix_site_material_issues_requisition_line_id", "ix_site_material_issues_requisition_id", "ix_site_material_issues_warehouse_id"]:
            b.drop_index(name)
        for col in ["issued_by_id", "requisition_line_id", "requisition_id", "warehouse_id"]:
            b.drop_column(col)
    with op.batch_alter_table("stock_movements") as b:
        b.drop_constraint("fk_stock_movements_warehouse", type="foreignkey")
        b.drop_index("ix_stock_movements_warehouse_id")
        b.drop_column("warehouse_id")
    op.drop_index("ix_warehouses_project_id", table_name="warehouses")
    op.drop_index("ix_warehouses_branch_id", table_name="warehouses")
    op.drop_index("ix_warehouses_company_id", table_name="warehouses")
    op.drop_table("warehouses")
