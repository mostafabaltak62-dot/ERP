"""Batch 20 construction document specialized forms and decisions."""
from alembic import op
import sqlalchemy as sa
revision='v2w3x4y5z6b8'
down_revision='u1v2w3x4y5z6'
branch_labels=None
depends_on=None

def upgrade():
    op.create_table('construction_document_forms',
        sa.Column('id',sa.Integer(),primary_key=True),sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id',ondelete='CASCADE'),nullable=False),sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id',ondelete='CASCADE'),nullable=False),sa.Column('document_id',sa.Integer(),sa.ForeignKey('project_documents.id',ondelete='SET NULL')),sa.Column('form_type',sa.String(30),nullable=False),sa.Column('form_no',sa.String(100),nullable=False),sa.Column('title',sa.String(255),nullable=False),sa.Column('status',sa.String(30),nullable=False,server_default='draft'),sa.Column('submission_type',sa.String(30),nullable=False,server_default='new'),sa.Column('discipline',sa.String(80)),sa.Column('zone',sa.String(120)),sa.Column('level',sa.String(120)),sa.Column('issue_date',sa.Date()),sa.Column('due_date',sa.Date()),sa.Column('data_json',sa.Text(),nullable=False,server_default='{}'),sa.Column('contractor_representative',sa.String(160)),sa.Column('consultant_representative',sa.String(160)),sa.Column('current_revision',sa.Integer(),nullable=False,server_default='0'),sa.Column('created_by_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False),sa.Column('created_at',sa.DateTime(),nullable=False),sa.Column('updated_at',sa.DateTime(),nullable=False),sa.Column('closed_at',sa.DateTime()),sa.UniqueConstraint('company_id','form_no',name='uq_construction_document_form_company_no'))
    op.create_index('ix_construction_form_project_type_status','construction_document_forms',['project_id','form_type','status'])
    op.create_table('construction_document_form_decisions',sa.Column('id',sa.Integer(),primary_key=True),sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id',ondelete='CASCADE'),nullable=False),sa.Column('form_id',sa.Integer(),sa.ForeignKey('construction_document_forms.id',ondelete='CASCADE'),nullable=False),sa.Column('decision',sa.String(40),nullable=False),sa.Column('comments',sa.Text()),sa.Column('decided_by_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False),sa.Column('decided_at',sa.DateTime(),nullable=False),sa.Column('is_final',sa.Boolean(),nullable=False,server_default=sa.false()))
    op.create_index('ix_construction_document_form_decisions_form','construction_document_form_decisions',['form_id'])

def downgrade():
    op.drop_index('ix_construction_document_form_decisions_form',table_name='construction_document_form_decisions');op.drop_table('construction_document_form_decisions');op.drop_index('ix_construction_form_project_type_status',table_name='construction_document_forms');op.drop_table('construction_document_forms')
