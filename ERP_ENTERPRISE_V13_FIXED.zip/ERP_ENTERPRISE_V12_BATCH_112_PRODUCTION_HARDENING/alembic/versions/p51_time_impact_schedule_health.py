"""Patch 51: time impact analysis and schedule health governance."""
from alembic import op
import sqlalchemy as sa

revision='p51_time_impact_schedule_health'
down_revision=('p49_merge_all_heads','p49_planning_controls')
branch_labels=None
depends_on=None

def upgrade():
    op.create_table('construction_time_impact_analyses',
        sa.Column('id',sa.Integer(),primary_key=True),
        sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),
        sa.Column('project_id',sa.Integer(),sa.ForeignKey('projects.id'),nullable=False),
        sa.Column('delay_event_id',sa.Integer(),sa.ForeignKey('construction_schedule_delay_events.id'),nullable=False),
        sa.Column('baseline_id',sa.Integer(),sa.ForeignKey('construction_schedule_baselines.id'),nullable=True),
        sa.Column('status_date',sa.Date(),nullable=False),
        sa.Column('impacted_activity_id',sa.Integer(),sa.ForeignKey('construction_activities.id'),nullable=True),
        sa.Column('baseline_project_finish',sa.Date(),nullable=True),
        sa.Column('current_project_finish',sa.Date(),nullable=True),
        sa.Column('impacted_project_finish',sa.Date(),nullable=True),
        sa.Column('calculated_impact_days',sa.Integer(),nullable=False,server_default='0'),
        sa.Column('critical_path_impact',sa.Boolean(),nullable=False,server_default=sa.false()),
        sa.Column('analysis_method',sa.String(40),nullable=False,server_default='fragnet'),
        sa.Column('status',sa.String(30),nullable=False,server_default='draft'),
        sa.Column('approved_by_id',sa.Integer(),sa.ForeignKey('users.id')),
        sa.Column('approved_at',sa.DateTime()),
        sa.Column('notes',sa.Text()),
        sa.Column('created_by_id',sa.Integer(),sa.ForeignKey('users.id')),
        sa.Column('created_at',sa.DateTime(),nullable=False),
        sa.UniqueConstraint('project_id','delay_event_id',name='uq_tia_project_delay_event'),
        sa.CheckConstraint('calculated_impact_days >= 0',name='ck_tia_impact_days_nonnegative'))
    for n in ('company_id','project_id','delay_event_id','baseline_id','impacted_activity_id'):
        op.create_index('ix_construction_tia_'+n,'construction_time_impact_analyses',[n])

def downgrade():
    op.drop_table('construction_time_impact_analyses')
