"""Phase 84 — commercial completion and control layer."""
from typing import Sequence, Union
from alembic import op
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Numeric
from app.db_base import Base
from app import commercial_completion_models  # noqa: F401

revision: str = "u1v2w3x4y5z6"
down_revision: Union[str, Sequence[str], None] = "t1u2v3w4x5y6"
branch_labels = None
depends_on = None

def upgrade():
    bind=op.get_bind()
    from sqlalchemy import inspect
    insp=inspect(bind)
    additions={
        "sales_orders":[("warehouse_id",Column("warehouse_id",Integer)),("approval_status",Column("approval_status",String(30),nullable=False,server_default="approved"))],
        "sales_deliveries":[("warehouse_id",Column("warehouse_id",Integer))],
        "purchase_invoices":[("approval_status",Column("approval_status",String(30),nullable=False,server_default="approved")),("approval_request_id",Column("approval_request_id",Integer))],
        "purchase_orders":[("project_id",Column("project_id",Integer)),("approval_status",Column("approval_status",String(30),nullable=False,server_default="approved")),("approval_request_id",Column("approval_request_id",Integer))],
        "purchase_receipts":[("warehouse_id",Column("warehouse_id",Integer))],
        "purchase_invoice_lines":[("po_line_id",Column("po_line_id",Integer))],
    }
    for table, cols in additions.items():
        if table not in insp.get_table_names(): continue
        existing={x["name"] for x in insp.get_columns(table)}
        pending=[col for name,col in cols if name not in existing]
        if pending:
            with op.batch_alter_table(table, schema=None) as batch:
                for col in pending: batch.add_column(col)
    # Named foreign keys keep SQLite batch mode happy and preserve integrity on PostgreSQL.
    fk_specs=[
        ("sales_orders","fk_sales_orders_warehouse","warehouse_id","warehouses","id"),
        ("sales_deliveries","fk_sales_deliveries_warehouse","warehouse_id","warehouses","id"),
        ("purchase_invoices","fk_purchase_invoices_approval_request","approval_request_id","approval_requests","id"),
        ("purchase_orders","fk_purchase_orders_project","project_id","projects","id"),
        ("purchase_orders","fk_purchase_orders_approval_request","approval_request_id","approval_requests","id"),
        ("purchase_receipts","fk_purchase_receipts_warehouse","warehouse_id","warehouses","id"),
        ("purchase_invoice_lines","fk_purchase_invoice_lines_po","po_line_id","purchase_order_lines","id"),
    ]
    for table,name,col,ref_table,ref_col in fk_specs:
        with op.batch_alter_table(table, schema=None) as batch:
            try: batch.create_foreign_key(name,ref_table,[col],[ref_col],ondelete="SET NULL")
            except Exception: pass
    for name in [
        "customer_credit_policies","supplier_credit_policies","inventory_policies","budget_control_policies",
        "procurement_requests","procurement_request_lines","rfqs","rfq_suppliers","rfq_quotes","rfq_quote_lines","commercial_events"
    ]:
        Base.metadata.tables[name].create(bind=bind,checkfirst=True)

def downgrade():
    bind=op.get_bind()
    for name in reversed(["commercial_events","rfq_quote_lines","rfq_quotes","rfq_suppliers","rfqs","procurement_request_lines","procurement_requests","budget_control_policies","inventory_policies","supplier_credit_policies","customer_credit_policies"]):
        Base.metadata.tables[name].drop(bind=bind,checkfirst=True)
    for table,name in [("purchase_invoice_lines","po_line_id"),("purchase_receipts","warehouse_id"),("purchase_orders","approval_request_id"),("purchase_orders","approval_status"),("purchase_orders","project_id"),("purchase_invoices","approval_request_id"),("purchase_invoices","approval_status"),("sales_deliveries","warehouse_id"),("sales_orders","approval_status"),("sales_orders","warehouse_id")]:
        try: op.drop_column(table,name)
        except Exception: pass
