"""phase 5.4 production transaction integrity"""
from alembic import op
import sqlalchemy as sa

revision = "9e7f6a5b4c32"
down_revision = "8c4d5e6f7a91"
branch_labels = None
depends_on = None

def upgrade():
    # Batch mode keeps the migration portable to SQLite while emitting native
    # ALTER/constraint DDL on PostgreSQL.
    with op.batch_alter_table("finance_vouchers", recreate="auto") as batch:
        batch.add_column(sa.Column("idempotency_key", sa.String(length=180), nullable=True))
        batch.create_unique_constraint("uq_finance_voucher_company_idempotency", ["company_id", "idempotency_key"])
    op.create_index("ix_finance_vouchers_idempotency_key", "finance_vouchers", ["idempotency_key"])
    with op.batch_alter_table("payment_allocations", recreate="auto") as batch:
        batch.create_check_constraint("ck_payment_allocation_positive", "amount > 0")
    op.create_index("ix_payment_alloc_invoice", "payment_allocations", ["company_id", "sale_invoice_id", "purchase_invoice_id"])

def downgrade():
    op.drop_index("ix_payment_alloc_invoice", table_name="payment_allocations")
    with op.batch_alter_table("payment_allocations", recreate="auto") as batch:
        batch.drop_constraint("ck_payment_allocation_positive", type_="check")
    op.drop_index("ix_finance_vouchers_idempotency_key", table_name="finance_vouchers")
    with op.batch_alter_table("finance_vouchers", recreate="auto") as batch:
        batch.drop_constraint("uq_finance_voucher_company_idempotency", type_="unique")
        batch.drop_column("idempotency_key")
