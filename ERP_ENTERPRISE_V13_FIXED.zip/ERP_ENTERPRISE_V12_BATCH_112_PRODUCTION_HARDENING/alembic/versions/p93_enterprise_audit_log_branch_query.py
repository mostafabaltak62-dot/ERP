"""Patch 93 — enterprise audit log branch-aware query performance."""
from alembic import op

revision = "p93_enterprise_audit_log"
down_revision = "p83_financial_validation"
branch_labels = None
depends_on = None


def upgrade():
    op.create_index(
        "ix_governance_audit_logs_company_branch_created",
        "governance_audit_logs",
        ['company_id', 'branch_id', 'created_at', 'id'],
        unique=False,
    )


def downgrade():
    op.drop_index("ix_governance_audit_logs_company_branch_created", table_name="governance_audit_logs")
