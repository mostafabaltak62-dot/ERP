"""Patch 44 — New Purchase Order database integrity controls."""
from alembic import op
import sqlalchemy as sa

revision = "w11x22y33z44"
down_revision = "v10p43po_tenant"
branch_labels = None
depends_on = None


def upgrade():
    bind = op.get_bind()
    # Backfill legacy PO tenant ownership before making the parent document mandatory.
    bind.execute(sa.text("""
        UPDATE purchase_orders
        SET company_id = (
            SELECT s.company_id FROM suppliers s WHERE s.id = purchase_orders.supplier_id
        )
        WHERE company_id IS NULL
    """))
    remaining = bind.execute(sa.text("SELECT COUNT(*) FROM purchase_orders WHERE company_id IS NULL")).scalar()
    if remaining:
        raise RuntimeError(f"Cannot enforce purchase_orders.company_id NOT NULL; {remaining} rows remain unmapped")

    with op.batch_alter_table("purchase_orders") as batch:
        batch.alter_column("company_id", existing_type=sa.Integer(), nullable=False)

    # Database-level duplicate-line protection. Existing duplicates are rejected rather
    # than silently merged because automatic merging could change historical quantities.
    duplicates = bind.execute(sa.text("""
        SELECT company_id, po_id, item_id, COUNT(*) AS n
        FROM purchase_order_lines
        GROUP BY company_id, po_id, item_id
        HAVING COUNT(*) > 1
        LIMIT 1
    """)).first()
    if duplicates:
        raise RuntimeError(
            "Cannot add uq_po_line_company_po_item: duplicate purchase-order lines exist "
            f"for company={duplicates[0]}, po={duplicates[1]}, item={duplicates[2]}"
        )
    with op.batch_alter_table("purchase_order_lines") as batch:
        batch.create_unique_constraint("uq_po_line_company_po_item", ["company_id", "po_id", "item_id"])


def downgrade():
    with op.batch_alter_table("purchase_order_lines") as batch:
        batch.drop_constraint("uq_po_line_company_po_item", type_="unique")
    with op.batch_alter_table("purchase_orders") as batch:
        batch.alter_column("company_id", existing_type=sa.Integer(), nullable=True)
