"""branch-level finance ledgers and company consolidation support"""
from alembic import op
import sqlalchemy as sa

revision = 'l3m4n5o6p7q8'
down_revision = 'k2l3m4n5o6p7'
branch_labels = None
depends_on = None

TABLES = [
    'accounts', 'journal_entries', 'journal_lines', 'accounting_periods',
    'finance_vouchers', 'payment_allocations', 'bank_reconciliations',
    'bank_reconciliation_items', 'sale_invoices', 'purchase_orders', 'purchase_invoices'
]

def upgrade():
    for table in TABLES:
        with op.batch_alter_table(table, schema=None) as batch:
            batch.add_column(sa.Column('branch_id', sa.Integer(), nullable=True))
            batch.create_index(f'ix_{table}_branch_id', ['branch_id'])
            batch.create_foreign_key(f'fk_{table}_branch_id', 'branches', ['branch_id'], ['id'])
    with op.batch_alter_table('accounts', schema=None) as batch:
        batch.create_unique_constraint('uq_account_company_branch_code', ['company_id', 'branch_id', 'code'])


def downgrade():
    with op.batch_alter_table('accounts', schema=None) as batch:
        batch.drop_constraint('uq_account_company_branch_code', type_='unique')
    for table in reversed(TABLES):
        with op.batch_alter_table(table, schema=None) as batch:
            batch.drop_constraint(f'fk_{table}_branch_id', type_='foreignkey')
            batch.drop_index(f'ix_{table}_branch_id')
            batch.drop_column('branch_id')
