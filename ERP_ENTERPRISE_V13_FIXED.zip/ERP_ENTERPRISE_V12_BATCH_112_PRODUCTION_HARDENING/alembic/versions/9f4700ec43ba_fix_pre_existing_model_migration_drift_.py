"""fix pre-existing model/migration drift: notifications.branch_id and
workflow_instances.branch_id were present on the SQLAlchemy models in the
uploaded package but had never been migrated -- meaning a fresh deploy from
that migration chain would be missing these columns entirely the first time
code tried to read/write them. (The rest of the autogenerate diff for this
package was purely cosmetic server_default/index-name noise between
Python-side and DB-side defaults, not a real schema gap, so it is
intentionally NOT included here to avoid unrelated churn.)

Revision ID: 9f4700ec43ba
Revises: 6585f71899a6
Create Date: 2026-08-24 22:30:00.000000
"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa


revision: str = '9f4700ec43ba'
down_revision: Union[str, Sequence[str], None] = '6585f71899a6'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table('notifications') as batch_op:
        batch_op.add_column(sa.Column('branch_id', sa.Integer(), nullable=True))
        batch_op.create_index(batch_op.f('ix_notifications_branch_id'), ['branch_id'], unique=False)
        batch_op.create_foreign_key('fk_notifications_branch_id', 'branches', ['branch_id'], ['id'])

    with op.batch_alter_table('workflow_instances') as batch_op:
        batch_op.add_column(sa.Column('branch_id', sa.Integer(), nullable=True))
        batch_op.create_index(batch_op.f('ix_workflow_instances_branch_id'), ['branch_id'], unique=False)
        batch_op.create_foreign_key('fk_workflow_instances_branch_id', 'branches', ['branch_id'], ['id'])


def downgrade() -> None:
    with op.batch_alter_table('workflow_instances') as batch_op:
        batch_op.drop_constraint('fk_workflow_instances_branch_id', type_='foreignkey')
        batch_op.drop_index(batch_op.f('ix_workflow_instances_branch_id'))
        batch_op.drop_column('branch_id')

    with op.batch_alter_table('notifications') as batch_op:
        batch_op.drop_constraint('fk_notifications_branch_id', type_='foreignkey')
        batch_op.drop_index(batch_op.f('ix_notifications_branch_id'))
        batch_op.drop_column('branch_id')
