"""Patch 66 — inventory traceability and GL reconciliation."""
from alembic import op
import sqlalchemy as sa
revision='p66_inventory_traceability_reconciliation'
down_revision='p65_inventory_transaction_engine'
branch_labels=None
depends_on=None

def upgrade():
    op.create_table('inventory_traceability',
        sa.Column('id',sa.Integer(),primary_key=True),
        sa.Column('company_id',sa.Integer(),sa.ForeignKey('companies.id'),nullable=False),
        sa.Column('item_id',sa.Integer(),sa.ForeignKey('items.id'),nullable=False),
        sa.Column('stock_movement_id',sa.Integer(),sa.ForeignKey('stock_movements.id',ondelete='CASCADE'),nullable=False),
        sa.Column('serial_no',sa.String(length=120),nullable=True),
        sa.Column('lot_no',sa.String(length=120),nullable=True),
        sa.Column('expiry_date',sa.DateTime(),nullable=True),
        sa.Column('quantity',sa.Numeric(20,6),nullable=False),
        sa.Column('created_at',sa.DateTime(),nullable=False,server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.UniqueConstraint('company_id','item_id','stock_movement_id','serial_no',name='uq_inventory_trace_movement_serial'),
        sa.CheckConstraint('quantity > 0',name='ck_inventory_trace_positive_qty'))
    op.create_index('ix_inventory_trace_company','inventory_traceability',['company_id'])
    op.create_index('ix_inventory_trace_item','inventory_traceability',['item_id'])
    op.create_index('ix_inventory_trace_movement','inventory_traceability',['stock_movement_id'])
    op.create_index('ix_inventory_trace_expiry','inventory_traceability',['company_id','item_id','expiry_date'])
    op.create_index('ix_inventory_trace_lot_expiry','inventory_traceability',['company_id','item_id','lot_no','expiry_date'])

def downgrade():
    for n in ['ix_inventory_trace_lot_expiry','ix_inventory_trace_expiry','ix_inventory_trace_movement','ix_inventory_trace_item','ix_inventory_trace_company']:
        op.drop_index(n,table_name='inventory_traceability')
    op.drop_table('inventory_traceability')
