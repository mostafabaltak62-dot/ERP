"""Batch 29 item edit governance

Revision ID: a7b8c9d0e129
Revises: z6a7b8c9d0e1
"""
from alembic import op
import sqlalchemy as sa
revision='a7b8c9d0e129'
down_revision='z6a7b8c9d0e1'
branch_labels=None
depends_on=None

def upgrade():
    op.add_column('items', sa.Column('barcode', sa.String(length=100), nullable=True))
    op.create_index('ix_items_barcode', 'items', ['barcode'], unique=False)
    op.add_column('items', sa.Column('valuation_method', sa.String(length=30), nullable=False, server_default='weighted_average'))
    op.add_column('items', sa.Column('tax_rate', sa.Numeric(8,2), nullable=False, server_default='0'))
    op.add_column('items', sa.Column('track_serial', sa.Boolean(), nullable=False, server_default=sa.false()))
    op.add_column('items', sa.Column('track_expiry', sa.Boolean(), nullable=False, server_default=sa.false()))

def downgrade():
    op.drop_index('ix_items_barcode', table_name='items')
    op.drop_column('items','track_expiry'); op.drop_column('items','track_serial'); op.drop_column('items','tax_rate'); op.drop_column('items','valuation_method'); op.drop_column('items','barcode')
