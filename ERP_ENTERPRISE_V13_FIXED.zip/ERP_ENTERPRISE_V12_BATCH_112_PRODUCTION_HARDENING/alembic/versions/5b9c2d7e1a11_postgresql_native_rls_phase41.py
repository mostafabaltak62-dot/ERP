"""Add PostgreSQL native tenant RLS for all company-scoped tables.

Revision ID: 5b9c2d7e1a11
Revises: 31317df4a78e
"""
from alembic import op
from sqlalchemy import inspect

revision = "5b9c2d7e1a11"
down_revision = "31317df4a78e"
branch_labels = None
depends_on = None


def _tenant_tables(bind):
    insp = inspect(bind)
    out = []
    for table in insp.get_table_names():
        cols = {c["name"] for c in insp.get_columns(table)}
        if "company_id" in cols:
            out.append((table, "branch_id" in cols))
    return out


def upgrade():
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return
    for table, has_branch in _tenant_tables(bind):
        # Identifier quoting is delegated to PostgreSQL after strict inspection
        # of metadata-derived names; these are never user supplied.
        quoted = '"' + table.replace('"', '""') + '"'
        policy = "tenant_isolation_%s" % table
        op.execute(f"ALTER TABLE {quoted} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {quoted} FORCE ROW LEVEL SECURITY")
        op.execute(f"DROP POLICY IF EXISTS {policy} ON {quoted}")
        if has_branch:
            expr = (
                "company_id = NULLIF(current_setting('app.company_id', true), '')::integer "
                "AND branch_id IS NOT DISTINCT FROM "
                "NULLIF(NULLIF(current_setting('app.branch_id', true), ''), '-1')::integer"
            )
            # Branch-scoped rows must match the selected branch; company-wide
            # rows (branch_id NULL) are readable only if the model is explicitly
            # designed as company-wide. To fail closed for cross-branch data,
            # permit NULL branch rows but never another branch.
            expr = (
                "company_id = NULLIF(current_setting('app.company_id', true), '')::integer "
                "AND (branch_id IS NULL OR branch_id = NULLIF(current_setting('app.branch_id', true), '')::integer)"
            )
        else:
            expr = "company_id = NULLIF(current_setting('app.company_id', true), '')::integer"
        op.execute(
            f"CREATE POLICY {policy} ON {quoted} USING ({expr}) WITH CHECK ({expr})"
        )


def downgrade():
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return
    for table, _ in _tenant_tables(bind):
        quoted = '"' + table.replace('"', '""') + '"'
        policy = "tenant_isolation_%s" % table
        op.execute(f"DROP POLICY IF EXISTS {policy} ON {quoted}")
        op.execute(f"ALTER TABLE {quoted} NO FORCE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {quoted} DISABLE ROW LEVEL SECURITY")
