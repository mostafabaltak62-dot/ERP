"""Phase 5.1 end-to-end transaction workflows.

Adds sales orders/deliveries, purchase invoices, invoice financial totals,
and supplier payment allocation support.
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import inspect

revision = "6d2f8e1a9c77"
down_revision = "5b9c2d7e1a11"
branch_labels = None
depends_on = None


def _rls(bind, tables):
    if bind.dialect.name != "postgresql":
        return
    for table, has_branch in tables:
        q = '"' + table.replace('"','""') + '"'
        policy = f"tenant_isolation_{table}"
        op.execute(f"ALTER TABLE {q} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {q} FORCE ROW LEVEL SECURITY")
        op.execute(f"DROP POLICY IF EXISTS {policy} ON {q}")
        expr = "company_id = NULLIF(current_setting('app.company_id', true), '')::integer"
        if has_branch:
            expr += " AND (branch_id IS NULL OR branch_id = NULLIF(current_setting('app.branch_id', true), '')::integer)"
        op.execute(f"CREATE POLICY {policy} ON {q} USING ({expr}) WITH CHECK ({expr})")


def upgrade():
    op.create_table(
        "sales_orders",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id"), nullable=True),
        sa.Column("order_number", sa.String(30), nullable=False),
        sa.Column("customer_id", sa.Integer(), sa.ForeignKey("customers.id"), nullable=False),
        sa.Column("order_date", sa.DateTime(), nullable=False),
        sa.Column("status", sa.String(30), nullable=False, server_default="draft"),
        sa.Column("payment_method", sa.String(30), nullable=False, server_default="credit"),
        sa.Column("notes", sa.String(255)),
        sa.Column("created_by_id", sa.Integer(), sa.ForeignKey("users.id")),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("order_number", name="uq_sales_order_number"),
    )
    op.create_index("ix_sales_orders_company_id", "sales_orders", ["company_id"])
    op.create_index("ix_sales_orders_order_number", "sales_orders", ["order_number"])
    op.create_index("ix_sales_orders_status", "sales_orders", ["status"])

    op.create_table(
        "sales_order_lines",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id"), nullable=True),
        sa.Column("order_id", sa.Integer(), sa.ForeignKey("sales_orders.id", ondelete="CASCADE"), nullable=False),
        sa.Column("item_id", sa.Integer(), sa.ForeignKey("items.id"), nullable=False),
        sa.Column("quantity", sa.Numeric(20,6), nullable=False),
        sa.Column("unit_price", sa.Numeric(20,6), nullable=False),
        sa.Column("line_total", sa.Numeric(20,6), nullable=False),
        sa.Column("delivered_quantity", sa.Numeric(20,6), nullable=False, server_default="0"),
    )
    op.create_index("ix_sales_order_lines_company_id", "sales_order_lines", ["company_id"])

    op.create_table(
        "sales_deliveries",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id"), nullable=True),
        sa.Column("delivery_number", sa.String(30), nullable=False),
        sa.Column("order_id", sa.Integer(), sa.ForeignKey("sales_orders.id"), nullable=False),
        sa.Column("delivery_date", sa.DateTime(), nullable=False),
        sa.Column("status", sa.String(30), nullable=False, server_default="posted"),
        sa.Column("created_by_id", sa.Integer(), sa.ForeignKey("users.id")),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("delivery_number", name="uq_sales_delivery_number"),
    )
    op.create_index("ix_sales_deliveries_company_id", "sales_deliveries", ["company_id"])
    op.create_index("ix_sales_deliveries_delivery_number", "sales_deliveries", ["delivery_number"])

    op.create_table(
        "sales_delivery_lines",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id"), nullable=True),
        sa.Column("delivery_id", sa.Integer(), sa.ForeignKey("sales_deliveries.id", ondelete="CASCADE"), nullable=False),
        sa.Column("order_line_id", sa.Integer(), sa.ForeignKey("sales_order_lines.id"), nullable=False),
        sa.Column("item_id", sa.Integer(), sa.ForeignKey("items.id"), nullable=False),
        sa.Column("quantity", sa.Numeric(20,6), nullable=False),
        sa.Column("unit_cost", sa.Numeric(20,6), nullable=False),
        sa.Column("total_cost", sa.Numeric(20,6), nullable=False),
    )
    op.create_index("ix_sales_delivery_lines_company_id", "sales_delivery_lines", ["company_id"])

    op.create_table(
        "purchase_invoices",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id"), nullable=True),
        sa.Column("invoice_number", sa.String(40), nullable=False),
        sa.Column("supplier_id", sa.Integer(), sa.ForeignKey("suppliers.id"), nullable=False),
        sa.Column("po_id", sa.Integer(), sa.ForeignKey("purchase_orders.id")),
        sa.Column("receipt_id", sa.Integer(), sa.ForeignKey("purchase_receipts.id")),
        sa.Column("invoice_date", sa.DateTime(), nullable=False),
        sa.Column("subtotal", sa.Numeric(20,6), nullable=False, server_default="0"),
        sa.Column("discount_amount", sa.Numeric(20,6), nullable=False, server_default="0"),
        sa.Column("tax_amount", sa.Numeric(20,6), nullable=False, server_default="0"),
        sa.Column("total_amount", sa.Numeric(20,6), nullable=False, server_default="0"),
        sa.Column("status", sa.String(30), nullable=False, server_default="posted"),
        sa.Column("notes", sa.String(255)),
        sa.Column("created_by_id", sa.Integer(), sa.ForeignKey("users.id")),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("invoice_number", name="uq_purchase_invoice_number"),
    )
    op.create_index("ix_purchase_invoices_company_id", "purchase_invoices", ["company_id"])
    op.create_index("ix_purchase_invoices_invoice_number", "purchase_invoices", ["invoice_number"])
    op.create_index("ix_purchase_invoices_status", "purchase_invoices", ["status"])

    op.create_table(
        "purchase_invoice_lines",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("company_id", sa.Integer(), sa.ForeignKey("companies.id"), nullable=True),
        sa.Column("invoice_id", sa.Integer(), sa.ForeignKey("purchase_invoices.id", ondelete="CASCADE"), nullable=False),
        sa.Column("item_id", sa.Integer(), sa.ForeignKey("items.id"), nullable=False),
        sa.Column("quantity", sa.Numeric(20,6), nullable=False),
        sa.Column("unit_price", sa.Numeric(20,6), nullable=False),
        sa.Column("line_total", sa.Numeric(20,6), nullable=False),
    )
    op.create_index("ix_purchase_invoice_lines_company_id", "purchase_invoice_lines", ["company_id"])

    with op.batch_alter_table("sale_invoices", recreate="auto") as batch:
        batch.add_column(sa.Column("subtotal", sa.Numeric(20,6), nullable=False, server_default="0"))
        batch.add_column(sa.Column("discount_amount", sa.Numeric(20,6), nullable=False, server_default="0"))
        batch.add_column(sa.Column("tax_amount", sa.Numeric(20,6), nullable=False, server_default="0"))
        batch.add_column(sa.Column("total_amount", sa.Numeric(20,6), nullable=False, server_default="0"))
        batch.add_column(sa.Column("status", sa.String(30), nullable=False, server_default="posted"))
        batch.add_column(sa.Column("order_id", sa.Integer(), nullable=True))
        batch.add_column(sa.Column("delivery_id", sa.Integer(), nullable=True))
        batch.create_foreign_key("fk_sale_invoice_order", "sales_orders", ["order_id"], ["id"])
        batch.create_foreign_key("fk_sale_invoice_delivery", "sales_deliveries", ["delivery_id"], ["id"])
        batch.create_index("ix_sale_invoices_status", ["status"])

    # Backfill existing invoices from their lines without changing their accounting history.
    bind = op.get_bind()
    if bind.dialect.name == "sqlite":
        op.execute("UPDATE sale_invoices SET subtotal = COALESCE((SELECT SUM(line_total) FROM sale_invoice_lines l WHERE l.invoice_id = sale_invoices.id), 0), total_amount = COALESCE((SELECT SUM(line_total) FROM sale_invoice_lines l WHERE l.invoice_id = sale_invoices.id), 0)")
    else:
        op.execute("UPDATE sale_invoices si SET subtotal = COALESCE((SELECT SUM(line_total) FROM sale_invoice_lines l WHERE l.invoice_id = si.id), 0), total_amount = COALESCE((SELECT SUM(line_total) FROM sale_invoice_lines l WHERE l.invoice_id = si.id), 0)")

    with op.batch_alter_table("payment_allocations", recreate="auto") as batch:
        batch.add_column(sa.Column("purchase_invoice_id", sa.Integer(), nullable=True))
        batch.create_foreign_key("fk_payment_alloc_purchase_invoice", "purchase_invoices", ["purchase_invoice_id"], ["id"])
        batch.create_index("ix_payment_alloc_purchase_invoice", ["purchase_invoice_id"])

    _rls(bind, [
        ("sales_orders", False), ("sales_order_lines", False),
        ("sales_deliveries", False), ("sales_delivery_lines", False),
        ("purchase_invoices", False), ("purchase_invoice_lines", False),
    ])


def downgrade():
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        for table in ["sales_orders","sales_order_lines","sales_deliveries","sales_delivery_lines","purchase_invoices","purchase_invoice_lines"]:
            q='"'+table+'"'; policy=f"tenant_isolation_{table}"
            op.execute(f"DROP POLICY IF EXISTS {policy} ON {q}")
            op.execute(f"ALTER TABLE {q} NO FORCE ROW LEVEL SECURITY")
            op.execute(f"ALTER TABLE {q} DISABLE ROW LEVEL SECURITY")
    with op.batch_alter_table("payment_allocations", recreate="auto") as batch:
        batch.drop_index("ix_payment_alloc_purchase_invoice")
        batch.drop_constraint("fk_payment_alloc_purchase_invoice", type_="foreignkey")
        batch.drop_column("purchase_invoice_id")
    with op.batch_alter_table("sale_invoices", recreate="auto") as batch:
        batch.drop_index("ix_sale_invoices_status")
        batch.drop_constraint("fk_sale_invoice_order", type_="foreignkey")
        batch.drop_constraint("fk_sale_invoice_delivery", type_="foreignkey")
        for c in ["delivery_id","order_id","status","total_amount","tax_amount","discount_amount","subtotal"]:
            batch.drop_column(c)
    op.drop_table("purchase_invoice_lines")
    op.drop_table("purchase_invoices")
    op.drop_table("sales_delivery_lines")
    op.drop_table("sales_deliveries")
    op.drop_table("sales_order_lines")
    op.drop_table("sales_orders")
