"""expand user directory with employee profile fields"""
from alembic import op
import sqlalchemy as sa

revision = 'r9s0t1u2v3w4'
down_revision = 'q8r9s0t1u2v3'
branch_labels = None
depends_on = None

def upgrade():
    # batch mode keeps this migration portable to the project's SQLite test/dev
    # database while producing normal ALTER statements on PostgreSQL.
    with op.batch_alter_table('users', schema=None, recreate='auto') as batch:
        batch.add_column(sa.Column('employee_code', sa.String(length=40), nullable=True))
        batch.add_column(sa.Column('job_title', sa.String(length=120), nullable=True))
        batch.add_column(sa.Column('department', sa.String(length=120), nullable=True))
        batch.add_column(sa.Column('manager_user_id', sa.Integer(), nullable=True))
        batch.create_index('ix_users_employee_code', ['employee_code'], unique=True)
        batch.create_index('ix_users_department', ['department'], unique=False)
        batch.create_index('ix_users_manager_user_id', ['manager_user_id'], unique=False)
        batch.create_foreign_key('fk_users_manager_user_id', 'users', ['manager_user_id'], ['id'], ondelete='SET NULL')

def downgrade():
    with op.batch_alter_table('users', schema=None, recreate='auto') as batch:
        batch.drop_constraint('fk_users_manager_user_id', type_='foreignkey')
        batch.drop_index('ix_users_manager_user_id')
        batch.drop_index('ix_users_department')
        batch.drop_index('ix_users_employee_code')
        batch.drop_column('manager_user_id')
        batch.drop_column('department')
        batch.drop_column('job_title')
        batch.drop_column('employee_code')
