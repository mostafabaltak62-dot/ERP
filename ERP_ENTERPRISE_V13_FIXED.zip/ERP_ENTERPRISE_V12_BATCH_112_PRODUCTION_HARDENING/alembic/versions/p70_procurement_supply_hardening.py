"""Patch 70 procurement and supply workflow hardening."""
from alembic import op
import sqlalchemy as sa

revision = 'p70_procurement_supply_hardening'
down_revision = 'p69_inventory_policy_governance'
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table('procurement_requests', recreate='auto') as batch:
        batch.create_check_constraint('ck_proc_request_status', "status IN ('draft','submitted','rfq','closed','cancelled')")
        batch.create_check_constraint('ck_proc_request_priority', "priority IN ('normal','high','urgent')")
    with op.batch_alter_table('procurement_request_lines', recreate='auto') as batch:
        batch.create_unique_constraint('uq_proc_request_line_item', ['company_id','request_id','item_id'])
        batch.create_check_constraint('ck_proc_request_line_positive_qty', 'quantity > 0')
    with op.batch_alter_table('rfqs', recreate='auto') as batch:
        batch.create_check_constraint('ck_rfq_status', "status IN ('draft','issued','open','closed','cancelled')")
        batch.create_check_constraint('ck_rfq_due_after_issue', 'due_date IS NULL OR due_date >= issue_date')
    op.create_index('ix_purchase_order_company_branch_status', 'purchase_orders', ['company_id','branch_id','approval_status'])


def downgrade():
    op.drop_index('ix_purchase_order_company_branch_status', table_name='purchase_orders')
    with op.batch_alter_table('rfqs', recreate='auto') as batch:
        batch.drop_constraint('ck_rfq_due_after_issue', type_='check')
        batch.drop_constraint('ck_rfq_status', type_='check')
    with op.batch_alter_table('procurement_request_lines', recreate='auto') as batch:
        batch.drop_constraint('ck_proc_request_line_positive_qty', type_='check')
        batch.drop_constraint('uq_proc_request_line_item', type_='unique')
    with op.batch_alter_table('procurement_requests', recreate='auto') as batch:
        batch.drop_constraint('ck_proc_request_priority', type_='check')
        batch.drop_constraint('ck_proc_request_status', type_='check')
