"""Patch 83 — financial validation hardening and legacy cost-center index cleanup.

The baseline schema created a globally unique index on cost_centers.code. Patch
47 introduced company/branch scoped uniqueness but only removed a legacy
constraint name, leaving that index alive on fresh SQLite chains and causing
false cross-branch uniqueness failures. Remove the obsolete index safely.
"""
from alembic import op
import sqlalchemy as sa

revision = "p83_financial_validation"
down_revision = "p77_bank_statement_reconciliation_hardening"
branch_labels = None
depends_on = None


def _drop_index_if_present(table, name):
    bind = op.get_bind()
    names = {x.get("name") for x in sa.inspect(bind).get_indexes(table)}
    if name in names:
        op.drop_index(name, table_name=table)


def _rebuild_without_legacy_unique(table_name, model_table, legacy_column):
    bind = op.get_bind()
    if bind.dialect.name != "sqlite":
        return
    uniques = sa.inspect(bind).get_unique_constraints(table_name)
    if not any(u.get("column_names") == [legacy_column] for u in uniques):
        return
    from sqlalchemy.schema import CreateTable, CreateIndex
    tmp = f"_p83_{table_name}_new"
    bind.execute(sa.text(f'DROP TABLE IF EXISTS "{tmp}"'))
    ddl = str(CreateTable(model_table).compile(dialect=bind.dialect)).replace(f'CREATE TABLE {table_name}', f'CREATE TABLE "{tmp}"', 1)
    bind.execute(sa.text(ddl))
    cols = [c.name for c in model_table.columns]
    col_sql = ', '.join(f'"{c}"' for c in cols)
    bind.execute(sa.text(f'INSERT INTO "{tmp}" ({col_sql}) SELECT {col_sql} FROM "{table_name}"'))
    bind.execute(sa.text('PRAGMA foreign_keys=OFF'))
    bind.execute(sa.text(f'DROP TABLE "{table_name}"'))
    bind.execute(sa.text(f'ALTER TABLE "{tmp}" RENAME TO "{table_name}"'))
    bind.execute(sa.text('PRAGMA foreign_keys=ON'))
    for idx in model_table.indexes:
        bind.execute(sa.text(str(CreateIndex(idx).compile(dialect=bind.dialect))))


def upgrade():
    _drop_index_if_present("cost_centers", "ix_cost_centers_code")
    from app.models import TaxRate, FixedAsset
    _rebuild_without_legacy_unique("tax_rates", TaxRate.__table__, "code")
    _rebuild_without_legacy_unique("fixed_assets", FixedAsset.__table__, "asset_code")


def downgrade():
    bind = op.get_bind()
    names = {x.get("name") for x in sa.inspect(bind).get_indexes("cost_centers")}
    if "ix_cost_centers_code" not in names:
        op.create_index("ix_cost_centers_code", "cost_centers", ["code"], unique=True)
