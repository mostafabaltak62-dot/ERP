"""Patch 65 — authoritative inventory transaction engine governance."""
from alembic import op
import sqlalchemy as sa

revision='p65_inventory_transaction_engine'
down_revision='p64_inventory_items_governance'
branch_labels=None
depends_on=None

def upgrade():
    with op.batch_alter_table('stock_movements', recreate='auto') as batch:
        batch.add_column(sa.Column('operational_date', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')))
        batch.add_column(sa.Column('source_type', sa.String(length=60), nullable=True))
        batch.add_column(sa.Column('source_id', sa.Integer(), nullable=True))
        batch.add_column(sa.Column('transfer_id', sa.String(length=40), nullable=True))
        batch.add_column(sa.Column('reversal_of_id', sa.Integer(), nullable=True))
        batch.create_check_constraint('ck_stock_movement_nonnegative_unit_cost','unit_cost >= 0')
        batch.create_check_constraint('ck_stock_movement_nonnegative_total_cost','total_cost >= 0')
        batch.create_index('ix_stock_movement_company_item_wh_date',['company_id','item_id','warehouse_id','operational_date','id'])
        batch.create_index('ix_stock_movement_source',['company_id','source_type','source_id'])
        batch.create_index('ix_stock_movement_transfer',['company_id','transfer_id'])
        batch.create_foreign_key('fk_stock_movement_reversal','stock_movements',['reversal_of_id'],['id'],ondelete='SET NULL')
    with op.batch_alter_table('stock_movements', recreate='auto') as batch:
        batch.alter_column('operational_date', existing_type=sa.DateTime(), server_default=None)

def downgrade():
    with op.batch_alter_table('stock_movements', recreate='auto') as batch:
        batch.drop_constraint('fk_stock_movement_reversal', type_='foreignkey')
        batch.drop_index('ix_stock_movement_transfer')
        batch.drop_index('ix_stock_movement_source')
        batch.drop_index('ix_stock_movement_company_item_wh_date')
        batch.drop_constraint('ck_stock_movement_nonnegative_total_cost', type_='check')
        batch.drop_constraint('ck_stock_movement_nonnegative_unit_cost', type_='check')
        batch.drop_column('reversal_of_id'); batch.drop_column('transfer_id'); batch.drop_column('source_id'); batch.drop_column('source_type'); batch.drop_column('operational_date')
