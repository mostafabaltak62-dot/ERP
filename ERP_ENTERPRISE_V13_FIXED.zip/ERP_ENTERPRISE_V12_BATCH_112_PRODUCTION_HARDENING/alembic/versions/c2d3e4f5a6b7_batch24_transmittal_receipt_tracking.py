"""batch24 transmittal receipt tracking (SQLite/PostgreSQL safe)."""
from alembic import op
import sqlalchemy as sa
revision='c2d3e4f5a6b7'
down_revision=None
branch_labels=None
depends_on=None

def upgrade():
    op.add_column('document_transmittals', sa.Column('received_at', sa.DateTime(), nullable=True))
    op.add_column('document_transmittals', sa.Column('receipt_acknowledged_at', sa.DateTime(), nullable=True))
    op.add_column('document_transmittals', sa.Column('receipt_acknowledged_by_id', sa.Integer(), nullable=True))
    with op.batch_alter_table('document_transmittals', recreate='auto') as batch:
        batch.create_foreign_key('fk_document_transmittal_receipt_ack_user', 'users', ['receipt_acknowledged_by_id'], ['id'])

def downgrade():
    with op.batch_alter_table('document_transmittals', recreate='auto') as batch:
        batch.drop_constraint('fk_document_transmittal_receipt_ack_user', type_='foreignkey')
        batch.drop_column('receipt_acknowledged_by_id')
        batch.drop_column('receipt_acknowledged_at')
        batch.drop_column('received_at')
