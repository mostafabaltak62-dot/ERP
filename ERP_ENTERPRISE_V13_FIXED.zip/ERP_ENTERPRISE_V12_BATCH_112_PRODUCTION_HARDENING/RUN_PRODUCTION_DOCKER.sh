#!/usr/bin/env sh
set -eu
if [ ! -f .env ]; then
  cp .env.production.example .env
  echo 'Created .env from .env.production.example.'
  echo 'STOP: replace every CHANGE_ME value and configure ERP_ALLOWED_ORIGINS before starting production.'
  exit 1
fi
if grep -q 'CHANGE_ME' .env; then
  echo 'ERROR: .env still contains CHANGE_ME placeholder values.' >&2
  exit 1
fi
docker compose --env-file .env -f docker-compose.production.yml up --build -d
printf '\nProduction services started. Check status with:\n  docker compose --env-file .env -f docker-compose.production.yml ps\n'
