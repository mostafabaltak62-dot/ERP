# ERP Quality Gate

The release pipeline now blocks changes that introduce critical code-quality, security, dependency, or database-schema regressions.

## Mandatory checks

1. Python compilation.
2. Critical Ruff rules (`E9`, `F821`).
3. High-confidence/high-severity Bandit findings.
4. Dependency vulnerability audit with `pip-audit`.
5. Single Alembic migration head and duplicate-revision detection.
6. Fresh-database migration from an empty SQLite database.
7. Model/schema contract check for tables, columns, nullability, and foreign keys.
8. Pytest with `DeprecationWarning` treated as an error.

The schema gate intentionally compares the fresh migrated schema with the SQLAlchemy model contract rather than relying on Alembic's cosmetic `server_default` and index-name diff output. This keeps the gate focused on deploy-breaking drift.

## Local command

```bash
python scripts/quality_gate.py
pytest -q -W error::DeprecationWarning
```

CI additionally runs Ruff, Bandit, and pip-audit.
