"""Phase 5.5 production gate.

Run with DATABASE_URL pointing to a real PostgreSQL instance. The script fails
closed if PostgreSQL is not configured, so an unavailable database is never
reported as a passed security test.
"""
import os, sys
from sqlalchemy import create_engine, text

url = os.getenv("DATABASE_URL", "")
if not url.startswith("postgresql"):
    print("UNVERIFIED: DATABASE_URL is not PostgreSQL; native RLS/concurrency gate not executed.")
    sys.exit(2)

engine = create_engine(url, pool_pre_ping=True)
with engine.begin() as conn:
    version = conn.execute(text("select version()" )).scalar_one()
    required = ["items", "customers", "sale_invoices", "purchase_invoices", "projects", "contracts", "notifications", "idempotency_keys"]
    for table in required:
        r = conn.execute(text("select relrowsecurity, relforcerowsecurity from pg_class where oid = to_regclass(:t)"), {"t": table}).first()
        if not r or not r[0] or not r[1]:
            raise SystemExit(f"FAIL: RLS/FORCE RLS missing on {table}")
    conn.execute(text("select set_config('app.company_id','-999999',true)"))
    for table in required:
        count = conn.execute(text(f'SELECT count(*) FROM "{table}"')).scalar_one()
        if count != 0:
            raise SystemExit(f"FAIL: tenant fail-closed check returned {count} rows for {table}")
print("PASS: PostgreSQL RLS + FORCE RLS + fail-closed tenant isolation")
print(version)
