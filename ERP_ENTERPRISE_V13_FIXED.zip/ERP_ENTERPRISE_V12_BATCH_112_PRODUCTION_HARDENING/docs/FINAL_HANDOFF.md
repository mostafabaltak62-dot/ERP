# ERP V8 Final Handoff

## Product areas covered
Accounting, finance, sales, procurement, inventory, construction, BOQ/WBS, cost control, EVM/forecasting, HR/payroll, daily labor, equipment, documents, approvals, quality, maintenance, field operations, RBAC, multi-tenancy/RLS, offline sync foundation, webhooks, production deployment controls, CI quality/security gates, and the unified web UX shell.

## Web UX
The current release includes the shared ERP design system and the Construction Command Center. Existing business routes continue to use the shared shell and can be migrated incrementally without changing domain logic.

## Mobile
The Flutter mobile foundation is included in `mobile_app/`. Native Android/iOS signing and store packaging require the organization's Apple/Google signing credentials and platform build environments; those credentials are intentionally not embedded in the repository.

## Deployment
Use the production runbook in `docs/PHASE72_PRODUCTION_DEPLOYMENT_RUNBOOK.md`, run Alembic migrations in order, provision PostgreSQL RLS, Redis/RabbitMQ, persistent document storage, and execute the full test suite before release.
