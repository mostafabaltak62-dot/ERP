# Accounting Checklist — Applied to ERP V9

The attached checklist was converted into concrete ERP controls and screens. The implementation remains based on a **posted-journal source of truth** and is scoped by company/tenant.

## 1. Chart of Accounts + Daily Journals
- Hierarchical Chart of Accounts with parent/child accounts.
- Company-local account codes.
- Account edit/deactivation flow rather than destructive deletion of accounting history.
- Journal numbering through the sequence service.
- Double-entry validation before posting.
- Posted journals are immutable; corrections use reversals/adjustments.
- Journal source type/source id link to operational documents.
- Audit log entries for manual journal creation and financial actions.
- Manual journal screen now supports optional cost-centre allocation per line.

## 2. General Ledger + Trial Balance
- Posted journals only feed GL and financial statements.
- General Ledger supports opening balance and running balance.
- Trial Balance exposes opening, period movement and closing balance.
- Accounting control screen checks unbalanced posted journals.
- Orphan-account hygiene report identifies active leaf accounts with no posted activity.

## 3. AR / AP + Reconciliations
- AR and AP ageing buckets: current, 1–30, 31–60, 61–90, 90+.
- Customer and supplier statements.
- Subledger-to-GL reconciliation controls for receivables and payables.
- Bank reconciliation now stores statement lines in addition to the header reconciliation.
- Bank book balance is calculated from posted journals through the statement date and is company-scoped.

## 4. Cost Centres + Project Accounting
- Cost-centre master data is company scoped.
- Journal lines can be allocated to cost centres with an amount and calculated percentage.
- Allocation exceptions are surfaced by the accounting control report.
- Cost centres can optionally reference a project for analytical reporting.

## 5. Inventory Accounting + COGS
- Perpetual valuation layer engine.
- FIFO and weighted-average valuation methods.
- Negative valuation is blocked by default.
- COGS is driven by authoritative valuation cost on inventory issues/sales.
- Inventory valuation reconciliation compares movement value, remaining layers and consumed cost.
- Dedicated inventory reconciliation report is available from Accounting.

## 6. Fixed Assets + Depreciation
- Asset acquisition is linked to GL.
- Monthly depreciation is idempotent by asset/period.
- Accumulated depreciation is maintained separately.
- Residual value is supported.
- Fixed-asset disposal is now recorded with proceeds, net book value and gain/loss, with an automatic GL entry.

## 7. Tax Engine + Compliance
- VAT input and output accounts are separated.
- Tax transactions retain direction (input/output), taxable base and tax amount.
- Tax report calculates output VAT, input VAT and net VAT for a period.
- Withholding-tax rate master and transaction structures were added.
- Tax configuration now explicitly records input/output direction.

## 8. Financial Statements
- Trial Balance.
- General Ledger.
- Statement of Profit or Loss.
- Statement of Financial Position.
- Statement of Cash Flows.
- Statement of Changes in Equity.
- Automated validation of double-entry balance, balance-sheet equation and cash-flow reconciliation.
- Excel/PDF exports are available for the authoritative financial reports and the accounting control checklist.

## Standards mapping
The design is aligned to the project's accounting policy target:
- Egyptian Accounting Standards (EAS) as applicable to the entity.
- IFRS presentation principles, including IAS 1 / IFRS 18 transition considerations.
- IAS 7 — cash-flow classification and reconciliation.
- IAS 2 — inventory measurement and cost formulas.
- IAS 16 — property, plant and equipment and depreciation.
- IFRS 15 — revenue recognition principles.
- IAS 37 — provisions/contingencies where applicable.

This is an ERP control implementation, not a statutory audit opinion. Entity-specific EAS/IFRS policy decisions, tax treatment, revenue recognition, leases, provisions, financial instruments and disclosures still require management/auditor approval.

## Verification
- Python compilation: PASS.
- Accounting/financial/inventory targeted tests: **10 passed, 0 failed** after the checklist changes.
- Broader accounting suite: **18 passed, 0 failed**.
- Full repository suite: **88 passed, 3 failed**; the three failures are in pre-existing mobile/governance test fixtures and are unrelated to the accounting checklist changes.
- Application health smoke test: `/health/live` PASS, `/health/ready` PASS.
- New Alembic head: `h8i9j0k1l2m3`.
