# Patch 78 — Enterprise Control Center Deep Audit

## Baseline
Patch 77 — Bank Statement Reconciliation Production Hardened.

## Scope
Deep production audit of the Enterprise Control Center and its related governance/procurement/credit/budget data paths, including tenant and branch isolation, permissions, workflow integrity, auditability, performance, UI status visibility, and regression/migration safety.

## Findings & Fixes
1. **Branch isolation gap in the control-center dashboard** — approval requests, procurement requests, projects, and dashboard counters were company-scoped only. They are now branch-scoped when a branch is selected, while company-wide records remain visible where their model has no branch ownership.
2. **Approval center branch leakage** — approval requests are now filtered by current branch (or unassigned/company-wide rows).
3. **Procurement workspace branch leakage** — requests are now filtered by branch; supplier/item lists are scoped where their schema supports branch ownership and safely remain company-wide where it does not.
4. **Credit dashboard consistency** — active customer policies are loaded once; customer balances respect the current branch when branch context exists.
5. **Procurement audit trail modernization** — legacy `AuditLog` writes for Procurement Request and RFQ creation were replaced with tenant-aware `GovernanceAuditLog` records carrying company, branch, user, entity and reason context.
6. **Dashboard observability** — added budget-alert count and explicit branch-context status indicator so management can distinguish company-wide from branch-scoped views.
7. **Performance hardening** — avoided repeated credit-policy lookups per customer in the control-center dashboard by building a policy map once.

## Security / Integrity
- Company context remains mandatory.
- Branch-aware reads include only current branch and explicitly unassigned records.
- Existing route-level module permissions remain enforced.
- Existing write-side company/branch validations remain intact.
- No new cross-tenant write path introduced.

## Validation
- Targeted regression tests: **10 passed, 0 failed**.
- Python compilation: **PASS**.
- Fresh SQLite database migration from empty state to Alembic head: **PASS**.
- Alembic head after baseline: **single head (`p77_bank_statement_reconciliation_hardening`)**.
- Full pytest run reached **64%** before the execution environment timeout; no assertion failure was reported in the executed portion, so this is **not** claimed as a full-suite pass.

## Release
Patch 78 is the hardened Enterprise Control Center release built directly from Patch 77.
