# Branch & Company Management UI

## Scope

The ERP now exposes `/admin/organization` for users with `admin:tenants`.

### Company controls
- Create company (with automatic `MAIN` branch).
- Edit company legal/name/tax/base currency data.
- Activate/deactivate companies without deleting historical records.

### Branch controls
- Create, edit, activate and deactivate branches under the selected company.
- Branch codes are unique within a company.
- New branches automatically receive management access for active administrators of that company.

### User branch access
- Explicit branch-level `UserCompanyAccess` can be granted or revoked.
- `can_manage` is separately controlled.
- Active administrators retain company-wide management scope.
- Users do not inherit access to a branch merely because the branch exists.

### Consolidation contract
Every branch-aware financial/operational transaction should carry `company_id` and `branch_id` where applicable. Reports can therefore filter by branch or consolidate at company level.

### Safety
- Branch/company deletion is intentionally not offered; deactivation preserves audit and accounting history.
- Cross-company management is rejected unless the administrator has the appropriate company scope.
- Endpoint access is enforced by `admin:tenants` and the central HTTP permission policy.
