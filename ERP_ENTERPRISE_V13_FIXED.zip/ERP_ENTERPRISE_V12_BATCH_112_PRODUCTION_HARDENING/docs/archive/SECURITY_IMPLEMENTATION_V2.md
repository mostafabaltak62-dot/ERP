# Security & Integrity Implementation V2

Implemented controls requested in the security/financial/offline-performance brief:

- Mandatory `DATABASE_URL`, `JWT_SECRET_KEY`, `ENCRYPTION_KEY`; startup fails closed when missing/placeholder.
- SQLAlchemy global company/branch criteria via `Session.do_orm_execute` for mapped models exposing `company_id`.
- JWT `jti` revocation in Redis (with bounded local fallback for development), plus per-user authorization-version invalidation after role/permission/profile changes.
- Logout revokes both access and refresh tokens.
- Posted journal entries/lines are immutable at ORM level and PostgreSQL trigger level; corrections use reversal entries.
- Positive stock quantities enforced by ORM model and DB CHECK constraint.
- Item-row pessimistic locks serialize stock balance changes; cash/bank account rows are locked during balance-changing journal creation.
- Financial Trial Balance and General Ledger use grouped aggregate queries instead of per-account N+1 queries.
- Uploads enforce size, extension, magic-byte signature, sanitized names and UUID storage names.
- Jinja templates retain autoescaping; untrusted text is validated for length/control characters rather than HTML-escaped before storage.
- Mobile/API bearer authentication remains compatible with the existing Authorization header flow; tenant context is resolved server-side and headers are never trusted as grants.

## Production prerequisites

Use PostgreSQL and Redis in production. Set the required secrets through the process environment/secret manager; do not commit `.env`. Run `alembic upgrade head` before starting the application.
