# Patch 99 — New Manual Journal Deep Audit & Production Hardening

## Scope
Deep audit of the New Manual Journal page and its posting path, including UI validation, tenant/branch isolation, accounting-period governance, account/cost-center scope, balancing, immutability, audit trail, and regression compatibility.

## Findings fixed
- Added governed company/branch selection to the journal form.
- Restricted account choices and server-side account validation to the selected tenant/branch; global accounts remain usable from an allowed branch.
- Restricted cost-center choices and server-side validation to the selected tenant/branch.
- Fixed line-metadata alignment when a blank/zero row exists before a populated row.
- Added strict finite/non-negative monetary validation and one-sided debit/credit validation.
- Added description/reference/line-description length validation.
- Added explicit accounting-period requirement for manual UI posting; closed or missing periods are rejected.
- Preserved atomic posting through the authoritative `create_entry()` service.
- Preserved double-entry balance enforcement and posted-entry immutability.
- Prevented branch cross-scope journal detail access.
- Kept CSRF/security controls in the global application middleware path.
- Hardened cost-center allocation in the shared accounting service against cross-branch assignments.

## Validation
- Patch 99 focused tests: **3/3 PASS**
- Accounting core + period governance + security integrity + HTTP regression + Patch 99: **20/20 PASS**
- Python compilation: **PASS**
- Fresh SQLite Alembic upgrade to head: **PASS**
- Alembic heads: **single head `p93_enterprise_audit_log`**
- No schema migration required for Patch 99.

## Release note
Manual journals created through the UI now require an explicitly configured open accounting period. This is intentional posting governance; lower-level/system workflows retain their existing period bootstrap behavior.
