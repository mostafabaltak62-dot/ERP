# BATCH 57 — Stock Movement Ledger Deep Audit & Production Hardening

## Scope
Audited and hardened the Inventory Stock Movement Ledger at `/inventory/stock-ledger` from Patch 56 baseline.

## Findings and fixes
- Tenant/company scope enforced on every ledger and export query.
- Selected Item and Warehouse are validated against the current company; cross-tenant identifiers cannot be used to inspect data.
- Invalid movement types return HTTP 400 instead of leaking a server error.
- Invalid date input is rejected with a controlled HTTP 400 response.
- Reversed date ranges are rejected.
- Opening/running balances are derived from authoritative StockMovement rows rather than cached stock values.
- Movement-type filtering is intentionally excluded from balance-seed calculations so an inbound-only/outbound-only report does not corrupt the displayed balance.
- Running balance remains continuous across pagination, including rows sharing the same timestamp, using `(created_at, id)` ordering.
- Pagination added with bounded page sizes to avoid unbounded HTML result sets.
- Ledger KPI totals added for inbound, outbound, net quantity, and movement count.
- Warehouse and item names are resolved within the active company only; raw warehouse IDs are no longer the primary UI presentation.
- CSV export added with the same tenant and filter validation as the visible ledger.
- Ledger UI upgraded with clear filters, KPI cards, pagination, export, and post-movement balance.

## Security / integrity
- Existing inventory RBAC (`require_module("inventory")`) retained.
- No cross-company Item/Warehouse lookup is permitted.
- No write capability was added to the ledger itself.
- The ledger remains read-only and auditable.

## Tests
- Targeted Stock Ledger + material-flow + security integrity tests: **9 passed**.
- Full regression suite reached **171 passed** before the runner teardown/process completed; the execution environment still exhibits the previously observed post-test hang/timeout behavior. No test failure was observed before teardown.
- Python compilation: **PASS**.

## Important remaining architectural observation
`StockMovement` still permits `warehouse_id = NULL` and uses a creation timestamp as its operational date. This batch makes the ledger safe and auditable with the current data model, but a future inventory-control phase should introduce an immutable movement/document date, source document references, transfer IDs, reversal governance, and warehouse-required rules where business policy requires them.

## Baseline
Patch 56 → Patch 57
