# Patch 71 — Source-of-Truth Deep Audit & Remediation

## Baseline
Revalidated the physically available Patch 70 Rebuilt artifact. No reliance was placed on prior release claims without checking the actual source and tests.

## Verified prior requested fixes
- Command Center authentication: VERIFIED. Command Center routes depend on `construction:view`, tenant context, and project scope checks; targeted UI regression passes.
- Accounting/auth rate-limit regression: VERIFIED. Browser `/login` uses the account+IP login limiter; API auth paths are classified by the global middleware without a second route-level limiter. Targeted security/HTTP regression passes.
- Mobile login fixture/bootstrap admin: VERIFIED. Bootstrap creates the configured admin only when absent and never overwrites an existing account; mobile login regression passes.
- Inventory Policy & Valuation: VERIFIED. Company default policy is used to seed an item-level authoritative valuation policy when no explicit item policy exists; FIFO/weighted-average/standard methods are recognized by the valuation engine.
- Migration `recreate='always'`: VERIFIED absent from all Alembic revisions; portability scan passes.

## Additional defects found and fixed during this audit
1. **Direct stock-movement valuation chronology defect.** `on_stock_movement()` used `created_at` when creating valuation layers/consumptions, which could corrupt historical valuation ordering when operational date differs from insertion time. It now uses `operational_date or created_at` for both inbound and outbound valuation events.
2. **Standard-cost rebuild inconsistency.** `rebuild_item()` rejected `standard` even though the authoritative valuation engine supports standard cost. The rebuild validation now accepts `standard`.
3. **Fresh SQLite migration blocker in historical Batch 26.** Three direct `op.create_unique_constraint()` calls were not portable to SQLite. They were converted to Alembic batch operations, removing the blocker discovered after Batch 24.

## QA
- Targeted security/auth/mobile/Command Center/inventory valuation/procurement regression: **26/26 PASS**.
- Python compilation: **PASS**.
- Migration portability scan: **PASS (78 revisions)**.
- Full pytest collection/execution was attempted. The suite progressed to approximately **71%** before the environment execution ceiling terminated the process; no assertion failure was emitted in the completed portion. This is **not** reported as a full-suite pass.

## Important remaining validation
A fresh SQLite migration should be rerun end-to-end after Patch 71 to prove the complete historical chain beyond Batch 26. The current portability scan is static and does not substitute for that runtime migration test.

## Release assessment
Patch 71 is a stronger source-of-truth baseline than Patch 70 Rebuilt because it re-verifies the requested historical fixes and closes three additional integrity/portability gaps found during the second audit.
