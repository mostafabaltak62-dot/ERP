# BATCH 47 — Tax Report Deep Audit & Production Hardening

## Scope
Deep audit of `/pro-finance/tax-report` as an Enterprise production tax/VAT reporting surface.

## Findings and fixes
1. **Accounting-period correctness (High):** report previously filtered `TaxTransaction.created_at`, which can differ from the accounting date. Report now uses the linked posted `JournalEntry.entry_date`; unposted/draft journal-backed tax transactions are excluded. Transactions without a journal use their creation timestamp as a controlled fallback.
2. **Tenant isolation (Critical):** report now requires a valid company context and filters both `TaxTransaction.company_id` and `TaxRate.company_id` to the active company, preventing cross-company tax-rate joins.
3. **Date-boundary bug (High):** replaced inclusive end-of-day comparisons with an exclusive next-day boundary, preventing microsecond/timezone edge cases from dropping or double-counting transactions.
4. **Invalid date range (Medium):** reversed date ranges now fail with HTTP 400 instead of returning misleading empty reports.
5. **Scalability (Medium):** removed unbounded date query risk from the old `<= end_of_day` pattern and added deterministic ordering; future very-large datasets should be paginated/exported through a dedicated reporting store if required.
6. **Traceability (High):** detail rows expose the linked journal entry ID and summary is grouped by tax rate + direction.
7. **Export (Medium):** added UTF-8 BOM CSV export with `nosniff` and the same authorization/tenant/date predicate as the screen report.
8. **UX/RTL:** added explicit date filters, clear net VAT wording, transaction count, rate-level summary, and CSV action while retaining the existing RTL ERP shell.

## Security review
- RBAC remains protected by `require_module("accounting")`.
- Company context fails closed when absent.
- No user-supplied SQL or dynamic query fragments are used.
- CSV export reuses the exact report data predicate, avoiding a weaker export path.

## Tests
- Targeted tax-report + adjacent regression tests: **12 passed**.
- Full regression suite: **155 passed, 0 failed**.
- Python compileall: **PASS**.
- Security audit: **PASS** — no dynamic SQL construction or hard-coded DB URLs detected in `app/`.

## Production note
The report is a VAT/tax transaction report, not a jurisdiction-specific statutory return. Local Egyptian VAT filing rules, tax authority schemas, withholding tax, reverse charge, exempt/zero-rated supplies, credit notes and official e-invoicing requirements should be mapped as separate compliance policies rather than inferred by the generic report.
