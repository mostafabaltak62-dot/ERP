# PATCH 73 — Tax Management Deep Audit & Production Hardening

## Scope
Deep audit of Tax Management (`/pro-finance/taxes`) and its downstream tax-reporting and posting paths. Review covered UI, RBAC, tenant/branch isolation, tax master governance, historical reporting integrity, VAT transaction creation, legacy tax endpoint, database model constraints, migration graph, and regression tests.

## Findings fixed
1. **Tax master governance** — added validated create/update/toggle workflows with strict company/branch scope and accounting-account validation.
2. **Historical tax integrity** — tax transactions now snapshot applied rate, code, name, and tax account so later master edits cannot rewrite historical reporting.
3. **Branch traceability** — added `TaxTransaction.branch_id` and backfill from the originating journal entry where available; tax reporting branch filters now operate against a real persisted field.
4. **Tax master integrity** — model-level checks enforce 0–100 rate and valid input/output direction; transaction amounts and applied rate are non-negative/in-range.
5. **Post-use master protection** — once a tax rate is used, code/account/direction cannot be changed; a new master must be created for a semantic change.
6. **Legacy enterprise tax endpoint** — company/branch scoped invoice/rate lookup, duplicate protection, and rejection of re-taxing invoices that already contain tax.
7. **Auditability** — tax master create/update/activate/deactivate operations generate audit records.
8. **UI** — management page now exposes status and controlled edit/deactivate actions with explicit historical-integrity guidance.
9. **Migration governance** — tax migration added and migration heads merged to a single head. During fresh-chain verification, historical SQLite portability defects were found and corrected in Batch 39, Patch 58, Patch 62, and Patch 63.

## Validation
- Python compilation: PASS
- Targeted Tax + HTTP + Inventory regression: **13/13 PASS** on a clean test database
- Alembic heads: **single head — `p74_merge_tax_procurement`**
- Full suite: execution progressed substantially but hit the environment execution timeout before completion; no assertion failure was observed in the timed run. This is not reported as a full-suite pass.

## Important architectural note
Tax reporting is now materially safer, but jurisdiction-specific filing logic (for example Egyptian VAT return boxes, e-invoice/e-receipt integration, withholding certificates, tax periods, filing submissions, and statutory reconciliation) remains a separate business capability and should not be inferred merely from generic VAT master/report support.

## Baseline
This release is the Tax Management hardening baseline built on Patch 72.
