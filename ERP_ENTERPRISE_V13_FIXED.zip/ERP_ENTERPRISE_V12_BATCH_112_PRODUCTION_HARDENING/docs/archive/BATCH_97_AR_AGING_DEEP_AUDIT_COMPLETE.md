# Patch 97 — Accounts Receivable Aging — Deep Audit & Production Hardening

## Baseline
Patch 96 — Add Accounting Account Production Hardened.

## Scope
Deep production audit of **أعمار الذمم المدينة / Accounts Receivable Aging**, including the authoritative AR aging engine, posted-invoice eligibility, as-of payment/return behavior, due-date policy, branch/company isolation, customer filtering, UI/RTL reporting, exports, API parity, performance, and regression safety.

## Critical findings fixed
1. **AR aging had an incomplete reporting surface**: the page showed invoice numbers but not customer names, invoice dates, original receivable, paid, returns, outstanding, or overdue amount consistently. The report was rebuilt around a full receivable-aging dataset.
2. **AR overdue KPI was incorrect/disabled**: the previous shared aging template showed `—` for AR overdue totals. It now calculates overdue outstanding balances from `overdue_days > 0`.
3. **AR due date was hidden in the UI**: the backend calculated due dates, but the AR table displayed `—`. The due date is now displayed and exported.
4. **No AR export route existed**: dedicated XLSX and PDF exports were added, preserving as-of date, branch, and customer scope.
5. **Customer filtering was missing**: a tenant-scoped customer filter was added to the UI and export path.
6. **Branch leakage risk in payments**: payment allocations were company-scoped but their allocation/voucher branch could disagree with the invoice branch. AR aging now ignores branch-inconsistent allocations, while allowing legacy NULL branch records as company-global history.
7. **N+1 query pattern**: payment allocations, sales returns, and customer credit policies were previously queried per invoice. They are now batch-loaded and grouped in memory.
8. **Malformed overpayment/return data could produce negative outstanding balances**: outstanding is clamped at zero and fully settled invoices are omitted.
9. **API parity was weak**: the deep-transactions AR aging endpoint previously exposed only company-wide, current-time data. It now accepts as-of date, authorized branch, and customer scope and returns those scopes explicitly.
10. **Historical policy limitation made explicit**: due dates use the currently active customer credit policy because the existing schema has no historical policy snapshot. The UI/report note states this limitation rather than implying historical policy reconstruction.

## Accounting integrity
- Only `SaleInvoice.status == posted` invoices effective by the as-of date are eligible.
- Payments count only when their finance voucher date is effective by the as-of date.
- Payment allocation and voucher branch must match the invoice branch, or be NULL for legacy/global records.
- Posted sales returns effective by the as-of date reduce the invoice receivable.
- Customer payment terms determine due date.
- All financial arithmetic remains Decimal-based.
- Company/branch/customer filters are validated inside the current tenant context.

## Verification
- AR + AP + accounting/reporting + deep transaction + Patch 96 regression slice: **18/18 PASS**.
- Python compileall: **PASS**.
- Jinja template parse: **PASS**.
- UI/API route registration: **PASS**.
- Alembic heads: **single head — `p93_enterprise_audit_log`**.
- Fresh SQLite `alembic upgrade head`: **PASS**.
- No new schema migration required; Patch 97 is application/reporting hardening only.

## Full-suite note
The full repository pytest was started and reached approximately **26% before the execution environment timeout**, with no assertion failure shown in the executed portion. It is **not claimed as a full-suite pass**.

## Release decision
**APPROVED — Patch 97**

The AR aging page is now a production reporting surface backed by the authoritative posted receivables engine, with customer/branch/as-of controls, consistent exports, and explicit data-quality/accounting limitations.
