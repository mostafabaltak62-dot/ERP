# BATCH 108 — Executive Dashboard Deep Audit & Functional Hardening

## Scope
Deep audit of the Executive Dashboard shown in the supplied screenshot, including tenant isolation, branch/project scope, KPI correctness, EVM correctness, approvals, activity visibility, performance, navigation, and executable functionality.

## Findings fixed

### Critical — tenant fallback risk
The dashboard previously derived the company from `user.company_id`, then access rows, then fell back to the first active company. The fallback could expose another tenant's dashboard data when access was incomplete.

**Fix:** Dashboard now requires `get_tenant_context`; there is no arbitrary-company fallback.

### High — project KPI undercount
Projects were limited to 12 before totals were calculated. Companies with more than 12 projects received incorrect Project Count, Project Value and Actual Cost.

**Fix:** All visible projects are used for KPI calculations; only the UI display is limited by the template.

### High — project scope was not enforced
The old dashboard queried every project in the company without applying project/site scope rules.

**Fix:** Every dashboard project passes `scope_allows` for the current user.

### High — branch context was ignored
Resolved branch context was not consistently applied to projects, approvals, and audit activity.

**Fix:** Branch-aware filtering is applied while retaining company-wide (`NULL branch`) records where appropriate.

### High — EVM portfolio data was mathematically misleading
The dashboard called the section “portfolio aggregate” while using the latest snapshot from one arbitrary project.

**Fix:** Latest snapshot per visible project is selected and portfolio CPI/SPI are calculated from aggregate EV/AC and EV/PV. EAC and VAC are aggregated across visible projects.

### Medium — N+1 cost query
Actual cost was queried once per project.

**Fix:** Costs are aggregated in one grouped query by project.

### Medium — approval count could be misleading
The old count showed all pending company approvals even if the current user could not act on them.

**Fix:** The dashboard counts only branch-valid pending requests whose current approval step permission is available to the current user.

### Medium — hardcoded company name
The sidebar always displayed “الشركة الرئيسية”.

**Fix:** The resolved current company name is rendered dynamically.

### Medium — export button was non-functional
“تصدير التقرير” was a button without an action.

**Fix:** Added `/dashboard/export.csv`, exporting only the current user's resolved tenant and visible project scope.

### Medium — “New Project” action did not open a creation workflow
The button pointed to the command center.

**Fix:** Added `/projects/new` GET/POST with validation for company, branch, customer, unique project code, non-negative budget and `construction:manage` authorization.

### Medium — governance quick link could expose an unavailable page
The workspace card linked to `/users` for every user although the route is restricted.

**Fix:** Governance workspace card is shown only to admins.

### Known UX limitation retained for compatibility
The Document Control workspace still routes through the existing Project Command Center because the current application has no standalone HTML Document Control landing route. A new fake route was intentionally not introduced.

## Verification
- `python -m compileall -q app` — PASS
- Deep dashboard/EVM/HTTP regression test selection — PASS
- Result: **8 passed**

The HTTP verification covered:
- authenticated dashboard rendering
- resolved company display
- tenant-safe CSV export
- new-project page rendering
- existing HTTP regression coverage

## Release outcome
Dashboard metrics are now tenant-safe, branch-aware, project-scope-aware, mathematically consistent for portfolio EVM, and backed by executable export and project-creation workflows.
