# Phase 6.2 — Construction Commercial & Accounting Integration

## Scope
This phase connects construction commercial documents to the authoritative accounting engine.

### Client progress certificates
Approved certificates are posted atomically through `create_entry()`:
- Dr Accounts Receivable (net due)
- Dr Customer Retention Receivable
- Dr Customer Advances (advance recovery)
- Cr Construction/Project Revenue

A certificate cannot be posted without a valid customer contract. Advance recovery is consumed from open customer advances in FIFO-by-date order and is locked during posting.

### Customer advances
- Received customer advance: Dr Cash / Cr Customer Advances.
- Recovery is posted against the customer-advance liability and updates the advance subledger.
- Every advance stores its source journal.

### Subcontractor progress certificates
Approved subcontractor certificates are posted as:
- Dr Project/Construction Cost (gross less deductions)
- Cr Accounts Payable (net payable)
- Cr Subcontractor Retention Payable
- Cr Supplier/Contractor Advances for advance recovery
- Deductions reduce the recognized project cost according to the configured deduction treatment.

Subcontractor advance recovery consumes open payable advances with row locking.

## New accounting defaults
- `1210` Customer Retention Receivable
- `1400` Supplier/Contractor Advances
- `2300` Customer Advances
- `2310` Subcontractor Retention Payable

## Integrity controls
- Posted journal entries are created only through the existing accounting engine.
- Source-based journal idempotency is retained.
- Closed accounting periods remain enforced by the accounting engine.
- All financial operations remain company-scoped.
- Advance recovery cannot exceed the outstanding advance balance.
- Progress certificate posting is locked at the certificate row.
- Subcontractor certificate posting is locked at the certificate row.

## API additions
- Progress certificate accepts optional `contract_id`.
- Existing approval endpoint now posts the certificate to GL.
- Customer/subcontractor advances create their accounting entry immediately.
- New endpoint: `POST /api/v1/construction/subcontractor-progress/{progress_id}/approve`.

## Database
Migration: `8b9c0d1e2f34`

Changes include journal linkage and approval metadata for:
- `progress_certificates`
- `construction_advances`
- `subcontractor_progress`

SQLite-compatible batch migration is used.

## Verification
- Construction regression tests: 7 passed.
- Full non-HTTP regression suite: 56 passed.
- Fresh Alembic migration to HEAD: passed; 112 tables created.
- HTTP runtime remains an environment gate when `bcrypt` is unavailable.
- PostgreSQL native RLS runtime remains an environment gate until a real PostgreSQL server is available.
