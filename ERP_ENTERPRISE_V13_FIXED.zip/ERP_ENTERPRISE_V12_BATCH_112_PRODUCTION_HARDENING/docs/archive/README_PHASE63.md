# ERP Accounting System V8 — Phase 6.3

Construction Cost Control & Subcontractor Management.

This release extends Phase 6.2 into a full project cost-control chain:

**Budget → Commitment → Actual → Forecast/ETC → EAC → Project Profitability → Cash Flow**

and:

**Subcontractor BOQ → Measurements → Certificates → Retention → Advances → Deductions → AP → Project Actual Cost**

## Delivered

- Project cost budget lines by cost code / WBS / BOQ.
- Commitment ledger with contract and subcontractor BOQ traceability.
- Subcontractor measurement register and line-level quantities.
- Measurement approval gate before certificate creation.
- Subcontractor certificates can be generated directly from approved measurements.
- Certificate-to-measurement line traceability.
- Retention payable, advance recovery, and deductions remain separate accounting treatments.
- Posted subcontractor certificates create authoritative `ProjectCost` actuals equal to gross certified value less commercial deductions.
- Forecast/ETC register and calculated EAC.
- Project cost-control summary: Budget, Commitment, Actual, ETC, EAC, variance and committed exposure.
- Subcontractor commercial-control summary.
- Project profitability directly consumes EAC and certified revenue.
- Cash-flow summary now exposes retention and advance balances alongside operational outflows.
- Company/tenant scoping and existing permission model preserved.

## New API

- `POST /api/v1/construction/cost-control/budgets`
- `POST /api/v1/construction/cost-control/commitments`
- `POST /api/v1/construction/cost-control/forecasts`
- `POST /api/v1/construction/subcontractor-measurements`
- `POST /api/v1/construction/subcontractor-measurements/{measurement_id}/approve`
- `POST /api/v1/construction/subcontractor-progress/from-measurement`
- `GET /api/v1/construction/projects/{project_id}/cost-control`
- `GET /api/v1/construction/projects/{project_id}/profitability`
- `GET /api/v1/construction/projects/{project_id}/cash-flow-v63`
- `GET /api/v1/construction/projects/{project_id}/subcontractors/{contract_id}/control`

## Accounting / control logic

For an approved subcontractor certificate:

- Dr Construction Cost = gross less commercial deductions
- Cr Accounts Payable = net payable
- Cr Subcontractor Retention Payable = retention
- Cr Supplier/Contractor Advances = advance recovery
- Deductions reduce recognized project cost according to the Phase 6.2 configured treatment.

The operational actual-cost subledger receives a `ProjectCost` row linked to the certificate, making EAC and profitability consume the same authoritative actual.

## Migration

`9c0d1e2f3a45` — Phase 6.3 construction cost control and subcontractor management.

Fresh Alembic migration to HEAD was verified successfully on SQLite: **118 tables**, HEAD `9c0d1e2f3a45`.

## Verification

- Phase 6.3 tests: **3 passed**.
- Existing construction/accounting regression set: **17 passed**.
- Full suite remains blocked only by the existing environment dependency `bcrypt` missing during HTTP test collection.
- Alembic `check` still reports pre-existing schema/index/default drift in the uploaded project; it is not treated as a Phase 6.3 migration failure.
