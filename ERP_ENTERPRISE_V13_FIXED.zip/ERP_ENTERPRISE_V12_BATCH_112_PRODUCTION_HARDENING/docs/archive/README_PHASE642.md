# Phase 6.4.2 — Performance Alerts, Thresholds & Forecast Governance

Adds governed EVM alerts and corrective-action lifecycle on top of Phase 6.4.1.

## Alert metrics
- CPI: warning/critical thresholds
- SPI: warning/critical thresholds
- VAC %: warning/critical thresholds
- TCPI(EAC): required-efficiency warning

## Lifecycle
`open -> acknowledged -> resolved`

Alerts are deterministic per `project + status_date + alert_type + metric` and are linked to the EVM snapshot.

## APIs
- `POST /api/v1/construction/projects/{project_id}/performance-alerts/evaluate`
- `GET /api/v1/construction/projects/{project_id}/performance-alerts`
- `POST /api/v1/construction/performance-alerts/{alert_id}/acknowledge`
- `POST /api/v1/construction/performance-alerts/{alert_id}/resolve`

## Migration
`c3d4e5f6a7b8_phase642_performance_governance.py`

## Regression
Phase 6.4.2 + Phase 6.4.1 + Phase 6.4 focused tests: **3/3 passed**.
