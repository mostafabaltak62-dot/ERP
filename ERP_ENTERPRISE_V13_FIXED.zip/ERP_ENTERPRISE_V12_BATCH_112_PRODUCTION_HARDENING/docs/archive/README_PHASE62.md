# ERP Accounting V8 — Phase 6.2

Construction Commercial & Accounting Integration.

Base: Phase 6.1 Construction Site Operations.

This release connects client progress certificates, customer advances, subcontractor progress certificates and subcontractor advances to the authoritative accounting engine with journal traceability, advance recovery controls, tenant scoping, and regression tests.
