# Phase 6.7 — Enterprise Construction Document Controller

## Purpose
Central controlled repository and register for project documents, submittals, drawings, material approvals, inspections, correspondence, minutes and handover records.

## Supported document types
DRAWING, SHOP_DRAWING, MATERIAL, MATERIAL_SUBMITTAL, SIR, MIR, MT, DOC, RFI, NCR, METHOD_STATEMENT, ITP, TEST_REPORT, LETTER_IN, LETTER_OUT, MINUTES, HANDOVER, DELIVERY_NOTE, APPROVAL, OTHER.

## Core lifecycle
`Draft → Submitted → Under Review → Approved / Approved With Comments / Rejected → Closed`

## Controlled records
- Document Register with project/site/WBS/BOQ/cost-code linkage.
- Immutable revision history with revision code, checksum, file size and uploader.
- SHA-256 file integrity verification.
- Project Document Register and Dashboard.
- Transmittals with current-revision capture, recipient, purpose and response tracking.
- Approval decisions and comments per revision.
- Distribution and acknowledgement records.
- Due dates, overdue reporting and status metrics.

## Construction integration
Documents can be linked directly to Contract, Site, WBS, BOQ Line, Cost Code, Item/Material, Equipment, Purchase Order, Measurement, Progress Certificate, Subcontractor Progress, Site Material Issue, Equipment Usage and Labor Entry.

## Storage
Binary files are stored outside the relational database. The database stores metadata and a SHA-256 checksum. Configure `ERP_DOCUMENT_STORAGE_PATH` to select the storage root and `ERP_DOCUMENT_MAX_BYTES` to set the maximum upload size (default 50 MiB).

## Security
- Tenant/company scoped records.
- Project/site scope enforcement through the existing RBAC middleware.
- Dedicated permissions: `documents:view`, `documents:create`, `documents:edit`, `documents:approve`.
- File path normalization and storage-root containment checks on download.
- Extension allow-list and configurable file-size limit.

## API surface
- `POST /api/v1/document-controller/documents`
- `GET /api/v1/document-controller/documents`
- `GET /api/v1/document-controller/documents/{id}`
- `POST /api/v1/document-controller/documents/{id}/revisions`
- `GET /api/v1/document-controller/documents/{id}/revisions/{revision_id}/download`
- `POST /api/v1/document-controller/documents/{id}/status`
- `POST /api/v1/document-controller/documents/{id}/revisions/{revision_id}/approve`
- `POST /api/v1/document-controller/transmittals`
- `GET /api/v1/document-controller/transmittals`
- `POST /api/v1/document-controller/transmittals/{id}/response`
- `POST /api/v1/document-controller/documents/{id}/distribute`
- `POST /api/v1/document-controller/documents/{id}/acknowledge`
- `GET /api/v1/document-controller/projects/{project_id}/register`
- `GET /api/v1/document-controller/projects/{project_id}/dashboard`
