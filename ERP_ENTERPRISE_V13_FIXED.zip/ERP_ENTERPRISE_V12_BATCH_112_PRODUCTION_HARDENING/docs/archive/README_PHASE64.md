# ERP Accounting System V8 — Phase 6.4

## Construction Planning, EVM & Advanced Forecasting

Phase 6.4 extends Phase 6.3 from cost control into time-phased construction performance management.

### Core chain

`WBS → Activities → Schedule Baseline → Time-Phased Budget → PV → EV → AC → CPI/SPI → EAC/ETC → VAC/TCPI`

### Delivered

- Construction activities linked to Project, WBS and optional BOQ line.
- Schedule baseline and activity baseline tables.
- Status-date progress periods.
- Activity earned-progress register with earned value.
- Time-phased budget / planned value register.
- EVM calculation service exposing PV, EV, AC, BAC, CPI, SPI, CV, SV, EAC, ETC, VAC and TCPI.
- CPI-based and CPI×SPI forecast methods, plus manual ETC-based EAC.
- Persisted EVM snapshots for period-over-period performance reporting.
- New planning and EVM API endpoints under `/api/v1/construction`.
- Existing Phase 6.3 actual-cost ledger remains authoritative for AC.
- Tenant/company scoping preserved.

### EVM rules

`CPI = EV / AC`

`SPI = EV / PV`

`CV = EV - AC`

`SV = EV - PV`

`EAC(CPI) = BAC / CPI`

`EAC(CPI×SPI) = AC + (BAC - EV) / (CPI × SPI)`

`ETC = max(EAC - AC, 0)`

`VAC = BAC - EAC`

`TCPI(BAC) = (BAC - EV) / (BAC - AC)`

`TCPI(EAC) = (BAC - EV) / (EAC - AC)`

Zero denominators return zero rather than producing an invalid ratio.

### New API

- `POST /api/v1/construction/planning/activities`
- `POST /api/v1/construction/planning/baselines`
- `POST /api/v1/construction/planning/progress-periods`
- `POST /api/v1/construction/planning/progress`
- `POST /api/v1/construction/planning/time-phased-budget`
- `GET /api/v1/construction/projects/{project_id}/evm?status_date=YYYY-MM-DD&forecast_method=cpi`
- `POST /api/v1/construction/projects/{project_id}/evm/snapshot`

### Migration

`a1b2c3d4e5f6` — Phase 6.4 construction planning, EVM and advanced forecasting.

### Verification

- Phase 6.3 regression: **3 passed**.
- Phase 6.4 EVM chain: **1 passed**.
- Combined targeted verification: **4 passed**.
