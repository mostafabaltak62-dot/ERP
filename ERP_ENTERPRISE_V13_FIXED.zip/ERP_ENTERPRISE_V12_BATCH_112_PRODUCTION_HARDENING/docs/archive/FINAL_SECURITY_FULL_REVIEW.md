# ERP Full Security / Integrity Review — Release V3.1

Date: 2026-08-27

## Scope

Full source review of authentication, authorization/RBAC, tenant/company/branch isolation, SQL safety, document handling, password recovery, API governance, deployment checks, migrations, and regression tests.

## Findings fixed

1. **Password-recovery endpoints were not in the strict authentication rate-limit bucket.**
   - Added `/forgot-password/request`, `/forgot-password/verify`, `/forgot-password/complete` to the 5/min/IP authentication bucket.
   - Added `/api/v1/mobile/auth/refresh` to the strict authentication bucket.
   - Recovery requests now revoke older active recovery transactions for the same account before issuing a new one, reducing OTP spam and stale-token accumulation.

2. **Deep transaction reconciliation had an authorization mismatch.**
   - `POST /api/v1/deep-transactions/reconcile` was centrally classified as `reports:view`, despite being a state-changing accounting operation.
   - It is now governed by `journal:post`.

3. **Cross-tenant writes could be attempted through APIs that accepted `company_id` in request data.**
   - Added ORM-level defense-in-depth in the tenant `before_flush` hook.
   - Explicit `company_id` must match the authenticated tenant context.
   - Explicit `branch_id` must match the active branch context when a branch context is selected.
   - This protects all ORM writes, including endpoints whose request schemas contain client-supplied company IDs.

4. **Project/contract branch consistency was strengthened.**
   - Project creation cannot target a different branch from the active branch context.
   - Contract references cannot point to a project outside the active branch context.

5. **Notification recipient integrity was strengthened.**
   - Notification recipients must exist, be active, and have company access matching the current company.

6. **Production API documentation exposure was hardened.**
   - Swagger/OpenAPI/ReDoc remain available in development.
   - They are disabled automatically when `ERP_ENV=production`.

7. **Production deployment preflight was stale.**
   - The expected migration revision was still pointing to the previous release.
   - Updated to the current release head `r9s0t1u2v3w4` and synchronized the production runbook.

## Validation

- Security audit: PASS
- Quality gate: PASS
- Python compilation: PASS
- Regression/security suites: PASS
- Total tests executed across the complete suite: **109/109 PASS**

The 109 tests were executed in isolated groups because one single long-running pytest invocation exceeded the execution window; the complete collected test set was covered by the successful grouped runs.

## Security controls confirmed

- bcrypt password hashing in production requirements.
- Password policy: 12+ chars, upper/lower/numeric.
- JWT access tokens with short expiry.
- Rotating hashed refresh tokens with replay protection.
- HTTP-only SameSite cookies.
- IP-based authentication/API rate limiting with Redis support for multi-instance deployments.
- Same-origin protection for cookie-authenticated state changes.
- Security headers including CSP, frame denial, MIME sniffing protection and HSTS in production.
- SQL construction audit: no dynamic SQL construction or hard-coded DB URLs detected in `app/`.
- PostgreSQL native RLS migration and application-level tenant filtering are present.
- Append-only audit log protection is present.
- Document upload extension/size/path containment controls are present.

## Remaining production requirements (configuration, not source blockers)

- Set a strong `ERP_SECRET_KEY` (32+ chars) in production.
- Use PostgreSQL with the native RLS migrations applied.
- Configure Redis for shared rate limiting in multi-worker deployments.
- Configure a real SMTP/SMS provider for password recovery.
- Put the application behind TLS and a production WAF/reverse proxy.
- Keep CI `bandit`, `pip-audit`, and Ruff checks enabled; those binaries are not installed in this local review environment.

## Release assessment

No release-blocking failure was found by the available static/security/quality gates or the complete 109-test regression suite. The source package is ready for the next integration/testing cycle, subject to the production configuration requirements above.
