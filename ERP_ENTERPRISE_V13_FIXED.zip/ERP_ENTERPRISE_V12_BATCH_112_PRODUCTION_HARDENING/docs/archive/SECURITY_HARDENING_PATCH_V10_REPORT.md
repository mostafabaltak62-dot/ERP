# ERP Security Hardening Patch V10

## Implemented

1. Excel Formula Injection mitigation
   - Added `_excel_safe_value()` in `app/report_exports.py`.
   - User-controlled strings beginning with `=`, `+`, `-`, `@`, or containing tab/newline/carriage-return are forced to literal Excel text.
   - Numeric/non-string values remain typed values instead of being stringified.

2. Password reset token privacy
   - Removed reset token from `/forgot-password` redirects and hidden HTML fields.
   - Reset token is stored in a short-lived `HttpOnly`, `SameSite=Strict` cookie scoped to `/forgot-password`.
   - Verification/completion endpoints read the token from the cookie and clear it after successful reset.

3. CSRF hardening
   - Missing `Origin` and `Referer` now fail closed by default.
   - Controlled development override is available only through `ERP_CSRF_ALLOW_MISSING_ORIGIN=true`.
   - Authentication endpoints are excluded from the authenticated-browser CSRF gate to avoid treating login itself as an already-authenticated state-changing request.

4. Login rate limiting
   - Added a second account-level limiter in addition to the per-IP limiter.
   - Defaults: 5/IP/minute and 12/account/minute.
   - Login exhaustion now returns HTTP 429 with `Retry-After`.

5. Timing-resistant username handling
   - Non-existent/inactive users still execute a bcrypt verification against a dummy hash before returning an authentication failure.

6. Production Redis authentication
   - Added `REDIS_PASSWORD` to production configuration.
   - Redis starts with `--requirepass`.
   - Web/worker/beat/Celery/rate-limit/auth Redis URLs use the authenticated connection.
   - Redis healthcheck authenticates before checking PONG.

7. Mobile production endpoint hardening
   - `ERP_API_URL` is now required.
   - Only the Android emulator's explicit `http://10.0.2.2:<port>` development endpoint or HTTPS endpoints are accepted; arbitrary HTTP endpoints are rejected.

8. Regression tests
   - Updated the CSRF contract test to reflect the new fail-closed policy.

## Verification

- `pytest -q --disable-warnings --maxfail=1`: **119 passed**
- `python -m compileall -q app`: **PASS**
- `python scripts/security_audit.py`: **PASS**
- `python scripts/check_migration_portability.py`: **PASS (44 revisions scanned)**

## Not claimed

A real external PostgreSQL/Redis production deployment was not executed in this container. The production compose configuration was statically checked, while the existing project tests and security/migration audits were executed locally.
