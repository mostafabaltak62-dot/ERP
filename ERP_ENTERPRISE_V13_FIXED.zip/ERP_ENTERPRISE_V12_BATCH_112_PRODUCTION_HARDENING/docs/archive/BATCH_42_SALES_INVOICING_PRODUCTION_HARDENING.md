# Batch 42 — Sales & Invoicing Production Hardening Patch

## Scope
Follow-up deep audit of the Sales & Invoicing module in Batch 41, focused on hidden accounting,
inventory valuation, tenant integrity, input robustness, and consistency of customer metrics.

## Changes implemented

### P0/P1 — Accounting integrity
1. **Authoritative COGS engine**
   - Sales posting no longer derives COGS from `Item.purchase_price`.
   - Product issues now call the enterprise inventory valuation engine.
   - FIFO / weighted-average policy is therefore respected.
   - The resulting actual issue cost is used for the COGS journal and the stock-out movement.

### P1 — Data / tenant integrity
2. **Explicit tenant guard on customer list**
   - Customer list now requires a resolved company context rather than relying on a nullable context lookup.

3. **Customer dashboard semantics corrected**
   - Customer total sales, invoice counts, and per-customer sales summaries now use posted invoices only.
   - This prevents draft/cancelled documents from being presented as realized sales.

### P1 — Input hardening
4. **Invoice line-count limit**
   - Server rejects requests containing more than 500 invoice lines.

5. **Finite numeric validation**
   - Discount, tax, quantity, and unit-price values must be finite Decimal values.
   - NaN/infinite numeric payloads are rejected instead of passing comparison-based validation.

## Deep audit findings still requiring architecture work

### P0/P1 — Warehouse-aware inventory is not yet end-to-end
The sales invoice has `warehouse_id`, and stock movements have `warehouse_id`, but the current valuation layers
and `compute_stock()` logic are company/item scoped rather than warehouse scoped. The current sales screen therefore
cannot safely represent a true multi-warehouse issue. This must be solved centrally before claiming full
multi-warehouse production readiness.

### P1 — Inventory concurrency
The valuation engine locks the item row during issue, which is substantially safer than aggregate-only stock checks.
However, the legacy pre-check in the sales route still reads aggregate stock before the transaction enters the
valuation issue. The valuation engine remains the final authority and rejects insufficient valued inventory.
The pre-check should eventually be removed or converted into a shared inventory availability service to eliminate
duplicate policy logic.

### P1 — Payment-method/account mapping
The page accepts payment labels that do not map one-to-one to a configurable payment-account master.
Accounting currently maps methods to hard-coded account codes. Enterprise production should use a company-scoped
payment method master linked to an account, rather than embedding account codes in the route.

### P1 — Document numbering
The current architecture intentionally uses globally unique document numbers. This avoids cross-tenant collisions,
but it means invoice numbering is not company-local and can reveal global sequence progression. If statutory/local
numbering requires per-company or per-branch sequences, the schema and uniqueness constraints must be redesigned
together.

### P2 — Customer code generation
Customer codes are globally unique in the current schema, so the suggestion generator scans globally. This is
consistent with the current database contract but is not ideal for high-volume multi-tenant operation. A future
tenant-scoped code policy should be implemented with a database constraint and atomic sequence.

## Security review
- BOLA/IDOR: invoice and customer retrieval are explicitly company scoped.
- RBAC: sales edit/view checks remain enforced server-side.
- CSV formula injection: already hardened in Batch 41.
- CSRF/same-origin: covered by the application security middleware.
- XSS: Jinja template escaping remains enabled for rendered values.
- Client-side totals are not trusted; server recalculates financial totals.

## Verification
- Focused Batch 41 deep-audit tests: **4 passed**
- Full project test suite: **139 passed**

## Patch status
**Batch 42 — applied and verified.**
