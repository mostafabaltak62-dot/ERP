# ERP ENTERPRISE V13 — FINAL TEST RELEASE

## Purpose
This package is prepared for local user acceptance testing and production deployment validation.

## Fastest local start on Windows
### Option A — PowerShell
```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\RUN_LOCAL_WINDOWS.ps1
```

### Option B — Double-click / CMD
Run `RUN_LOCAL_WINDOWS.bat`.

Then open:
- http://127.0.0.1:8000
- API docs: http://127.0.0.1:8000/docs (if enabled by the application configuration)

## Production start
1. Copy `.env.production.example` to `.env`.
2. Replace **all** `CHANGE_ME` values with strong secrets.
3. Set the real HTTPS domain in `ERP_ALLOWED_ORIGINS`.
4. Run the PostgreSQL production validation script after database startup.
5. Start with:
```bash
./RUN_PRODUCTION_DOCKER.sh
```

## What was completed before this release
- Security and environment hardening
- Tenant isolation and query audit
- Approval workflow company isolation
- Sequence concurrency protection
- Targeted N+1 fixes
- Strict financial/inventory validation
- Accounting and inventory engine preservation/hardening
- Alembic metadata discovery audit
- Production preflight fixes
- Redis configuration alignment
- Celery Beat per-company dispatching
- PostgreSQL materialized-view refresh transaction handling
- PostgreSQL production validation tooling

## Validation status
Automated validation previously reported 299/299 collected tests passing in the project validation run, plus Alembic and compilation checks. Deployment-level validation still depends on your actual PostgreSQL/Redis/Docker environment.

## Mandatory before going live with real company data
- Backup strategy and restore drill
- Real PostgreSQL validation
- Redis failure/recovery test
- Multi-user/load test
- HTTPS/reverse proxy configuration
- External penetration test

## Important
This release is ready for you to begin testing. Do not use placeholder secrets or the development configuration for internet-facing production deployment.
