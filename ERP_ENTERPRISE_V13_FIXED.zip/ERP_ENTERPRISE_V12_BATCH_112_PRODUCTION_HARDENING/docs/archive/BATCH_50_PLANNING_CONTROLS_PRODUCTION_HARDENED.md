# Patch 50 — Planning Controls Production Hardening

## Scope
Second production hardening pass for Planning & Scheduling on Patch 49.

## Implemented
- Baseline variance engine: current vs approved baseline start/finish and actual-finish variance.
- Explicit progress status-date support on activity updates; no longer forces today's date when a historical cut-off is supplied.
- Delay / EOT event register with project/activity scope, claimed days, approved days, excusable and compensable flags.
- Governance rule: approved delay days cannot exceed claimed days; delay event numbers are unique per project.
- Resource loading register per activity with labor/equipment/subcontractor/material types and planned vs actual units.
- Non-negative resource controls and project/company isolation in service operations.
- Planning dashboard sections for baseline variance, delay events and resource loading.
- New Alembic migration `p49_planning_controls`.

## Validation
- Python compilation: PASS.
- Planning UI regression: 2/2 PASS.
- Recovery planning regression: 2/2 PASS.

## Known infrastructure item
Patch 49 already documented legacy Alembic multiple-head / SQLite legacy migration issues. This patch does not silently mask those unrelated migration-history problems.
