# ERP Accounting System V8 — Phase 7.0 Execution Report

## Objective
Implement the field-first and financial intelligence layer while keeping the codebase practical, domain-oriented and maintainable.

## Codebase quality
- Domain rules are isolated in `app/field_ops_services.py`.
- SQLAlchemy models live in `app/field_ops_models.py`.
- HTTP contracts and authorization live in `app/routers/field_ops_router.py`.
- No business workflow was placed directly in route handlers beyond validation, authorization and transaction commit.
- Domain failures use `FieldOpsError`, `BudgetExceeded` and `SyncConflict` rather than generic application exceptions.
- Comments are limited to design rationale and non-obvious business decisions.

## Delivered capabilities

### 1. Equipment & Fleet field costing
- `EquipmentLog` records meter readings, hours, estimated hourly cost, fuel, maintenance, actual cost and variance.
- Equipment cost entries support fuel, maintenance and other field costs.
- Existing `FuelTransaction` and `MaintenanceRecord` can be allocated directly to a project.
- Posted equipment logs create one authoritative `ProjectCost` record.
- Direct fuel/maintenance allocations create one authoritative `ProjectCost` record.
- Estimated versus actual hourly cost is calculated deterministically.

### 2. Variation Orders & commercial control
- Variation amendments capture approved amount, time extension, approver, amendment number and document evidence.
- Approval updates the project approved budget exactly once.
- A linked customer contract value is updated exactly once.
- Financial and schedule approval status are retained for auditability.

### 3. Site Material Requisitions
- Site requisition header/lines with project, site, WBS, BOQ and cost-code context.
- Workflow: draft → engineer approval → stock issue or purchase request.
- BOQ-linked quantity limits warn/block requests above approved quantity.
- Fulfillment state is retained on the requisition.

### 4. Offline readiness
- Device/batch idempotency.
- Operation idempotency.
- Explicit operation status and conflict records.
- Manual conflict resolution choices: accept server, accept client, manual.
- No silent overwrite policy.

### 5. Webhook & alert engine
- Event subscriptions with secrets.
- Durable delivery queue and unique event delivery keys.
- HMAC SHA-256 signatures.
- Dispatch endpoint with retry/attempt state.
- Project budget-exceeded events.
- License expiry and upcoming-expiry events.
- License register supports project/site/equipment context and reminder windows.

## Migration
Revision: `b7c8d9e0f1a2`

Fresh SQLite database was migrated from the baseline to `head` successfully.

New tables: 11
- equipment_logs
- equipment_cost_entries
- variation_amendments
- site_material_requisitions
- site_material_requisition_lines
- offline_sync_batches
- offline_sync_operations
- offline_conflicts
- webhook_subscriptions
- webhook_deliveries
- license_register

Existing `construction_variations` receives six governance columns for financial/schedule approval and budget application traceability.

## Tests
Full suite: **88 passed / 0 failed**.

Additional Phase 7.0 coverage includes:
- Equipment estimated vs actual hourly costing.
- Fuel and maintenance allocation to project cost.
- Variation amendment budget/contract update and idempotent approval.
- Material requisition budget guardrails and fulfillment workflow.
- Offline batch idempotency and conflict model.
- Webhook queue and signature generation.
- License expiry alert queue.
- End-to-end material requisition → project cost → BOQ measurement → progress certificate preparation.

## Validation notes
The warning-free maintenance pass removed the legacy `datetime.utcnow()` and FastAPI startup-event deprecations. The complete suite passes with `DeprecationWarning` promoted to errors.
