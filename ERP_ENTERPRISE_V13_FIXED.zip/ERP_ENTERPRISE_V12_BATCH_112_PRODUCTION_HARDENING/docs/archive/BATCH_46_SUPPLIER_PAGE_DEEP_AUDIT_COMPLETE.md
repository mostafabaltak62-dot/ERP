# BATCH 46 — Supplier Master Page Deep Audit & Production Hardening

## Scope
Deep audit of `/purchases/suppliers`, supplier creation/edit/detail, status lifecycle, tenant isolation, RBAC, BOLA/IDOR, data validation, financial master-data integrity, responsive/RTL UI, privacy of banking data, performance and integration with PO/Purchase Invoice/AP workflows.

## Findings & Fixes
1. **Unbounded supplier list** — fixed with server-side pagination (50/page).
2. **Weak search surface** — added code/name/tax/registration search with bounded input.
3. **Inactive supplier visibility** — added explicit active/inactive/all filters.
4. **Operational visibility** — added per-page PO and Purchase Invoice counts using tenant-scoped aggregate queries.
5. **Sensitive banking exposure** — banking data is excluded from list and masked on detail (last four characters only).
6. **Missing supplier lifecycle controls** — added tenant-scoped detail, edit and activate/deactivate workflow; no destructive delete is exposed.
7. **Supplier code mutability risk** — supplier code is immutable after creation to protect historical references/document identity.
8. **Financial currency integrity** — supplier currency cannot be changed after purchase invoices exist; prevents historical financial ambiguity.
9. **Tenant fail-open risk** — supplier list/detail/create/update now fail closed when company context is missing.
10. **BOLA/IDOR** — supplier detail/edit/status endpoints require the supplier to belong to the current company before any read/write.
11. **Audit trail** — create/update/activate/deactivate actions write AuditLog entries.
12. **Validation** — non-finite credit limits, invalid payment terms, invalid currency/type and malformed email/code remain rejected server-side.
13. **UI/UX** — list is responsive, status is explicit, bank details are intentionally not exposed in list view, and edit/create share one governed form.
14. **Routing safety** — static `/suppliers/new` is registered before `/suppliers/{supplier_id}` to prevent route capture/ID parsing conflicts.

## Architecture observations intentionally not changed
- `Supplier.company_id` remains nullable in the legacy model; application routes fail closed and always scope supplier access to an explicit company context. Converting the legacy column to NOT NULL requires a controlled data migration/backfill policy for existing records.
- The legacy Supplier table/model contains historical Item Master columns from earlier batches. They are not exposed or used by the Supplier UI. Removing them physically requires a separate schema cleanup migration and compatibility review.

## Verification
- Supplier + purchase regression suite: 17 passed.
- Full project regression: 151 passed, 0 failed.
