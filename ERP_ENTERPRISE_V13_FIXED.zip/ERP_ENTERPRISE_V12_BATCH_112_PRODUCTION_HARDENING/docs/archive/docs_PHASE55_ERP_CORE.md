# Phase 5.5 — ERP Core + Production Security Gate

## Production PostgreSQL gate

A fail-closed production gate was added in `scripts_phase55_production_gate.py`.
It verifies on a real PostgreSQL database:

- RLS enabled and FORCE RLS on core tenant tables.
- Tenant context fails closed when no valid company is selected.
- Core tenant tables are protected by native policies.

The current build environment has no PostgreSQL server, so the runtime PostgreSQL gate is **UNVERIFIED**, not marked as passed. It must be executed in CI/staging with a real PostgreSQL service before production certification.

## ERP Core delivered

- Company/branch/department organizational foundation.
- Tenant-safe analytical dimensions and dimension values.
- Tenant-safe projects and project validation.
- Generic contracts with financial validation and cross-company reference protection.
- Global search across customers, suppliers, items, projects, contracts, employees and equipment.
- User-owned notifications with read-state operation.
- Core RBAC permissions:
  - `core:manage`
  - `core:branches`
  - `core:departments`
  - `core:dimensions`
  - `core:projects`
  - `core:contracts`
  - `core:search`
- New `/api/v1/core/*` API surface with backend authorization and tenant context.
- Expanded tenant columns on previously indirect child entities, including workflow, project, contract, HR, manufacturing, equipment, notifications and idempotency records.
- PostgreSQL RLS policies for the newly tenant-aware child tables.
- Idempotency uniqueness is now company-scoped.

## Verification

- Fresh Alembic migration to `b7c6d5e4f321`: PASS.
- Full regression suite: **39/39 PASS**.
- Python compilation: PASS.
- No SQLite database, Python cache or bytecode artifacts are included in the release archive.
