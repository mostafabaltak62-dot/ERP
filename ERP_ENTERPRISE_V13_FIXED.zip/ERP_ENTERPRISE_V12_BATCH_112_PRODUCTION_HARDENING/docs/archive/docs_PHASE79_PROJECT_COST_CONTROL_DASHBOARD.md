# Phase 79 — Project Cost Control Dashboard

Implemented a project-scoped enterprise cost-control dashboard covering:
- Approved/active budget with BOQ fallback.
- Open commitments, including subcontractor BOQ commitment baseline.
- Authoritative ProjectCost actuals.
- Actual cost breakdown: materials, labor, equipment, subcontractors, other.
- ETC (manual forecast when present, otherwise remaining budget).
- EAC and variance at completion.
- Certified project revenue and forecast profit/margin.
- Budget and commitment utilization KPIs.
- Project-scoped HTML UI and API summary endpoint.

Routes:
- `/site-operations/project-cost-control?project_id=<id>`
- `/api/v1/construction/projects/<project_id>/cost-control/summary`

All queries are constrained by company and project and the UI resolves access through the existing project scope checks.
