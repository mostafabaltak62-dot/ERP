# ERP Enterprise — Accounting Standards Implementation

This release hardens the accounting engine around a single posted-journal source of truth and maps the presentation layer toward Egyptian Accounting Standards (EAS) and IFRS principles.

## Implemented controls

- Posted journal entries only feed the trial balance and financial statements.
- Draft/cancelled/unposted journals are excluded from authoritative reporting.
- Every journal is required to balance: total debits = total credits.
- Tenant/company scoping is applied to accounts, journal headers, journal lines and reports.
- Account codes are company-local rather than globally unique.
- Chart-of-accounts metadata now maps each account to normal balance, financial-statement section and cash-flow category.
- Balance sheet equation is validated explicitly: Assets = Liabilities + Equity.
- Current-period profit is included in equity without double-counting periods already closed into retained earnings.
- Cash flow statement reconciles opening cash + net cash movement = closing cash.
- Separate default VAT output and input accounts are provided (2200 / 2220); legacy purchase tax configuration pointing to 2200 is redirected to input VAT 2220.
- Sales invoices paid by bank/transfer use the bank account rather than receivables.
- Inventory valuation remains based on FIFO or weighted-average cost layers and blocks unsupported negative valuation.
- Fixed assets support acquisition and depreciation entries.
- Accruals and period closing entries remain linked to the general ledger.
- Financial statements and key reports can be exported to Excel and PDF.
- Accounting UI typography and journal-entry controls have been enlarged for operational use.

## Financial statements

The release includes:

1. Trial Balance
2. General Ledger
3. Statement of Profit or Loss
4. Statement of Financial Position
5. Statement of Cash Flows
6. Statement of Changes in Equity
7. Automated financial validation

## Standards alignment target

The presentation and control design is informed by:

- Egyptian Accounting Standards as maintained/published by the Financial Regulatory Authority (FRA).
- IAS 1 / the transition to IFRS 18 for presentation and disclosure.
- IAS 7 for operating, investing and financing cash-flow classification.
- IAS 2 for inventory measurement and cost formulas.
- IAS 16 for property, plant and equipment and depreciation.
- IFRS 15 for revenue recognition principles.
- IAS 37 for provisions and contingencies where applicable.

The system is an accounting implementation aid, not a substitute for an Egyptian statutory auditor's review, tax/legal advice, or entity-specific accounting policy decisions. Account mappings, tax treatment, revenue recognition, provisions, leases, financial instruments and disclosures should be approved against the entity's actual activities and applicable EAS/IFRS requirements.

## Checklist implementation extension — V9

The V9 accounting release additionally implements the attached accounting checklist through:
- cost-centre allocation on journal lines and exception reporting;
- orphan-account hygiene checks;
- statement-line level bank reconciliation records;
- fixed-asset disposal accounting with gain/loss;
- explicit VAT input/output direction and tax-period reporting;
- withholding-tax master structures;
- inventory-to-GL reconciliation screen;
- a consolidated Accounting Compliance control page with Excel/PDF export.

See `ACCOUNTING_CHECKLIST_APPLIED.md` for the complete mapping and verification results.
