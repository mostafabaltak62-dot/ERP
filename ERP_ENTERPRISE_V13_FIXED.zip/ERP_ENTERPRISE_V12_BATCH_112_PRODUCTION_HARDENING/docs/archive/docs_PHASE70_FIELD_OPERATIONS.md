# Phase 7.0 — Field Operations & Financial Intelligence

## Delivered
- EquipmentLog with estimated versus actual hourly cost.
- Fuel, maintenance and other equipment cost entries allocated to project cost.
- Variation amendment governance with financial/time approval and automatic project/contract budget update.
- Site Material Requisition workflow: site request → approval → stock issue or purchase request.
- BOQ-linked material quantity guardrails.
- Offline sync batches, idempotent operation intake and explicit conflict records.
- Webhook subscriptions and durable event delivery queue with HMAC signing helper.
- Unit/integration coverage for the full field workflow and failure cases.

## Codebase directives
Business rules live in `field_ops_services.py`; routers only validate input, authorize and commit. Comments are limited to design rationale. Domain errors are explicit `FieldOpsError`, `BudgetExceeded` and `SyncConflict` types.

## Commercial behavior
Approved variations update the project's approved budget and, when linked, the customer contract value exactly once. The amendment number and timestamp provide the audit trail.

## Offline behavior
The server does not silently overwrite concurrent changes. Operations are accepted only after basic validation; conflicting or invalid operations become explicit conflict records for deterministic reconciliation.
