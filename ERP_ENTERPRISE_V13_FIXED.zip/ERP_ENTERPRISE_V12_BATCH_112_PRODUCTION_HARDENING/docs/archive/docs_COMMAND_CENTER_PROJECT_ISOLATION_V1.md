# ERP — Construction Command Center V1

## Scope
This release fixes the Construction Command Center navigation and establishes project-scoped commercial/document views.

## Project isolation
- Command Center project selector is restricted to the authenticated user's company/branch/project scope.
- All selected-project queries are filtered by `company_id` and `project_id`.
- `scope_allows()` is checked before rendering project-specific pages.
- Project-specific pages:
  - `/projects/command-center`
  - `/projects/command-center/certificates?project_id=<id>`
  - `/projects/command-center/documents?project_id=<id>`

## Progress certificates
Two distinct commercial streams are displayed:
1. Main/customer contract progress certificates: commercial revenue / receivable workflow at recognition and posting, subject to the company's accounting policy.
2. Subcontractor progress certificates: project cost / payable or accrual workflow when approved; payment later settles the liability and must not duplicate the project cost.

The UI now provides working create-draft forms backed by the existing secured construction APIs.

## Document control
The old Command Center buttons no longer point directly to API-only endpoints. They now open HTML project-specific pages, avoiding the browser JSON/405 experience.

## Validation
Targeted regression: 14 tests passed, including:
- Branch finance consolidation
- Construction phases 60–62
- HTTP regression
- New Command Center HTML/project-isolation test

The broader suite still contains a pre-existing mobile security fixture/order failure in `tests/test_mobile_security.py`; it is unrelated to this release and should be handled as a separate baseline cleanup.
