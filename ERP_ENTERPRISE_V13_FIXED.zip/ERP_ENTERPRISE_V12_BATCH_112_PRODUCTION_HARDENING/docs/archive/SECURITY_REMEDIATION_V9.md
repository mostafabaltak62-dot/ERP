# Security Remediation V9

## Fixed
- Production PostgreSQL now separates the migration/admin role from the FastAPI application role.
- The application role is explicitly `NOSUPERUSER NOBYPASSRLS`; grants are applied after migrations and default privileges cover future tables/sequences.
- Enterprise Plus create models no longer accept client-supplied `company_id`; the value is derived from the authorized request context.
- A global API guard rejects mismatched `company_id` values in query parameters and JSON bodies for non-admin organization routes.
- Alembic migrations were changed from unconditional `recreate="always"` to dialect-safe `recreate="auto"`.
- Phase 4 governance seed inserts now use PostgreSQL `ON CONFLICT DO NOTHING` while retaining SQLite compatibility for tests.
- Dependencies are pinned to the tested environment versions.
- Added migration portability gate and a live PostgreSQL RLS proof script.
- Added security contract tests for tenant input handling, production DB roles, and migration portability.

## Verification
- Python compilation: PASS.
- Migration portability gate: PASS (44 revisions scanned).
- Security/Enterprise Plus targeted tests: PASS (11/11 before the additional contract tests).
- Additional contract tests are included in the release.

## Important environment limitation
This execution environment does not provide Docker/PostgreSQL binaries, so a live PostgreSQL RLS proof and a fresh PostgreSQL `alembic upgrade head` could not be executed here. The project contains `scripts/verify_postgres_rls.py` specifically for the deployment/CI environment. Do not treat SQLite tests as proof of PostgreSQL RLS enforcement.
