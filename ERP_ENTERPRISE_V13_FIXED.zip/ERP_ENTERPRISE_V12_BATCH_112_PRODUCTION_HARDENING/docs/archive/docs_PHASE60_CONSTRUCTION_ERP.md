# Phase 6.0 — Construction ERP Core

## Scope
A reusable Construction module built on the existing ERP Core. It does not create a separate accounting system.

## Delivered
- Construction cost-code hierarchy: material, labor, equipment, subcontract, overhead, other.
- Project WBS hierarchy with budget amounts.
- BOQ revisions with immutable revision numbering and tenant scoping.
- BOQ lines linked to WBS and cost codes.
- Quantity/rate validation using NUMERIC/Decimal.
- Measurement sheets with current and cumulative quantities.
- Guard against cumulative quantities exceeding contractual BOQ quantities.
- Approved measurement lifecycle.
- Variation orders with approval lifecycle.
- Customer progress certificates with retention and advance recovery.
- Certificate approval lifecycle.
- Construction advances with controlled recovery and outstanding balance protection.
- Subcontractor progress certificates with retention, advance recovery and deductions.
- Project cost-control endpoint: original BOQ, approved variations, revised contract value, actual cost, certified revenue and forecast profit.
- Company/tenant isolation and granular permissions: `construction:manage`, `construction:approve`.
- Alembic migration `6f7a8b9c0d12`.

## API
- `POST /api/v1/construction/cost-codes`
- `POST /api/v1/construction/wbs`
- `POST /api/v1/construction/boq/revisions`
- `POST /api/v1/construction/measurements`
- `POST /api/v1/construction/measurements/{id}/approve`
- `POST /api/v1/construction/variations`
- `POST /api/v1/construction/variations/{id}/approve`
- `POST /api/v1/construction/progress-certificates`
- `POST /api/v1/construction/progress-certificates/{id}/approve`
- `POST /api/v1/construction/advances`
- `POST /api/v1/construction/advances/{id}/recover`
- `POST /api/v1/construction/subcontractor-progress`
- `GET /api/v1/construction/projects/{id}/control`

## Integrity Rules
- No negative BOQ quantities/rates.
- No duplicate project BOQ codes within a revision/project.
- Cumulative measured quantity cannot exceed contractual quantity.
- Advance recovery cannot exceed the advance balance.
- Certificate deductions cannot exceed gross certificate value.
- Approved variations are included in revised contract value.
- Project cost control reads authoritative `ProjectCost` records.

## Verification
- Fresh Alembic migration to `6f7a8b9c0d12`: PASS.
- Construction tests: 2/2 PASS.
- Full non-HTTP regression suite: 51/51 PASS.
- HTTP regression remains environment-gated because `bcrypt` is not installed in this execution environment.
- PostgreSQL native RLS runtime remains an external production gate requiring a real PostgreSQL instance.
