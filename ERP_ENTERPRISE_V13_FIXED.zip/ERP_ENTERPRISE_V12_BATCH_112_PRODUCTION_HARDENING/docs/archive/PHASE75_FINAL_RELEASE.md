# Phase 7.5 — Construction Command Center & Enterprise UX Consolidation

## Scope
- Construction Command Center with project selector and executive construction KPIs.
- AC, budget consumption, forecast/EAC, VAC, CPI/SPI when an EVM snapshot exists.
- Progress certificate, variation, document and project-cost visibility.
- Responsive workspace UI built on the Phase 7.x design system.
- Construction `view` permission added to the central permission catalog.
- Existing API/business services remain unchanged except for the presentation route and permission catalog entry.

## Quality gate
- `python -m pytest -q -W error::DeprecationWarning`
- Python compilation of changed modules.
- No new dependency introduced.
