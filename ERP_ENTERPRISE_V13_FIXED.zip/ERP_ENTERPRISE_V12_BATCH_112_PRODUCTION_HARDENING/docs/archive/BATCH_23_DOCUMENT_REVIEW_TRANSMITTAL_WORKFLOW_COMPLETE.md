# Batch 23 — Document Review & Resubmission Workflow
Implemented reviewer assignments, revision-scoped review comments, assigned-reviewer decisions, controlled decision statuses, and a workflow read endpoint. This extends the existing transmittal/revision infrastructure and keeps all records company-scoped.

Workflow: Draft/Submitted → Reviewer Assignment → Under Review → Approved / Approved with Comments / Revise & Resubmit / Rejected → New Revision → Re-review.
