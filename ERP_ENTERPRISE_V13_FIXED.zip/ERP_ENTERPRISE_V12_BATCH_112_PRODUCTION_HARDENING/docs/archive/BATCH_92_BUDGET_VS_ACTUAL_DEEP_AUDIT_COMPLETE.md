# Patch 92 — Budget vs Actual Deep Audit

## Baseline
Patch 91 — Accounting Controls & Standards Readiness production hardened.

## Scope
Deep production-grade audit of **Budget vs Actual / الموازنة مقابل الفعلي**, including the UI report, accounting-core variance API, tenant/branch isolation, period accuracy, normal-balance presentation, cost-center analytical allocation, unsupported project dimensions, exports, performance, and regression compatibility.

## Findings & fixes
1. Actuals were previously calculated per budget line with N+1 queries; the report now uses bulk fiscal-year aggregates grouped by account/month plus bulk cost-center allocation aggregates.
2. Actuals were previously calculated for the entire fiscal year and repeated on every monthly budget line; the report now matches actuals to the budget line's fiscal month.
3. Credit-normal accounts were displayed with raw debit-credit signs; actuals are now normalized to each account's normal balance.
4. Cost-center budget lines previously consumed the whole account actual; they now consume only posted analytical allocations for the exact account + cost center + month.
5. Project-only budget lines cannot be safely reconciled because JournalLine has no project dimension; they are explicitly marked `project_dimension_unavailable` rather than falsely matched.
6. Project + cost-center mismatches are detected and excluded from reconciled actual/variance KPIs.
7. Cross-company / cross-branch budget IDs no longer fail silently; UI/export reject them.
8. The API variance endpoint now uses the same calculation service as the UI, preventing screen/API divergence.
9. Dedicated Excel/PDF exports were added using the same calculation service.
10. Draft/non-approved budgets remain viewable but are explicitly labeled as not approved.
11. Summary KPIs keep full budget/forecast visible while actual/variance KPIs include only safely reconciled lines; unsupported budget exposure is shown separately.
12. No schema migration was required; existing financial-core tables are reused.
13. OpenAPI was regenerated to include the updated variance endpoint and new UI export route.

## Accounting definition
- Actual source: posted JournalEntry + JournalLine only.
- Period basis: budget fiscal year + budget line month (1–12).
- Normal-balance normalization: debit-normal uses debit-credit; credit-normal uses credit-debit.
- Cost-center lines: posted JournalLineCostCenter allocation for same account, center, branch, and month.
- Project-only lines: explicitly unreconciled because project is not a JournalLine dimension.
- Actual variance: `Actual − Budget`.
- Forecast variance: `Forecast − Budget`.

## Validation
- Patch 92 targeted Budget-vs-Actual tests: **3/3 PASS**
- Budget-control regression: **3/3 PASS**
- Project profitability regression: **2/2 PASS**
- Cost-control linkage regression: **3/3 PASS**
- Financial validation regression: **3/3 PASS**
- Financial reporting UI regression: **2/2 PASS**
- Phase 5.8 financial-core regression: **2/2 PASS**
- Combined targeted result: **18/18 PASS**
- Python compilation: **PASS**
- Fresh SQLite `alembic upgrade head`: **PASS**
- Alembic heads: **single head — p83_financial_validation**
- Runtime OpenAPI generation: **PASS**; Budget-vs-Actual UI and export routes are present.

## Full regression note
A complete full-suite green claim is **not** made. The full `pytest -q` execution reached approximately **56%** before the execution environment timed out, with no assertion failure shown before timeout. Targeted production gates passed.

## Release
**PATCH 92 — Budget vs Actual Production Hardened**
