# Batch 41 — Sales & Invoicing Deep Audit Complete

## Scope
Deep audit of the Sales & Invoicing list page and the execution paths directly reachable from it.

## Hidden issues discovered and corrected

1. **Runtime stock validation crash**: the sales router called `compute_stock()` without the required company argument. This could fail when loading the invoice form or posting a product invoice. Fixed with explicit tenant/company scoping.
2. **Cross-company sequence defect**: `SequenceCounter.key` is globally unique while `next_number()` previously searched by company. A second company could create a conflicting counter or duplicate document-number flow. Fixed by making the technical counter global per document key, matching globally unique document-number columns.
3. **Spreadsheet formula injection**: CSV fields could begin with `=`, `+`, `-`, or `@`. Export now neutralizes formulas and adds `nosniff` protection.
4. **Mismatched invoice arrays**: `zip()` silently ignored extra item/quantity/price values. Posting now rejects inconsistent line arrays.
5. **Invalid customer identifier handling**: malformed IDs could raise uncontrolled conversion errors. Now validated with a controlled 422 response.
6. **Unrestricted payment method input**: arbitrary payment text could select an unintended accounting path. Now restricted to supported methods.
7. **Incorrect dashboard meaning**: the page total mixed cancelled/draft values with actual posted sales. Metrics now explicitly report posted invoices and posted sales value.
8. **Weak operational visibility**: added status and date filters, deterministic newest-first ordering, and bounded pagination.
9. **Export consistency**: CSV now respects the selected status filter and includes status.
10. **Tenant clarity**: invoice stock validation and list access use an explicit required company context helper.

## Tests
- Added focused deep-audit regression tests for CSV formula neutralization, invalid dates, tenant-scoped stock, and global document sequencing.
- Full project test suite: **139 passed**.

## Remaining architecture note
Inventory availability is calculated from movement aggregates. Database-level row/advisory locking for simultaneous stock consumption remains an architectural hardening area and should be addressed centrally in the inventory posting service rather than only in this screen, to avoid inconsistent locking rules across sales, site operations, and warehouse transactions.
