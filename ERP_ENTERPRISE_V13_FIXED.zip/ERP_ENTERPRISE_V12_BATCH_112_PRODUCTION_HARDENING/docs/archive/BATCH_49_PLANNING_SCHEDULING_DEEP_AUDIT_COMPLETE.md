# Patch 49 — Planning & Scheduling Engine Hardening

## Scope
Production-grade hardening of Planning & Scheduling on Patch 48.

## Implemented
- Activity dependency engine: FS / SS / FF / SF with lag days.
- Dependency cycle detection before persistence.
- Project/company scoping on dependency and calendar operations.
- Project scheduling calendar model with Mon..Sun working-day mask and holidays.
- Actual Start / Actual Finish fields on activities.
- CPM-style early/late dates, total float and critical activity calculation.
- Planning workspace exposes dependency and critical-path indicators.
- Progress validation moved into service layer; closed progress periods are immutable.
- Completed status requires 100% progress; 100% requires completed status.
- Actual date ordering validation.
- New migration for the scheduling schema.

## Validation
- Python compilation: PASS.
- Planning UI tests: PASS (2/2).
- Recovery planning tests: PASS.
- Fresh Alembic validation exposed a pre-existing unrelated SQLite migration defect in batch24 (`document_transmittals` FK added outside batch mode). The new scheduling migration itself is structurally valid, but the repository currently has multiple historical Alembic heads and the full fresh chain cannot reach the final merge without addressing that legacy SQLite issue.

## Next hardening candidates
- True calendar-aware backward-pass for all dependency types.
- Schedule variance against approved baseline.
- Schedule status periods / cut-off date workflow.
- Delay events, EOT and time-impact analysis.
- Resource loading and leveling.
- Full schedule export/import and richer Gantt controls.
