# ERP V10 - Repair Batch 04

## Applied fixes
- Sales list modernized to the shared ERP UI structure.
- Purchases list improved with real supplier and value metrics.
- Added real CSV export endpoints for sales and purchase lists.
- Added company/tenant ownership validation for customer, supplier, item, warehouse, and project references submitted during sales/purchase creation.
- Stock movements created from sales invoices now explicitly retain company_id.
- Accounting home now scopes recent posted journal entries to the active company.
- Improved empty states and null-safe supplier/customer/date rendering.

## Validation
- Python compilation passed.
- Jinja template loading passed.
- Targeted regression suite: 18 passed.

## Next repair scope
- Financial reporting and treasury pages.
- AP/AR workflows and aging screens.
- HR, documents, site operations, project planning, and remaining enterprise navigation pages.
- Full route/page audit before final screenshot capture.
