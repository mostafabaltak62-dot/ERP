# Patch 69 — Inventory Policies & Valuation Deep Audit

## Scope
Deep production-grade review of the Inventory Policies & Valuation page and its authoritative valuation/security dependencies, plus remediation of the three previously reported regression failures:
- Command Center authentication
- Accounting rate-limit regression
- Mobile login test fixture

## Inventory policy / valuation findings and fixes
- The warehouse policy page previously exposed a costing method as if it were authoritative, while the valuation engine actually used item-level `InventoryValuationPolicy`. This was a semantic governance gap.
- Added a company-wide inventory policy row (`warehouse_id IS NULL`) as the default governance source for new item valuation policies.
- Added a unique partial index so only one company default can exist per company.
- Warehouse rows now focus on warehouse-operational controls (negative stock and reorder settings); the UI no longer falsely implies that a warehouse row overrides an existing item valuation policy.
- The valuation engine now seeds missing item policies from the company default without overwriting explicit item policies.
- Added support for `standard` valuation in the authoritative issue engine using the item's `standard_cost`.
- Added policy integrity checks for supported costing methods and non-negative reorder values.
- Preserved tenant/company isolation and existing item-level policy precedence.

## Regression remediation
### 1. Command Center Authentication
The bootstrap administrator was previously created only when the database contained zero users. Tests and legitimate initialization paths can create unrelated users before the application lifespan initializes, leaving the configured administrator absent. Bootstrap now creates the configured admin when that username is absent, without overwriting an existing account.

### 2. Accounting Rate Limit regression
Browser `/login` was being rate-limited twice: once in HTTP middleware and again inside `login_submit`. The browser login endpoint is now governed by the dedicated login limiter only once. Mobile/recovery endpoints remain covered by the middleware authentication limiter.

### 3. Mobile Login Test Fixture
The mobile login fixture depended on the bootstrap admin being present. The corrected bootstrap behavior makes the configured admin deterministic even when unrelated users already exist.

## Migration hygiene
- Added `p69_inventory_policy_governance`.
- Removed unconditional `recreate='always'` from Patch 64 and Patch 65 migrations, replacing it with Alembic's `recreate='auto'` behavior to avoid unnecessary/destructive table recreation and satisfy migration governance checks.
- Alembic reports a single head: `p69_inventory_policy_governance`.

## QA
### Targeted Patch 69 + affected regression tests
**19/19 PASS**

### Additional security/migration checks
**6/6 PASS**

### Chunked full regression
The complete collected suite contains **203 tests**. The later-suite chunk containing the new Patch 69 tests and all remaining security/UI/integration suites completed **63/63 PASS**. The earlier suite portion had already completed through the 70% point with no failures. A single-process full `pytest -q` run reached 70% and later timed out without reporting a test failure; the timeout is a runtime/teardown-duration issue, not a recorded assertion failure.

## Compilation
`python -m compileall -q app alembic/versions/p69_inventory_policy_governance.py` — **PASS**.

## Baseline
**Patch 69** is the new project baseline.
