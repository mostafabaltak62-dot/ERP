# Batch 39 — Purchase Returns Control Center

Implemented a full tenant-scoped Purchase Returns control layer:

- Search by return number, purchase invoice, supplier code/name.
- Status, supplier and date filters.
- KPI summary for total returns, value, posted returns and affected suppliers.
- Return creation only from posted purchase invoices.
- Cumulative quantity validation excluding cancelled returns.
- Optional warehouse traceability.
- Header and line-level return reasons, condition and notes.
- Inventory valuation issue with explicit prevention of unsupported/unvalued returns.
- Stock movement audit trail with warehouse linkage.
- AP, VAT and inventory/variance accounting entry.
- Full return detail page showing source invoice, supplier, warehouse, reasons and financial impact.
- Database migration for all new control fields.
