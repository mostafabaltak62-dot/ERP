# Patch 68 — Journal Reversal Deep Audit & Production Hardening

## Scope
Full audit of the accounting journal reversal page, route, reversal service, tenant/RBAC boundary, period governance, immutability, source-document integrity, audit trail, UI and regression behavior.

## Findings and fixes
- Replaced the page route's duplicated reversal logic with the central `create_reversing_entry()` service.
- Enforced granular `journal:reverse` permission on the POST reversal endpoint.
- Separated page viewing (`journal:view`) from reversal execution (`journal:reverse`).
- Added company/branch-scoped reversal listing and eligible-entry listing.
- Generic reversal now accepts only generic journal sources (`manual`, `other`, `accrual`, `recurring_journal`, or no source).
- Operational postings (sales, purchases, inventory, payroll, assets, etc.) are blocked from generic reversal so their owning subledger workflow remains authoritative.
- Reversing a reversal is blocked.
- Closing entries are blocked from generic reversal.
- Reversal date cannot precede the original journal date.
- Reason is trimmed, required and limited to 255 characters.
- Reversal lines are generated from the original account lines and their debit/credit sides are exactly inverted.
- Existing open-period validation remains authoritative for the reversal date.
- Duplicate reversal protection remains enforced by the reversal record and journal source idempotency.
- Explicit legacy `AuditLog` entry added for the reversal operation; governance audit remains append-only.
- UI now shows only eligible entries, source type, safe links, required reversal date/reason, and confirmation before posting.
- Reversal history is tenant/branch scoped and links both journals.

## QA
- Targeted regression: **15/15 PASS** (`tests/test_batch68_journal_reversal.py`, security integrity and phase-41 governance tests).
- Python compilation: **PASS**.
- Full suite: **101 passed before 3 pre-existing unrelated failures** in command-center authentication, accounting rate-limit regression, and mobile login fixture. The suite was intentionally not reported as green.

## Migration
No schema migration was required for Patch 68; the existing `journal_reversals.company_id`, unique original/reversal references, and journal source idempotency constraints are sufficient.
