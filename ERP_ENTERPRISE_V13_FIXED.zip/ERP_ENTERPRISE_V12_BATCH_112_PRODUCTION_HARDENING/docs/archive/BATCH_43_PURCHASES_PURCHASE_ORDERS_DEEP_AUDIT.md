# BATCH 43 — Purchases & Purchase Orders Deep Audit / Production Hardening

## Scope
Deep review of the Purchases and Purchase Orders workflow from the Batch 42 production-hardened baseline.

Reviewed layers:
- Visual/UI and RTL risk points
- Responsive/layout risks
- UX and workflow semantics
- Hidden business-logic risks
- Database integrity and tenant ownership
- Multi-tenant isolation / BOLA-IDOR
- RBAC / approval enforcement
- Accounting and inventory receiving boundary
- Auditability
- Performance/scalability
- Integration with suppliers, inventory, warehouse, projects, approvals and AP/3-way match

## Findings fixed in Patch 43

### P43-01 — Purchase order lines were tenant-nullable
**Severity: Critical**
`purchase_order_lines.company_id` existed but was nullable. A line could therefore be created without an explicit tenant and could become invisible under tenant filtering or create cross-tenant integrity ambiguity.

**Fix:**
- Model changed to `nullable=False`.
- New PO creation explicitly stamps `company_id` on every line.
- Migration backfills legacy lines from their parent PO and fails closed if any line cannot be mapped.

### P43-02 — Duplicate item lines could corrupt three-way matching
**Severity: High**
Three-way matching resolves a PO line by `item_id`. Duplicate item rows in one PO could cause the wrong PO line to be selected.

**Fix:**
PO creation now rejects duplicate item IDs in the same order.

### P43-03 — Non-finite numeric input
**Severity: High**
Decimal values such as `NaN` / `Infinity` could bypass ordinary `< 0` validation and contaminate totals.

**Fix:**
PO quantity and unit price parsing now rejects non-finite values and enforces sensible upper bounds.

### P43-04 — Malformed identifiers could cause server errors
**Severity: Medium**
Raw `int()` conversion on supplier/warehouse/project/item identifiers could surface as unhandled errors.

**Fix:**
Identifiers are parsed with controlled 422 responses.

### P43-05 — Payment method was client-controlled without an allow-list
**Severity: Medium**
Any arbitrary payment-method string could be stored.

**Fix:**
Allow-list added while preserving existing Arabic and legacy English values used by the system.

### P43-06 — Product PO could be received without a warehouse through the UI
**Severity: High**
A product PO without a warehouse could eventually generate a stock movement with `warehouse_id=NULL`, weakening warehouse-level inventory control.

**Fix:**
Creation of product POs now requires an active company-owned warehouse.

### P43-07 — Approval enforcement existed only at the route boundary
**Severity: High**
The browser route checked approval before receipt, but direct service callers could invoke the receiving service without that guard.

**Fix:**
Approval status is now re-checked inside the authoritative receiving service.

### P43-08 — Invalid warehouse ownership at receipt boundary
**Severity: High**
The receiving service now validates the selected warehouse against the current company before creating the stock movement.

### P43-09 — PO list used unbounded `.all()`
**Severity: Medium / Scalability**
The purchase-order page could load every order for a tenant into memory.

**Fix:**
- Added bounded pagination (50 rows/page).
- Added result count and previous/next navigation.
- Search state is preserved between pages.
- Displayed total is explicitly page-scoped to avoid misleading aggregate claims.

### P43-10 — UI workflow wording was misleading
**Severity: Medium / UX**
The create form implied inventory would be updated after saving the PO.

**Fix:**
UI now clearly states that inventory changes only happen on actual receipt after approval.

### P43-11 — Pending approval UX
**Severity: Medium**
Receipt action is now hidden while approval is pending and the detail page shows the pending state.

## Existing architecture risks identified but intentionally not silently redesigned

### A-01 — Inventory valuation is not warehouse-scoped
The current valuation engine is company + item scoped while stock movements are warehouse scoped. This is a material multi-warehouse accounting architecture gap and should be handled as a dedicated inventory-valuation migration rather than a local PO patch.

### A-02 — Purchase receipt is currently one-per-PO
The database has a unique `purchase_receipts.po_id`, while the service accepts a `quantities` argument. This means the code hints at partial receipt support but the persistence model currently enforces a single receipt. A production-grade partial-receipt redesign should aggregate received quantities per PO line and remove the single-receipt constraint with a dedicated migration and UI workflow.

### A-03 — Three-way matching is still item-oriented
The matching service maps invoice lines to a PO line by item. Duplicate lines were therefore blocked in Patch 43. A future dedicated hardening should move the matching contract to explicit PO-line references end-to-end.

### A-04 — Document numbering remains globally unique
The existing accounting sequence design intentionally uses global document numbers because the schema has global uniqueness. This remains a business/legal configuration question for companies requiring independent branch/company numbering series.

### A-05 — Alembic repository has pre-existing multiple heads
The baseline contains multiple migration heads unrelated to this patch. Patch 43 is chained from the Phase 84 head but does not silently merge unrelated migration branches. This should be resolved in a dedicated migration-governance patch.

## Security review outcome
- Company filters remain enforced on PO, supplier, item, warehouse and project selection.
- Central tenant filtering remains active.
- Route RBAC remains protected by the purchases module and central permission policy.
- Receipt approval is now enforced in both route and service layers.
- No new BOLA/IDOR path was introduced.
- CSRF origin protection remains provided centrally by the existing security middleware.

## Tests
Full project suite after Patch 43:

**141 passed**

Focused purchase/PO hardening tests:
- non-finite numeric rejection
- payment method allow-list
- supplier master regression
- purchase receipt / three-way match regression

## Release
`ERP_ENTERPRISE_V10_PATCH_43_PURCHASES_PURCHASE_ORDERS_PRODUCTION_HARDENED.zip`
