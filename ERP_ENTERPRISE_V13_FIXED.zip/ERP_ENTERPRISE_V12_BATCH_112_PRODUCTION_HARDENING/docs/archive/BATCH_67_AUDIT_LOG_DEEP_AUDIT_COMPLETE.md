# BATCH 67 — Audit Log Deep Audit & Production Hardening

## Scope
Institutional Audit Log list/detail, authorization, tenant isolation, audit snapshot privacy, filtering, pagination, export, and query performance.

## Fixes
- Audit Log pages now require the dedicated `audit:view` permission instead of broad `accounting:view`.
- Invalid date input returns HTTP 422 instead of an internal parsing error.
- Added company-scoped composite indexes for date, entity, and action filtering.
- Added CSV export using the same company/permission filters as the UI.
- Audit snapshots redact credential/token/signature secrets, including password hashes and token hashes.
- Existing append-only ORM protection remains enforced for audit rows.
- Company/branch scope continues to be enforced by the governance tenant filter and explicit company predicates.

## Verification
- Targeted Audit tests: **13/13 PASS**.
- Python compilation: **PASS**.
- Full regression was started. First three pre-existing failures reproduced after **97 passing tests**:
  1. Command Center UI authentication fixture — 401.
  2. Accounting page rate-limit fixture — 429.
  3. Mobile security login fixture — 401.
- These failures are outside the Audit Log changes and were not counted as passes.
