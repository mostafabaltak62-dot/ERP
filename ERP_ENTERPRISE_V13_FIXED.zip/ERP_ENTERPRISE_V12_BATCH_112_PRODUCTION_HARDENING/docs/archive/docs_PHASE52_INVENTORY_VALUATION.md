# Phase 5.2 — Inventory Valuation & Cost Integrity

This phase intentionally avoids superficial UI expansion. It strengthens the financial engine behind inventory and COGS.

## Implemented

- Per-company, per-item valuation policy.
- FIFO costing.
- Weighted-average costing.
- Immutable receipt cost layers.
- Explicit cost-consumption records linking an issue to its cost layers.
- Valuation run records for auditable stock valuation snapshots.
- Sales delivery COGS now comes from the valuation engine, not `Item.purchase_price`.
- Posted purchase-invoice product lines create inventory receipts and cost layers.
- Legacy stock movements are bootstrapped into valuation layers idempotently.
- Negative inventory is fail-closed unless an explicit policy allows it; this release does not invent a zero-cost deficit.
- Daily Celery inventory valuation now executes the authoritative valuation service and persists a valuation run.
- PostgreSQL RLS policies cover the new valuation tables.

## Accounting significance

Inventory quantity and inventory value are now distinct authoritative concepts. COGS is derived from the configured valuation method and traceable through `InventoryCostConsumption` to the original `InventoryCostLayer`.

## Remaining production gates

- Historical valuation migration for real production databases must be executed as a controlled data migration with reconciliation against the GL.
- Returns and credit/debit notes need cost-layer reversal semantics.
- Periodic revaluation and landed-cost allocation need their own controlled workflows.
- PostgreSQL concurrency tests must verify row locking under parallel issues/receipts.
