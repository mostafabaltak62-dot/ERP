# Phase 5.4 — Production Transaction Integrity

## Completed
- Row locking (`FOR UPDATE`) added to sales-order delivery and purchase-order receiving critical sections.
- Payment idempotency added through `Idempotency-Key` and a database unique constraint scoped by company.
- Customer/supplier payment services lock the target invoice before calculating outstanding balance.
- Payment allocations have a database-level positive-amount CHECK constraint.
- Inventory valuation reconciliation service compares authoritative stock movement value with valued remaining layers and consumption.
- Inventory reconciliation API endpoint added.
- PostgreSQL production-gate script added. It refuses to claim a PostgreSQL pass when PostgreSQL is not configured.
- SQLite-compatible Alembic batch migration implemented for the new constraints.

## Verification
- Pytest: 36/36 passed.
- Python compilation: passed.
- Fresh SQLite Alembic migration through revision `9e7f6a5b4c32`: passed.
- PostgreSQL runtime RLS/concurrency gate: **not executed in this environment** because no PostgreSQL server/driver is available. This is intentionally reported as unverified rather than falsely marked passed.

## Remaining production gate
Run:

```bash
DATABASE_URL='postgresql+psycopg://USER:PASSWORD@HOST/erp' python scripts_phase54_production_gate.py
```

Then execute the PostgreSQL concurrency/security suite against a disposable production-like database before release.
