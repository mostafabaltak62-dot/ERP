# PATCH 104 — Construction Document Control / Official Forms Deep Audit

## Scope
Deep production audit of the Construction Document Forms workspace shown in the supplied UI reference, including all official document types, schema validation, create/edit lifecycle, tenant/project scope, approval workflow, attachments, print, PDF export, Excel export, responsive UI, and regression coverage.

## Official document coverage — 15/15
1. SIR — Site Inspection Request
2. MIR — Material Inspection Request
3. MT — Material Transmittal / Submittal
4. DWG — Drawing Register
5. LITER — Letter / Correspondence
6. BOQ — Bill of Quantities
7. RFI — Request for Information
8. V.O — Variation Order
9. QS — Quantity Survey
10. SNA — Snag List
11. DOC — Document / File
12. POUR — Pouring Permit
13. INITIAL_HANDOVER — Initial Taking Over Certificate
14. FINAL_HANDOVER — Final Handover Certificate
15. LOG — Document / Site Log

## Findings against Patch 103
### Critical / material gaps found
- The workspace did not provide official Excel export for each created form.
- The workspace did not provide direct PDF export for each created form.
- Existing print output was HTML/browser print only and did not expose a direct PDF artifact.
- Existing workspace had no edit UI/API for draft or revision-required forms.
- Select/date/numeric values inside the flexible JSON schema were not fully validated server-side against their declared field schema; client-side controls alone were insufficient.
- Revision-required resubmission did not increment the form revision counter.
- Print decision indicators were static and could disagree with the actual system status.
- Excel sheet titles required sanitization for document labels containing invalid Excel characters such as the slash in `Document / File`.
- The legacy accounting regression contained a false-positive assertion (`or True`). It was corrected.
- A multi-tenant sequence-counter interaction caused the full regression to fail because the tenant ORM filter hid the globally unique technical counter. The counter lookup now bypasses tenant filtering only for the technical counter and increments it using direct SQL without making a foreign-tenant ORM object dirty.

## Patch 104 corrections
### Workspace
- Added official-form mini previews to the 15 cards.
- Added direct actions for existing records: View/Print, PDF, Excel, and Edit when lifecycle state permits.
- Preserved RTL and responsive behavior.

### Lifecycle / backend
- Added `PUT /construction-document-forms/{form_id}` for controlled editing.
- Editing is allowed only for `draft` and `revision_required` states.
- Project and form type are immutable during edit.
- Document Register mirror is updated with edited title/discipline/due date/content.
- Resubmission from `revision_required` increments `current_revision`.

### Validation / integrity
- Submission type is allow-listed (`new`, `resubmission`).
- Required fields are validated server-side with whitespace handling.
- Select fields are validated against declared options.
- Date fields are validated as ISO dates.
- Numeric fields reject non-numeric, NaN, and Infinity values.
- Quantity/rate/measurement/volume/time-impact fields reject negative values.
- Flexible text values are bounded to prevent uncontrolled payload growth.
- Pouring Permit trade checklist remains mandatory for Civil, Architectural, Electrical, and Mechanical.

### Export / print
- Added Excel export for every official form type.
- Excel is RTL, print-configured for A4, bordered, wrapped, with merged official header/sections and all stored values.
- Added PDF export for every official form type with Arabic shaping support where available, A4 layout, wrapped long values, metadata, form fields, decision status, and signatures.
- Browser print remains available and uses the same authoritative stored values.
- Print decision now reflects actual workflow status rather than static checkboxes.

### Security / scope
- Existing tenant/company/project scope checks remain enforced for view, edit, submit, approve, print, export, attachment listing, and attachment download.
- No export endpoint accepts a client-supplied company/project scope; it resolves scope from the authenticated form and server tenant context.

## Test results
### Construction-document focused suite
**19/19 PASS**

Includes all 15 form registrations/schemas, server validation, Excel generation for all 15 forms, PDF generation for all 15 forms, document register integration, document controller regression, and accounting sequence regression touched by the patch.

### Construction/document governance regression
**16/16 PASS**

### Accounting regression touched by sequence-counter correction
**13/13 PASS**

### Complete repository regression
The repository test suite was split into two fresh-database batches because a single uninterrupted run exceeded the execution time window. Both batches covered the complete collected test-file set:
- Batch A: **135/135 PASS**
- Batch B: **154/154 PASS**
- Total complete coverage: **289/289 PASS**

The earlier uninterrupted run was therefore treated as a timeout, not as a PASS claim. The final complete split execution passed all 289 collected tests.

## Release status
**PATCH 104 — READY AS THE CURRENT SOURCE OF TRUTH FOR THIS WORKSTREAM**

No new Alembic migration was required for Patch 104.
