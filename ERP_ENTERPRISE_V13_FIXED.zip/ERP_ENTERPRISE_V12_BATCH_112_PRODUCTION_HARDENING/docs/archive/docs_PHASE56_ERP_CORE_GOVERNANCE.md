# ERP V8 — Phase 5.6 ERP Core Governance

## Delivered
- Versioned tenant-scoped document attachments with unique storage keys.
- Generic workflow definition API with ordered approval steps and required permissions.
- Hardened workflow decisions: tenant scope, row locking, required-permission enforcement, and duplicate-action prevention.
- Centralized notification creation with tenant/user ownership.
- New granular permissions: `core:documents`, `core:workflow`, `core:notifications`.
- Central RBAC route mapping for the new Core APIs.
- PostgreSQL RLS for newly governed Core tables where `company_id` exists.
- Migration `c9d8e7f6a5b4`.

## Validation
- Full test suite: **42 passed**.
- Python compilation: **passed**.
- Fresh Alembic migration through `c9d8e7f6a5b4`: **passed on SQLite**.
- PostgreSQL native RLS remains a staging gate because a PostgreSQL server was not available in this execution environment.

## Production notes
- Attachment `storage_key` is metadata only; actual object storage integration must be supplied by the deployment environment.
- UTC timestamp generation is centralized through the project time helper; the suite is clean under `-W error::DeprecationWarning`.
