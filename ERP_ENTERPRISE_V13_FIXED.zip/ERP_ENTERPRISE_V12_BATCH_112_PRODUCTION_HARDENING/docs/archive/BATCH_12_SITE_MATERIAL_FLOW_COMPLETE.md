# Batch 12 — Site Material Flow Complete

Base: `ERP_ENTERPRISE_V10_BATCH_11_PROJECT_COST_CONTROL_COMPLETE`

## Completed
- Rebuilt the Site Material Flow workspace with operational KPIs.
- Enforced the physical workflow: warehouse issue -> site receipt -> consumption/waste/return.
- Site availability now uses posted site receipts instead of warehouse issues, preventing consumption before receipt.
- Receipt rows now show received quantity, remaining quantity and site/item names.
- Added receipt date and reference capture.
- Consumption validates active project site and active company item.
- Consumption cost uses the latest posted receipt cost and creates a linked `ProjectCost` record.
- Waste creates a linked project cost; returns create a negative project cost and stock movement back to the warehouse.
- Added unified recent movement ledger with named item/site details, quantities, costs, dates and references.
- Added project-scoped KPI cards for issued, received, pending receipt, consumed, waste, return, site balance and cost values.
- Improved empty states and mobile-friendly table/form layout.
- Fixed a discovered application startup regression in `planning_costs_router.py` where `_date` was referenced before import.

## Validation
- Python compilation passed for modified modules.
- Jinja template validation passed.
- Targeted regression tests: 9 passed.
