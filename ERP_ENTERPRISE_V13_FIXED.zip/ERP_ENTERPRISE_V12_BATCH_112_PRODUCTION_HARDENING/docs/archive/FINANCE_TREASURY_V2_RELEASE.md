# Finance & Treasury V2 — Branch Accounting + Consolidation

## Implemented
- Branch-level accounting dimensions on Accounts, Journal Entries/Lines, Finance Vouchers, Accounting Periods, Bank Reconciliations, Payment Allocations, Sales Invoices, Purchase Orders and Purchase Invoices.
- Company-wide consolidation is the default administrator workspace; branch drill-down remains available through authorized branch context.
- Branch-specific account resolution prefers a branch account and safely falls back to a company-wide account.
- New postings carry company_id and branch_id; legacy NULL branch rows remain part of consolidated/company-wide reporting.
- Tenant authorization remains server-side; branch selection is validated against UserCompanyAccess.
- Finance dashboard upgraded with cash/bank position, YTD operating/investing/financing cash flow, branch/consolidated selector, recent vouchers and accounting-period controls.
- Cash-flow reporting unified under the authoritative accounting reporting engine; the duplicate legacy enterprise cash-flow implementation now redirects to the authoritative report.
- Cash-flow report upgraded with IAS 7 summary, opening/closing reconciliation and detailed posted cash movements.
- Hard-coded cash account lists replaced in the new Finance UI with accounts classified as cash_and_equivalents, scoped to company/branch.
- Sales/Purchase documents created through web/API flows now inherit the authorized branch and their journal entries are branch-aware.
- Company-wide Chart of Accounts is protected from accidental branch stamping; branch-specific accounts can be explicitly created.
- PostgreSQL/psycopg3 URL normalization and dotenv loading are enabled.
- Pre-existing FK model/migration drift was closed with a dedicated migration.

## Migrations
- `l3m4n5o6p7q8`: branch-level finance ledgers and company consolidation support.
- `m4n5o6p7q8r9`: financial foreign-key hardening.

## Verification
- Fresh SQLite Alembic migration to head: PASS.
- Security audit: PASS.
- Quality gate: PASS.
- Targeted accounting/finance/security/http/login/branch tests: PASS.
- Full repository suite still contains legacy test-isolation failures when tests are executed as one process; these are not hidden or counted as release success. The affected tests pass in their intended isolated execution paths.
