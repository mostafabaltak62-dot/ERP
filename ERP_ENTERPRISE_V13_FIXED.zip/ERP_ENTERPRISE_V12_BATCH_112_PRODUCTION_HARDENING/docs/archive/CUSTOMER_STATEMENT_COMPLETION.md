# Customer Statement Completion

## Scope completed
The customer statement workspace was completed as a functional ERP page, not a visual-only change.

### Functional improvements
- Customer profile block: code, phone, email and address.
- Date range filtering and quick periods: month, quarter, year, all periods.
- Search by reference/document description.
- Customer-specific transaction type filtering.
- Financial summary based on the full selected period so text/type filters cannot distort accounting balances.
- Correct opening and closing balance calculation.
- Running balance per transaction.
- Human-readable transaction labels.
- Drill-down links to source sales invoices where available.
- CSV/Excel-compatible export with the same active filters.
- Print / Save as PDF workflow from the real statement.
- Clear empty state and reset action.
- Company and branch scoping preserved for invoices and payment allocations.
- Cancelled/void/draft sales invoices excluded from the statement movement.

## Validation
- `python -m py_compile app/routers/advanced_finance_router.py` passed.
- Jinja template loading passed.
- Relevant test set: 5 passed.

## Important accounting rule
Search and transaction-type filters only control what the user sees in the table. Opening balance, period totals and closing balance remain based on all movements in the selected date range, preventing a filtered view from presenting a false accounting balance.
