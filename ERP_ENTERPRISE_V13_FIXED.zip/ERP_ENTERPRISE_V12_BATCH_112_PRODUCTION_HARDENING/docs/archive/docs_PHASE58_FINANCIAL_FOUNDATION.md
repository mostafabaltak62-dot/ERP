# ERP Accounting V8 — Phase 5.8 Financial Foundation

## Delivered
- Reused the existing tenant-aware CostCenter model instead of creating a duplicate table.
- Added Budget and BudgetLine with company-scoped uniqueness and NUMERIC financial precision.
- Added ProjectForecast for budget/commitment/actual/final-cost/revenue/profit forecasting.
- Added governed API endpoints for cost centers, budgets, budget lines, budget variance, project profitability, and project forecasts.
- Budget variance derives actuals from posted JournalEntry/JournalLine data.
- Project profitability derives revenue from active project-linked Contracts and costs from ProjectCost; no hard-coded revenue fallback.
- Added PostgreSQL RLS policies for new financial-core tables.
- Added migration `4e5f6a7b8c90_phase58_financial_foundation.py`.
- Added automated tests for tenant-scoped budgets and project forecasting.

## Verification
- Existing regression suite + Phase 5.8: 44 passed.
- Fresh Alembic migration to `4e5f6a7b8c90` passed on SQLite.
- Python compilation passed.
- Temporary/binary artifacts cleaned.

## Known gates
- HTTP runtime tests remain unverified in this execution environment because `bcrypt` is not installed.
- PostgreSQL runtime RLS/concurrency verification still requires a real PostgreSQL service.
- UTC timestamp generation is now centralized and timezone-safe; the test suite is clean under strict deprecation-warning enforcement.
