# Phase 4.1 — PostgreSQL RLS & Authorization Enforcement

## Security boundary

The application now has two independent tenant-isolation layers:

1. FastAPI/SQLAlchemy authorization and tenant filtering.
2. PostgreSQL native Row-Level Security (RLS) on every table containing `company_id`.

The DB layer is fail-closed. A request without an authorized tenant context receives a sentinel context and cannot satisfy an RLS policy.

## PostgreSQL requirements

Production must use PostgreSQL. The application publishes the already-authorized request context to each SQLAlchemy transaction using:

- `app.company_id`
- `app.branch_id`
- `app.user_id`

Policies are created with `FORCE ROW LEVEL SECURITY`, so table-owner bypass is not silently available.

## Branch isolation

Company-scoped records are visible only inside the active company. Records carrying `branch_id` are visible only when their branch matches the active branch; company-wide rows with `branch_id IS NULL` remain visible to users inside that company.

## Important deployment rule

The runtime PostgreSQL role must not be granted `BYPASSRLS`. Database migrations should run under a controlled deployment role; the application runtime role should have only the privileges required to operate the schema.

## Testing

The RLS contract is tested even in SQLite CI. A PostgreSQL integration environment should additionally execute live cross-company and cross-branch queries after migrations.
