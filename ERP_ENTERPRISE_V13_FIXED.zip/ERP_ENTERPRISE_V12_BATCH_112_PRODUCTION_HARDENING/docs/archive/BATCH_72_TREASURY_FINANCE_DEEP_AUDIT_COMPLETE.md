PATCH 72 — TREASURY & FINANCE DEEP AUDIT COMPLETE

Baseline:
ERP_ENTERPRISE_V10_PATCH_71_SOURCE_OF_TRUTH_DEEP_AUDIT_HARDENED.zip

Scope:
Cash Flow, Bank Reconciliation, Accounts Receivable, Accounts Payable, Audit Log, General Ledger.

Deep findings and fixes:
1. Bank reconciliation was incorrectly treating matched bank-statement items as reconciliation adjustments. This could distort the difference and prevent/allow closure incorrectly. Fixed: only UNMATCHED statement items affect adjusted-book reconciliation.
2. Bank matching could select a posted GL movement far outside the statement transaction date. Fixed with a bounded 7-day matching window plus statement-date upper bound, while retaining company/branch/account/status/amount controls.
3. Legacy finance audit endpoint used the older unscoped AuditLog and accounting-module access, creating a tenant-isolation risk. Fixed to use GovernanceAuditLog scoped to the current company and audit permission, with the hardened audit UI.
4. Fresh migration syntax audit found a historical Batch 26 migration containing invalid Python syntax caused by placing `with` after a semicolon on the same statement. Rewritten safely while preserving schema intent and batch constraints.
5. Re-validated the finance/reporting stack after changes.

Existing Patch 69/71 controls revalidated:
- Command Center Authentication
- Accounting rate-limit behavior
- Mobile login/bootstrap fixture
- Inventory valuation policy controls
- Migration governance

QA:
- Full pytest: 210 passed, 0 failed.
- Python py_compile across all .py files: 0 errors.
- Targeted finance tests after fixes: 10 passed.
- No migration head was introduced by this patch.

Important accounting integrity:
- GL remains the authoritative source for posted financial reports.
- Cash-flow uses posted GL lines.
- Bank reconciliation uses posted GL bank balances.
- AR/AP aging remains company/branch scoped.
- Audit viewing is tenant scoped.

Note:
AR/AP currently derive aging from invoice date because the existing invoice schema has no explicit due_date field. Payment allocations are company-scoped. Adding contractual due dates would be a separate schema/business-rule enhancement rather than silently inventing one here.

Release status:
PRODUCTION HARDENED — with the above known schema limitation explicitly documented.
