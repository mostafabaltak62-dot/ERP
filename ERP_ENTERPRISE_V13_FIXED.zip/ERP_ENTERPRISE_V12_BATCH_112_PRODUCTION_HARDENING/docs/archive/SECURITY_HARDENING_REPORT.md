# ERP Security Hardening Report

## Scope

Implemented and verified the requested security controls without changing the accounting business rules.

## 1. Rate Limiting

- Authentication endpoints: **5 requests/minute/IP**.
- API endpoints: **100 requests/minute/IP**.
- Excess traffic returns **HTTP 429** with `Retry-After` and rate-limit headers.
- The application uses a bounded in-process limiter by default.
- Multi-worker/cluster deployments can set `ERP_RATE_LIMIT_REDIS_URL` to share counters through Redis.
- Proxy IP headers are not trusted unless `ERP_TRUST_PROXY_HEADERS=true` is explicitly enabled.

## 2. SQL Injection Protection

- Existing application SQL access was reviewed for dynamically constructed SQL.
- No f-string/concatenated SQL was found in the application SQL expressions.
- SQLAlchemy ORM/select statements remain the primary query mechanism.
- Added `scripts/security_audit.py` as a repeatable static gate against dynamic SQL expressions and hard-coded database URLs.
- Existing Pydantic request models provide type/length/range validation on API inputs.

## 3. Authentication

- bcrypt password hashing remains enabled.
- Password creation is now rejected unless it is at least 12 characters and contains upper-case, lower-case and numeric characters.
- Access JWTs now carry an explicit `type=access` claim and default to a 1-hour lifetime.
- Added server-side opaque refresh tokens stored only as SHA-256 hashes.
- Refresh tokens expire after 7 days by default.
- Refresh tokens are rotated on use and the previous token is revoked, preventing replay.
- Logout revokes the refresh token and clears both cookies.

## 4. Authorization / Tenant Isolation

- Existing centralized endpoint RBAC remains active.
- Existing tenant access is resolved from `UserCompanyAccess`; client-supplied tenant IDs never grant access.
- Existing project/site scope checks remain active.
- Existing PostgreSQL native RLS migration remains part of the Alembic chain.

## 5. Database Migration

Added:

`j1k2l3m4n5o6_security_refresh_tokens.py`

A fresh SQLite migration test reached Alembic `head` successfully and created `refresh_tokens`.

## Verification

- Security hardening tests: **17/17 PASS**.
- Python compilation: **PASS**.
- Fresh Alembic upgrade to head: **PASS**.
- SQL static audit: **PASS**.
- Existing project tests were also exercised. Two legacy governance tests can fail when the complete suite is executed in a polluted global test-database/order context, while they pass independently; this is test-isolation debt rather than a security implementation failure.
- PostgreSQL/Neon production RLS/concurrency gates cannot be honestly marked executed from an environment without a live PostgreSQL connection.

## Deployment Safety

The changes are additive and preserve the existing ORM, tenant, RBAC and accounting flows. Production should run Alembic migrations before starting the application and should configure Redis for shared rate limiting when multiple workers/instances are used.
