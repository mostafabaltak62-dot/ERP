# ERP Enterprise V10 — Patch 107
## Production Secret Encoding & Authentication Fail-Closed Hardening

### Baseline
Patch 106 — report/source comparison and production Compose validation.

### Deep audit finding 1 — Reserved characters could corrupt production connection URLs
**Severity: Release-blocking configuration integrity risk**

Patch 106 correctly fixed Compose syntax and secret injection, but the Compose file still embedded raw database and Redis passwords directly inside URI strings. Passwords containing reserved characters such as `@`, `:`, `/`, `#` or spaces can change URI parsing and cause failed authentication, incorrect host parsing, or unexpected startup failures.

#### Fix
- Added safe PostgreSQL URL construction from discrete `ERP_DB_*` values using percent-encoding.
- Updated `migrate`, `web`, `worker`, and `beat` to pass discrete DB credentials rather than interpolating raw secrets into `DATABASE_URL`.
- Added safe Redis URL construction from `ERP_REDIS_HOST`, `ERP_REDIS_PORT`, and `REDIS_PASSWORD`.
- Updated Celery, auth revocation, shared rate limiting, and readiness checks to use safely built Redis URLs when explicit provider URLs are absent.
- Updated `.env.production.example` and the production runbook to match the actual deployment model.

### Deep audit finding 2 — JWT revocation could fail open during a Redis outage
**Severity: High / security boundary risk**

Production already required Redis to be configured at startup, but after startup a Redis operation failure could fall back to process-local memory. In a multi-worker deployment, a token revoked on another worker might therefore remain valid on the current worker.

#### Fix
- Added `AuthBackendUnavailable` for shared authorization-state failures.
- Production token validation now fails closed when authorization-state lookup cannot be trusted.
- Production revocation-store failures no longer silently degrade to per-process memory.
- Development/test retains bounded in-memory fallback behavior for local usability.

### Validation performed
- `python -m compileall -q app alembic/versions`: **PASS**
- Production Compose YAML parse: **PASS**
- Reserved-character PostgreSQL URL regression: **PASS**
- Reserved-character Redis URL regression: **PASS**
- Focused security/document/export regression suite: **40 passed**
- Repository test collection: **295 tests collected**
- Full-suite PASS is **not claimed**; a prior full run again exceeded the available execution window at about 24% without an assertion failure.

### Release status
**PATCH 107 — PRODUCTION CONFIGURATION AND AUTHENTICATION HARDENED**

This patch fixes two hidden production issues discovered after Patch 106 and keeps QA reporting explicit about what was and was not fully executed.
