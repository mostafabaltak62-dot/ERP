# PATCH 44 — New Purchase Order Deep Production Audit

## Scope
Deep audit of the **New Purchase Order** page (`/purchases/new`) and its authoritative create workflow (`POST /purchases/new`). Review covered UI/RTL/responsive behavior, validation, tenant isolation, branch scope, RBAC/permission layering, BOLA/IDOR, database integrity, approval workflow, audit trail, transaction safety, scalability, and integration with inventory/receiving.

## Findings and fixes

### Critical / High
- **PO tenant ownership**: new POs now require an active company context and the ORM model marks `purchase_orders.company_id` as non-nullable. Patch 44 migration backfills legacy PO company ownership from the supplier and fails closed if any row cannot be mapped.
- **Duplicate PO lines**: application validation already rejected duplicate item IDs. A database unique constraint was added for `(company_id, po_id, item_id)` so concurrent or non-HTTP writes cannot create duplicate lines.
- **Branch isolation**: selected warehouse/project are now validated against the active branch when they carry a branch assignment, preventing cross-branch purchase commitments.
- **Audit trail**: successful PO creation now writes an immutable-governed `AuditLog` entry containing the PO identifier and amount.
- **Commit conflict handling**: integrity conflicts at final commit now rollback and return a controlled 409 instead of leaking a database exception.

### Medium
- **Responsive layout**: the form now collapses its metadata grid on small screens and keeps the line editor usable through controlled horizontal scrolling rather than clipping columns.
- **Client-side guardrails**: the browser validates finite numeric quantities/prices and requires a valid line before submission. Server-side validation remains authoritative.
- **Stock hint clarity**: the UI explicitly labels the displayed stock as company-level stock; it no longer implies that it is warehouse-specific when the receiving warehouse is selected separately.

## Existing architecture risks reviewed
- Inventory valuation is still warehouse-independent at the valuation-layer level; this is a broader inventory architecture issue and was not silently changed inside the PO form patch.
- Partial receiving remains a separate workflow concern; current authoritative receiving behavior intentionally prevents a second receipt for the same PO.
- Global document numbering remains consistent with the current globally-unique schema.
- Payment method remains an allow-listed business field; mapping to configurable accounting accounts belongs to the broader AP/payment configuration layer.

## Security review
- Tenant-scoped Supplier, Item, Warehouse and Project lookups are enforced server-side.
- RBAC remains enforced by `require_module(..., need_edit=True)` plus the central route permission layer.
- Client-supplied totals are not trusted; line totals are recomputed server-side.
- Numeric input rejects NaN/Infinity and out-of-range values.
- Cross-site unsafe browser requests are blocked by the existing same-origin CSRF middleware.
- No new direct object reference path was introduced; PO creation accepts only validated tenant-owned foreign keys.

## Verification
- Python compilation: PASS
- Targeted Patch 43 + Patch 44 tests: **4 passed**
- Full regression suite: **143 passed, 0 failed**

## Release
**ERP Enterprise V10 — PATCH 44 — NEW PURCHASE ORDER PRODUCTION HARDENED**
