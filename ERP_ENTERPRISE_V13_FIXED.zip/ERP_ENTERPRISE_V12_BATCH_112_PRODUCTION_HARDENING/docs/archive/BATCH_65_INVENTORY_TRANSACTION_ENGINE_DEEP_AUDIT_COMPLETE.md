# Patch 65 — Inventory Transaction Engine Deep Audit & Production Hardening

## Scope
Deep audit of the inventory transaction engine following the Inventory & Items review. Scope included stock movement model integrity, operational dating, source traceability, transfer atomicity, tenant/warehouse isolation, negative-stock enforcement, valuation compatibility, direct movement paths, and regression impact.

## Findings fixed
1. **Critical runtime bug:** `_item_for_update()` in `inventory_router.py` recursively called itself and could never return an item. Replaced with a tenant-scoped `SELECT ... FOR UPDATE` query.
2. **Missing operational transaction date:** `StockMovement` now has `operational_date`, separated from system creation time, with a database index for ledger/time-phased queries.
3. **Weak source traceability:** added `source_type`, `source_id`, and `transfer_id` fields plus indexes. Critical sales/purchase/return/site paths now populate source metadata where the originating document is available.
4. **Reversal traceability foundation:** added nullable `reversal_of_id` self-FK to support governed reversal chains without deleting historical movements.
5. **Financial numeric integrity:** added database checks preventing negative unit cost and total cost.
6. **Transfer integrity:** warehouse transfers now use a single transfer identity and the centralized movement primitive; both legs are created in the same transaction and source-warehouse availability is locked/validated.
7. **Centralized movement primitive:** added `app/inventory_transactions.py` enforcing company/item/warehouse scope, active-item checks, positive quantities, non-negative cost, negative-stock policy, and source duplicate protection.
8. **Item model drift:** `Item.code` remains non-global at the SQLAlchemy model level so the Patch 64 company-scoped unique constraint is authoritative. Customer/Supplier code declarations were verified/restored after the edit to avoid unrelated schema drift.

## Architectural follow-up retained
- `warehouse_id` remains nullable for legacy movements and historical compatibility; the new primitive supports warehouse-scoped control and should be adopted by every remaining legacy writer during the next transaction migration wave.
- Serial/lot/expiry quantity ledgers and full reversal documents are not fabricated in this patch because they require dedicated domain models and workflow semantics.
- Negative stock is not silently valued. The valuation engine continues to reject unsupported negative valuation scenarios.

## Validation
- Python compilation: PASS.
- Targeted inventory/transaction regression: **18 passed**.
- Full regression: **164 passed before timeout/stop, 5 known failures outside the Patch 65 inventory scope**. Known failures include Command Center authentication, accounting rate-limit, mobile bootstrap credentials, and legacy test fixtures for password/approval data. These were not misreported as passing.
- Alembic revision graph: **single head `p65_inventory_transaction_engine`**.
- Fresh full Alembic upgrade could not be completed because the pre-existing `c2d3e4f5a6b7_batch24_transmittal_receipt_tracking` migration attempts a direct SQLite foreign-key ALTER and raises `NotImplementedError` before Patch 65 is reached. This is a legacy migration-chain blocker, not a Patch 65 migration failure.

## Result
Patch 65 hardens the inventory transaction foundation without claiming the remaining legacy movement writers or legacy Alembic chain are fully migrated.
