# Batch 88 — Changes in Equity Deep Audit

Baseline: Patch 87 — General Ledger Production Hardened
Release: Patch 88

## Scope
Deep audit of the Statement of Changes in Equity across calculation engine, fiscal closing behavior, tenant/branch scope, presentation, exports, API endpoint, and regression safety.

## Findings & Fixes
1. Corrected the opening-equity source to use the selected period opening balances rather than a to-date-only trial balance.
2. Prevented fiscal-period closing entries from being counted as a second equity movement.
3. Prevented fiscal-period closing entries from causing period profit to be double-counted; profit is now derived from posted revenue/expense activity excluding closing transfers.
4. Added an explicit reconciliation invariant: closing equity = opening equity + non-closing equity movements + period profit.
5. Added per-equity-account opening, period movement, and closing values for auditability.
6. Preserved Company/Branch isolation in the reporting engine and API path.
7. Added a dedicated tenant-aware equity export route and ensured UI Excel/PDF links preserve the selected branch.
8. Replaced the minimal equity presentation with a detailed RTL statement and explicit explanation of closing-entry treatment.

## Validation
- Targeted equity regression: 1/1 PASS.
- Existing financial reporting regression: 3/3 PASS.
- Combined targeted reporting regression: 4/4 PASS.
- Python compilation: PASS.
- Fresh SQLite Alembic upgrade from empty database to head: PASS.
- Alembic heads: single head `p83_financial_validation`.

## Full Regression
A complete suite run was not used as a release-gate claim for this patch; only completed targeted/regression checks above are reported as passing.

## Release Status
Patch 88 is the approved sequential release for the Changes in Equity page.
