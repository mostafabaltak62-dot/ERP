# BATCH 64 — Inventory & Item Master Deep Audit

## Scope
Deep production-grade review of the Inventory & Items page and its related model/router/database contracts, using Patch 63 as the baseline.

## Implemented fixes
- Changed item code identity from globally unique to **company-scoped unique** (`company_id + code`) to prevent false cross-company conflicts.
- Added company-scoped barcode uniqueness (`company_id + barcode`).
- Added database constraints for non-negative prices, stock thresholds, reorder quantities, positive conversion factor, and tax rate range.
- Hardened text validation for item code/name (trim, required, max length).
- Hardened checkbox parsing so string values such as `false` are not interpreted as truthy.
- Allowed valid fractional unit conversion factors (`> 0`) instead of incorrectly forcing all factors to `>= 1`.
- Added safe barcode duplicate checks at application level.
- Prevented converting a product with existing stock movements into a service.
- Prevented new movements against inactive items.
- Added row locking for manual stock movement creation to reduce concurrent over-issue races on PostgreSQL.
- Manual stock issue now preserves the explicit item-level negative-stock policy instead of unconditionally rejecting all negative stock configurations.
- Search now includes barcode and is bounded/trimmed.
- Reworked the item list stock aggregation to avoid one stock SUM pair per item (N+1 pattern) and calculate balances in a grouped query.
- Preserved company scoping on item listing/export/detail/update/create paths.

## Tests
### Targeted
`10 passed`

Covered:
- Patch 64 item governance contract
- Patch 57 stock ledger controls
- Patch 58 warehouse governance
- Patch 60 financial voucher controls
- Patch 63 accounting period governance

### Full regression
The suite was started and reached:
- **86 passed before the first 3 failures were displayed** when rerun with `--maxfail=3`.
- The failures are pre-existing/unrelated to the Inventory & Items changes:
  1. Command Center UI test receives 401 authentication.
  2. HTTP regression hits 429 rate limit on `/accounting`.
  3. Mobile security login fixture receives 401 invalid credentials.
- A normal full run also timed out during the suite after reaching the later test stages.

These are explicitly not counted as a clean full-suite pass.

## Files changed
- `app/models.py`
- `app/routers/inventory_router.py`
- `alembic/versions/p64_inventory_items_governance.py`
- `tests/test_batch64_inventory_items.py`

## Migration
Revision: `p64_inventory_items_governance`
Down revision: `p63_accounting_period_governance`

Migration uses Alembic batch mode for SQLite portability.

## Remaining architectural follow-up
The broader inventory transaction engine still needs a dedicated hardening pass for:
- operational transaction dates vs `created_at`
- mandatory warehouse/source document identity
- formal transfer/reversal governance
- serial/lot/expiry transaction enforcement
- valuation synchronization for direct/manual movements

Those concerns are intentionally not hidden by superficial UI fixes.
