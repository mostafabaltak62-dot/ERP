# BATCH 54 — Cost Control & Governance Deep Audit

## Scope
Production-grade audit and hardening of Project Cost Control: Budget → Commitment → Actual → ETC → EAC → Variance, with explicit EAC governance and auditable status snapshots.

## Implemented
- Added `ConstructionCostControlSnapshot` with company/project isolation and unique status date.
- Added governed EAC methods: `manual_etc`, `remaining_budget`, and `cpi`.
- CPI-based EAC requires a positive EVM CPI and uses the latest snapshot on/before the status date.
- Added draft/approved workflow for cost-control snapshots with row locking on approval.
- Added duplicate status-date protection and database non-negative constraints.
- Added Cost Status Snapshot UI to the Cost Control workspace.
- Added POST endpoints for snapshot creation and approval with existing project/tenant authorization.
- Preserved existing Budget/Commitment/Actual/Forecast logic and all prior planning integrations.

## Validation
- Python compilation: PASS
- Targeted cost-control + branch scope + planning governance tests: 7 PASS
- Full regression suite: 163 PASS, 1 warning
- Alembic graph: Patch 54 is chained after `p52_recovery_eot_schedule_updates`.

## Notes
The existing repository contains legacy Alembic modules that import application settings during graph discovery; therefore Alembic CLI discovery requires a valid `DATABASE_URL` runtime configuration. This is an existing runtime configuration requirement, not a Patch 54 application failure.
