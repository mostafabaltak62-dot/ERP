# Patch 74 — Budget Monitoring Center Deep Audit

## Scope
Deep production audit of the Budget Monitoring Center (`/enterprise-control/budget-control`) and its authoritative cost-control dependencies.

## Findings and fixes
1. **Authoritative budget mismatch fixed** — the monitoring center previously rebuilt its displayed budget from active budget lines/project budget and could ignore approved budget revisions. It now consumes materialized authoritative budget lines when present, with a safe legacy fallback only when no authoritative rows exist.
2. **Zero-authoritative-budget fallback fixed** — a legitimate authoritative total of zero is no longer mistaken for an uninitialized budget.
3. **Inactive policy leakage fixed** — only active budget-control policies are applied to monitoring rows.
4. **Branch scoping fixed** — the center now respects the active branch context using the established ERP rule: current branch plus explicitly unassigned projects.
5. **Budget-control enforcement completed** — `block_over_budget` is now a real backend control for new commitments, not merely a dashboard checkbox. It evaluates actual + open/approved/active commitments against authoritative budget plus configured tolerance, under the company/project scope.
6. **Concurrency protection strengthened** — commitment creation locks the project row before evaluating budget exposure to reduce race-condition oversubscription.
7. **Fresh migration defect discovered and fixed** — Patch 64 attempted to drop `items_code_key` as a unique constraint, while the baseline schema actually created `ix_items_code` as a unique index. The migration now detects the actual legacy object and safely removes it before applying company-scoped item uniqueness.

## Validation
- Targeted Budget/Cost-Control tests: **24 passed**
- Python compilation: **PASS**
- Alembic heads: **single head `p74_merge_tax_procurement`**
- Fresh SQLite `alembic upgrade head`: **PASS** after the Patch 64 migration repair
- Full pytest run: environment execution timeout after approximately 66% progress; no assertion failure was observed before timeout. It is intentionally not represented as a full-suite pass.

## Quality gate
No unsupported claim of 100% full-suite completion is made. The release is considered production-hardened for the audited Budget Monitoring Center scope, with the full-suite timeout documented as an environment/runtime limitation.
