# Batch 27 — Enterprise Item Master Complete
تم تحويل صفحة الصنف إلى بطاقة Item Master موسعة تشمل البيانات الأساسية والفنية ووحدات القياس والتكلفة وسياسات المخزون والجودة.

## إضافات
- أسماء عربية/إنجليزية ووصف وShort Name
- Category + Item Group
- Brand / Manufacturer / Model / Origin
- Purchase & Issue UOM + Conversion Factor
- Standard/Purchase/Sale Cost
- Min/Max/Reorder/Safety Stock + Lead Time
- Negative Stock Policy
- Inspection/MIR/Certificate Requirements
- Migration مستقلة ومتوافقة مع Batch 26
