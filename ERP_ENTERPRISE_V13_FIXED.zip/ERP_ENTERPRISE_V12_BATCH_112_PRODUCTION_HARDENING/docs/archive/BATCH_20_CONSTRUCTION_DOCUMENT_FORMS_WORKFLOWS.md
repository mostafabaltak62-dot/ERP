# ERP Enterprise V10 — Batch 20
## Construction Document Forms & Workflows Completion

## Scope
This batch continues the Document Control module and adds specialized, database-backed construction forms rather than treating SIR/MIR/RFI/etc. as only generic document type labels.

## Implemented form families
- SIR — Site Inspection Request
- MIR — Material Inspection Request
- MT — Material Transmittal / Submittal
- DWG — Drawing Register
- LITER — Official Letter / Correspondence
- BOQ — Bill of Quantities reference workflow
- RFI — Request for Information
- V.O — Variation Order
- QS — Quantity Survey
- SNA — Snag List
- DOC — Controlled Document / File
- POUR — Pouring Permit with civil/architectural/electrical/mechanical checklist requirement
- Initial Handover certificate
- Final Handover certificate
- LOG — Document / Site Log

## Architecture
- `construction_document_forms` stores specialized form identity, project scope, workflow status and structured payload.
- `construction_document_form_decisions` stores immutable decision history.
- Every specialized form creates and links a central `project_documents` record, keeping the main register as the single project-wide document index.
- Company/project scoping and project access checks are enforced.
- Form numbers are generated per form type/project/year sequence.

## Workflow
Draft -> Submitted -> Decision

Supported decisions:
- Approved
- Approved as Noted
- Revise & Resubmit
- Rejected
- Accepted
- Closed

The decision updates both the specialized form and the linked central Project Document status.

## Validation
Each form type has required structured fields. Examples:
- SIR: description
- MIR: material + supplier
- MT: material + technical reference
- DWG: drawing number + revision
- RFI: question
- V.O: reason
- SNA: snag description + assigned to
- Pouring Permit: all trade checklist sections required

## UI
A new Construction Document Forms workspace lists all requested form families and provides a project-scoped creation workspace plus recent-form register.

## Migration
`v2w3x4y5z6b8_batch20_construction_document_workflows.py`

## Verification
- Python compilation: PASS
- Migration syntax compilation: PASS
- Batch 20 tests: 2 passed

## Important next completion work
The module now has the shared specialized form/workflow layer. The next hardening pass should replace the temporary structured-data editor with dedicated field-by-field print forms for each family (SIR, MIR, MT, etc.), then connect each family to its operational domain records and official printable layouts.
