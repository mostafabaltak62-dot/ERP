# ERP Enterprise V10 — Batch 32: Customer Statement Complete

## Page completed
Customer Statement (كشف حساب عميل)

## Implemented
- Customer-specific statement wording and KPIs.
- Opening balance, sales, collections, net movement, closing balance and document count.
- Account status with customer-specific due wording.
- Customer profile block.
- Date range, transaction type and text search filters.
- Quick periods: month, quarter, year and all periods.
- Running balance retained from full chronological account movement.
- Export CSV/Excel-compatible and print/PDF workflow.
- Search/type filters do not distort accounting opening/closing balances.
- Company and branch scoping retained.
- Cancelled/void/draft sales invoices excluded by existing movement logic.
- CSV formula-injection hardening added to the shared statement export endpoint.

## Validation
- `python -m py_compile app/routers/advanced_finance_router.py` passed.
- Jinja template compilation passed.
