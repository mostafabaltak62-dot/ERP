# BATCH 60 — Financial Voucher Creation Deep Audit & Production Hardening

## Scope
Audited the `إنشاء سند مالي` workflow end-to-end: template, route, tenant/branch scope, permissions, account resolution, customer/supplier ownership, date parsing, accounting period governance, journal posting, idempotency, audit logging, and regression behavior.

## Findings & Fixes
- Added explicit `journal:post` authorization to the financial-voucher POST route; UI edit permission alone is no longer sufficient to post.
- Enforced an open accounting period for the voucher's effective date and tenant/branch scope. Posting is rejected when no applicable period exists or when the period is closed.
- Added server-generated idempotency token to the creation form and server-side duplicate detection to make browser retries safe.
- Validated and normalized description; blank descriptions are rejected.
- Hardened amount parsing and retained positive-only monetary validation.
- Hardened voucher date parsing with controlled 422 response for invalid dates; timezone-aware input is normalized for the current DateTime schema.
- Replaced implicit/hard-coded cash-account selection with tenant + branch scoped active account resolution, preferring branch-specific accounts.
- Replaced unvalidated hard-coded AR/AP usage with tenant + branch scoped active account resolution for 1200/2100.
- Validated expense account ownership, activity, type, tenant and branch scope.
- Added audit log entry for successful voucher creation/posting.
- Restricted expense-account choices in the form to the current tenant/branch scope.
- Preserved atomic document + journal posting through the existing `create_entry` transaction boundary.

## Tests
- Targeted voucher creation + financial core + accounting core: **11 passed**.
- Full repository suite: **64 passed before an existing unrelated authentication/UI failure** in `test_command_center_and_project_subpages_are_real_html` (`/projects/command-center` returned 401 after login). No voucher test failure occurred before that suite stop.
- Python compilation: PASS.
- No database migration was required; all hardening uses existing schema fields/constraints.

## Known Follow-up
The wider repository still contains a pre-existing command-center test/runtime authentication mismatch. It is outside the financial-voucher workflow and was not masked as a success.
