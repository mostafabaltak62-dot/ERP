# Batch 110 — Tenant Isolation & Query Deep Audit Started

## Scope started
- Static inventory of direct `Session.get()` calls because these paths require
  explicit review against application-level tenant filtering.
- Query hotspot inventory to prioritize N+1/performance profiling.
- Review of explicit `skip_tenant_filter` use.
- First application-layer remediation applied to approval workflow lookup.
- First confirmed N+1 remediation applied to payroll integration summary.

## First fixes applied
1. `app/workflows.py`
   - Approval requests are now loaded through an explicit `company_id` filter
     when tenant context is available instead of unconditional `db.get()`.
2. `app/routers/commercial_completion_router.py`
   - Passes the active company scope into `act_on_approval()`.
3. `app/routers/hr_router.py`
   - Replaced per-allocation `db.get(PayrollLine, ...)` calls with a single
     joined query returning allocation + employee id.
4. `scripts/tenant_query_audit.py`
   - Added a repeatable static audit tool for future regression checks.

## Next audit queue
- Review remaining direct `Session.get()` calls by model scope.
- Endpoint-by-endpoint company/branch/project authorization tests.
- PostgreSQL RLS integration tests, not SQLite-only tests.
- Query-count profiling for the largest dashboard/service hotspots.
