# Patch 101 — General Accounting / General Ledger Deep Production Audit

## Baseline
- Approved baseline: Patch 100 — AP Aging.
- Scope: General Accounting landing page and all directly related accounting drill-down surfaces: Chart of Accounts, account ledger compatibility route, authoritative General Ledger, Account Statement, Journal Detail, Add/Edit Account, Deactivate Account, Accounting Control/Orphan Accounts, and accounting report exports.

## Findings and fixes
1. **General Accounting landing page tenant isolation**
   - Replaced company-only account/entry loading with governed company + branch resolution.
   - Company-wide users can view consolidated scope or explicitly select an active branch.
   - Branch-only users cannot escape their assigned scope.

2. **General Accounting performance**
   - Removed per-account debit/credit N+1 queries.
   - Replaced them with one grouped journal aggregation for the page.
   - Recent posted journals are fetched in one scoped query.

3. **Historical accounting integrity**
   - Landing page includes accounts in the governed company/branch scope, including inactive accounts that remain historically relevant.
   - Posted-only rule is preserved.

4. **Legacy account ledger drill-down**
   - The old `/accounting/ledger/{account_id}` route was inconsistent with the authoritative GL data shape and could lose branch scope.
   - It now validates the account against governed tenant/branch scope and redirects to the authoritative General Ledger with account/date/branch filters preserved.

5. **Account Statement drill-down**
   - General Ledger → Account Statement now preserves the selected branch and reporting period.
   - This prevents a branch-specific click from silently expanding back to consolidated data.

6. **Journal Detail drill-down**
   - Existing tenant/branch authorization retained.
   - Added visible branch/source context and direct Account Statement links from journal lines.

7. **Chart of Accounts mutation security**
   - POST Edit Account now re-validates access to the account's branch instead of relying only on the GET screen.
   - Deactivate Account now performs the same branch authorization check.
   - This closes an ID-based cross-branch mutation path for branch-scoped users.

8. **Accounting Control / Orphan Accounts**
   - Orphan Accounts now accepts and validates branch scope and preserves it in navigation.

9. **Legacy accounting exports**
   - Fixed the legacy dynamic export handler so Trial Balance, Income Statement, Cash Flow, Equity and General Ledger exports actually receive the selected branch.
   - General Ledger export now supports an explicit `account_id` filter and validates it within tenant/branch scope.

10. **UI/UX / navigation**
   - Reworked the General Accounting page into a single accounting workspace with scoped branch selector, KPIs, GL/Journal/Reports/Controls shortcuts, financial report links, and governed account drill-downs.
   - Fixed the legacy ledger template so it no longer expects the obsolete row object structure.

## Tests
- Patch 101 dedicated tests: **3/3 PASS**.
- Combined accounting/security/reporting regression set: **17/17 PASS**.
- Jinja template compilation for all affected accounting templates: **PASS**.
- Python compile/compileall: **PASS**.
- Fresh SQLite Alembic `upgrade head`: **PASS**.
- No new schema migration required.

## Full suite status
- Full `pytest -q` was attempted.
- It did **not** complete: execution timed out around **51%**.
- A first-failure run showed an existing test-environment/database issue (`attempt to write a readonly database`) before reaching the Patch 101 assertions; therefore no full-suite PASS claim is made.

## Release gate
- Patch 101 changes are based on Patch 100.
- Release package excludes runtime SQLite databases, `__pycache__`, `.pyc`, and pytest cache artifacts.
