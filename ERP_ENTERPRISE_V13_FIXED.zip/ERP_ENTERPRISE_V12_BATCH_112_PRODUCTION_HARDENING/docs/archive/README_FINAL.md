# ERP Accounting System V8 — FINAL RELEASE

## Scope
This package is the consolidated ERP V8 release through **Construction Performance Management Phase 6.4.3**.

### Construction performance stack
- Phase 6.3 — Construction Cost Control, commitments, actual cost, BOQ/subcontractor control, ETC/EAC.
- Phase 6.4 — Planning, time-phased budgets, PV/EV/AC, CPI/SPI, CV/SV, BAC/EAC/ETC/VAC/TCPI.
- Phase 6.4.1 — WBS/BOQ/Cost Code EVM roll-up and executive performance dashboard.
- Phase 6.4.2 — Performance thresholds, deterministic alerts, acknowledgement/resolution governance.
- Phase 6.4.3 — Recovery plans, corrective actions, approval and closure governance.

## Core guarantees
- `ProjectCost` remains the authoritative actual-cost source for EVM AC.
- EVM is calculated with Decimal/NUMERIC values.
- WBS and BOQ dimensions are tenant/project scoped.
- EVM snapshots are immutable in identity by `project + status_date` and can be refreshed deterministically.
- Alert uniqueness is governed by `project + status_date + alert_type + metric`.
- Recovery plans and actions have explicit approval/closure states.
- Cross-tenant lookup checks are enforced in construction services and routes.
- Fresh database creation through Alembic reaches the final migration head `d4e5f6a7b8c9`.
- HTTP regression tests cover anonymous and authenticated application access.

## Verification performed
- Python compilation: PASS.
- Full pytest suite: **68 passed, 0 failed**.
- Fresh Alembic `upgrade head`: PASS.
- Alembic final head: `d4e5f6a7b8c9`.
- OpenAPI/HTTP regression: PASS as part of the full 68-test suite.

The test suite is warning-free under `-W error::DeprecationWarning`; UTC timestamps use the centralized timezone-safe helper and FastAPI uses lifespan startup handling.

## Deployment
1. Install `requirements.txt`.
2. Set a production `ERP_SECRET_KEY` of at least 32 characters.
3. Set `DATABASE_URL` to the production database.
4. Run `alembic upgrade head`.
5. Start the FastAPI application with the existing deployment process.

Do not rely on the development password fallback in production. `bcrypt` and `python-jose` remain production dependencies; the code also contains a development/test compatibility fallback so the application can be imported in minimal test environments.

## Final status
**Release candidate delivered as a consolidated final package.** No Phase 6.4 implementation step is left pending in this package.

## Phase 6.5 Final — Enterprise HR & Access Control

The final release includes Enterprise HR, payroll-to-project cost integration, employee project/site assignments, attendance, leave, performance, training, HR documents, granular role/permission management, project/site scopes, and role-level approval limits.

Final Alembic head: `f6a7b8c9d0e1`.

Final validation: **70 passed, 0 failed**.

## Phase 6.8 — Daily Labor & Overtime
The final package includes daily-paid site labor (sarky), configurable daily and overtime rates, automatic overtime calculation from check-in/check-out, additions/deductions, approval, period settlements, and authoritative ProjectCost integration. Project Documents can reference daily-labor entries.

## V9 Accounting Checklist Extension

The package now includes the V9 accounting compliance checklist extension. See `ACCOUNTING_CHECKLIST_APPLIED.md` and `ACCOUNTING_STANDARDS_IMPLEMENTATION.md`.

New accounting controls include cost-centre journal allocations, orphan-account checks, bank statement lines, fixed-asset disposal, VAT input/output direction and tax reporting, withholding-tax structures, inventory-to-GL reconciliation, and a consolidated accounting compliance report with Excel/PDF export.

Current Alembic head: `h8i9j0k1l2m3`.

Targeted accounting/financial/inventory verification: **18 passed, 0 failed**.
Full repository verification: **88 passed, 3 failed** in pre-existing mobile/governance fixture tests unrelated to this accounting extension; these are explicitly called out rather than hidden.
