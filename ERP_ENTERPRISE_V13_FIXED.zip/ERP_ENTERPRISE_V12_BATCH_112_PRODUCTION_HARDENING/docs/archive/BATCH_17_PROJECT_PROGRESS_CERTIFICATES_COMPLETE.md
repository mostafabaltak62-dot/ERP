# Batch 17 — Project Progress Certificates Complete

## Scope
Completed and hardened the Project Certificates / مستخلصات المشروع workspace on top of Batch 16.

## Delivered
- Customer and subcontractor certificate dashboards with totals, net exposure, draft and approved counts.
- Search by certificate number and client-side filters by type and status.
- Clear Arabic status labels.
- Approval workflow buttons for draft customer and subcontractor certificates.
- Approval confirmation before irreversible accounting posting.
- Uses existing authoritative API/service approval flows; no duplicate accounting logic was created in the UI.
- Print-ready workspace.
- Existing BOQ-based customer certificate creation and commercial deductions retained.

## Validation
- Python compilation passed for relevant construction modules.
- Jinja template compilation passed.
