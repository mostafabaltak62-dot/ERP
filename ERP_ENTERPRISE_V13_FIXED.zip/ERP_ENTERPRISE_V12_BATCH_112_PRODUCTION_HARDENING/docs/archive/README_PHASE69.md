# Phase 6.9 — Enterprise Completeness Suite

This release extends ERP V8 with the enterprise gaps identified during the Odoo comparison.

## Main additions

- HR work schedules, overtime rules, contracts and lifecycle
- Attendance event ledger with project/site/device/GPS context
- Recruitment and onboarding
- Employee expenses
- Project timesheets and task planning
- Quality inspections and defects
- Preventive maintenance and maintenance work orders
- Field service visits
- Document templates and controlled sequential electronic signing

## Existing construction foundation preserved

- BOQ / WBS / activities
- Cost Control
- PV / EV / AC / CPI / SPI
- ETC / EAC / VAC / TCPI
- Performance alerts and recovery planning
- Construction Document Controller: SIR / MIR / MT / DOC / letters / transmittals / revisions / approvals / distribution / handover evidence
- Daily labor / sarky and overtime

## Validation

Run:

```bash
pytest -q
```

Expected release result: **81 passed**.

Fresh database:

```bash
DATABASE_URL=sqlite:///erp.db alembic upgrade head
```

Current migration head: `a66a79eb1cf4`.
