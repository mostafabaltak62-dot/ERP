# PATCH 48 — Advanced Finance + Branches — Deep Production Audit

## Scope
Deep audit of the **المستوى المالي المتقدم** workspace and all of its branches/sub-pages:
- Cost Centers
- Taxes
- Withholding
- Accruals
- Fixed Assets / Depreciation / Disposal
- Tax Report
- Cost Center Report
- Branch selector and company-wide fallback

## Critical findings fixed
1. Advanced-finance masters were not consistently tenant scoped and several routes used `user.company_id` instead of the active tenant context.
2. Advanced-finance pages had no consistent branch selector and several list queries were globally unbounded.
3. Cost-center, tax-rate, withholding-rate and fixed-asset codes used global uniqueness where branch-aware enterprise configuration requires `(company_id, branch_id, code)`.
4. Mutating endpoints did not consistently persist company/branch scope or pass explicit branch scope to accounting postings.
5. Accrual recognition and fixed-asset depreciation/disposal could operate on records outside the active branch/company if IDs were supplied directly.
6. Tax report did not expose branch filtering even though tax transactions are branch-aware.
7. Cost-center report aggregated non-posted or cross-tenant lines and had no branch isolation.
8. Advanced finance had no proper landing page summarizing its sub-modules and active scope.

## Hardening implemented
- Added active tenant + branch resolution using the enterprise tenant resolver.
- Fail-closed when no company context exists.
- Added branch selector to the advanced-finance workspace and preserved it across sub-pages.
- Added company/branch scope to advanced-finance masters and transactions.
- Added branch-aware database indexes and foreign keys.
- Replaced global uniqueness for advanced-finance master codes with company/branch-scoped uniqueness.
- Added branch-safe account resolution with company-wide fallback.
- Explicitly passed `company_id` and `branch_id` to journal posting.
- Added row locking for accrual recognition and fixed-asset operations.
- Added branch filtering to tax reporting and CSV export.
- Limited advanced-finance list pages to 500 rows per request.
- Cost-center report now uses posted journal entries and enforces company/branch scope.
- Added empty states and explicit scope labels to the UI.
- Preserved company-wide configuration (`branch_id = NULL`) as a deliberate fallback.

## Security / Integrity
- RBAC remains enforced through the accounting module permission.
- BOLA/IDOR is mitigated by company + authorized branch resolution before object lookup.
- Cross-company and cross-branch mutation by forged IDs is rejected.
- Accounting postings inherit the selected branch explicitly.
- Financial master creation validates referenced accounts against the active company/branch.

## Tests
- Advanced Finance branch scope: **2 passed**
- Branch finance consolidation: **passed**
- Financial core/reporting/tax/P2P regression set: **16 passed**
- Security regression set: **26 passed**
- Python `compileall`: **passed**
- Application/router import smoke test: **passed**

The repository contains pre-existing multiple Alembic heads. This patch adds a migration on the Purchase-to-Pay chain and does not silently merge unrelated historical heads.
