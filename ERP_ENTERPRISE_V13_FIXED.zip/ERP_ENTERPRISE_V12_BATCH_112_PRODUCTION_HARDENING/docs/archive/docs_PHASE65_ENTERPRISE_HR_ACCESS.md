# Phase 6.5 — Enterprise HR, Payroll Integration & Scoped Access Control

## Scope

Phase 6.5 adds an enterprise HR layer and connects people, payroll, projects, sites and cost control. It also adds scoped RBAC so a user can be restricted by company, branch, project and site, with edit/approve flags and role-level approval limits.

## HR capabilities

- Employee profile and employment lifecycle fields
- Department / branch / manager / job grade / employment type
- Optional Employee → User account linkage
- Attendance and overtime records
- Leave requests and leave balances
- Payroll components (recurring and one-off)
- Payroll project allocation
- Project labor cost posting into `ProjectCost`
- Project / site / WBS / cost-code employee assignments
- Performance reviews
- Training records and certificate expiry
- HR document register

## Access control

The governed model is:

`User → Role → Permission → Scope → Approval Limit`

Scope dimensions:

- Company
- Branch
- Project
- Site

A scope can independently grant view, edit and approve. If a user has explicit `UserScope` rows, project/site-specific requests are checked centrally. System administrators bypass scoped restrictions.

Approval limits are stored by role, company and document type, for example:

- Procurement Officer: PO up to 10,000 EGP
- Procurement Manager: higher limit
- Procurement Director: highest operational limit

The actual numeric limits are configuration data, not hard-coded business logic.

## Construction integration

Employee assignments can point to:

`Project → Site → WBS → Cost Code`

Payroll lines with a project can be allocated to that project and posted to `ProjectCost` as `labor_payroll`, allowing labor payroll to flow into construction actual cost and therefore AC / CPI / EAC.

## Migrations

- `e5f6a7b8c9d0_phase65_enterprise_hr_access.py`
- `f6a7b8c9d0e1_phase65_hr_completion.py`

Final Alembic head: `f6a7b8c9d0e1`.

## Validation

- Fresh SQLite migration to head: PASS
- Full test suite: **70 passed, 0 failed**
- Application route count: 214
- SQLAlchemy model table count: 140
- New Phase 6.5 tests: 2 passed

UTC timestamps now use the centralized timezone-safe helper, and application startup uses FastAPI lifespan handlers.
