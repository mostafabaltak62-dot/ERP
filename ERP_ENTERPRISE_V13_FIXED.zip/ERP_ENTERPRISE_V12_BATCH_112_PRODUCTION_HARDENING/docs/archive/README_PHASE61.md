# ERP Accounting System V8 — Phase 6.1

Construction ERP Core expanded into Site Operations & Field Cost Control.

This release adds sites, material issues, equipment usage, labor costing, subcontractor BOQ, and construction cash-flow reporting while preserving the existing ERP Core.
