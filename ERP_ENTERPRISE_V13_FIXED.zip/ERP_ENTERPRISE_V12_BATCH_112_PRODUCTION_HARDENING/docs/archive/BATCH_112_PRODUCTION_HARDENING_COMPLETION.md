# ERP ENTERPRISE V12 — Batch 112 Production Hardening Completion

## New issues discovered and fixed

### 1. Stale hard-coded Alembic head in production preflight
`deployment_preflight.py` and the E2E audit contained an obsolete expected revision.
This could produce a false production failure after valid migrations.

**Fix:** derive the authoritative head from Alembic's migration graph and require a
single-head graph.

### 2. Production preflight Redis configuration mismatch
The production compose contract configures Redis through `ERP_REDIS_HOST` and
`REDIS_PASSWORD`, while the preflight previously required only `CELERY_BROKER_URL`.

**Fix:** the preflight now uses the same `redis_connection_url()` resolution path as
the application when an explicit broker URL is not supplied.

### 3. Scheduled finance/inventory jobs were silently skipped
Celery Beat scheduled per-company tasks with `company_id=None`. Those tasks correctly
returned `skipped`, meaning monthly depreciation, recurring journals and inventory
valuation could be scheduled without actually processing any company.

**Fix:** added dispatcher tasks that enumerate active companies and queue one scoped
task per company. Beat now schedules dispatchers instead of empty company tasks.

### 4. PostgreSQL materialized-view refresh transaction bug
`REFRESH MATERIALIZED VIEW CONCURRENTLY` cannot run inside a PostgreSQL transaction
block, but the task used `engine.begin()`.

**Fix:** run concurrent refreshes through an AUTOCOMMIT connection.

### 5. PostgreSQL validation tooling
Added `scripts/postgres_production_validation.py` for an authoritative PostgreSQL
validation pass covering:
- PostgreSQL dialect requirement
- live server connectivity
- Alembic revision equality
- tenant-table RLS enablement

## Validation completed in the source environment
- Python compilation of `app` and `scripts`: PASS
- Alembic migration graph: PASS
- Alembic head: one head (`p93_enterprise_audit_log`)
- Alembic metadata audit: PASS (14 model modules covered)
- Existing Batch 111 automated suite remains the latest full suite result: 299/299 passed

## Validation that remains environment-dependent
These cannot be truthfully marked complete without a running authorized environment:
1. Live PostgreSQL schema-drift classification and final migration reconciliation.
2. Redis outage/failover validation.
3. Multi-worker load/stress test.
4. Docker/Compose deployment smoke test.
5. Authorized external penetration test.

## Status
All additional source-code issues discovered during this production-hardening pass have
been fixed. The remaining items are execution-environment validation gates rather than
safe source-only patches.
