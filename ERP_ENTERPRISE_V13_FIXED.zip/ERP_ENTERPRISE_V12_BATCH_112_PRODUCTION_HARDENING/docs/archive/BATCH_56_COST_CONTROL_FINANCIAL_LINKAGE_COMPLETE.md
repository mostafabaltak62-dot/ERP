# BATCH 56 — Cost Control Financial Linkage Production Hardening

## Scope
Authoritative Budget Revision application and end-to-end linkage:
Budget → Revised Budget → Commitment → Actual → ETC → EAC → Variance → Cash Flow → Project Profitability.

## Implemented
- Added materialized authoritative construction budget lines.
- Approved budget revisions now rebuild the authoritative budget atomically; negative resulting budget scopes are rejected.
- Added automatic project cost reconciliation at a Status Date.
- Added automatic forecast generation using Remaining Budget, CPI, and CPI+SPI methods.
- Added cost alert persistence and refresh for unbudgeted exposure, high utilization, over-budget exposure, and reconciliation exceptions.
- Added cost cash-flow snapshots linked to actual inflow/outflow, open commitments, and forecast EAC.
- Added ProjectForecast refresh linkage so approved forecast versions update project-level forecast cost, revenue, and profit.
- Added Cost Control UI metrics for authoritative budget, reconciliation exposure, forecast version, cash-flow forecast, and profitability forecast.
- Added secured API endpoints for revision approval/linkage, reconciliation, automatic forecasting, alerts, cash-flow snapshot, and profitability refresh.
- Preserved company/project isolation and existing permission model.

## Validation
- Targeted Cost/Planning regression: 16 passed.
- Patch 56 focused tests: 3 passed.
- Patch 55 + Patch 56 + UI focused tests: 7 passed.
- Python compilation: PASS.
- Alembic heads: single head `p56_cost_control_authoritative_linkage`.
- Full-suite run reached substantial progress but did not complete within the execution timeout; therefore no claim of full-suite completion is made.
- Fresh Alembic upgrade was attempted. It is still blocked by a pre-existing SQLite-incompatible legacy migration (`c2d3e4f5a6b7_batch24_transmittal_receipt_tracking.py`) using ALTER-style foreign-key creation. Patch 56 migration itself is chained correctly after Patch 55.

## Important Design Note
The authoritative budget is a materialized control layer derived from active base construction budget lines plus all approved revision deltas. It is not a replacement for the historical revision ledger; revisions remain immutable governance records while the authoritative layer represents the current approved budget state.
