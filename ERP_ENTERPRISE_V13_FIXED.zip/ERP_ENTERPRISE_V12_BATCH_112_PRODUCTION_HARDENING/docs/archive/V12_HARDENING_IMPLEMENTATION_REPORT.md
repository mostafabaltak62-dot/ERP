# ERP V12 — Security, Database & Core Logic Hardening Report

## Implemented fixes

### 1. Security & environment
- Added `pydantic-settings==2.12.0`.
- Replaced ad-hoc dotenv runtime loading with centralized `EnvironmentSettings`.
- Added fail-closed validation for `JWT_SECRET_KEY` and `ENCRYPTION_KEY`.
- Added restricted `ALLOWED_ORIGINS` parsing with wildcard rejection.
- Preserved legacy `ERP_ALLOWED_ORIGINS` compatibility.
- Added PostgreSQL production enforcement and rejection of `sslmode=disable`.

### 2. Database and Alembic
- Split declarative SQLAlchemy metadata into `app/db_base.py`.
- Kept runtime engine/session creation in `app/database.py`.
- This allows Alembic metadata discovery without loading production database secrets.
- Added validated pool settings, `pool_pre_ping`, recycle/timeout configuration.
- Added `expire_on_commit=False` and rollback safety in `get_db()`.
- SQLite foreign keys remain enabled for development/tests.
- Verified `alembic heads` successfully resolves to one head:
  `p93_enterprise_audit_log`.

### 3. Middleware and authorization
- Fixed project/site scope authorization so `scope_allows()` runs while its database session is still open.
- Hardened readiness database cleanup.
- Ensured request context is cleared even when downstream request processing raises.

### 4. ORM and N+1 reduction
- Added targeted eager-loading defaults (`selectin` / `joined`) to high-frequency stock and invoice relationships.
- This is intentionally targeted rather than globally forcing eager loading across all 246 models.

### 5. Strict schemas
Added `app/schemas.py` containing strict `extra="forbid"` schemas for:
- invoice creation
- invoice items
- inventory receipts
- journal lines

Validation includes:
- positive quantities
- positive prices
- tax rate range 0..1
- non-empty invoice items
- duplicate product protection
- exactly one debit/credit side per journal line

### 6. Accounting and inventory
- Confirmed the project already contains an authoritative accounting engine in `app/accounting.py`; a duplicate journal engine was not introduced.
- Confirmed weighted-average valuation already exists in `app/inventory_valuation.py`.
- Added a reusable Decimal-safe `calculate_weighted_average()` helper.
- Preserved Decimal arithmetic and authoritative project money precision.

### 7. Error handling
- Replaced a silent password-reset notification failure with server-side exception logging while preserving the generic public response to avoid account enumeration.

### 8. Test and validation results
- Python compilation of the application succeeded.
- `alembic heads` succeeded and reported one head.
- Production configuration security tests passed: 3/3.
- Strict schema and weighted-average smoke tests passed.
- A broader suite previously reached hundreds of passing tests before time constraints in this environment; full CI should be run against PostgreSQL in the deployment environment.

## Important architectural decision
The requested screenshot suggested converting the whole project immediately to AsyncPG / `create_async_engine`. This was NOT applied blindly because the current ERP codebase is synchronous SQLAlchemy and FastAPI dependencies/services are built around synchronous `Session`. A partial async conversion would create mixed sync/async database access and production instability. The safer next phase is a complete, planned async migration only if load testing proves it necessary.

## Remaining mandatory deep-audit work
1. Automated tenant-scope audit for every ORM query and `session.get()` path.
2. Distributed Redis/API-gateway rate limiting for multi-worker production.
3. PostgreSQL integration tests for accounting, inventory and concurrency.
4. Endpoint-by-endpoint N+1 profiling for dashboards and large reports.
5. Full transaction-boundary audit for document, inventory and accounting workflows.
6. Full production test suite with real environment secrets and PostgreSQL.
