# Financial Reporting & Audit V2

## Delivered
- Financial Reporting Center with dedicated navigation.
- Tenant-aware General Ledger with account/branch filters and source drill-down.
- Account Statement view derived from posted journal entries only.
- Existing Trial Balance, P&L, Balance Sheet, Cash Flow, Equity and Validation reports remain available.
- Governance Audit Trail V2 based on `governance_audit_logs` with company scoping, date/action/entity/user filters, pagination, request ID, IP, before/after snapshots and change details.
- Audit detail view is read-only.
- No new database migration was required; existing governance audit table is reused.

## Integrity rules
- Financial reports use posted journal entries only.
- Report queries are company/branch scoped.
- Audit queries are company scoped and do not expose another company's events.
- Source drill-down preserves entry number, source type and source ID.

## Validation
- Full regression: **104 passed**.
- Python compilation: **PASS**.
