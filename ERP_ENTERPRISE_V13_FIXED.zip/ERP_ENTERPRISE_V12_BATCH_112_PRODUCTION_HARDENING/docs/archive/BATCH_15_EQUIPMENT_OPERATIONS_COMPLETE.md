# Batch 15 — Equipment Operations Complete

## Page completed
- تشغيل المعدات / Site Equipment Control

## Implemented
- Operational dashboard for records, active equipment, hours, total cost and average hourly cost.
- Equipment and site/date filters.
- Equipment names/codes and site names in the history instead of raw IDs.
- Optional hourly rate defaults to the equipment master hourly rate.
- Validation for positive operating hours, non-negative rate and non-backward meter readings.
- Duplicate equipment usage protection.
- Every valid usage entry is posted as an equipment actual cost to the project.
- Clear UI controls explaining operational and costing rules.

## Validation
- Python compileall: passed.
- Jinja template load: passed.
