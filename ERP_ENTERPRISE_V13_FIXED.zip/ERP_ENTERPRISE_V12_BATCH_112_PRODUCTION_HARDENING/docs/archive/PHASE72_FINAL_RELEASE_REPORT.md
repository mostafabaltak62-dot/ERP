# ERP Accounting System V8 — Phase 7.2 Final Release Report

## Release status

**Release:** Phase 7.2 Production Hardening
**Alembic head:** `b8c9d0e1f2a3`
**Regression tests:** 88 passed / 0 failed
**Deprecation warnings:** 0 under `-W error::DeprecationWarning`
**Fresh SQLite migration:** PASS
**Quality Gate:** PASS

## What was reviewed

The release was reviewed against the deployment requirements supplied by the project owner and the previously identified risks:

- Alembic ordering and PostgreSQL native RLS
- Celery/Redis background processing
- persistent Document Controller storage
- regression testing
- migration drift
- API/template coexistence
- service-layer size and business-logic placement
- high-volume query performance
- multi-tenant isolation
- SQLAlchemy model organization

## Changes implemented

### 1. Migration configuration hardening

Alembic now accepts both `DATABASE_URL` and the legacy-compatible `ERP_DATABASE_URL`, with `DATABASE_URL` taking precedence. This fixes a real deployment failure where a supplied `ERP_DATABASE_URL` could be ignored and Alembic would migrate the local `erp.db` instead.

The historical migration chain was preserved. It is linear and reaches a single head. The project does not rewrite historical migrations because existing production installations depend on those revision identifiers.

### 2. PostgreSQL RLS closure

Migration `5b9c2d7e1a11_postgresql_native_rls_phase41.py` remains mandatory in the chain.

Phase 7.2 adds a final catalog-driven RLS pass over every currently deployed table containing `company_id`, including modules introduced after Phase 4.1. RLS is enabled and forced, and tenant policies fail closed when no company context is present.

The deployment preflight checks the PostgreSQL catalog and refuses release promotion when a company-scoped table lacks RLS.

### 3. Performance hardening

Composite indexes were added for the highest-volume access paths across:

- project costs
- EVM snapshots
- performance alerts
- project documents and revisions
- daily labor
- equipment logs
- material requisitions
- variation orders
- project timesheets
- attendance

PostgreSQL reporting materialized views were added:

- `mv_project_cost_summary`
- `mv_project_evm_current`

Celery refreshes them hourly. SQLite deployments skip these views intentionally.

### 4. Background services

Celery remains configurable through environment variables and is now included in the production deployment profile with separate worker and beat services.

### 5. Persistent document storage

The Document Controller storage root is explicitly configurable and the production Docker profile mounts it as a durable volume. PostgreSQL backups are not treated as sufficient backups for uploaded documents.

A production backup script now creates both:

- PostgreSQL custom-format dump
- compressed Document Controller storage archive

### 6. Health and readiness

Added:

- `/health/live`
- `/health/ready`

Production readiness can require the background broker as well as the database.

### 7. Production deployment profile

Added:

- `Dockerfile`
- `docker-compose.production.yml`
- `.env.production.example`
- `.dockerignore`
- `scripts/deployment_preflight.py`
- `scripts/backup_production.sh`

The compose profile provisions PostgreSQL, Redis, migration job, web service, Celery worker, Celery beat and persistent document storage.

### 8. CI quality gate

CI now includes a PostgreSQL + Redis production smoke job that:

1. creates a fresh PostgreSQL instance;
2. runs every Alembic migration to head;
3. validates RLS and runtime dependencies;
4. runs the regression suite with deprecations treated as errors.

## Architectural risks retained intentionally

### Template/API coexistence

The server-rendered templates are retained for compatibility with the existing operational UI. They do not own business rules. New logic must live in services/domain modules and be consumed by routers or UI adapters.

### Large legacy service modules

`construction_services.py` and `core_services.py` remain compatibility modules. A blind split would create unnecessary regression risk. The release instead establishes a service-first rule for new work and adds CI gates. A future bounded-context refactor should be performed incrementally with endpoint-level characterization tests.

### Historical model modules

The existing model modules are retained because they represent a live schema history. New domains should have one authoritative model location and one migration path. Duplicate table definitions are prohibited by review and quality checks.

## Deployment prerequisites

Production requires:

- PostgreSQL 14+
- Redis or another supported Celery broker/backend
- durable Document Controller storage
- TLS at the reverse proxy/load balancer
- deployment-managed secrets
- scheduled database and document backups
- tested restore procedures

## Final acceptance

The supplied release is the cleanest deployment baseline produced in the project so far. The codebase passes the current automated regression and quality gates, and the deployment path now explicitly covers the infrastructure requirements that were previously only documented.
