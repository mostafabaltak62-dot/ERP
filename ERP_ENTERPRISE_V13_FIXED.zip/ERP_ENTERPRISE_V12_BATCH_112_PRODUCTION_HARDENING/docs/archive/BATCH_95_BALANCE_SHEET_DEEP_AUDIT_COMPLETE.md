# Patch 95 — Balance Sheet / Statement of Financial Position

## Scope
Deep production audit of the authoritative Statement of Financial Position, its UI, exports, API, tenant/branch scope, period-closing interaction, and regression behavior, based on Patch 94.

## Findings and fixes
- Fixed branch leakage in current-period profit calculation after an accounting-period close: the latest close is now selected within the requested branch when a branch is selected.
- Made current-period P&L used by the balance sheet branch-aware.
- Hardened period-close accounting logic so expense/revenue credit aggregation is constrained to the same company and branch, preventing cross-tenant/cross-branch contamination of closing entries.
- New `PeriodClosingEntry` records now persist `company_id` explicitly for governance traceability.
- Added a dedicated balance-sheet export implementation and preserved branch/date context through the UI export path.
- Added strict invalid-date handling for the balance-sheet UI.
- Added branch-aware authoritative API behavior for `/api/v1/reports/balance-sheet`.
- Hardened the legacy accounting export path so it validates the requested branch and no longer guesses a company from the first Account row when tenant context is missing.
- Removed the unreachable duplicate balance-sheet export route after confirming the legacy dynamic export route was registered earlier and would shadow it.
- UI now clearly exposes the accounting-equation test and difference, and the export contains assets, liabilities, equity, current-period profit, liabilities+equity, and the balancing difference.

## Accounting behavior
The report continues to derive balances from posted journal entries only. Liabilities and equity are displayed using their credit-normal presentation sign, while current-period profit is separated from equity accounts after the most recent applicable period close. The accounting equation remains an explicit invariant:

`Assets = Liabilities + Equity`

## Verification
- Targeted financial reporting regression: 11/11 PASS.
- Python compilation: PASS.
- Fresh SQLite Alembic migration from baseline to current head: PASS.
- Alembic single head: `p93_enterprise_audit_log`.
- Route registration: PASS for balance-sheet UI and authoritative API.
- No schema migration was required by Patch 95; model changes are compatible with the existing nullable `PeriodClosingEntry.company_id` column.

## Full-suite status
A full repository suite was not used as a release-gate for this patch; therefore no full-suite pass is claimed.
