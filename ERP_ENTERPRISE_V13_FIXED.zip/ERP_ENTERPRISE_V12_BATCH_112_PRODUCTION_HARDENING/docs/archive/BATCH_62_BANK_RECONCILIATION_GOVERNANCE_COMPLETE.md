# Patch 62 — Bank Reconciliation Governance & Treasury Hardening

## Scope
Deep production-grade hardening following Treasury Report Patch 61.

## Implemented
- Explicit tenant/branch-scoped bank account linkage (`bank_account_id`).
- Recalculation of book balance from posted GL entries only.
- Recalculation of reconciliation difference after every statement item change.
- Statement adjustments affect adjusted book balance without altering the GL.
- Bank account selection in reconciliation creation instead of hard-coded account-only behavior.
- Validation for non-negative statement balances and statement item dates.
- Automatic statement-line matching against authoritative posted bank-account journal lines by amount/date/scope.
- Prevent duplicate matching of the same journal line within a reconciliation.
- Closed reconciliations cannot receive or match statement items.
- Closing requires zero difference and no unmatched statement items.
- Audit log coverage for create, statement-line add, match, and close actions.
- Account/date database index and foreign-key linkage migration.
- UI updated to expose account selection, detail navigation, reconciliation state, and matching action.

## Validation
- Targeted treasury/reconciliation/finance/stock/warehouse/HR regression: **12 passed**.
- Full suite: **175 passed, 6 failed** before the runner timed out during teardown.
- The 6 failures are pre-existing/out-of-scope environment or unrelated regression issues: command-center authentication, accounting rate limit, mobile bootstrap credentials, password-policy fixture, approval-rule fixture, and mobile refresh fixture.
- Python compilation: **PASS**.
- Alembic heads with required runtime environment: **single head: p62_bank_reconciliation_governance**.

## Important QA note
The full-suite failures were not reclassified as successes. The current patch is considered functionally validated for the Treasury/Bank Reconciliation scope, while the six unrelated regressions remain explicitly recorded for later system-wide remediation.
