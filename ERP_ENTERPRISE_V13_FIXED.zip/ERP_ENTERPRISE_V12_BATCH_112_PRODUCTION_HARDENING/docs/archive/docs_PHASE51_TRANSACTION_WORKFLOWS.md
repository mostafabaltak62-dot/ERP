# Phase 5.1 — End-to-End Transaction Workflows

## Implemented

### Sales
- Sales Order lifecycle: `draft -> confirmed -> partially_delivered -> delivered`.
- Partial delivery support.
- Stock availability validation before delivery.
- Delivery creates immutable stock movement records inside the caller transaction.
- Delivery can be invoiced exactly once.
- Sales invoice totals are stored as authoritative Decimal/NUMERIC values.
- Discount and configurable tax are calculated before posting.
- Sales invoice posts AR/cash + revenue + output tax + COGS/inventory in one transaction.
- TaxTransaction links the tax result to the originating invoice and journal.

### Purchasing
- Purchase Invoice model and lines.
- PO linkage and supplier validation.
- Configurable tax and discount.
- Purchase invoice posts inventory/input tax against AP/cash in one transaction.

### Receivables / Payables
- Customer receipts can be allocated to a specific sales invoice.
- Supplier payments can be allocated to a specific purchase invoice.
- Partial payment is supported.
- Overpayment beyond outstanding balance is rejected.
- Outstanding balance is derived from invoice total minus authoritative allocations.

### Accounting Integrity
- Every financial posting uses the existing `create_entry()` engine.
- Journal source references provide duplicate-posting protection.
- Posted journals remain immutable.
- Open-period validation remains enforced.
- Business document + inventory + tax + journal operations are committed by the endpoint as one transaction.

### Multi-tenancy
- New transaction tables include `company_id`.
- Application tenant filtering applies automatically.
- PostgreSQL RLS policies are created for the new transaction tables by migration.

### API
New API namespace:

`/api/v1/transactions`

Endpoints cover:
- sales orders
- confirmation
- delivery
- delivery invoicing
- purchase invoices
- customer payments
- supplier payments
- AR/AP invoice balance

Endpoint permissions are centrally mapped through the Phase 4 governance layer.

## Tests

Phase 5.1 adds three transaction tests covering:
- sales order -> delivery -> invoice -> partial customer payment
- purchase invoice -> partial supplier payment
- rollback on failed delivery

Current suite result: **28 passed**.

## Migration

Revision: `6d2f8e1a9c77`

The migration was tested from the baseline to Alembic `head` on SQLite, including SQLite batch-alter handling for existing invoice/payment tables.

## Known next gates

1. PostgreSQL runtime test for the new RLS policies.
2. FIFO/Weighted Average inventory valuation engine instead of item purchase price as the COGS source.
3. Credit notes, returns, write-offs and reversal workflows.
4. Purchase Request -> PO -> Receipt -> Invoice three-way matching.
5. Sales quotation -> order -> delivery -> invoice workflow UI.
6. E2E API tests with real authorization/tenant context.
7. Frontend screens for the new transaction workflows.
