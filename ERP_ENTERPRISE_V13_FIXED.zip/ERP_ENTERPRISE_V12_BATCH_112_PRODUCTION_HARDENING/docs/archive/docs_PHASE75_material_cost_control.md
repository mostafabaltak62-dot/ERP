# Phase 75 — Site Material Cost Control

Added direct BOQ linkage to site material issues and a project-scoped material cost-control view. The report compares BOQ planned quantity against issued, consumed, waste, returned, site balance, and issue variance.

Material issue BOQ links are backfilled from requisition lines by migration `p7q8r9s0t1u2`.
