# Patch 77 — Bank Statement Reconciliation Deep Audit

## Scope
Deep production audit of the **Bank Statement Reconciliation / تسوية كشف البنك** workflow, based on Patch 76.

## Findings & fixes

### 1. Unsafe automatic matching — FIXED
The previous workflow selected the first eligible GL line when more than one line had the same amount/date/account criteria. This could silently reconcile a statement transaction to the wrong journal line.

**Patch 77:** candidate discovery is separated from selection. Automatic matching now succeeds only when there is exactly one eligible candidate; ambiguous candidates return HTTP 409 and require deliberate user resolution.

### 2. Matched journal line could theoretically be reused concurrently — FIXED
Application-level filtering alone was not sufficient to guarantee uniqueness under concurrent requests.

**Patch 77:** added a database-level unique index on `bank_reconciliation_items.matched_journal_line_id` (nullable, so unmatched rows remain unrestricted). The migration explicitly blocks if historical duplicate matches already exist instead of silently changing financial history.

### 3. No controlled unmatch action — FIXED
Matched statement items had no safe way to be released while a reconciliation remained open.

**Patch 77:** added an authenticated/RBAC-protected `unmatch` action. It is available only for open reconciliations, clears the matched GL reference, restores `unmatched` status, and records an audit event.

### 4. Non-finite monetary input — FIXED
Decimal parsing alone can accept non-finite values such as NaN/Infinity in some input paths.

**Patch 77:** statement balance and statement-line amount are required to be finite numbers before persistence/calculation.

### 5. Statement reconciliation performance/indexing — IMPROVED
Added a company/status index for efficient tenant-scoped unmatched/matched item operations.

### 6. Migration topology — HARDENED
The source contained multiple historical Alembic heads outside the Patch 74 chain. Patch 77 now merges the existing heads into one authoritative head while applying the reconciliation integrity index.

## Existing controls revalidated
- Company/tenant scoping on reconciliation and statement lines.
- Branch scoping where a branch context exists.
- Only posted GL entries are eligible for matching.
- Bank account is resolved inside the current company scope.
- Matching window remains bounded to ±7 days and the statement date upper bound.
- A GL line already matched elsewhere is excluded.
- Closed reconciliations cannot receive or alter statement lines.
- Reconciliation cannot be closed with a non-zero difference.
- Reconciliation cannot be closed with unmatched statement lines.
- Cross-site state-changing requests remain protected by the application CSRF layer.

## Tests

### Targeted
- Patch 76 bank reconciliation regression tests: **4/4 PASS**
- Patch 77 bank statement reconciliation hardening tests: **2/2 PASS**
- Combined targeted result: **6/6 PASS**
- Python compilation: **PASS**

### Fresh database migration
A brand-new SQLite database was upgraded from the migration base through the latest head.

Result:
- Alembic heads: **1**
- Latest head: `p77_bank_statement_reconciliation_hardening`
- Fresh `upgrade head`: **PASS**
- Unique matched-journal-line index verified in SQLite.

### Full regression
`pytest -q` was started against the complete suite. Execution reached approximately **64%** before the execution environment timeout. No assertion failure was reported in the completed portion, but this is **not** counted as a full-suite pass.

## Release
**ERP_ENTERPRISE_V10_PATCH_77_BANK_STATEMENT_RECONCILIATION_PRODUCTION_HARDENED.zip**

Based on Patch 76 and containing the complete source tree plus Patch 77 changes.
