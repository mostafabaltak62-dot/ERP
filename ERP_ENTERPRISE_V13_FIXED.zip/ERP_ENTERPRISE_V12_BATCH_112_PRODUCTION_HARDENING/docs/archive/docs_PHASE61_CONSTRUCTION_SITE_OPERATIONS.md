# Phase 6.1 — Construction Site Operations & Field Cost Control

Built on the existing Construction ERP Core.

## Delivered
- Construction sites with company/project isolation.
- Site material issues integrated with stock movements and project costs.
- Stock-overdraw protection for site material issues.
- Equipment usage with meter validation and hourly costing.
- Labor time/cost capture with regular and overtime rates.
- Subcontractor BOQ lines linked to subcontractor contracts and cost codes.
- Project construction cash-flow view derived from certified revenue and recorded field costs.
- Backend permission enforcement through `construction:manage` / `reports:view`.
- NUMERIC/Decimal financial calculations and database checks.

## API
- `POST /api/v1/construction/sites`
- `POST /api/v1/construction/site-material-issues`
- `POST /api/v1/construction/equipment-usage`
- `POST /api/v1/construction/labor`
- `POST /api/v1/construction/subcontractor-boq`
- `GET /api/v1/construction/projects/{project_id}/cash-flow`

## Integrity
Site material issue is atomic at the service transaction boundary: field issue + stock movement + project cost are committed together by the route transaction.

## Migration
`7a8b9c0d1e23` — Phase 6.1 construction site operations.

## Verification
- 53 non-HTTP regression/unit tests passed.
- Fresh Alembic upgrade reached `7a8b9c0d1e23` successfully.
- Authenticated HTTP runtime remains an environment gate because bcrypt is unavailable in the current execution environment.
- PostgreSQL native RLS runtime remains an environment gate until a real PostgreSQL service is available.
