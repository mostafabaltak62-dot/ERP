# Patch 93 — Enterprise Audit Log Deep Audit

## Scope
Production-grade audit of the Enterprise Audit Log page starting from Patch 92.

## Findings and fixes
- Consolidated the audit workspace around the tenant-aware `/accounting/reports/audit` implementation.
- Added explicit Company/Branch-safe branch filtering to the page and all export paths.
- Reused a single `_audit_query` builder for UI and exports to prevent filter drift.
- Added branch-aware user/action/entity filter dimensions.
- Added Excel and PDF exports in addition to the existing UTF-8 CSV export.
- Preserved date/action/entity/user/search filters across pagination and exports.
- Kept audit details tenant-scoped and immutable; no write/delete UI or endpoint was introduced.
- Converted legacy `/finance/audit` into a compatibility redirect to the canonical enterprise audit workspace, eliminating the weaker duplicate implementation.
- Added a compound `(company_id, branch_id, created_at, id)` index for branch-scoped audit history queries.
- Retained existing append-only ORM protection and secret redaction from the governance layer.

## Security / governance
- Audit access remains protected by `audit:view` through the existing governance/RBAC stack.
- Company access is resolved server-side; requested branch IDs are validated through `resolve_tenant`.
- Branch-specific queries cannot cross into another branch.
- Company-wide mode intentionally shows company-level and all accessible branch events.
- No audit record mutation capability was added.

## Tests
- Patch 93 targeted tests: **5/5 PASS**.
- Existing audit hardening + financial reporting UI tests: **10/10 PASS**.
- Governance, security enforcement, company/branch management, and job-role permission regression set: **25/25 PASS**.
- Combined selected regression run: **25/25 PASS**.
- Python compilation: **PASS**.
- Fresh SQLite Alembic migration from baseline to head: **PASS**.
- Final Alembic head: `p93_enterprise_audit_log`.
- New audit query index verified on fresh migrated database.

## Full-suite status
A full repository-wide pytest run was not used as a release gate for this patch; therefore no full-suite pass is claimed.

## Release
**Patch 93 — Enterprise Audit Log Production Hardened**
