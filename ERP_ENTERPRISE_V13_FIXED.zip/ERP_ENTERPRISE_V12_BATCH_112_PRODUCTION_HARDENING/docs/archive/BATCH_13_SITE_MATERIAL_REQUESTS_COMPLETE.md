# Batch 13 — Site Material Requests Complete

## Completed
- Added request workflow KPIs and clear Arabic statuses.
- Added project/shared warehouse scope visibility.
- Added requisition line-level tracking for requested, approved and fulfilled quantities.
- Added stock availability inspection by item and available warehouse.
- Added approved requisition execution paths: stock issue or purchase-request handoff.
- Kept tenant/project authorization on every route.
- Preserved the physical workflow: request -> approval -> issue/purchase -> site material flow.

## Validation
- Python compileall passed.
