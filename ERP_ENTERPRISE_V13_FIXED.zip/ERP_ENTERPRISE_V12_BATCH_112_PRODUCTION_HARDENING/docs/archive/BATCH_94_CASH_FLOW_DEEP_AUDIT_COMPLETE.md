# Patch 94 — Cash Flow Deep Audit / Production Hardening

## Scope
Audited the authoritative financial reporting cash-flow page and its underlying engine from Patch 93.

## Findings and fixes
1. **Historical cash accounts** — inactive cash/bank accounts were excluded from opening/closing balances. Fixed so posted historical activity remains visible, consistent with the historical-account behavior of the Trial Balance and General Ledger.
2. **Export parity** — the cash-flow UI exposed Excel/PDF links without an authoritative export endpoint in the newer financial-reporting router. Added tenant/branch/date-preserving XLSX/PDF exports using the same cash-flow engine.
3. **Classification integrity** — invalid/missing counterpart cash-flow mappings are now explicitly reported as mapping exceptions instead of silently disappearing. They remain temporarily classified as operating for arithmetic continuity, while the report clearly marks the mapping as incomplete.
4. **Mixed transactions** — detailed rows now show `mixed` when a single cash transaction contains more than one non-zero operating/investing/financing classification, rather than selecting an arbitrary bucket.
5. **Standards wording** — removed the inaccurate implication that the transaction-classification engine is a formal IAS 7 indirect-method reconciliation. The page now accurately describes the source as posted-journal, transaction-based classification.
6. **Tenant/branch scope** — retained the authoritative `_report_ctx` / `resolve_tenant` path and branch-preserving report execution.

## No migration required
No database schema changed in Patch 94. Alembic remains at the single head `p93_enterprise_audit_log`.

## Validation
- Targeted cash-flow/accounting regression: **10/10 PASS**
- Python compilation: **PASS**
- OpenAPI contains `/accounting/reports/cash-flow`: **PASS**
- OpenAPI contains `/accounting/reports/cash-flow/export/{fmt}`: **PASS**
- Fresh SQLite `alembic upgrade head`: **PASS**
- Alembic heads: **single head `p93_enterprise_audit_log`**

## Release note
Patch 94 is an application/reporting hardening patch; it intentionally does not introduce a migration because no schema change was necessary.
