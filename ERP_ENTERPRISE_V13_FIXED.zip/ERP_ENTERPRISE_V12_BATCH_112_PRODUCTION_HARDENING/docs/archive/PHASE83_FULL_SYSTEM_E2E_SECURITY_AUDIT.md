# Phase 83 — Full-System E2E / Security / Integrity Audit

## Status
**PASS — release candidate hardened**

This phase was performed against the reviewed ERP package after the previous security/RBAC work.

## Findings fixed in this phase

### 1. Distributed rate limiting bug
The Redis-backed limiter was only used when the timestamp happened to be an exact integer second. Real requests normally carry fractional timestamps, so production multi-worker deployments could silently fall back to per-process limits.

**Fix:** Redis enforcement is now used whenever Redis is configured; local sliding-window remains the fallback if Redis is unavailable.

### 2. Cross-company workflow identity collision
`workflow_instances` had a global unique constraint on `(document_type, document_id)`. That is incorrect for a multi-company ERP because document ID `500` may legitimately exist in two companies.

**Fix:** identity is now tenant-scoped by `(company_id, document_type, document_id)`.

Migration: `s0t1u2v3w4x5_workflow_tenant_unique.py`.

### 3. Workflow service tenant lookup
The workflow service now explicitly scopes existing workflow instances to the active company before reusing one.

### 4. Project-cost tenant boundary
Project-cost creation now requires the active `company_id` and resolves the project through an explicit company filter instead of trusting a bare project primary key.

### 5. Refresh-token replay race hardening
Refresh-token rotation now locks the token row before revoking/rotating it, preventing two concurrent refresh requests from both consuming the same refresh token.

### 6. OTP verification race hardening
Password-recovery OTP verification now locks the recovery request row before checking/incrementing attempts, protecting the five-attempt limit against concurrent requests.

### 7. SMS recovery transport
Production SMS recovery webhooks are required to use HTTPS and a syntactically valid HTTP(S) URL.

### 8. Production deployment wiring
The production Docker web service now passes `ERP_RATE_LIMIT_REDIS_URL` so the distributed limiter is actually connected to Redis.

### 9. Deployment preflight drift
The deployment preflight expected the previous Alembic head. It now expects the actual current head:

`s0t1u2v3w4x5`

### 10. Integration audit added
`scripts/e2e_audit.py` now checks:
- Jinja templates referenced by application code exist.
- Router handlers have authentication/authorization/tenant protection, with only intentional public auth/health endpoints exempted.
- Exactly one Alembic head exists and matches the release contract.

## Validation performed

- Full pytest suite: **111 passed**
- Quality Gate: **PASS**
- Security Audit: **PASS**
- E2E Integration Audit: **PASS**
- Alembic upgrade on a fresh SQLite database: **PASS**
- Deployment Preflight against the migrated database: **PASS**
- HTTP regression suite: **5 passed**
- Inventory valuation suite: **2 passed**
- Branch finance consolidation: **1 passed**
- Command Center UI: **1 passed**
- Planning/Cost UI: **1 passed**
- User Directory/RBAC: **3 passed**
- Security hardening suite: **6 passed**

## Security note
Passwords remain non-recoverable by design. The administrative interface may reset a password through the controlled workflow, but the plaintext password must never be displayed or stored. This is intentional and is safer than implementing a "show password" feature for existing accounts.

## Release conclusion
No known failing automated check remains in the reviewed package. Production readiness still depends on deployment-time secrets, PostgreSQL/RLS configuration, HTTPS, Redis availability, SMTP/SMS provider configuration, and CI execution of external dependency scanners.
