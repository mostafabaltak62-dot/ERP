# BATCH 61 — TREASURY REPORT DEEP AUDIT COMPLETE

## Baseline
Patch 60 — Financial Voucher Production Hardened

## Scope
Treasury report UI, query correctness, tenant isolation, branch scope, accounting source of truth, date validation, running balances, reconciliation, and CSV export.

## Findings and fixes
- Replaced FinanceVoucher-only reporting with POSTED JournalEntry/JournalLine cash reporting so drafts/unposted vouchers cannot appear in the treasury report.
- Added tenant/company scoping to entries, lines, accounts, and voucher source lookup.
- Applied current branch scope to both journal entries and lines.
- Added strict cash-account whitelist and rejected inaccessible account codes.
- Added opening balance and deterministic running balance.
- Added debit/credit/net columns and closing balance.
- Added independent reconciliation against the authoritative cash-flow engine when a complete date range is supplied.
- Added safe invalid-date and reversed-date handling.
- Added CSV export using the same tenant/branch/cash-account constraints.
- Improved UI with opening/closing balances, reconciliation status, account names, and export action.

## Tests
Targeted: 9 passed.
Full suite: 173 passed, 6 failed. The six failures are pre-existing/unrelated areas: command-center authentication, accounting-page rate limit, mobile bootstrap credentials, password-policy fixture, approval-rule fixture, and mobile refresh fixture. No Treasury test failed.

## Validation
Python compilation: PASS.
ZIP integrity: PASS.

## Next follow-up
Treasury should later gain period lock awareness, cash reconciliation workflows, bank reconciliation, transfers, and formal opening-balance governance as part of the broader treasury module.
