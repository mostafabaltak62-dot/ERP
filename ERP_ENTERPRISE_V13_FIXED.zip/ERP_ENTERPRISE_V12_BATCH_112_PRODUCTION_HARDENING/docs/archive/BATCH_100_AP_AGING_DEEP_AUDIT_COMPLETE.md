# Patch 100 — Accounts Payable Aging (أعمار الذمم الدائنة)

## Baseline
- Approved baseline: Patch 99 — New Manual Journal.
- Scope: complete production audit of AP Aging UI, service logic, API, exports, tenant/branch controls, date-as-of integrity, payments, purchase returns, supplier terms, and regression impact.

## Findings and fixes
1. **AP Aging was materially incomplete compared with the hardened AR Aging implementation.**
   - Added authoritative `as_of` handling for both `date` and `datetime`.
   - Purchase invoices are included only when posted and effective on/before the report date.
2. **Payments were previously not truly as-of.**
   - Payment allocations are now counted only when the linked Finance Voucher date is <= report date.
   - Company and branch scope is validated against the invoice; mismatched branch allocations/vouchers are ignored rather than contaminating AP.
3. **Purchase returns were not reducing AP aging.**
   - Posted purchase returns effective by the report date now reduce the invoice liability.
   - Returns remain linked to the already tenant/branch-filtered purchase invoice because the return model has no branch dimension.
4. **Supplier payment terms were not using the configured supplier credit policy.**
   - Active `SupplierCreditPolicy` is preferred when present; supplier master `payment_terms_days` remains the fallback.
5. **No supplier drill-down filter existed on the page/API.**
   - Added governed supplier filter to the UI and API.
6. **AP export coverage was missing.**
   - Added tenant/branch/date/supplier-aware Excel and PDF exports.
7. **AP API was under-governed.**
   - Added `as_of_date`, `branch_id`, and `supplier_id` with tenant validation and consistent output.
8. **UI totals were not AP-correct.**
   - Added original liability, paid, returns, outstanding and overdue calculations using the authoritative service rows.
   - AP table now displays original, paid, returned, outstanding, overdue days and aging bucket.
9. **PO-only commitments remain excluded.**
   - The report is invoice/subledger based and does not turn approved/received but uninvoiced POs into accounting liabilities.
10. **Negative AP protection.**
    - Outstanding is clamped at zero so malformed overpayments/returns cannot produce negative open balances.

## No database migration required
The implementation uses existing PurchaseInvoice, PaymentAllocation, FinanceVoucher, PurchaseReturn and SupplierCreditPolicy fields. No schema change was necessary.

## Tests
### Dedicated Patch 100
- `tests/test_patch100_ap_aging.py`: **4/4 PASS**
  - as-of payment handling and supplier terms
  - supplier filter and branch scope
  - purchase returns + supplier credit policy
  - UI/API route and template hardening checks

### Selected regression suite
- **34/34 PASS** covering:
  - Patch 79 supplier/AP hardening
  - Patch 100 AP Aging
  - Phase 5.3 deep transactions
  - Patch 80 AR Aging
  - Patch 98 Financial Reports Center
  - accounting core
  - accounting period governance
  - security integrity
  - HTTP regression

### Static/DB validation
- Python compile/compileall: **PASS**.
- Fresh SQLite `alembic upgrade head`: **PASS**; migration chain reaches `p93_enterprise_audit_log`.

### Full suite status
A full `pytest -q` run was attempted. The run reached ~51% before timeout. A deterministic `pytest -x -q` reproduction stopped at the existing Patch 99 manual-journal test with a SQLite `UNIQUE constraint failed: sequence_counters.key` interaction. The Patch 99 test passes in isolation, and the AP-focused/selected regression suite is fully green. This is not an AP Aging failure and no AP code depends on that sequence-counter behavior.

## Release status
**Patch 100 is production-hardened for Accounts Payable Aging and is based directly on approved Patch 99.**
