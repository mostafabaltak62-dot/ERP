# PHASE 5.9 — AUTHORITATIVE ERP REPORTING

## Objective
Create a single reporting foundation whose financial results are derived from posted journal entries and tenant-scoped master data. Reports do not maintain independent balances.

## Delivered
- Trial Balance from posted JournalEntry/JournalLine rows.
- General Ledger with chronological running balances and source-document traceability.
- Profit & Loss derived from revenue/expense journal activity.
- Balance Sheet derived from posted ledger balances plus current retained earnings effect.
- Executive Dashboard sourced from the same P&L and Balance Sheet engines.
- Tenant isolation on every report query: company_id is required on journal, line and account joins.
- Date validation with HTTP 422 for invalid ranges.
- Decimal/Numeric-safe serialization.
- Report permission: `reports:view`.

## Accounting rules
- Only `JournalEntry.status == posted` contributes to financial reports.
- Draft, cancelled or unposted entries are excluded.
- Revenue is credit-normal; expenses are debit-normal.
- Current-period profit is included in equity for balance-sheet presentation.
- The Balance Sheet exposes a `balanced` invariant: Assets = Liabilities + Equity.

## API
- `GET /api/v1/reports/trial-balance`
- `GET /api/v1/reports/general-ledger`
- `GET /api/v1/reports/profit-and-loss`
- `GET /api/v1/reports/balance-sheet`
- `GET /api/v1/reports/executive-dashboard`

## Production gate
Runtime PostgreSQL RLS and authenticated HTTP tests still require the production/staging dependencies and PostgreSQL service. They are intentionally not marked PASS from a SQLite-only environment.
