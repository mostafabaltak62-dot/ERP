# Phase 4.1 — Security Enforcement Sweep

Implemented on top of Phase 4 Governance.

## Completed

- Tenant headers are treated as requested context only and are validated against `UserCompanyAccess`.
- Ambiguous multi-branch users must select an explicit branch; arbitrary first-branch selection is no longer allowed.
- Central SQLAlchemy tenant filtering now scopes by `company_id` and, where the model supports it, `branch_id`.
- Branch-wide records (`branch_id IS NULL`) remain visible within the active company/branch.
- Audit logs are append-only at the ORM layer; mutation/deletion raises HTTP 409.
- Central endpoint permission policy maps business routes to granular RBAC permissions.
- Legacy `ModulePermission` access is synchronized into governed `Role/RolePermission/UserRole` assignments during startup as a compatibility bridge.
- Legacy admin checks on user-management endpoints were replaced with `admin:users` and `admin:permissions` dependencies.
- System administrator role is granted the complete permission vocabulary.

## Security Tests

17 tests pass, including:

- cross-company row isolation
- tenant-header authorization bypass prevention
- immutable audit logs
- granular route permission mapping
- role-based permission evaluation
- existing accounting invariants
- existing Phase 4 governance tests

## Migration Validation

Fresh Alembic migration to `head` succeeds on SQLite. Production deployment should use PostgreSQL for native database RLS and enterprise concurrency.

## Remaining production gates

- PostgreSQL native RLS policies and FORCE ROW LEVEL SECURITY.
- Full route inventory test generated from FastAPI's route table.
- E2E authorization matrix for every permission/action.
- CSRF protection for cookie-authenticated state-changing HTML forms.
- Rate limiting and login abuse controls.
- Celery/Redis deployment integration test.
- Security scanning and load testing.
