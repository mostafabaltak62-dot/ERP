# Patch 102 — General Accounting Scope Correction / Deep Verification

## Baseline
- Source of Truth: Patch 101 — General Accounting Production Hardened.
- Purpose: independently verify the Patch 101 report against the shipped source and tests, then correct any discrepancy found.

## Verification result
Patch 101 was substantially implemented, but its report contained one material mismatch:

1. **Deactivate Account branch authorization — FIXED in Patch 102**
   - Patch 101 report stated that Deactivate Account performed the same branch authorization as Edit Account.
   - Source verification showed the POST `/accounting/accounts/{account_id}/deactivate` handler validated only company scope before mutation.
   - A branch-only user could therefore target an account from another branch by changing `account_id`.
   - Patch 102 now re-validates the account's branch through the governed `_account_tenant()` path before deactivation.
   - Global/company-level accounts remain governed by the user's company-wide scope.

2. **Legacy account-ledger drill-down**
   - Verified that when both `start_date` and `end_date` are supplied, the redirect preserves account, date range, and branch scope.
   - When dates are absent, it intentionally falls back to the account-statement route with branch scope only.

3. **General Accounting bulk aggregation and tenant scope**
   - Verified in source and dedicated tests: company/branch filtering is server-side and account activity is aggregated in bulk rather than per-account debit/credit queries.

4. **Reports / exports**
   - Verified authoritative General Ledger and legacy export paths validate branch scope and account scope before querying.
   - Patch 101's legacy export assertion was weak (`... or True`) and therefore was not treated as sufficient evidence by this verification. Source inspection and regression tests were used instead.

## Tests after correction
- Patch 101 dedicated tests + new branch-mutation regression: **4/4 PASS**.
- Combined accounting/security/reporting regression set: **25/25 PASS**.
- Python `compileall`: **PASS**.
- Fresh SQLite Alembic `upgrade head`: **PASS** (database reaches existing migration head `p93_enterprise_audit_log`; Patch 102 requires no schema migration).

## Full suite status
- No Full Suite PASS claim is made. Patch 101's documented full-suite run did not complete and timed out around 51%.

## Release gate
- Patch 102 is the corrected successor to Patch 101.
- No database migration is required.
- Runtime databases, caches, bytecode and pytest artifacts are excluded from the release package.
