# ERP Enterprise V10 — Batch 34

## Sales Invoice Complete

- Rebuilt the new sales invoice workspace.
- Added responsive invoice header, customer/payment controls and references.
- Added dynamic multi-line items with live stock indicators and client-side over-stock warning.
- Added server-side aggregation and validation of duplicate items.
- Added invoice-level discount and tax percentages with server-side recalculation.
- Persisted subtotal, discount, tax and total amounts correctly.
- Improved credit-limit validation for credit invoices.
- Posted inventory and accounting movements atomically.
- Added tax accounting line when tax exists.
- Improved invoice detail total breakdown.
