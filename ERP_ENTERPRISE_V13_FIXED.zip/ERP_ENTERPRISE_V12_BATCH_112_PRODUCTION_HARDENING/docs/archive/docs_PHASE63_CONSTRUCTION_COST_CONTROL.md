# Phase 6.3 — Construction Cost Control & Subcontractor Management

## 1. Objective

Phase 6.3 closes the project-control loop between commercial commitments, operational actuals, subcontractor certification, forecasting, profitability and cash exposure.

### Core chain

`Budget → Commitment → Actual → Forecast / ETC → EAC`

### Subcontractor chain

`Subcontractor BOQ → Measurement → Certificate → Retention / Advance / Deductions → AP → Project Actual`

## 2. Cost-control data model

### Budget
`construction_cost_budget_lines` stores approved cost-control budget by project, cost code, WBS and optionally BOQ line.

If explicit cost-budget lines exist, the project control report uses them. Otherwise the existing construction BOQ value is used as the baseline budget.

### Commitment
`construction_commitments` stores contractual/operational committed cost and optional released amount. Commitments can be linked to contracts and subcontractor BOQ lines.

Existing subcontractor BOQ value is also exposed as commitment coverage when no larger explicit commitment ledger exists.

### Actual
`ProjectCost` remains the operational actual-cost subledger.

Phase 6.1 already feeds:
- material issues
- equipment usage
- labor

Phase 6.3 additionally feeds:
- posted subcontractor certificates

Subcontractor actual cost is `gross certificate - commercial deductions`; retention and advance recovery are balance-sheet movements, not additional project cost.

### Forecast / ETC
`construction_cost_forecasts` stores remaining cost estimates (ETC).

If explicit ETC forecast rows exist, their active total is used. If no explicit ETC exists, the engine falls back to the remaining budget amount.

### EAC
`EAC = Actual + ETC`

`Variance at Completion = Budget - EAC`

Positive variance means remaining cost is forecast below budget; negative variance means projected overrun.

## 3. Subcontractor management

### BOQ
Existing `subcontractor_boq_lines` remains the contract quantity/rate baseline.

### Measurements
New:
- `subcontractor_measurements`
- `subcontractor_measurement_lines`

Controls:
- contract and project must match
- cumulative quantity cannot exceed BOQ quantity
- cumulative quantity cannot move backwards
- measurement must be approved before certification

### Certificates
`subcontractor_progress` now has an optional `measurement_id`.

`subcontractor_progress_lines` preserves the exact BOQ quantities/amounts carried from the approved measurement into the certificate.

This gives auditable traceability:

`BOQ line → measured quantity → certified quantity → accounting entry → project actual`.

### Retention
Retention remains a separate payable liability using account `2310`.

### Advances
Existing advance recovery is FIFO by advance date with row locking and balance validation.

### Deductions
Deductions reduce recognized construction cost under the Phase 6.2 accounting policy while remaining visible on the certificate.

### AP
Approved certificates continue to post through the authoritative accounting engine to AP and retention/advance accounts. No direct journal-line manipulation is introduced.

## 4. Project profitability

`GET /projects/{project_id}/profitability` reports:

- certified revenue
- EAC
- forecast profit
- forecast margin %

The profitability calculation therefore consumes the same EAC produced by cost control.

## 5. Cash flow

`GET /projects/{project_id}/cash-flow-v63` extends the Phase 6.1 cash-flow view with:

- customer retention receivable
- subcontractor retention payable
- customer advance balance
- subcontractor advance balance
- subcontractor cash/commitment exposure

## 6. Security and tenancy

All new services require the existing tenant context and use:
- `construction:manage` for creation/maintenance
- `construction:approve` for measurement approval
- `reports:view` for control and profitability reports

All new records carry `company_id`, and project/contract relationships are validated against the active company.

## 7. Migration

Migration: `9c0d1e2f3a45`

New tables:
- `construction_cost_budget_lines`
- `construction_commitments`
- `subcontractor_measurements`
- `subcontractor_measurement_lines`
- `subcontractor_progress_lines`
- `construction_cost_forecasts`

Existing table extended:
- `subcontractor_progress.measurement_id`

## 8. Verification

Phase 6.3 regression tests cover:
1. BOQ → measurement → certificate → AP/project actual linkage.
2. Budget → commitment → actual → ETC → EAC arithmetic.
3. Retention and deductions in subcontractor control reporting.

Result: **3/3 Phase 6.3 tests passed**.

The previous construction/accounting regression set also passes.
