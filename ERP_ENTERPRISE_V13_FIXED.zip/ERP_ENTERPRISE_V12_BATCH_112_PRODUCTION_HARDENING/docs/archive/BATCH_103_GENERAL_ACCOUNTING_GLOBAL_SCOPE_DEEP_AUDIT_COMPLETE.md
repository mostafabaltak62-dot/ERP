# Patch 103 — General Accounting Global Account Scope Correction

## Baseline
- Source of Truth: Patch 102 — General Accounting Scope Correction.
- Purpose: independent verification of Patch 102 claims and closure of remaining global-account mutation scope gaps.

## Material finding
Patch 102 correctly hardened branch-specific account mutation, but a second scope edge case remained:
- `Edit Account` POST and `Deactivate Account` enforced branch scope only when the target account had a branch.
- A branch-only user could therefore target a company-wide/global account by `account_id`.
- Patch 103 now requires explicit company-wide `UserCompanyAccess` for mutation of global accounts.
- Branch-specific accounts continue to require governed access to the target branch.

## Tests
- General Accounting focused suite: **5/5 PASS**.
- Financial reporting / accounting report regression slice: **13/13 PASS**.
- Python compileall: **PASS**.
- Fresh SQLite Alembic upgrade: **PASS**.

## Full suite status
- Full `pytest -q` is **not green** in this environment.
- The first deterministic failure observed after 102 is in the legacy Patch 99 manual-journal test: `sequence_counters.key` has a global UNIQUE constraint while the test path can attempt a duplicate `journal` counter insert. Running that test alone passes.
- Therefore no full-suite PASS claim is made.

## Release gate
Patch 103 is the corrected successor to Patch 102 for General Accounting scope. No schema migration is required.
