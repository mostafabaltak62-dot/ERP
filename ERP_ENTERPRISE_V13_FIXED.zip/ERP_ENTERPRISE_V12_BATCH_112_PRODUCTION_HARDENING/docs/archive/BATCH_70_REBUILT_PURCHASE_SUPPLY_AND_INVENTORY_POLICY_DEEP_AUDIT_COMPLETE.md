# Patch 70 Rebuilt — Purchase & Supply + Inventory Policy/Valuation Deep Audit

## Baseline
This release is rebuilt directly from the last physically available artifact, Patch 69, because the previously generated Patch 70 ZIP was not accessible in the current runtime.

The release therefore reapplies the Patch 69 inventory-policy/bootstrap hardening already present in the baseline and adds a second, deeper production-grade remediation pass focused on Purchase Requests & Supply and valuation chronology.

## Purchase & Supply findings and fixes
- Hardened Purchase Request input parsing and validation.
- Enforced company ownership for every requested item.
- Enforced project company/branch ownership.
- Enforced supported priorities and bounded justification length.
- Rejected duplicate items inside one request.
- Added database-level positive quantity and request-line uniqueness constraints.
- Added Purchase Request status/priority database governance.
- Hardened RFQ creation:
  - request company and branch scope;
  - allowed source statuses;
  - non-empty request lines;
  - active supplier validation;
  - de-duplication of supplier IDs;
  - reject partially invalid supplier lists instead of silently dropping them;
  - prevent duplicate active RFQ for the same request;
  - bounded notes.
- Added RFQ status and due-date database constraints.
- Added audit events for Purchase Request and RFQ creation.
- Hardened Purchase Order list/export/detail/receive branch isolation.
- Fixed malformed PO line-id input returning a server error instead of a controlled 422.
- Fixed PO approval integration bug where the approval handler assigned a non-existent `PurchaseOrder.status` attribute. `approval_status` is now the authoritative field.
- Added idempotent Project Commitment creation for approved project-linked POs using `source_type=purchase_order` and `source_id=po.id`.
- Fixed the Purchase Order detail UI so partial receipts remain actionable until all quantities are received. The previous UI hid the receive action after the first receipt.
- Added a production index for Purchase Order company/branch/approval filtering.

## Inventory valuation findings and fixes
- Legacy valuation-layer synchronization now orders stock movements by `operational_date`, then creation timestamp, then ID for deterministic chronology.
- Historical layer timestamps use the operational transaction date when available rather than silently substituting creation time.
- Rebuild operations now follow the same operational chronology.
- Patch 69 company-default valuation policy and bootstrap/rate-limit hardening remain intact.

## Migration governance
- Added `p70_procurement_supply_hardening` as the single new head.
- Migration portability scan: PASS (78 revisions scanned).
- During fresh SQLite upgrade validation, an older unrelated migration chain issue was uncovered and remediated for SQLite compatibility in Batch 24 (`c2d3e4f5a6b7`) by using batch-alter for the foreign key.
- Fresh upgrade then progressed further and exposed another older pre-existing SQLite migration incompatibility in `y5z6a7b8c9d0_batch26_site_operations_center.py`, where a unique constraint is created using `op.create_unique_constraint()` outside batch mode. This remains a pre-P70 historical migration blocker and is explicitly not claimed as fixed in this release.

## Test results
### Targeted purchase / inventory regression
23 passed.

### Security / authentication regression
10 passed, including Command Center UI, login UI, mobile security and HTTP regression coverage.

### Combined relevant tests
The purchase, purchase-to-pay, supplier, inventory valuation, Patch 69 and Patch 70 rebuild tests completed with 23/23 PASS.

### Full suite
207 tests were collected. A full one-process run progressed past 69% and then timed out at the execution ceiling without producing assertion failures in the completed portion. Therefore the full suite is **not** reported as a clean pass.

### Compilation
Python compilation: PASS.

### Migration head / portability
Single Alembic head: `p70_procurement_supply_hardening`.
Migration portability: PASS (78 revisions scanned).

## Release assessment
This is a production-hardening rebuild based on the accessible Patch 69 artifact. The purchase/supply and inventory-policy focused regression is green. The historical fresh-install migration chain still contains an older Batch 26 SQLite constraint-creation blocker and must be remediated before claiming a clean fresh SQLite migration path.
