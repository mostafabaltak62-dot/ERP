# Supplier / Customer Statement Upgrade

## Implemented
- Supplier and customer statement filters: date from/to, transaction type, text search.
- Party header with code, phone and email when available.
- Financial summary cards: opening balance, total debit, total credit, closing balance.
- Transaction type column.
- Drill-down links to supported sales and purchase documents.
- Clear empty state for filtered periods.
- CSV export endpoint with UTF-8 BOM for Excel compatibility.
- Print/PDF browser action using the real rendered statement.
- Server-side company and branch scoping retained.
- Date validation added for statement filters.

## Files changed
- app/routers/advanced_finance_router.py
- templates/party_statement_v2.html

## Validation
- Python compilation passed for the modified router.
- Jinja template syntax validation passed.
- Full test suite was started but did not complete within the execution time limit, so no claim of full-suite success is made.
