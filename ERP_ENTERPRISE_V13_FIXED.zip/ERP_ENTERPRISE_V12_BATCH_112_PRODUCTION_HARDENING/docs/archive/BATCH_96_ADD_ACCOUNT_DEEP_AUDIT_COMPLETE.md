# Patch 96 — Add Accounting Account — Deep Production Audit

## Baseline
- Audited from: Patch 95 — Balance Sheet Production Hardened.
- Target: `/accounting/accounts/new` and the related account create/edit backend in `app/routers/accounting_router.py` and `templates/account_form.html`.
- Schema migration: **not required**. Existing `accounts` schema already supports `company_id`, `branch_id`, hierarchical `parent_id`, presentation mappings, and the company/branch/code uniqueness constraint.

## Findings and fixes
1. **Tenant scope was not explicit on the create screen.** Added governed company/branch scope resolution and a branch selector. Company-wide users can create either a company-wide account or a selected active branch account; branch-only users cannot escape their assigned branch.
2. **Account-code uniqueness was incorrectly checked at company level only.** Corrected it to the actual database scope: `company_id + branch_id + code`, with a database `IntegrityError` safety net for concurrent requests.
3. **Parent account candidates could cross branch boundaries.** Candidate lists now contain only company-global accounts plus accounts in the selected branch.
4. **Parent validation was incomplete.** Added company scope, active-state, branch compatibility, same account-type enforcement, self-parent protection, and ancestor-cycle detection.
5. **Used accounts could have their account type changed.** This could retroactively alter financial-statement classification. Account type is now immutable after journal usage; presentation/name/mapping changes remain available.
6. **Free-form mapping inputs lacked backend validation.** Name/code/statement-section lengths and cash-flow category values are validated server-side; client HTML constraints are supplementary only.
7. **Edit form did not preserve/indicate the account scope clearly.** Added scope display and safe branch handling; account branch is immutable through edit.
8. **Company-wide access could not explicitly select a branch through the generic `resolve_tenant` path.** The account-specific resolver now correctly recognizes company-wide access while still requiring a real active branch and never trusting a client-supplied branch without access validation.
9. **No schema change was introduced.** This avoids unnecessary migration risk for a master-data workflow.

## Regression validation
- `python -m compileall -q app` — PASS
- Patch 96 targeted account tests — **5/5 PASS**
- Accounting core + reporting + financial validation + GL + equity + security + user directory regression set — **33/33 PASS**
- HTTP regression suite — **5/5 PASS**
- Fresh SQLite `alembic upgrade head` — PASS
- Alembic heads — single head: `p93_enterprise_audit_log`
- Runtime/test database artifacts removed from release package.

## Release decision
**PATCH 96 APPROVED** for the Add Accounting Account page.

The full repository suite was not used as the release gate; no full-suite pass is claimed.
