# Patch 87 — General Ledger Deep Audit & Production Hardening

## Baseline
Patch 86 — Income Statement Production Hardened.

## Scope
Deep audit of the General Ledger page, account statement drill-down, reporting engine, tenant/branch isolation, historical accounting visibility, exports, and regression behavior.

## Findings & Fixes
1. **Historical posted activity could disappear when an account was deactivated.**
   - Root cause: the authoritative `general_ledger()` query filtered `Account.is_active = true`.
   - Fix: posted ledger lines are now reportable regardless of current account active status, while remaining strictly company-scoped.
   - This preserves accounting history after master-data retirement.

2. **Account statement blocked inactive accounts.**
   - Fix: account statement now permits a historical inactive account when it belongs to the current company/authorized branch scope.

3. **Account filter required stronger tenant/branch validation.**
   - Fix: selected account IDs are validated against the current company and, when selected, the current branch scope before querying the ledger.

4. **General Ledger lacked a dedicated export path.**
   - Added tenant-aware Excel/PDF endpoints using the exact same report engine and filters as the visible page.
   - Export preserves start date, end date, account, and branch filters.

5. **Running-balance auditability.**
   - Each ledger row now carries the account opening balance used for the period, in addition to the running balance.
   - This makes the calculation auditable without relying on hidden context.

6. **UI hardening.**
   - Added explicit opening/running balance columns and Excel/PDF actions.
   - Retained RTL layout and existing responsive table structure.

## Accounting Integrity
- Posted journal entries only.
- Company + branch scoping retained.
- Opening balance is calculated from posted activity before the selected start date.
- Period movement is ordered by entry date, entry ID, and line ID for deterministic running balances.
- No changes were made to posted-journal immutability rules.

## Validation
- Patch 87 focused tests: **2/2 PASS**.
- Existing financial reporting tests: **5/5 PASS** in the focused run.
- Combined reporting/security regression set: **23/23 PASS**.
- Python compilation: **PASS**.
- Alembic heads: **Single Head — p83_financial_validation**.
- Fresh SQLite `alembic upgrade head`: **PASS**.
- Full pytest with an isolated test database: reached approximately **61% before the execution environment timeout; no assertion failure appeared in the executed portion.** Therefore this is **not** reported as a full-suite pass.

## Migration
No schema migration was required for Patch 87. The change is application/reporting-layer hardening only.

## Release Status
**PATCH 87 APPROVED AS THE NEXT PROJECT BASELINE.**
