# Phase 7.1 — Quality, Security & Migration Hardening Report

## Objective

Turn the release-quality process into an enforceable engineering control rather than a manual checklist.

## Implemented

### Code quality
- Added `pyproject.toml` with a deliberately narrow Ruff baseline for release-critical parser/undefined-name errors.
- Added `requirements-dev.txt` for Ruff, Bandit and pip-audit.
- Added Python compilation to the mandatory local gate.
- Existing deprecation policy remains strict: `DeprecationWarning` is a test failure.

### Security
- Added an AST-based local security gate for dynamic execution, unsafe deserialization, shell execution and hard-coded credential-like literals.
- CI adds a high-confidence/high-severity Bandit scan.
- CI adds runtime dependency vulnerability auditing with `pip-audit`.

### Migration integrity
- Added a single-head check for the Alembic graph.
- Added duplicate revision detection.
- Added a fresh-database migration on every gate run.
- Added model/schema comparison for tables, columns, nullability and foreign keys.
- The gate intentionally ignores cosmetic Alembic differences such as server-default representation and index naming; those differences do not represent deploy-breaking schema drift in this codebase.

### CI
- Added `.github/workflows/quality-gate.yml`.
- CI runs against Python 3.11, 3.12 and 3.13.
- Release is blocked on any quality, security, dependency, migration or test failure.

## Validation performed on this release

- `pytest -q -W error::DeprecationWarning` — **88 passed / 0 failed**
- Python AST parse — **PASS**
- Deprecated API scan — **0 matches**
- Local security gate — **PASS**
- Alembic migration graph — **1 head / PASS**
- Fresh database migration — **PASS**
- Model/schema contract — **0 structural drifts / PASS**

The optional external scanners (Ruff/Bandit/pip-audit) are installed and executed by CI. They were not available in the isolated build environment used for this release because outbound package installation is disabled; the mandatory built-in checks were therefore run locally and passed.
