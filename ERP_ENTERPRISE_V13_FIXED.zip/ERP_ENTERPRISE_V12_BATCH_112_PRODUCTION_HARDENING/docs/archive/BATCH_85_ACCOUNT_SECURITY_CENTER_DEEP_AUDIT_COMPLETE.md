# Batch 85 — Account Management & Security Center — Deep Audit Complete

## Baseline
Patch 84 — Trial Balance production hardened.

## Scope
Deep production audit of the Account Management & Security Center, including account lifecycle, password-reset governance, password/session revocation, role changes exposed by the page, manager relationships, security/audit integrity, UI wording, and regression compatibility.

## Findings fixed
1. **Account lifecycle was broader than intended**: account creation/update/toggle/delete are now explicitly restricted to the platform administrator (`User.role == admin`).
2. **Privilege escalation via legacy account role**: non-platform administrators can no longer create or promote a user to the legacy `admin` role through this screen.
3. **Last-admin lockout**: demotion, disablement, and final deactivation now refuse to remove the last active platform administrator.
4. **Inactive manager assignment**: a user cannot be assigned to an inactive or missing manager; self-management remains forbidden.
5. **Duplicate identity fields on update**: email and phone uniqueness are now checked during account updates, not only on creation.
6. **Hard deletion of security principals**: the delete endpoint now performs a controlled deactivation instead of physically deleting the user. This preserves historical audit/user references and revokes access tokens.
7. **Password-reset approval hardening**: both approval paths require an active approver; two-person separation remains enforced.
8. **UI/security semantics**: the destructive action is labeled as permanent deactivation rather than deletion, and the confirmation text explains audit retention.

## Validation
- Patch 85 targeted security/account tests: **11/11 PASS**
- Security contract + hardening + Patch 82 RBAC + user directory regression: **20/20 PASS**
- Python `compileall`: **PASS**
- Migration portability scan: **PASS — 82 revisions scanned**
- Fresh SQLite `alembic upgrade head`: **PASS**
- Alembic heads: **single head — p83_financial_validation**

## Full-suite note
A complete full-suite execution was not used as a release gate in this batch. The targeted security/regression gates above passed. No assertion failure was observed in the executed targeted suite.

## Release decision
**PATCH 85 APPROVED** as the next sequential production-hardened project package.
