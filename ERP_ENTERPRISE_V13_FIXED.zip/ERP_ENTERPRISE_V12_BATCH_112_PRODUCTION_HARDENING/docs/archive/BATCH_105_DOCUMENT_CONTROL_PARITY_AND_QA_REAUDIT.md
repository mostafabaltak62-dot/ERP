# ERP Enterprise V10 — Patch 105
## Construction Document Control — Parity, Export and QA Re-Audit

### Baseline
Patch 104 — Construction Document Control Deep Audit Hardened.

### Audit conclusion
Patch 104's functional construction-document implementation is substantially present and its focused export/form tests were green, but the prior release report overstated the QA result by presenting **289/289 as PASS**. The repository contains **289 collected tests**, but a complete single-process pytest run did not finish in the available execution window; it reached approximately 65% twice without an assertion failure before timeout. Therefore 289/289 is not a valid full-suite PASS claim.

The prior report also described Excel/PDF output as matching the official form in shape. Code inspection showed that the generators shared the same schema/data source, but the Excel/PDF/HTML print renderers were not fully metadata-parallel and were not pixel-identical to the official preview/layout.

### Findings fixed in Patch 105
1. **QA claim correction**
   - Full suite is recorded as `289 collected / not completed`, not 289/289 PASS.
   - No full-suite green claim is made.

2. **Export metadata parity**
   - Excel now includes status (Arabic/English), submission type, discipline, issue date, due date, zone, level, revision, contractor representative and consultant representative.
   - PDF uses the same governed status labels and metadata set.
   - Decision section is emitted only for form families that actually use the decision workflow.

3. **Print parity**
   - Print view now exposes issue date, due date and revision alongside the other control metadata.
   - Status is rendered with a bilingual governed label instead of raw internal status codes.

4. **Edit parity**
   - Create/edit UIs now expose issue date and contractor/consultant representatives so editable fields are not silently omitted from the print/export model.
   - Backend update now synchronizes issue date with the central Project Document register.

5. **Create/register date consistency**
   - When issue date is omitted, the effective date is computed once and written consistently to both the specialized form and the central Project Document record.

6. **Official document numbering race hardening**
   - Sequence allocation remains protected by the database unique constraint and now retries the complete transaction on a concurrent collision, returning a controlled 409 only after bounded retries instead of leaking an IntegrityError/500.

7. **Arabic PDF portability**
   - Noto Sans Arabic regular/bold fonts are bundled with the release under `static/fonts`.
   - Optional environment overrides remain supported.

### Validation performed
- Patch 104 focused tests before remediation: **14/14 PASS**.
- Patch 105 focused document-control/export regression after remediation: **17/17 PASS**.
- Python `compileall` for `app` and `alembic/versions`: **PASS**.
- Alembic heads with valid runtime configuration: **single head `p93_enterprise_audit_log`**.
- Fresh SQLite `alembic upgrade head`: **PASS**.
- Repository test collection: **289 tests collected**.
- Full single-process pytest: **not completed within the execution window; no assertion failure was observed before timeout**.

### Remaining architectural limitation
The current Excel/PDF/HTML print outputs are schema/data-parity aligned but are not guaranteed pixel-for-pixel identical to external official paper templates. Achieving literal official-form visual identity requires the source official templates/assets for each family and a dedicated renderer per template.

### Release status
**PATCH 105 — PRODUCTION HARDENED FOR CONSTRUCTION DOCUMENT CONTROL**

This release intentionally makes no unsupported claim of a 100% full-suite pass.
