# Phase 77 — Site Material Issue Workflow

## Flow
Site request → approval → warehouse selection → physical issue → stock movement → project material cost.

## Controls
- Every requisition is company/project scoped.
- A warehouse can be global to the company or assigned to the selected project.
- Physical issue is blocked unless the requisition is approved.
- Physical issue is blocked when warehouse stock is insufficient.
- Issue quantities are incremental and cannot be duplicated after full fulfillment.
- Each issue creates one `SiteMaterialIssue`, one outbound `StockMovement`, and one `ProjectCost` in the same database transaction.
- The request remains separate from inventory; creating a request never changes stock.

## Accounting / valuation note
The physical issue uses the selected warehouse's weighted average movement cost for the material issue record. The enterprise valuation engine remains the authoritative company-wide valuation service for broader inventory reporting; warehouse-aware valuation can be introduced without changing the request/issue contract.
