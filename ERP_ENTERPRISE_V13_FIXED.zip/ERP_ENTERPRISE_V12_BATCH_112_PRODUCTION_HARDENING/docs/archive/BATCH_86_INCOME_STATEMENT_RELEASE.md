# Patch 86 — Income Statement Deep Audit

Baseline: Patch 85

## Scope
Deep production audit of the Income Statement page, authoritative P&L engine, branch scoping, exports, and historical account presentation.

## Fixes
- Income Statement UI now uses the dedicated `income_statement.html` instead of the generic financial-statement template.
- Added branch selector and preserved branch scope in Excel/PDF export links.
- Added dedicated tenant-aware Income Statement export endpoint.
- Added Gross Profit, Gross Margin %, Operating Expenses, Operating Profit, Net Profit, and Net Margin % metrics.
- Export uses the same authoritative `profit_and_loss()` engine as the UI.
- Financial reporting now retains historically used inactive accounts when they have posted activity in the requested reporting period, preventing valid historical transactions from disappearing after account retirement.
- Posted-only, company-scoped, and branch-scoped reporting remains enforced by the authoritative reporting engine.

## Verification
- Targeted reporting/UI regression: 6 passed.
- Python compilation: passed.
- Fresh SQLite migration to Alembic head: passed.
- Alembic heads: single head `p83_financial_validation`.
- Initial test construction exposed a test-fixture issue (adding lines to an already-posted journal), corrected before final verification.
