# Phase 78 — BOQ & Cost Code Material Consumption Control

Implemented on top of Site Operations V5.

## Controls
- Material consumption form now supports explicit BOQ Line and Cost Code selection.
- BOQ lines are tenant/project scoped.
- If a BOQ line has a Cost Code, an explicitly selected conflicting Cost Code is rejected; otherwise the BOQ Cost Code is inherited.
- Consumption quantity is capped by the selected BOQ contract quantity minus prior posted consumption for that BOQ line.
- Site and Cost Code ownership are validated before posting.

## Cost Control
The material cost-control report now shows:
- Planned quantity
- Issued quantity
- Consumed quantity
- Waste quantity
- Returned quantity
- Site balance
- Quantity variance
- Planned cost (active construction cost budget for the BOQ line; fallback to BOQ quantity × rate when no cost budget is configured)
- Actual operational material cost (consumption + waste valuation)
- Cost variance
- Waste percentage

Financial project-cost postings remain authoritative for accounting; this report is an operational cost-control view and does not double-post consumption.
