# Batch 40 — Supplier Master Deep Audit & Remediation

## Scope
Deep audit of the **Add Supplier** page across UI, server validation, tenancy, persistence, accounting integration boundaries, auditability, migration health, and edge cases.

## Hidden issues found and addressed
1. **Supplier form was only a five-field record** and could not safely represent a commercial supplier.
2. **Server validation was too weak**: whitespace, malformed codes, invalid currencies, negative credit limits and invalid payment terms were accepted or left to downstream failures.
3. **No transactional duplicate-race handling**: a concurrent insert could surface as a raw database error. Added `IntegrityError` rollback and a controlled conflict response.
4. **No explicit audit event** for supplier creation. Added an `AuditLog` record with actor and entity id.
5. **Client-side double-submit risk**: the save action is disabled after a valid submit while the server remains the authoritative validator.
6. **No legal/tax/contact/payment/bank master data**, which made purchase and supplier-account workflows incomplete.
7. **Migration graph corruption was detected**: duplicate Alembic revision IDs existed for Batch 28, Batch 29 and Batch 39, and the new Batch 40 id collided with an existing production-hardening migration. The conflicting local revisions were assigned distinct IDs so Alembic can load the graph without duplicate-revision warnings.
8. **Tenant-aware duplicate checks** were added for supplier code and tax number. The pre-existing database-level global unique constraint on `suppliers.code` remains a legacy compatibility restriction and should be converted to `(company_id, code)` in a controlled production migration window; this is documented rather than silently dropping a production constraint.

## Controls added
- strict normalized supplier code
- normalized email and ISO currency code
- bounded payment terms and non-negative credit limit
- supplier type allow-list
- tenant-scoped duplicate checks
- database race-condition handling
- audit trail
- responsive two-column/one-column form
- native HTML validation plus server-side validation

## Verification
- Full automated suite: **132 passed** before the supplier-specific additions.
- Supplier-specific validation tests are included in `tests/test_batch40_supplier_master.py`.
- Alembic revision loading was checked with runtime configuration and no duplicate-revision warnings remain; the project has multiple legitimate migration heads from existing parallel development branches.
