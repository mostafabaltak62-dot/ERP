# BATCH 45 — Purchase-to-Pay Production Hardening

## Scope
End-to-end audit and hardening of:

**Purchase Order → Partial/Multi GRN → Inventory Valuation → GRNI → Purchase Invoice → 3-Way Match → AP → Partial Payment → Payment Allocation**

## Critical findings fixed
1. **Single-GRN database constraint** — `purchase_receipts.po_id` was unique, making partial/multiple receipts impossible. Removed the semantic restriction and added company/PO indexing.
2. **Cumulative receipt control** — receiving now aggregates all prior GRN quantities per PO line and rejects over-receipt.
3. **GRN traceability** — every receipt receives a unique `GRN-*` document number and an audit-log entry.
4. **Warehouse integrity** — stocked-item GRNs require an active warehouse owned by the current company.
5. **Three-way match used only the first receipt** — replaced with aggregation across all GRNs for the PO.
6. **Cumulative over-invoicing** — invoice quantities are compared with cumulatively received quantities less previously matched quantities.
7. **Incorrect line matching by item only** — PO-backed invoice lines now carry/resolve an explicit `po_line_id`; ambiguous mappings fail closed.
8. **One invoice line across multiple GRNs** — matching allocates quantity across receipt lines in receipt order.
9. **PO invoice could post accounting before authoritative matching** — match validation now occurs before the PO invoice journal is posted; the entire workflow remains caller-transaction atomic.
10. **Inventory double-posting risk** — PO-backed invoices never create a second stock receipt; inventory enters only through GRN.
11. **GRNI/AP imbalance from unsupported header discounts** — PO-backed invoice header discounts are rejected until an explicit variance/discount accounting policy exists.
12. **Tax audit traceability** — purchase tax transactions now retain the purchase-invoice journal-entry reference.
13. **Payment remains partial/idempotent** — supplier payments continue to respect outstanding AP and existing idempotency controls.
14. **UI receiving workflow** — PO detail now supports partial/full GRN quantities and displays prior receipts, remaining quantities, and GRN history.

## Security / enterprise controls reviewed
- Tenant/company isolation
- PO supplier ownership
- PO line ownership
- Warehouse ownership
- Approval-before-receipt/invoice
- BOLA/IDOR paths
- RBAC on purchase posting
- Transaction atomicity
- Duplicate posting/idempotency
- Accounting-period validation through the GL engine
- Audit trail
- Inventory valuation source-of-truth

## Known architecture boundary
Header-level PO invoice discounts are deliberately rejected rather than silently posting an incorrect GRNI balance. A future commercial-variance policy can support discounts with explicit accounting allocation.

## Verification
- Focused Purchase-to-Pay + regression tests: **11 passed**
- Full project regression: **147 passed, 0 failed**
- Full suite completed successfully with a bounded process wrapper to avoid unrelated application background-worker shutdown behavior.

## Files changed
- `app/models.py`
- `app/deep_transactions.py`
- `app/transaction_services.py`
- `app/routers/purchases_router.py`
- `app/routers/transactions_router.py`
- `templates/po_detail.html`
- `alembic/versions/x10p45_purchase_to_pay_hardening.py`
- `tests/test_phase53_deep_transactions.py`
- `tests/test_batch45_purchase_to_pay_hardening.py`
