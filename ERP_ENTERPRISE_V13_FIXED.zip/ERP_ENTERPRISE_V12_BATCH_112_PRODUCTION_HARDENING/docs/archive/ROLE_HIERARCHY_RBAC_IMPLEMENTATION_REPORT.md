# Role Hierarchy & RBAC Implementation Report

## Scope
Implemented a construction/enterprise ERP role hierarchy on top of the existing governed RBAC model. The change keeps tenant scope separate from job role: role grants capabilities; company/branch/project/site scopes decide where those capabilities apply.

## Approved hierarchy
1. System Owner / Master Admin — Level 100 — global governance, identity, tenant, permissions, audit and emergency controls.
2. System Administrator — Level 95 — technical administration and account operations.
3. General Manager / CEO — Level 90 — executive reporting and high-level approvals.
4. Finance Manager — Level 80 — accounting, posting, reversal and financial reporting.
5. Projects Director — Level 78 — portfolio/project oversight and approvals.
6. Chief Accountant — Level 75 — accounting operations and review.
7. Project Manager — Level 70 — assigned project management, documents and approvals.
8. Planning & Cost Control Manager — Level 68 — WBS, planning, budget, forecast and EVM controls.
9. Accountant — Level 65 — journal entry and financial data entry/reporting.
10. HR Manager — Level 65 — HR, payroll and controlled access administration.
11. Warehouse Manager — Level 60 — warehouse, inventory adjustments and transfers.
12. Procurement Manager — Level 60 — procurement lifecycle and approvals.
13. Sales Manager — Level 60 — sales lifecycle and commercial controls.
14. Internal Auditor — Level 58 — broad read-only audit/report access.
15. Site Engineer — Level 55 — project/site operational entry.
16. Site Supervisor — Level 48 — daily site operations.
17. Procurement Officer — Level 45 — procurement preparation and editing.
18. Sales Officer — Level 45 — sales preparation and editing.
19. HR Officer — Level 45 — employee records and HR documents.
20. Document Controller — Level 42 — controlled document lifecycle.
21. Warehouse Keeper — Level 40 — warehouse transactions without sensitive approvals.
22. Read Only / Management Viewer — Level 10 — explicit-scope read-only access.

## Technical changes
- Added `app/role_catalog.py` as the authoritative job-role catalogue.
- Added idempotent `ensure_role_catalog()` seeding into `roles` and `role_permissions`.
- Added `admin:role_assign` permission.
- Startup now synchronizes the approved role catalogue without deleting existing custom/legacy roles.
- Added `/admin/roles` administration page.
- Added scoped role assignment: user + role + optional company + optional branch.
- Added validation that a branch belongs to the selected company.
- Added role revocation with protection against removing the current administrator's final governed role.
- Role assignment/revocation invalidates the user's existing authorization tokens.
- Existing `UserScope` / tenant access remains authoritative for project/site boundaries.
- No plaintext passwords are exposed or stored.

## Security model
The intended access chain is:

`User -> Job Role -> Permission -> Company/Branch Scope -> Project/Site Scope -> Endpoint/Object`

This prevents a job title from becoming an unrestricted global data grant.

## Validation
- Python compilation: PASS
- User Directory V2 tests: 4/4 PASS
- Security Integrity V2 tests: 4/4 PASS
- Combined targeted tests: 8/8 PASS

## Files changed
- `app/role_catalog.py`
- `app/governance.py`
- `app/main.py`
- `app/routers/admin_security_router.py`
- `templates/admin_roles.html`

No database migration is required because the implementation uses the existing `roles`, `permissions`, `role_permissions`, and `user_roles` schema.
