# ERP Enterprise V10 — Batch 22
## Document Register, Attachments & Official Form Integration

### Scope completed
Batch 22 continues directly from Batch 21 and closes the next operational gaps in the construction document cycle.

### Implemented
- Secure multi-attachment support for every official construction document form.
- Attachment metadata: original file name, MIME type, size, SHA-256 checksum, type, description, uploader and timestamp.
- Controlled storage under the configured ERP document storage root, segregated by company, project and form.
- File extension allow-list and configurable maximum file size.
- Tenant/company scoped attachment listing and download.
- Form history endpoint combining creation/issue, decisions and attachment events.
- Print view now lists form evidence and attachments.
- Central Project Document Register now recognizes official forms linked through `document_id`.
- Direct navigation from the register to the official form workspace and official printable form.
- Official-form operational KPIs in the project register: total, drafts, under action, approved/closed.
- Alembic migration for `construction_document_form_attachments`.

### Validation
- Python compilation passed.
- Existing Batch 20 workflow tests passed.
- Existing Batch 21 official form tests passed.
- New Batch 22 integration tests passed.
- Result: 8 focused tests passed.

### Version chain
- V10 Batch 20: specialized document workflows.
- V10 Batch 21: official professional forms.
- V10 Batch 22: register integration, evidence attachments and operational history.

### Next document-cycle hardening candidates
1. Formal transmittal UI connected directly to official forms and current revisions.
2. Consultant inbox / action queue for submitted forms.
3. Full revision/resubmission UI with revision comparison and immutable history.
4. Digital signature/approval evidence policy and handover packs.
