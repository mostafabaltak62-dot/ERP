# Phase 6.6 — HR ↔ Project ↔ Accounting ↔ Access Integration

## Delivered

### HR → Project
- `EmployeeProjectAssignment` is now the operational source for payroll labor allocation when a payroll line does not carry an explicit project.
- Active assignments are resolved by payroll period and can carry Project, Site, WBS and Cost Code.
- Payroll can be split across multiple active assignments by allocation percentage.
- Allocation percentages cannot exceed 100%.
- Every project allocation creates one authoritative `ProjectCost` row sourced from `payroll_allocation`.

### HR → Accounting
- Approved payroll runs can be posted exactly once to the general ledger.
- The payroll run stores the authoritative `journal_entry_id`.
- Posting uses the standard accounting engine and default payroll accounts:
  - 5200 — Operating / Labor Expense
  - 2210 — Accrued Expenses / Payroll Payable
- Journal posting is idempotent by `payroll_run` source.

### HR → Access Control
- HR endpoints now have granular route permissions instead of falling through to generic reporting permissions.
- HR role administration, user scopes and effective access use `hr:access`.
- Payroll allocation/posting uses `hr:payroll`.
- HR approval endpoints use `hr:approve`.
- HR read/create/edit operations use `hr:view`, `hr:create`, `hr:edit`.

### Approval Governance
- Approval requests persist the requested monetary amount.
- Configured `RoleApprovalLimit` values are enforced when an approval action is executed.
- Administrators bypass monetary limits; otherwise at least one applicable role limit must cover the document amount.
- Existing workflows without configured monetary limits retain previous behavior.

## New APIs

- `POST /api/v1/hr/payroll/{payroll_run_id}/allocate`
- `POST /api/v1/hr/payroll/{payroll_run_id}/post-to-accounting`
- `GET /api/v1/hr/payroll/{payroll_run_id}/integration-summary`

## Migration

`0a1b2c3d4e5f_phase66_hr_erp_project_accounting_integration.py`

Adds:
- `payroll_allocations.allocation_method`
- `payroll_runs.journal_entry_id`
- `approval_requests.amount`

The migration is SQLite-safe through Alembic batch constraint handling.

## Verification

- Full regression: **73 passed / 0 failed**
- Fresh SQLite migration to head: **PASS**
- Fresh schema tables after migration: **141**
- New integration tests: **3 passed**
- Existing HR/access tests: **2 passed**

Legacy UTC datetime and startup-event deprecations were removed; FastAPI startup now uses lifespan handling.
