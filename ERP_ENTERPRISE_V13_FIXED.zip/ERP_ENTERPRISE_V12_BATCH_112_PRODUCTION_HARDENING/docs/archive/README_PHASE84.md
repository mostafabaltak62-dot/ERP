# Phase 84 — Commercial Completion

This release completes the commercial-control layer around the existing ERP V10 core.

## Added
- Amount-aware approval center using the existing governed RBAC/workflow engine.
- Procurement request → RFQ supplier invitation workspace.
- Customer credit limits, payment terms and over-limit blocking.
- Inventory policy configuration for FIFO / Weighted Average / Standard costing, negative-stock policy and reorder points.
- Project budget-control policy configuration.
- Warehouse-aware sales delivery and purchase receipt paths.
- Three-way match endpoint for PO + goods receipt + supplier invoice.
- Tenant-scoped commercial UI and new control-center navigation.
- Alembic migration `u1v2w3x4y5z6`.

## Validation
- Fresh SQLite Alembic upgrade to head: passed.
- Existing automated suite: 119 tests passed.
- Phase 84 regression tests are included in `tests/test_phase84_commercial_completion.py`.
