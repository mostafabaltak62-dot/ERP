# Patch 66 — Inventory Traceability & Reconciliation Deep Audit

## Scope
Inventory transaction engine: serial/lot/expiry traceability, valuation reconciliation, Inventory-to-GL reconciliation, and regression safety.

## Implemented
- Added `InventoryTraceability` model and migration.
- Serial-tracked items require one unique serial per unit on authoritative movements.
- Outbound serials must exist in current stock; duplicate inbound ownership is rejected.
- Expiry-tracked items require lot + expiry; inbound expiry must be future-dated and expired stock cannot be issued.
- Trace rows are company/item/movement scoped and indexed.
- Authoritative movement engine now invokes traceability validation/persistence.
- Fixed inventory valuation reconciliation to use signed movement values and `operational_date` instead of `created_at`.
- Added `reconcile_inventory_to_gl()` comparing valued inventory to posted inventory GL and consumed valuation cost to posted COGS.
- Preserved existing FIFO/weighted-average valuation behavior and transaction atomicity.

## Verification
- Python compile: PASS.
- Targeted inventory/valuation/deep transaction regression: 12 passed.
- Patch 66 + prior inventory/valuation/deep transaction regression: 16 passed.
- Full suite was started. First unrelated pre-existing failure: `test_command_center_and_project_subpages_are_real_html` returned 401 for `/projects/command-center?project_id=1`; stopped with `-x` after 80 passed / 1 failed.
- Alembic static graph inspection shows legacy multiple heads remain in the repository; Patch 66 correctly descends from `p65_inventory_transaction_engine` and does not claim to resolve unrelated historical branches.

## Release
Patch 66 is the new baseline for the inventory engine work.
