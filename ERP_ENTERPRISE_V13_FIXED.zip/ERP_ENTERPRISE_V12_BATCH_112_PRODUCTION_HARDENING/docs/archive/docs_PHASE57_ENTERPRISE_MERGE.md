# Phase 5.7 — Enterprise Core Merge & Hardening

This release uses **Phase 5.6 ERP Core Governance as the primary codebase** and selectively merges verified fixes from `ERP_MERGED_PHASE4_HARDENED`.

## Merged fixes
- Idempotent/default granular permission seeding at application startup.
- HTTP regression suite for anonymous/authenticated page flows.
- Per-asset/per-period depreciation tracking (`AssetDepreciationRun`) so depreciation can post in every valid accounting period without violating journal source uniqueness.
- Real recurring journal template model and Celery task implementation.
- Migration drift repair for `notifications.branch_id` and `workflow_instances.branch_id`.
- Tenant scope + PostgreSQL RLS for newly introduced governance tables.

## Async architecture decision
The merged package used APScheduler inside the API process. This release intentionally **does not adopt that design**. Production background work remains broker-backed through **Celery + Redis + Celery Beat**, avoiding duplicate schedulers across API workers.

## Verification
- Fresh Alembic migration reaches `3d2f4a5b6c7e`.
- Existing service/integration suite passes.
- HTTP regression tests are included but require the project's authentication dependencies (`bcrypt`) in the execution environment.
- Native PostgreSQL RLS remains a deployment gate and must be executed against a real PostgreSQL instance before production certification.
