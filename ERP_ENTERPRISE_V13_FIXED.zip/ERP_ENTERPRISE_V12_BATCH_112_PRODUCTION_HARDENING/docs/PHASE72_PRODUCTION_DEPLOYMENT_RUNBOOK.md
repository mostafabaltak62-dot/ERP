# Phase 7.2 — Production Deployment Runbook

## Mandatory requirements before go-live

1. **Database / migrations**
   - PostgreSQL 14+ is required for the production profile.
   - For the bundled Docker Compose deployment, set `POSTGRES_*` and `ERP_APP_DB_*` credentials; the runtime constructs `DATABASE_URL` safely. For external/managed databases, `DATABASE_URL` remains supported.
   - Run `alembic upgrade head` once per release, in a controlled migration job.
   - The migration chain is linear and must reach `r9s0t1u2v3w4`.
   - `5b9c2d7e1a11_postgresql_native_rls_phase41.py` is part of the chain and must not be skipped. Later hardening migration `r9s0t1u2v3w4` closes RLS coverage for company-scoped tables introduced after Phase 4.1.
   - Never use `Base.metadata.create_all()` in production.

2. **RLS / tenant isolation**
   - PostgreSQL native RLS is a second isolation boundary; application RBAC remains mandatory.
   - Every table containing `company_id` must have RLS enabled before the release is promoted.
   - Run `python scripts/deployment_preflight.py` after migrations. It fails closed if any company-scoped table lacks RLS.

3. **Background jobs**
   - For the bundled Redis service, set `REDIS_PASSWORD`, `ERP_REDIS_HOST`, and `ERP_REDIS_PORT`; worker/web URLs are constructed safely. Explicit `CELERY_BROKER_URL` and `CELERY_RESULT_BACKEND` remain supported for external brokers.
   - Start the worker and beat processes separately from the web process.
   - Background tasks include depreciation, recurring journals, inventory valuation and reporting-view refreshes.

4. **Persistent Document Controller storage**
   - Mount a durable, access-controlled volume at `ERP_DOCUMENT_STORAGE_PATH`.
   - The Docker production profile uses `/app/storage/documents` backed by `documents_data`.
   - Back up this volume together with PostgreSQL. Database backups alone do not contain uploaded files.

5. **Regression testing**
   - Run `pytest -q -W error::DeprecationWarning` before release.
   - Run `python scripts/quality_gate.py` in CI and before a manual release.

## Production commands

```bash
cp .env.production.example .env
# edit .env; never commit it

docker compose --env-file .env -f docker-compose.production.yml build
docker compose --env-file .env -f docker-compose.production.yml up -d postgres redis
docker compose --env-file .env -f docker-compose.production.yml run --rm migrate
python scripts/deployment_preflight.py
docker compose --env-file .env -f docker-compose.production.yml up -d web worker beat
```

## Rollback policy

- Do not downgrade a production database automatically after application deployment.
- Take a PostgreSQL backup and a Document Controller storage snapshot before migration.
- Roll back the application image first when the schema remains backward-compatible.
- Use an Alembic downgrade only under an approved recovery plan and after verifying the downgrade path against a database clone.

## Operational minimums

- TLS terminates in a reverse proxy/load balancer.
- Secrets are supplied through the deployment secret manager, not source control.
- PostgreSQL backups are encrypted and tested by restore, not merely created.
- Document storage is backed up and periodically restored to a test environment.
- Redis is treated as a service dependency, not as the source of truth for ERP data.
