# Phase 7.1 — Quality, Security & Migration Hardening

This release adds a production quality gate rather than hiding warnings or relying on a pre-existing database.

### Code quality
- Critical Ruff lint rules are enforced in CI.
- Python compilation is mandatory.
- Deprecation warnings fail the test job.

### Security
- High-confidence/high-severity Bandit scan runs in CI.
- The local gate rejects dynamic execution, unsafe deserialization, `shell=True`, `os.system`, and hard-coded credential-like literals.

### Database integrity
- Alembic must have exactly one head.
- Fresh migration is executed on every quality run.
- Fresh schema is compared to SQLAlchemy models for tables, columns, nullability, and foreign keys.

### Dependency hygiene
- `pip-audit` scans runtime dependencies in CI.

The gate is designed to catch regressions before a release is promoted, not merely report them after deployment.
