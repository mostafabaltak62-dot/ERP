# ERP Accounting V8 — Phase 1/2 Progress

## Completed in this iteration

### Database integrity / migrations
- Added Alembic migration infrastructure.
- Added a baseline migration for the current ERP schema.
- Production startup no longer calls `create_all`; production schema changes are intended to run through Alembic.
- Added accounting-period database constraints: `end_date >= start_date` and unique period names.
- Retained SQLite foreign-key enforcement.

### Financial precision
- Removed SQLAlchemy `Float` usage from the application models.
- Financial calculations in sales, purchasing, finance, accounting, tax, and advanced finance paths were moved toward `Decimal`/`Numeric`.
- Inventory quantities/costs use `Numeric`/`Decimal` in the affected transactional paths.

### Accounting core
- Journal creation validates balanced double-entry.
- Journal rows are flushed and re-validated against authoritative database totals before returning.
- Posted journals are immutable.
- New journal lines cannot be appended to an already-posted journal.
- Duplicate source-document posting is rejected.
- Closed accounting periods reject posting at the service layer.
- Period closing is atomic with its closing journal when a P&L closing entry is required.

### Security baseline
- Removed the known hard-coded `admin/admin123` bootstrap.
- Initial admin creation now requires environment-provided credentials and a minimum password length.
- Production requires explicit initial-admin credentials if no users exist.

## Verification
- Python compilation: PASS
- Unit/accounting tests: PASS
- Current test suite: 7 tests passing
- Fresh SQLite Alembic upgrade: PASS
- Fresh migration produced 30 tables and the expected journal/period constraints.

## Remaining for the next accounting iteration
- Convert remaining non-core UI/form type hints from `float` to Decimal-compatible parsing.
- Add authoritative AR/AP subledger tables and allocation constraints.
- Add invoice tax fields and make invoice posting + tax + inventory + COGS one atomic posting service.
- Replace current purchase-order-as-payable behavior with a proper supplier invoice/subledger lifecycle.
- Implement inventory valuation layers for FIFO/weighted-average rather than relying on the item's reference purchase price.
- Add comprehensive accounting reconciliation tests for sales, purchases, inventory, AR, AP, tax and bank flows.
