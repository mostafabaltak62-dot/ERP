# Phase 6.8 — Daily Labor, Sarky & Odoo Gap Analysis

## Implemented in this release
- Daily Worker master for non-salaried site labor.
- Daily labor attendance by project/site/WBS/cost code/BOQ line.
- Check-in/check-out or explicit regular hours.
- Automatic overtime hours when check-out exceeds the worker's normal daily hours.
- Configurable daily rate and overtime hourly rate per worker.
- Other additions and deductions.
- Net daily entitlement calculation.
- Approval workflow for daily labor entries.
- One authoritative ProjectCost row per approved daily-labor entry; idempotent approval.
- Period settlement for approved daily labor, with gross/deductions/net totals.
- Project Document Controller can now reference a daily-labor entry.

## Odoo comparison
Odoo provides broad enterprise coverage across Employees, Attendances, Time Off, Payroll, Documents and Sign. Its Attendance module supports check-in/out, kiosk mode, worked hours, extra hours and management approval. Its Payroll module uses contracts, work schedules and work entries to calculate payslips. Odoo Sign supports electronic signatures, templates, signing order, reminders and completion certificates.

### Remaining gaps versus Odoo or mature enterprise suites
1. HR contracts and effective-dated salary structures/work entries.
2. Working schedules/calendars by employee/contract and formal overtime rulesets.
3. Attendance kiosk/device integration, GPS/IP audit and automatic checkout.
4. Overtime approval with partial approval, tolerance rules and conversion to time off.
5. Egypt-specific payroll localization/rules beyond the current payroll foundation.
6. Employee self-service portal for attendance, leave, payslips and documents.
7. Recruitment/applicant lifecycle and onboarding/offboarding checklists.
8. Expense management and employee expense reimbursement.
9. Planning/Gantt/resource scheduling and timesheets.
10. Field Service/mobile site workflows and offline capture.
11. Quality management: inspections, checklists, NCR/CAR, test plans and quality dashboards.
12. Maintenance/asset preventive maintenance with work orders and meter-based schedules.
13. Document electronic signature, templates, signing order, reminders and completion certificates.
14. Document email aliases/inbound filing, OCR/full-text indexing, retention policies and legal holds.
15. Unified activity/chatter/timeline across project, procurement, HR and documents.
16. Advanced BI/pivot dashboards and configurable report builder.
17. Integration/webhook layer for external systems and device synchronization.

## Construction-specific position
The current system already has several areas that are more construction-specific than a generic Odoo deployment: BOQ, measurements, progress certificates, construction cost control, EVM (PV/EV/AC/CPI/SPI/EAC/TCPI), WBS roll-up, performance governance, recovery planning, site operations and a controlled project document register. These should be retained as differentiators rather than replaced by generic modules.

## Recommended priority after Phase 6.8
1. Work Schedules + Overtime Rules + Approval Engine.
2. Employee Contracts + Work Entries + Egypt payroll rules.
3. Mobile/Kiosk Attendance for sites.
4. Document Signatures + automated reminders.
5. Planning/Timesheets/Field Service.
6. Quality + Maintenance.
