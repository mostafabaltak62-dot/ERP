# Phase 7.2 Architecture Review

## Findings addressed

### Migration drift
The deployment configuration previously ignored `ERP_DATABASE_URL` because Alembic only read `DATABASE_URL`. Alembic now accepts both, with `DATABASE_URL` taking precedence. Fresh migrations were re-run successfully to the Phase 7.2 head.

The project intentionally keeps the historical migration chain rather than rewriting production history. A clean chain is safer than an opportunistic squash once installations already exist. A future major-version baseline can be produced from a verified PostgreSQL backup/restore process.

### Template/API split
The HTML templates remain for the server-rendered operational screens while the REST API serves integrations and modern clients. This is treated as a compatibility layer, not as a second business-logic implementation. New business logic must live in services and repositories/domain modules; routers should remain thin.

### Monolithic services
`construction_services.py` and `core_services.py` remain compatibility entry points. New work is required to use focused services. Existing behavior is not moved blindly during this release because a broad refactor without endpoint-by-endpoint regression coverage creates more risk than value.

### Query performance
Phase 7.2 adds targeted composite indexes for the highest-volume construction, labor, equipment, document and EVM access paths. PostgreSQL also receives materialized reporting views:
- `mv_project_cost_summary`
- `mv_project_evm_current`

Celery refreshes these views hourly. SQLite deployments intentionally skip them.

### Multi-tenancy
Phase 7.2 closes PostgreSQL RLS coverage across all currently deployed company-scoped tables. The deployment preflight checks the database catalog and fails if any company-scoped table has RLS disabled.

### Naming/model organization
The historical model modules remain for compatibility. The release adds a rule for future modules: models must be placed by bounded domain and must not introduce a second definition for an existing table. Schema changes are migration-first.

## Release quality target

A release is considered deployable only when:

- all tests pass with deprecations treated as errors;
- Alembic reaches the single expected head;
- a fresh database can migrate from zero;
- PostgreSQL RLS coverage is complete;
- document storage is writable and persistent;
- the Celery broker is reachable in production;
- CI security/lint/dependency gates pass.
