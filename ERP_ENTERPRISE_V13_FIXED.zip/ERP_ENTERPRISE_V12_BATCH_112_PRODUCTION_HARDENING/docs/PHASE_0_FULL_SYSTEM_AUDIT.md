# ERP Accounting System V8 — Phase 0 Full System Audit

Audit date: 2026-08-24  
Scope: `erp_app_accounting_v8.zip` as supplied, plus the Phase-0 hardening changes made during this run.

## Executive assessment

The repository is a compact FastAPI + SQLAlchemy + Jinja2 ERP prototype with a meaningful accounting foundation. It is **not yet production-grade** and is substantially behind the requested industry-agnostic ERP target.

Existing functionality is concentrated in:
- Inventory/items
- Sales invoices
- Purchase orders/receipts
- General ledger
- Trial balance / income statement / balance sheet
- Finance vouchers
- AR/AP allocations
- Bank reconciliation
- Cost centers
- Tax rates/transactions
- Accruals
- Fixed assets
- Journal reversals
- Period closing
- Cash-flow reporting
- Audit logs
- Basic user/module permissions

The most serious original risks were accounting precision, posted-entry immutability, duplicated/unsafe period-closing paths, lack of real migrations, SQLite-by-default production risk, and a known default admin credential.

## 1. Architecture audit

### Current architecture

- Backend: Python / FastAPI.
- ORM/database: SQLAlchemy.
- Default database: SQLite.
- Production database is expected to be PostgreSQL through `DATABASE_URL`.
- Frontend: server-rendered Jinja2 HTML/CSS.
- Authentication: JWT stored in an HttpOnly cookie.
- Authorization: user/module view/edit permissions plus admin bypass.
- Business logic is largely implemented directly inside routers.
- Accounting logic is centralized partly in `app/accounting.py`.
- There is no dedicated service/repository/domain layer.
- There is no migration framework.
- There is no formal REST/API versioning strategy.
- There is no background job/queue architecture.
- There is no explicit multi-tenant/company isolation layer.

### Architectural strengths

- Existing accounting helper provides one central journal-entry creation path for many flows.
- Sequence counters are used instead of `COUNT()` for several document numbers.
- Business operations generally commit document + accounting work together.
- Existing reversal and period-closing concepts provide a foundation for a stronger accounting engine.
- Permission checks are performed server-side on the existing module routes.

### Architectural weaknesses

1. Routers contain too much domain/business logic.
2. Accounting, inventory, AR/AP, tax and document workflows are not represented as explicit domain services.
3. Source documents use polymorphic `source_type/source_id` instead of strongly typed references.
4. Company/branch/project dimensions are absent from the core transactional model.
5. There is no reusable workflow engine.
6. There is no event/outbox architecture for notifications/integrations.
7. There is no migration/versioning layer for schema evolution.
8. The application is HTML-first rather than a stable API + frontend architecture.

## 2. Module inventory

### Implemented / partially implemented

| Module | Current state |
|---|---|
| Authentication | Basic |
| Users | Basic |
| Module permissions | Basic |
| Inventory | Basic |
| Sales | Basic |
| Purchasing | Basic |
| General Ledger | Partial but functional foundation |
| AR | Basic |
| AP | Basic |
| Finance vouchers | Basic |
| Bank reconciliation | Basic |
| Tax | Partial |
| Fixed assets | Partial |
| Cost centers | Basic |
| Accruals | Partial |
| Audit log | Basic |
| Period control | Partial |
| Cash flow | Basic |
| Profitability | Basic |

### Missing major ERP modules

- Multi-company
- Multi-branch
- Multi-currency
- Projects core
- Construction ERP
- BOQ/WBS
- Contracts
- Subcontractors
- Equipment
- Fleet
- Fuel
- HR
- Payroll
- Manufacturing
- Advanced distribution
- Advanced warehouse/location/bin management
- Document management
- Workflow engine
- Notification engine
- Global search
- Safe import/export
- E-invoicing abstraction layer
- BI/executive analytics
- AI layer
- Sandbox/demo company

## 3. Database audit

### Current database

- 29 SQLAlchemy models/tables.
- SQLite is the default.
- PostgreSQL is only described/configured through an environment variable.
- `Base.metadata.create_all()` is executed at startup.

### Critical findings

**P0 — Financial precision:** original financial and quantity fields used SQLAlchemy `Float`. This violates the project directive for financial data.

**P0 — Schema evolution:** there is no migration system. `create_all()` does not safely migrate an existing production schema.

**P0/P1 — Referential integrity:** SQLite foreign-key enforcement was not explicitly enabled.

**P1 — Business constraints:** many important business rules are implemented only in Python rather than at the database layer.

**P1 — Polymorphic references:** `source_type/source_id`, `party_type/party_id` and tax source references cannot be protected by normal foreign keys.

### Phase-0 changes made

- Replaced model `Float` numeric fields with explicit `Numeric` precision.
- Added journal-line database checks for non-negative debit/credit and mutual exclusivity.
- Added unique source protection for journal source transactions.
- Enabled SQLite foreign keys.
- Added `pool_pre_ping`.

### Migration requirement

The Numeric conversion and new journal columns require a **real migration** for any existing database. The current runtime must not be used as an automatic production migration mechanism.

## 4. Accounting audit

### Existing accounting flow

The project already has:

Business document → accounting entry → ledger → financial reports

for several flows.

### Critical original risks

1. Journal values were calculated and stored through floating-point arithmetic.
2. Journal entries had no explicit posted state.
3. Posted-entry immutability was not enforced.
4. Duplicate source posting was not globally prevented.
5. Period closing existed through more than one route and one route could close a period without creating the required closing entry.
6. Reversal existed, but journal immutability was not enforced.
7. Tax was an after-the-fact reclassification workflow rather than a complete tax engine.
8. Inventory valuation relied on the current item's purchase price, not a robust valuation ledger.
9. AR/AP balances were partly derived from business documents rather than a formal subledger.
10. Payment allocations were not fully constrained at database level.

### Phase-0 accounting hardening made

- Central journal creation now normalizes values through `Decimal`.
- Journal entries must be balanced exactly at configured precision.
- Invalid/zero lines are rejected.
- Account validity is checked centrally.
- Closed periods are rejected centrally.
- Journal source duplication is rejected.
- Posted entries are marked `posted`.
- Posted journal entries and their lines are protected from mutation/deletion.
- Reversal remains append-only.
- Period closing has been consolidated around a shared accounting service.

## 5. Security audit

### Current strengths

- Passwords are bcrypt-hashed.
- JWT is HttpOnly-cookie based.
- Server-side module permission checks exist.
- Admin-only operations exist for some sensitive functions.

### Critical findings

**P1 — Known default password:** the original application created `admin/admin123`.

**P1 — JWT secret fallback:** the original production fallback used a known string.

**P1 — CSRF:** POST form endpoints have no CSRF protection.

**P1 — Cookie security:** Secure cookie behavior was not enforced by default.

**P1 — Audit immutability:** audit logs have no tamper-evidence mechanism.

**P2 — Authentication hardening:** no login rate limiting, lockout, MFA, password policy or session revocation model.

### Phase-0 changes made

- First admin creation now requires `ERP_BOOTSTRAP_ADMIN_PASSWORD` (minimum 12 characters).
- Production requires `ERP_SECRET_KEY` with sufficient entropy/length.
- Development can use an ephemeral secret.
- Cookie `Secure` can be explicitly enabled with `ERP_COOKIE_SECURE=true`.

## 6. API audit

The current project is primarily server-rendered HTML routes rather than a production API platform.

### Findings

- Validation exists but is inconsistent.
- Business operations often use form parameters directly.
- HTTP errors are generally represented with FastAPI exceptions.
- There is no API versioning.
- There is no OpenAPI-oriented DTO/schema layer for business modules.
- Idempotency was not systematically implemented.
- No consistent API envelope exists.
- No rate limiting.
- No request correlation IDs.
- No formal API authentication/authorization matrix.

## 7. Frontend audit

### Strengths

- Existing screens cover a substantial subset of the current backend.
- Jinja templates are connected to real database queries.
- Permission checks are reflected in several UI screens.

### Weaknesses

- HTML templates are tightly coupled to router internals.
- No SPA/component architecture.
- No centralized frontend state.
- No global API client.
- No standardized loading/error/success component system.
- No broad pagination strategy.
- No global search.
- No systematic CSRF protection.
- No evidence of automated end-to-end tests.

## 8. Testing audit

Original repository:

- No proper automated test suite was found.

Phase-0 hardening added:

- Balanced journal test.
- Unbalanced journal rejection test.
- Closed-period rejection test.
- Duplicate source/idempotency test.
- Posted-journal immutability test.

Result:

**5/5 accounting core tests passed.**

Python compilation also passed for the application source.

Warnings remain around `datetime.utcnow()` deprecation and should be addressed in the production-hardening phase.

## 9. Critical bugs / risks

### P0

1. Financial Float usage.
2. No posted journal immutability.
3. Duplicate financial posting protection was incomplete.
4. Unsafe schema evolution through `create_all()`.
5. Duplicate period-close implementation allowed a close path without the required closing journal.

### P1

1. Known default admin password.
2. Production JWT secret fallback.
3. SQLite default for a production-oriented ERP.
4. No CSRF protection.
5. Incomplete database business constraints.
6. Incomplete tax architecture.
7. Inventory valuation is not a true historical FIFO/weighted-average engine.
8. AR/AP are not complete subledgers.
9. Bank reconciliation does not yet reconcile individual bank transactions.
10. No comprehensive automated regression suite.
11. No API idempotency strategy across all financial endpoints.

### P2

1. Router/service separation.
2. API modernization.
3. Pagination/filtering standardization.
4. Better audit reporting.
5. Better report architecture.
6. Timezone modernization.
7. Performance optimization for stock and report queries.

### P3

1. AI.
2. Advanced BI.
3. Industry-specific extensions.
4. Advanced integrations.

## 10. Recommended implementation roadmap

### Immediate stabilization

1. Complete migration framework.
2. Migrate existing financial columns from Float to NUMERIC.
3. Add journal/status/source constraints through migration.
4. Complete accounting invariant test suite.
5. Add transaction/idempotency coverage to every financial endpoint.
6. Remove duplicate accounting implementations.

### Phase 1 — Database Integrity

- Alembic migrations.
- PostgreSQL production baseline.
- Foreign keys.
- Unique/check constraints.
- Composite indexes.
- Company/branch dimensions.
- Stronger document relationships.

### Phase 2 — Accounting Core

- Formal posting engine.
- Period engine.
- Journal lifecycle.
- Reversal/adjustment.
- Subledgers.
- Currency engine.
- Trial balance reconciliation.
- Financial statement engine.

### Phases 3–9

- Sales + AR.
- Purchasing + AP.
- Inventory.
- Banking.
- Tax.
- Fixed assets.
- Budgeting/cost centers.

### Phases 10–16

- Projects.
- Construction.
- Equipment/fleet.
- Contracts/documents.
- HR/payroll.
- Manufacturing.
- Distribution.

### Phases 17–23

- BI.
- Workflow/notifications.
- Import/export/e-invoicing.
- AI.
- Security hardening.
- Full automated testing.
- Production hardening.

## 11. Definition of current milestone

Phase 0 is complete as an **audit + initial P0 hardening milestone**.

The repository is not yet production-ready.

The next blocking milestone is:

**Database migration + complete Accounting Core stabilization.**

No large industry module should be built before that foundation is complete.
