#!/usr/bin/env python3
"""Phase 4 governance build/update entry point. Idempotent and non-destructive."""
from pathlib import Path
import shutil
ROOT = Path(__file__).resolve().parent
for p in ROOT.rglob("__pycache__"):
    if p.is_dir(): shutil.rmtree(p, ignore_errors=True)
for p in ROOT.rglob("*.pyc"): p.unlink(missing_ok=True)
print("Phase 4 governance sources installed; run alembic upgrade head and pytest.")
