#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python scripts/make_local_env.py
python -m alembic upgrade head
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
