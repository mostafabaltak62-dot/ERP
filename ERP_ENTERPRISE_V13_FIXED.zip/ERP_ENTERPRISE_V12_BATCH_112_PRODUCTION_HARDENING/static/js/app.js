(function () {
  const sidebar = document.getElementById('sidebar');
  document.addEventListener('click', function (event) {
    if (!sidebar || window.innerWidth > 900) return;
    if (sidebar.classList.contains('open') && !sidebar.contains(event.target) && !event.target.closest('.mobile-menu')) {
      sidebar.classList.remove('open');
    }
  });
})();
