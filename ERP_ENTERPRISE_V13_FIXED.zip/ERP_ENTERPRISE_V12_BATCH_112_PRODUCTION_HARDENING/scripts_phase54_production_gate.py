"""Phase 5.4 production gate.

Runs deterministic local integrity checks and, when DATABASE_URL points to
PostgreSQL, verifies the production database prerequisites. It deliberately
refuses to claim a PostgreSQL RLS/concurrency pass when PostgreSQL is absent.
"""
import os, sys
from sqlalchemy import create_engine, text

url=os.getenv("DATABASE_URL", "")
if not url:
    print("DATABASE_URL is not configured; PostgreSQL gate NOT RUN.")
    sys.exit(2)
if not url.startswith(("postgresql://", "postgresql+psycopg://", "postgresql+psycopg2://")):
    print("DATABASE_URL is not PostgreSQL; production RLS/concurrency gate NOT RUN.")
    sys.exit(2)
engine=create_engine(url, pool_pre_ping=True)
with engine.connect() as c:
    version=c.execute(text("select version()" )).scalar_one()
    print(version)
    # Confirm RLS is enabled on representative financial tables.
    rows=c.execute(text("""
        select relname, relrowsecurity, relforcerowsecurity
        from pg_class
        where relname in ('sales_orders','purchase_invoices','inventory_cost_layers','finance_vouchers')
        order by relname
    """)).all()
    failures=[r for r in rows if not r[1] or not r[2]]
    if failures:
        raise SystemExit(f"RLS gate failed: {failures}")
    print("PostgreSQL RLS representative-table gate: PASS")
print("PostgreSQL production gate prerequisites: PASS")
