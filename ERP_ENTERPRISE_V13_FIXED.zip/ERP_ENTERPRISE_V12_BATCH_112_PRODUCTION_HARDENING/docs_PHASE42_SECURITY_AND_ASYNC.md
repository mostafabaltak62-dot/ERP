# Phase 4.2 — Production Security & Tenant-Safe Async Hardening

## Implemented
- PostgreSQL native RLS remains the database isolation boundary for company-scoped tables.
- Application-level tenant filtering remains enabled as defense in depth.
- Cookie-authenticated unsafe browser requests now reject cross-origin `Origin`/`Referer` values.
- Production access-token cookies are `Secure`, `HttpOnly`, `SameSite=Lax`, and path-scoped.
- Login attempts are throttled per IP + username with a bounded local fallback; production deployments should additionally enforce an edge/WAF rate limit and can replace the local store with Redis.
- CORS is deny-by-default and requires explicit `ERP_ALLOWED_ORIGINS` values.
- Production responses receive CSP and HSTS headers in addition to existing security headers.
- Celery jobs require an explicit `company_id` and publish tenant context before touching the database.
- Tenant context is cleared after every background job.

## Production requirements
1. PostgreSQL must be used for production; SQLite is development/demo only.
2. The PostgreSQL role used by the application must not have `BYPASSRLS`.
3. Run the Phase 4.1 RLS migration before accepting tenant traffic.
4. Configure `ERP_ALLOWED_ORIGINS` explicitly; never use wildcard origins with credentials.
5. Run Redis + Celery worker/beat as separate production services.
6. Add an external distributed rate limit at the reverse proxy/WAF for login and other sensitive endpoints.
7. Run cross-company, cross-branch, direct-SQL, and concurrent-request security tests against a real PostgreSQL instance before certification.
