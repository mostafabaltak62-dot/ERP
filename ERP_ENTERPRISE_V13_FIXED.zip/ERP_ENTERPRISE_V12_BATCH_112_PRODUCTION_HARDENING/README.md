# ERP Enterprise V13

نظام ERP لشركات المقاولات: محاسبة، مخزون، مبيعات، مشتريات، موارد بشرية ومرتبات، ومقاولات (BOQ/WBS/EVM/مستندات).
Stack: FastAPI + SQLAlchemy + Alembic + PostgreSQL (SQLite للتطوير المحلي فقط) + Celery/Redis + قوالب Jinja.

## تشغيل محلي سريع
**Windows:** شغّل `RUN_LOCAL_WINDOWS.bat` — **Linux/macOS:** `./run_local.sh`

السكربت ينشئ بيئة افتراضية، يثبّت المتطلبات، يولّد `.env` بمفاتيح عشوائية (SQLite)، يطبّق الترحيلات،
ويطبع اسم المستخدم وكلمة مرور الأدمن مرة واحدة. افتح http://127.0.0.1:8000.
الملف `.env` لا يُستبدل إن كان موجودًا.

## الإنتاج (Docker + PostgreSQL)
1. `cp .env.example .env` ثم استبدل كل قيم `CHANGE_ME` (أي قيمة placeholder يرفضها التطبيق عند الإقلاع).
2. ولّد المفاتيح: `python -c "import secrets; print(secrets.token_urlsafe(48))"`.
3. اضبط `ERP_BOOTSTRAP_ADMIN_PASSWORD` (12 حرفًا على الأقل) لإنشاء أول أدمن.
4. `docker compose -f docker-compose.production.yml up -d --build`
5. خلف Nginx فعّل `ERP_TRUST_PROXY_HEADERS=true` ليرى الـ rate limit عناوين العملاء الحقيقية. عدد العمال: `WEB_CONCURRENCY` (الافتراضي 2).

## الاختبارات والجودة
```
pip install -r requirements-dev.txt
ruff check app tests scripts
pytest -q
python scripts/quality_gate.py
```

## أمور مهمة
- لا يوجد أدمن افتراضي ولا كلمة مرور افتراضية؛ الأدمن يُنشأ فقط من `ERP_BOOTSTRAP_ADMIN_*`.
- الإنتاج يتطلب PostgreSQL و Redis، ولا يعمل بمفاتيح placeholder.
- سجل التقارير التاريخية للمراحل في `docs/archive/`، والتغييرات في `CHANGELOG.md`.
